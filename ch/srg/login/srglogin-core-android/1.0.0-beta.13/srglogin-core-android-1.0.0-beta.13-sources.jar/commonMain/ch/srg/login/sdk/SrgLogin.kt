package ch.srg.login.sdk

import ch.srg.login.sdk.auth.AuthenticationManager
import ch.srg.login.sdk.auth.BackChannelLogoutListener
import ch.srg.login.sdk.auth.LoginMethod
import ch.srg.login.sdk.auth.LoginState
import ch.srg.login.sdk.auth.LogoutResult
import ch.srg.login.sdk.auth.LogoutType
import ch.srg.login.sdk.auth.PlatformAuthContext
import ch.srg.login.sdk.auth.TokenManager
import ch.srg.login.sdk.auth.TokenState
import ch.srg.login.sdk.auth.UserInfoService
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.lifecycle.AppLifecycleObserver
import ch.srg.login.sdk.logging.ErrorHandlerRegistry
import ch.srg.login.sdk.model.AccessToken
import ch.srg.login.sdk.model.TokenSet
import ch.srg.login.sdk.model.UserInfo
import ch.srg.login.sdk.result.SdkResult
import kotlinx.coroutines.flow.Flow

/**
 * The main entry point for the SRG Login SDK.
 * It delegates authentication tasks to a configured [AuthenticationManager].
 *
 * @property config The configuration for the SDK.
 * @property authManager The authentication manager responsible for the login flow.
 * @property tokenManager The token manager for token lifecycle management and automatic refresh operations.
 * @property userInfoService The service exposing the End-User profile information ([UserInfo])
 *   at any time during the session via [getUserInfo].
 * @property lifecycleObserver Platform-specific lifecycle observer for automatic resource cleanup.
 */
@Suppress("TooManyFunctions")
class SrgLogin internal constructor(
    private val config: SrgLoginConfig,
    private val authManager: AuthenticationManager,
    private val tokenManager: TokenManager,
    private val userInfoService: UserInfoService,
    private val lifecycleObserver: AppLifecycleObserver,
) {
    /**
     * Initiates a login flow with the specified credentials and authentication context.
     *
     * @param loginMethod The login flow to use (e.g., Web, Device, UserPassword).
     * @param authContext The platform-specific authentication context.
     * @param additionalScopes Additional OAuth scopes to request (e.g., "offline_access", "profile", "email").
     *                         The "openid" scope is automatically included for OIDC compliance.
     *                         Default: empty list (only "openid" will be requested).
     *
     *                         **Common scopes**:
     *                         - `"offline_access"`: Request a refresh token for token renewal
     *                         - `"profile"`: Access user's profile information (name, picture, etc.)
     *                         - `"email"`: Access user's email address
     *
     *                         **Example**:
     *                         ```kotlin
     *                         // Login with refresh token support
     *                         srgLogin.login(
     *                             loginMethod = LoginMethod.Web,
     *                             authContext = authContext,
     *                             additionalScopes = listOf("offline_access", "profile", "email")
     *                         )
     *
     *                         // Minimal login (only authentication)
     *                         srgLogin.login(
     *                             loginMethod = LoginMethod.Web,
     *                             authContext = authContext
     *                         ) // Only "openid" scope will be requested
     *                         ```
     *
     * @param additionalParameters Additional OAuth/OIDC parameters to customize the authentication flow.
     *                             All values are automatically URL-encoded.
     *                             Default: empty map (no additional parameters).
     *
     *                             **Common OAuth 2.0/OIDC parameters**
     *                             (OIDC Core 1.0, Section 3.1.2.1 - https://openid.net/specs/openid-connect-core-1_0.html#AuthRequest):
     *                             - `"ui_locales"`: Preferred user interface language (e.g., "fr", "de", "en")
     *                             - `"prompt"`: Controls re-authentication and consent prompts
     *                               - `"none"`: No UI prompts (silent authentication)
     *                               - `"login"`: Force user to re-authenticate
     *                               - `"consent"`: Force consent screen even if already consented
     *                               - `"select_account"`: Prompt user to select account
     *                             - `"display"`: Display mode for authentication UI
     *                               - `"page"`: Full page (default)
     *                               - `"popup"`: Popup window
     *                               - `"touch"`: Touch-optimized interface
     *                               - `"wap"`: Feature phone display
     *                             - `"max_age"`: Maximum authentication age in seconds (forces re-auth if exceeded)
     *                             - `"login_hint"`: Pre-fills username/email in login form
     *                             - `"acr_values"`: Requested Authentication Context Class Reference
     *
     *                             **Examples**:
     *                             ```kotlin
     *                             // Force French UI
     *                             srgLogin.login(
     *                                 loginMethod = LoginMethod.Web,
     *                                 authContext = authContext,
     *                                 additionalParameters = mapOf("ui_locales" to "fr")
     *                             )
     *
     *                             // Force re-authentication
     *                             srgLogin.login(
     *                                 loginMethod = LoginMethod.Web,
     *                                 authContext = authContext,
     *                                 additionalParameters = mapOf("prompt" to "login")
     *                             )
     *
     *                             // Pre-fill username and force consent
     *                             srgLogin.login(
     *                                 loginMethod = LoginMethod.Web,
     *                                 authContext = authContext,
     *                                 additionalParameters = mapOf(
     *                                     "login_hint" to "user@example.com",
     *                                     "prompt" to "consent"
     *                                 )
     *                             )
     *
     *                             // Multi-language support with max authentication age
     *                             srgLogin.login(
     *                                 loginMethod = LoginMethod.Web,
     *                                 authContext = authContext,
     *                                 additionalScopes = listOf("offline_access", "profile"),
     *                                 additionalParameters = mapOf(
     *                                     "ui_locales" to "fr de en",  // Preferred languages in order
     *                                     "max_age" to "3600"          // Force re-auth if older than 1 hour
     *                                 )
     *                             )
     *                             ```
     *
     * @return A [Flow] that emits [LoginState] updates throughout the login process.
     */
    fun login(
        loginMethod: LoginMethod,
        authContext: PlatformAuthContext,
        additionalScopes: List<String> = emptyList(),
        additionalParameters: Map<String, String> = emptyMap(),
    ): Flow<LoginState> = authManager.login(loginMethod, authContext, additionalScopes, additionalParameters)

    /**
     * Logs the user out using the specified logout type.
     *
     * Defaults to [LogoutType.LocalOnly] which clears stored tokens and session data locally.
     *
     * For [LogoutType.FrontChannel]: The platform auth context is embedded in the type itself,
     * e.g. `logout(LogoutType.FrontChannel(authContext, postLogoutRedirectUri))`.
     *
     * For [LogoutType.BackChannel]: Validates the logout token JWT and clears the local session.
     *
     * @param logoutType The type of logout to perform (defaults to [LogoutType.LocalOnly])
     * @return [LogoutResult] with details about what was cleared/terminated
     */
    suspend fun logout(logoutType: LogoutType = LogoutType.LocalOnly): LogoutResult = authManager.logout(logoutType)

    /**
     * Registers a listener for back-channel logout notifications.
     *
     * Back-channel logout allows the authorization server to notify the SDK
     * when a user's session should be terminated (e.g., user logged out from
     * another device, admin revoked access, etc.).
     *
     * @param listener The listener to receive back-channel logout events
     * @return [SdkResult.Success] if registered, [SdkResult.Failure] if not supported on this platform
     */
    fun registerBackChannelLogoutListener(listener: BackChannelLogoutListener): SdkResult<Unit> =
        authManager.registerBackChannelLogoutListener(listener)

    /**
     * Unregisters a back-channel logout listener.
     *
     * @param listener The listener to remove
     * @return [SdkResult.Success] if unregistered, [SdkResult.Failure] if not supported on this platform
     */
    fun unregisterBackChannelLogoutListener(listener: BackChannelLogoutListener): SdkResult<Unit> =
        authManager.unregisterBackChannelLogoutListener(listener)

    /**
     * Opens another SSO client URL in platform-specific browser, leveraging the current
     * authenticated session cookies.
     *
     * Perfect for displaying profile pages, settings, admin panels, or any other SSO client
     * that shares the same authentication system.
     *
     * Uses fire-and-forget approach - returns success immediately after launching browser.
     *
     * @param ssoClientUrl URL of the SSO client to display
     * @param authContext The platform-specific authentication context
     * @return A [SdkResult] indicating success or failure of launching the SSO client
     */
    suspend fun openSsoClient(
        ssoClientUrl: String,
        authContext: PlatformAuthContext,
    ): SdkResult<Unit> = authManager.openSsoClient(ssoClientUrl, authContext)

    /**
     * Returns a valid access token, refreshing internally if needed.
     *
     * This is the **primary token access method**. It replaces the removed `refreshToken()`.
     *
     * - Token valid → returns immediately (no network)
     * - Token expired → refreshes automatically, returns new token
     * - `forceRefresh = true` → always refreshes (use after 401 from resource server)
     *
     * **Usage Example**:
     * ```kotlin
     * // Normal access:
     * val result = srgLogin.getAccessToken()
     *
     * // After a 401 (force refresh):
     * val freshResult = srgLogin.getAccessToken(forceRefresh = true)
     * ```
     *
     * @param forceRefresh Force a network refresh even if the current token is valid.
     * @return SdkResult.Success with AccessToken, or SdkResult.Failure with error
     */
    suspend fun getAccessToken(forceRefresh: Boolean = false): SdkResult<AccessToken> = tokenManager.getAccessToken(forceRefresh)

    /**
     * Returns the End-User profile information ([UserInfo]) — OIDC Core 1.0 §5.1
     * Standard Claims plus the `phone` scope.
     *
     * Two paths:
     * - `forceRefresh = false` (default) → returns the cached snapshot persisted
     *   at the last successful login or token refresh. **Fast** (no network).
     *   May be slightly stale if the IdP-side profile changed since the last
     *   token issuance (email update, avatar change…).
     * - `forceRefresh = true` → calls the OIDC `/userinfo` endpoint (§5.3),
     *   validates the `sub` matches the access token's `sub` (§5.3.2 mismatch
     *   protection), replaces the cache, and returns the fresh snapshot.
     *
     * **Token handling** (consistent with [getAccessToken]): if the access token
     * is `Expired`, the SDK transparently refreshes before the `/userinfo` call.
     * **No retry-on-401** is performed internally — if `/userinfo` returns 401,
     * the failure surfaces here; the caller decides whether to compose
     * `getAccessToken(forceRefresh = true)` followed by a fresh
     * `getUserInfo(forceRefresh = true)`.
     *
     * **Concurrency**: concurrent `getUserInfo(forceRefresh = true)` calls are
     * serialised internally so they do not overlap or race into a
     * last-write-wins on the cache. Calls are serialised, **not
     * de-duplicated** — each concurrent caller still triggers its own
     * `/userinfo` round-trip, just one after the other. Cache reads
     * (`forceRefresh = false`) run unsynchronised.
     *
     * **Cancellation**: `CancellationException` propagates as-is at every level.
     *
     * **Errors returned in [SdkResult.Failure]**:
     * - [SrgLoginError.NotAuthenticated] — only with `forceRefresh = true`
     *   and no tokens to read or refresh from (genuinely no session). The
     *   user must log in.
     * - [SrgLoginError.InvalidDataError] with a "No cached UserInfo" reason —
     *   `forceRefresh = false` (default) and the cache is empty. **This does
     *   not mean the user is unauthenticated**: it also occurs for a valid
     *   session where the `openid` scope was not granted, or before the first
     *   login/refresh. Do **not** redirect to login on this error alone — call
     *   `getUserInfo(forceRefresh = true)` or check session state instead.
     * - [SrgLoginError.InvalidConfiguration] — the IdP discovery document does
     *   not advertise a `userinfo_endpoint`, or the endpoint is not HTTPS.
     * - [SrgLoginError.HttpError] — HTTP 4xx/5xx from `/userinfo`. A `401`
     *   typically means the access token was rejected by the IdP (server-side
     *   revocation, scope issue, clock skew); see retry note above.
     * - [SrgLoginError.SerializationError] — `/userinfo` returned malformed JSON
     *   or violated the OIDC §5.3.2 contract (missing/blank `sub`).
     * - [SrgLoginError.InvalidDataError] with
     *   `reason == "OIDC §5.3.2: userinfo sub mismatch"` — the `sub` returned
     *   does **not** match the access token's `sub`. Security-grade contract
     *   violation; the cache is **not** updated. The reason string is stable
     *   across versions (partial public contract — pattern-matching on it is
     *   supported).
     * - [SrgLoginError.NetworkError] — transport failure (timeout, DNS, no
     *   connectivity).
     *
     * **Usage Example**:
     * ```kotlin
     * // Fast path — cached snapshot (typical for UI rendering):
     * when (val result = srgLogin.getUserInfo()) {
     *     is SdkResult.Success -> displayProfile(result.data)
     *     is SdkResult.Failure -> handleError(result.error)
     * }
     *
     * // Forced refresh — when the user updates their profile and wants the
     * // change reflected immediately, or after a 401 from another resource:
     * val fresh = srgLogin.getUserInfo(forceRefresh = true)
     * ```
     *
     * @param forceRefresh `true` to fetch from `/userinfo` and replace the
     *   cache. `false` (default) to return the cached value.
     * @return [SdkResult.Success] wrapping the [UserInfo], or [SdkResult.Failure]
     *   with one of the errors above.
     */
    suspend fun getUserInfo(forceRefresh: Boolean = false): SdkResult<UserInfo> = userInfoService.getUserInfo(forceRefresh)

    /**
     * Checks whether a non-expired access token is currently in local storage.
     *
     * Returns `true` if and only if:
     * - A non-empty access token exists in storage, AND
     * - The access token's `exp` claim has not yet passed (local clock), AND
     * - The last refresh did not terminate the session with `invalid_grant`
     *
     * The mere presence of a refresh token does NOT count as authenticated.
     * Refresh tokens may be revoked server-side at any time (user logout from
     * another device, admin revocation, password change, refresh-token-rotation
     * reuse detection) without the SDK being able to detect it locally — the
     * revocation only surfaces when [getAccessToken] next contacts the IdP.
     * Treating a refresh token as authenticated would let callers flash
     * authenticated UI (profile, transactional data, etc.) before the next
     * [getAccessToken] surfaces the revocation.
     *
     * Callers who specifically want to know whether a silent refresh is
     * possible (without committing to "authenticated") should use
     * [hasRefreshToken] instead.
     *
     * **Scenarios**:
     * - ✅ Valid access token (with or without refresh token) → `true`
     * - ❌ Expired access token + refresh token → `false` (call [getAccessToken]
     *   first to attempt a refresh, then re-check or react to the result)
     * - ❌ Expired/missing access token + no refresh token → `false`
     * - ❌ Last refresh failed with `invalid_grant` → `false` (tokens cleared)
     *
     * **Locality**: this is a local check only — `exp` is compared to the local
     * clock, no network call is made. Server-side validity (revocation,
     * signature, audience) is asserted by [getAccessToken] and, ultimately, by
     * the Resource Server when the token is presented.
     *
     * **Usage Example**:
     * ```kotlin
     * if (srgLogin.isAuthenticated()) {
     *     navigateToMainScreen()
     * } else {
     *     // Access token is missing or expired. Try a silent refresh once
     *     // before sending the user back to login:
     *     when (val result = srgLogin.getAccessToken()) {
     *         is SdkResult.Success -> navigateToMainScreen()
     *         is SdkResult.Failure -> navigateToLoginScreen()
     *     }
     * }
     * ```
     *
     * @return `true` iff a non-expired access token is in storage and the
     *   session has not been terminated by `invalid_grant`, `false` otherwise.
     */
    suspend fun isAuthenticated(): Boolean = tokenManager.isAuthenticated()

    /**
     * Checks if a refresh token is currently stored.
     *
     * A refresh token is required to silently renew the access token without
     * prompting the user to log in again. If no refresh token is available, the
     * next token operation after expiry will fail and the user must re-authenticate.
     *
     * **Note**: A stored refresh token may still be expired or revoked server-side.
     * The actual validity is only confirmed when [getAccessToken] is called and
     * the server responds — at that point the SDK clears the invalid token and
     * returns [ch.srg.login.sdk.result.SrgLoginError.InvalidGrant].
     *
     * **Usage Example**:
     * ```kotlin
     * if (srgLogin.hasRefreshToken()) {
     *     // Silent renewal is possible — show "session active" UI
     * } else {
     *     // No refresh token — user will need to log in again after token expiry
     * }
     * ```
     *
     * @return true if a refresh token exists in storage, false otherwise
     */
    suspend fun hasRefreshToken(): Boolean = tokenManager.hasRefreshToken()

    /**
     * Returns the raw refresh token string from secure storage, or `null` if none exists.
     *
     * **Development and testing use only.** This method exposes the raw refresh token
     * for debugging, diagnostics, and integration testing. Do **not** use it to build
     * a manual refresh flow — use [getAccessToken] with `forceRefresh = true` instead.
     *
     * **Security**: Never log, persist outside secure storage, or transmit the refresh
     * token off-device. It is the most sensitive credential in the OAuth 2.0 session.
     *
     * **Example**:
     * ```kotlin
     * // In a debug screen or integration test:
     * val refreshToken = srgLogin.getRefreshToken()
     * println("Refresh token present: ${refreshToken != null}")
     * // ⚠️ Do NOT log the actual value in production builds
     * ```
     *
     * @return The raw refresh token string, or `null` if no tokens are stored
     * @see hasRefreshToken For a safe boolean check without exposing the raw value
     * @see getAccessToken For obtaining a valid access token (the recommended API)
     */
    suspend fun getRefreshToken(): String? = tokenManager.getRefreshToken()

    /**
     * Observes the current token state as a reactive StateFlow.
     *
     * The StateFlow emits token state changes automatically on:
     * - Login (new tokens available)
     * - Logout (tokens cleared)
     * - Token refresh (tokens updated)
     *
     * **Initial Value**: [TokenState.Uninitialized]. The SDK replaces it with a real
     * state within milliseconds. Observers must handle `Uninitialized` explicitly —
     * typically by showing a splash screen and **not** navigating to login, otherwise
     * the app will briefly flash the login screen on every cold start even when the
     * user is already authenticated.
     *
     * **Usage Example**:
     * ```kotlin
     * // In ViewModel
     * val tokenState = srgLogin.observeTokenState()
     *     .stateIn(viewModelScope, SharingStarted.Eagerly, TokenState.Uninitialized)
     *
     * // In Composable
     * val state by tokenState.collectAsState()
     * when (state) {
     *     is TokenState.Uninitialized -> ShowSplashScreen()  // wait, do not navigate
     *     is TokenState.Valid -> ShowMainContent()
     *     is TokenState.ExpiringSoon -> ShowExpiryWarning()
     *     is TokenState.Expired -> ShowReauthenticateDialog()
     *     is TokenState.NoTokens -> ShowLoginScreen()
     *     // Handle other states (Refreshing, Refreshed, RefreshFailed)
     * }
     * ```
     *
     * @return StateFlow that emits current TokenState
     */
    fun observeTokenState(): Flow<TokenState> = tokenManager.observeTokenState()

    /**
     * Checks if error tracking is currently enabled.
     *
     * @return true if an error handler is configured, false otherwise
     *
     * @example
     * ```kotlin
     * if (srgLogin.isErrorTrackingEnabled()) {
     *     println("Errors are being reported to error tracking service")
     * } else {
     *     println("Error tracking is disabled")
     * }
     * ```
     */
    fun isErrorTrackingEnabled(): Boolean = ErrorHandlerRegistry.isEnabled()
}
