package ch.srg.login.sdk.data.api

import ch.srg.login.sdk.auth.OAuthErrorMapper
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.internal.SecurityUtils
import ch.srg.login.sdk.logging.ErrorHandler
import ch.srg.login.sdk.logging.ErrorHandlerRegistry
import ch.srg.login.sdk.logging.LogCategory
import ch.srg.login.sdk.logging.SdkLogger
import ch.srg.login.sdk.model.DeviceAuthorizationResponse
import ch.srg.login.sdk.model.JwkSet
import ch.srg.login.sdk.model.OAuthErrorResponse
import ch.srg.login.sdk.model.OpenIdConfig
import ch.srg.login.sdk.model.TokenResponseDto
import ch.srg.login.sdk.model.UserInfoResponseDto
import ch.srg.login.sdk.result.SdkResult
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.plugins.ClientRequestException
import io.ktor.client.plugins.ServerResponseException
import io.ktor.client.request.forms.FormDataContent
import io.ktor.client.request.get
import io.ktor.client.request.headers
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsText
import io.ktor.http.Parameters
import kotlinx.coroutines.CancellationException
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject

/**
 * Implementation of [SrgAuthApiService].
 *
 * @property httpClient The pre-configured Ktor HttpClient.
 */
internal class SrgAuthApiServiceImpl(
    private val httpClient: HttpClient,
) : SrgAuthApiService {
    override suspend fun getOpenIdConfiguration(baseUrl: String): OpenIdConfig {
        try {
            validateUrl(baseUrl)
            val url = "$baseUrl/.well-known/openid-configuration"
            return httpClient.get(url).body()
        } catch (e: Exception) {
            // Report to error tracking
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "get_openid_configuration",
                        "endpoint" to "well_known_openid_configuration",
                        "base_url" to baseUrl,
                        "critical" to true,
                        "impact" to "sdk_initialization_failure",
                        "exception_type" to e::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.FATAL,
            )

            throw e
        }
    }

    override suspend fun exchangeCodeForToken(
        tokenEndpoint: String,
        code: String,
        redirectUri: String,
        clientId: String,
        codeVerifier: String,
    ): TokenResponseDto {
        try {
            val response =
                httpClient.post(tokenEndpoint) {
                    headers {
                        append("Content-Type", "application/x-www-form-urlencoded")
                        append("Accept", "application/json")
                    }
                    setBody(
                        FormDataContent(
                            Parameters.build {
                                append("grant_type", "authorization_code")
                                append("code", code)
                                append("redirect_uri", redirectUri)
                                append("client_id", clientId)
                                append("code_verifier", codeVerifier)
                            },
                        ),
                    )
                }
            return response.body()
        } catch (e: Exception) {
            val sanitizedMessage = SecurityUtils.sanitizeErrorMessage(e.message ?: "Unknown error")
            SdkLogger.e(LogCategory.NETWORK, throwable = e) { "Failed to exchange code for token: $sanitizedMessage" }

            // Report to error tracking
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "exchange_code_for_token",
                        "endpoint" to "token_endpoint",
                        "grant_type" to "authorization_code",
                        "stage" to "post_authentication",
                        "exception_type" to e::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.ERROR,
            )

            throw e
        }
    }

    override suspend fun getJwks(jwksUri: String): JwkSet {
        validateJwksUri(jwksUri)
        return httpClient.get(jwksUri).body()
    }

    override suspend fun exchangePasswordForToken(
        tokenEndpoint: String,
        username: String,
        password: String,
        clientId: String,
        clientSecret: String?,
        scope: String,
        additionalParameters: Map<String, String>,
    ): TokenResponseDto {
        try {
            val response =
                httpClient.post(tokenEndpoint) {
                    headers {
                        append("Content-Type", "application/x-www-form-urlencoded")
                        append("Accept", "application/json")
                    }
                    setBody(
                        FormDataContent(
                            Parameters.build {
                                append("grant_type", "password")
                                append("username", username)
                                append("password", password)
                                append("client_id", clientId)
                                if (!clientSecret.isNullOrBlank()) {
                                    append("client_secret", clientSecret)
                                }
                                append("scope", scope)
                                additionalParameters.forEach { (key, value) ->
                                    append(key, value)
                                }
                            },
                        ),
                    )
                }
            return response.body()
        } catch (e: ClientRequestException) {
            SdkLogger.e(LogCategory.NETWORK, throwable = e) { "ROPC token exchange failed" }
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "exchange_password_for_token",
                        "endpoint" to "token_endpoint",
                        "grant_type" to "password",
                        "exception_type" to e::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.ERROR,
            )
            throw e
        } catch (e: Exception) {
            val sanitizedMessage = SecurityUtils.sanitizeErrorMessage(e.message ?: "Unknown error")
            SdkLogger.e(LogCategory.NETWORK, throwable = e) { "ROPC token exchange failed: $sanitizedMessage" }
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "exchange_password_for_token",
                        "endpoint" to "token_endpoint",
                        "grant_type" to "password",
                        "exception_type" to e::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.ERROR,
            )
            throw e
        }
    }

    override suspend fun refreshAccessToken(
        tokenEndpoint: String,
        refreshToken: String,
        clientId: String,
    ): TokenResponseDto {
        try {
            val response =
                httpClient.post(tokenEndpoint) {
                    headers {
                        append("Content-Type", "application/x-www-form-urlencoded")
                        append("Accept", "application/json")
                    }
                    setBody(
                        FormDataContent(
                            Parameters.build {
                                append("grant_type", "refresh_token")
                                append("refresh_token", refreshToken)
                                append("client_id", clientId)
                            },
                        ),
                    )
                }
            return response.body()
        } catch (e: Exception) {
            val sanitizedMessage = SecurityUtils.sanitizeErrorMessage(e.message ?: "Unknown error")
            SdkLogger.e(LogCategory.NETWORK, throwable = e) { "Failed to refresh access token: $sanitizedMessage" }

            // Report to error tracking
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "refresh_access_token",
                        "endpoint" to "token_endpoint",
                        "grant_type" to "refresh_token",
                        "critical" to true,
                        "exception_type" to e::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.ERROR,
            )

            throw e
        }
    }

    override suspend fun requestDeviceAuthorization(
        deviceAuthorizationEndpoint: String,
        clientId: String,
        scope: String,
        additionalParameters: Map<String, String>,
    ): SdkResult<DeviceAuthorizationResponse> =
        try {
            val response =
                httpClient.post(deviceAuthorizationEndpoint) {
                    headers {
                        append("Content-Type", "application/x-www-form-urlencoded")
                        append("Accept", "application/json")
                    }
                    setBody(
                        FormDataContent(
                            Parameters.build {
                                append("client_id", clientId)
                                append("scope", scope)
                                val reservedParams = setOf("client_id", "scope", "grant_type")
                                additionalParameters
                                    .filterKeys { it.lowercase() !in reservedParams }
                                    .forEach { (key, value) ->
                                        if (value.isNotEmpty()) {
                                            append(key, value)
                                        }
                                    }
                            },
                        ),
                    )
                }
            SdkResult.Success(response.body())
        } catch (e: ClientRequestException) {
            val error = OAuthErrorMapper.mapClientRequestException(e)
            SdkLogger.e(LogCategory.NETWORK, throwable = e) { "Device authorization request failed" }
            captureDeviceFlowException(e, "request_device_authorization", "device_authorization_endpoint")
            SdkResult.Failure(error)
        } catch (e: ServerResponseException) {
            val error = OAuthErrorMapper.mapServerResponseException(e)
            SdkLogger.e(LogCategory.NETWORK, throwable = e) { "Device authorization server error" }
            captureDeviceFlowException(e, "request_device_authorization", "device_authorization_endpoint")
            SdkResult.Failure(error)
        } catch (e: Exception) {
            val sanitizedMessage = SecurityUtils.sanitizeErrorMessage(e.message ?: "Unknown error")
            SdkLogger.e(LogCategory.NETWORK, throwable = e) { "Device authorization failed: $sanitizedMessage" }
            captureDeviceFlowException(e, "request_device_authorization", "device_authorization_endpoint")
            SdkResult.Failure(SrgLoginError.NetworkError(details = sanitizedMessage, cause = e))
        }

    override suspend fun exchangeDeviceCodeForToken(
        tokenEndpoint: String,
        deviceCode: String,
        clientId: String,
    ): SdkResult<TokenResponseDto> =
        try {
            val response =
                httpClient.post(tokenEndpoint) {
                    headers {
                        append("Content-Type", "application/x-www-form-urlencoded")
                        append("Accept", "application/json")
                    }
                    setBody(
                        FormDataContent(
                            Parameters.build {
                                append("grant_type", "urn:ietf:params:oauth:grant-type:device_code")
                                append("device_code", deviceCode)
                                append("client_id", clientId)
                            },
                        ),
                    )
                }
            SdkResult.Success(response.body())
        } catch (e: ClientRequestException) {
            // RFC 8628 §3.5: Parse polling error codes from 4xx responses
            val error = mapDeviceTokenError(e)
            SdkLogger.d(LogCategory.NETWORK) { "Device token exchange: ${error::class.simpleName}" }
            // Only capture terminal errors, not expected polling responses
            if (error !is SrgLoginError.InvalidDataError) {
                captureDeviceFlowException(e, "exchange_device_code", "token_endpoint")
            }
            SdkResult.Failure(error)
        } catch (e: ServerResponseException) {
            val error = OAuthErrorMapper.mapServerResponseException(e)
            SdkLogger.e(LogCategory.NETWORK, throwable = e) { "Device token server error" }
            captureDeviceFlowException(e, "exchange_device_code", "token_endpoint")
            SdkResult.Failure(error)
        } catch (e: Exception) {
            val sanitizedMessage = SecurityUtils.sanitizeErrorMessage(e.message ?: "Unknown error")
            SdkLogger.e(LogCategory.NETWORK, throwable = e) { "Device token exchange failed: $sanitizedMessage" }
            captureDeviceFlowException(e, "exchange_device_code", "token_endpoint")
            SdkResult.Failure(SrgLoginError.NetworkError(details = sanitizedMessage, cause = e))
        }

    @Suppress(
        "TooGenericExceptionCaught", // Catch-all Exception is deliberate — see catch arm comment.
        "LongMethod", // Length is driven by 5 catch arms + documented Sentry policy + KDoc-grade
        //              comments. Splitting would scatter the error mapping decision tree across
        //              private helpers and degrade local readability of the contract.
        "ReturnCount", // 3 returns is the minimum for fail-fast: (1) pre-validation, (2) inner
        //               SerializationException early-return (avoids re-traversing HTTP catches),
        //               (3) implicit return of the try expression.
    )
    override suspend fun getUserInfo(
        endpoint: String,
        accessToken: String,
    ): SdkResult<UserInfoResponseDto> {
        // AUTHORITATIVE blank + HTTPS gate (PR #83 review #5): this is the
        // owning validation for endpoint validity, enforced BEFORE sending the
        // Bearer token. The endpoint comes from a validated OpenIdConfig, but a
        // stale/corrupt cache or misconfigured IDP could otherwise expose the
        // access token in cleartext over HTTP — defense in depth, must stay
        // here. UserInfoServiceImpl additionally fast-fails the common
        // "no userinfo_endpoint advertised" case earlier with a different
        // (discovery-oriented) message; the two messages intentionally differ
        // because they describe two distinct concerns.
        if (endpoint.isBlank() || !endpoint.startsWith("https://")) {
            return SdkResult.Failure(
                SrgLoginError.InvalidConfiguration(
                    "UserInfo endpoint must be a non-blank HTTPS URL",
                ),
            )
        }

        return try {
            val response =
                httpClient.get(endpoint) {
                    headers {
                        append("Authorization", "Bearer $accessToken")
                        append("Accept", "application/json")
                    }
                }
            // Read body once, then parse manually — this lets SerializationError
            // capture the offending payload (sanitized + truncated) for diagnostics.
            // Going via Ktor's content negotiation (body<JsonObject>()) would discard
            // the raw bytes and leave us blind to "what did the IDP actually return?".
            val rawBody = response.bodyAsText()
            val claims =
                try {
                    Json.decodeFromString<JsonObject>(rawBody)
                } catch (e: SerializationException) {
                    // Compute once: the sanitized body excerpt is needed both for the
                    // returned SerializationError (500 chars for the BU) and for the
                    // Sentry context (200 chars — Sentry context entries should stay
                    // small to keep grouping and rate-limit budgets healthy).
                    val sanitizedBody = SecurityUtils.sanitizeErrorMessage(rawBody)
                    SdkLogger.e(LogCategory.NETWORK, throwable = e) {
                        "UserInfo response JSON parse failed (HTTP ${response.status.value})"
                    }
                    captureUserInfoException(
                        e = e,
                        level = ErrorHandler.ErrorLevel.ERROR,
                        httpStatus = response.status.value,
                        responseBodyExcerpt = sanitizedBody.take(SENTRY_BODY_EXCERPT_MAX_CHARS),
                    )
                    return SdkResult.Failure(
                        SrgLoginError.SerializationError(
                            originalMessage = SecurityUtils.sanitizeErrorMessage(e.message ?: "JSON parse error"),
                            responseBody = sanitizedBody.take(SERIALIZATION_ERROR_BODY_MAX_CHARS),
                        ),
                    )
                }
            SdkResult.Success(UserInfoResponseDto(claims = claims))
        } catch (e: CancellationException) {
            // Project convention: coroutine cancellation propagates so collectors
            // upstream see the cancellation rather than a spurious Failure event.
            throw e
        } catch (e: ClientRequestException) {
            // Sentry capture policy for /userinfo (LOGIN-1881):
            // - 401 → WARNING. Intentionally CAPTURED (not skipped): tracking the
            //   volume of 401s on /userinfo is a valuable signal for detecting
            //   server-side mass revocation, IdP key rotation, or clock skew at
            //   scale. WARNING level keeps these visible in Sentry while remaining
            //   filterable. This is a deliberate divergence from the initial
            //   design decision (which proposed skipping 401) — kept because the
            //   observability gain outweighs the noise cost for a low-frequency
            //   endpoint like /userinfo.
            // - Other 4xx → ERROR. Indicates likely IdP misconfig (404 on a stale
            //   discovery cache), permission issues (403 on missing scope), or
            //   SDK bug — always actionable.
            // - 5xx → ERROR (see the ServerResponseException catch below).
            val status = e.response.status.value
            val level =
                if (status == HTTP_UNAUTHORIZED) {
                    ErrorHandler.ErrorLevel.WARNING
                } else {
                    ErrorHandler.ErrorLevel.ERROR
                }
            SdkLogger.e(LogCategory.NETWORK, throwable = e) {
                "UserInfo request failed: HTTP $status"
            }
            captureUserInfoException(e, level, httpStatus = status)
            SdkResult.Failure(
                SrgLoginError.HttpError(
                    code = status,
                    message = e.response.status.description,
                    url =
                        e.response.call.request.url
                            .toString(),
                ),
            )
        } catch (e: ServerResponseException) {
            // HTTP 5xx — IdP server error. Always actionable, captured at ERROR.
            val status = e.response.status.value
            SdkLogger.e(LogCategory.NETWORK, throwable = e) {
                "UserInfo server error: HTTP $status"
            }
            captureUserInfoException(e, ErrorHandler.ErrorLevel.ERROR, httpStatus = status)
            SdkResult.Failure(
                SrgLoginError.HttpError(
                    code = status,
                    message = e.response.status.description,
                    url =
                        e.response.call.request.url
                            .toString(),
                ),
            )
        } catch (e: Exception) {
            // Catch-all — primarily IO failures (timeout, DNS, no connectivity).
            // Captured at WARNING (transient, often not actionable).
            val sanitized = SecurityUtils.sanitizeErrorMessage(e.message ?: "Network error")
            SdkLogger.e(LogCategory.NETWORK, throwable = e) {
                "UserInfo network failure: $sanitized"
            }
            captureUserInfoException(e, ErrorHandler.ErrorLevel.WARNING, httpStatus = null)
            SdkResult.Failure(
                SrgLoginError.NetworkError(details = sanitized, cause = e),
            )
        }
    }

    /**
     * Maps a client request exception from the device token endpoint.
     *
     * RFC 8628 §3.5 defines polling-specific error codes:
     * - `authorization_pending`: User has not yet authorized. Continue polling.
     * - `slow_down`: Polling too fast. Increase interval by 5s.
     * - `access_denied`: User denied authorization. Terminal.
     * - `expired_token`: Device code expired. Terminal.
     *
     * These polling errors are returned as [SrgLoginError.InvalidDataError] with the
     * raw error code as the reason so the polling loop can distinguish them.
     */
    private suspend fun mapDeviceTokenError(e: ClientRequestException): SrgLoginError {
        val oauthError = parseDeviceOAuthError(e) ?: return OAuthErrorMapper.mapClientRequestException(e)
        return mapDeviceOAuthErrorCode(oauthError, e)
    }

    /** Parses the OAuth error body from a device token endpoint response, or null on parse failure. */
    private suspend fun parseDeviceOAuthError(e: ClientRequestException): OAuthErrorResponse? =
        runCatching { e.response.bodyAsText() }
            .getOrNull()
            ?.takeIf { it.trim().startsWith("{") }
            ?.let { bodyText ->
                runCatching { deviceFlowJson.decodeFromString<OAuthErrorResponse>(bodyText) }.getOrNull()
            }

    /** Maps a parsed RFC 8628 error code to the appropriate [SrgLoginError]. */
    private suspend fun mapDeviceOAuthErrorCode(
        oauthError: OAuthErrorResponse,
        e: ClientRequestException,
    ): SrgLoginError =
        when (oauthError.error) {
            // Polling continuation errors — encoded as InvalidDataError with the raw code
            "authorization_pending", "slow_down" -> {
                SrgLoginError.InvalidDataError(oauthError.error)
            }

            // Terminal errors
            "access_denied" -> {
                SrgLoginError.UserCancelled(
                    reason = oauthError.errorDescription ?: "User denied device authorization",
                )
            }

            "expired_token" -> {
                SrgLoginError.TokenExpired
            }

            "invalid_grant" -> {
                SrgLoginError.InvalidGrant(
                    errorDescription = oauthError.errorDescription,
                    errorCode = oauthError.error,
                )
            }

            // Fall through to standard mapper for any other error
            else -> {
                OAuthErrorMapper.mapClientRequestException(e)
            }
        }

    private val deviceFlowJson =
        Json {
            ignoreUnknownKeys = true
            isLenient = true
        }

    private fun validateUrl(baseUrl: String) {
        SdkLogger.d(LogCategory.NETWORK) { "Validating baseUrl='$baseUrl'" }
        require(baseUrl.isNotBlank()) { "Base URL cannot be blank" }
        require(baseUrl.startsWith("https://")) { "Base URL must use HTTPS" }
        require(!baseUrl.endsWith("/")) { "Base URL should not end with /" }
        SdkLogger.d(LogCategory.NETWORK) { "URL validation passed for baseUrl='$baseUrl'" }
    }

    private fun validateJwksUri(jwksUri: String) {
        require(jwksUri.isNotBlank()) { "JWKS URI cannot be blank" }
        require(jwksUri.startsWith("https://")) { "JWKS URI must use HTTPS for security" }
    }

    /** Reports a device flow exception to the error tracking registry. */
    private fun captureDeviceFlowException(
        e: Exception,
        operation: String,
        endpoint: String,
    ) {
        ErrorHandlerRegistry.captureException(
            throwable = e,
            context =
                mapOf(
                    "operation" to operation,
                    "endpoint" to endpoint,
                    "exception_type" to e::class.simpleName,
                ),
            level = ErrorHandler.ErrorLevel.ERROR,
        )
    }

    /**
     * Reports a `/userinfo` flow exception to the error tracking registry.
     *
     * @param responseBodyExcerpt Optional sanitized + truncated excerpt of the
     *   HTTP response body. Provided only for serialization failures, where
     *   "what did the IdP actually return?" is the most actionable diagnostic
     *   information available. Not used for HTTP failures (where the body is
     *   already encoded by the status code) or network failures (no body).
     */
    private fun captureUserInfoException(
        e: Exception,
        level: ErrorHandler.ErrorLevel,
        httpStatus: Int?,
        responseBodyExcerpt: String? = null,
    ) {
        ErrorHandlerRegistry.captureException(
            throwable = e,
            context =
                buildMap {
                    put("operation", "get_userinfo")
                    put("endpoint", "userinfo_endpoint")
                    put("exception_type", e::class.simpleName ?: "Unknown")
                    if (httpStatus != null) put("http_status", httpStatus.toString())
                    if (responseBodyExcerpt != null) put("response_body_excerpt", responseBodyExcerpt)
                },
            level = level,
        )
    }

    private companion object {
        /** HTTP 401 — used by `getUserInfo` to discriminate Sentry capture level. */
        private const val HTTP_UNAUTHORIZED = 401

        /**
         * Maximum length (chars) of the sanitised response body forwarded to Sentry
         * context on a `/userinfo` parse failure. Sentry context entries should stay
         * small to preserve grouping budgets and rate-limit headroom — 200 is a
         * pragmatic excerpt size, enough to identify content shape but not large
         * enough to balloon event size.
         */
        private const val SENTRY_BODY_EXCERPT_MAX_CHARS = 200

        /**
         * Maximum length (chars) of the sanitised response body returned in
         * [SrgLoginError.SerializationError.responseBody] to consuming apps. Larger
         * than the Sentry excerpt because the BU sees this once per failure (not
         * aggregated), and more context helps the developer reproduce the issue.
         */
        private const val SERIALIZATION_ERROR_BODY_MAX_CHARS = 500
    }
}
