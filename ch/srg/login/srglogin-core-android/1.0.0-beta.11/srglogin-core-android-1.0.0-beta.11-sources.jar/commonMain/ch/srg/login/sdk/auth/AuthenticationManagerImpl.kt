package ch.srg.login.sdk.auth

import ch.srg.login.sdk.auth.flows.LoginFlow
import ch.srg.login.sdk.auth.logout.BackChannelLogoutCapable
import ch.srg.login.sdk.auth.logout.LogoutHandler
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.logging.LogCategory
import ch.srg.login.sdk.logging.SdkLogger
import ch.srg.login.sdk.result.SdkResult
import kotlinx.coroutines.flow.Flow

/**
 * Unified authentication manager that delegates login to a [LoginFlow]
 * and logout to a [LogoutHandler].
 *
 * This replaces the per-flow `WebAuthenticationManager` / `DeviceAuthenticationManager`
 * classes with a single composable implementation.
 */
internal class AuthenticationManagerImpl(
    private val loginStrategy: LoginFlow,
    private val logoutHandler: LogoutHandler,
    private val ssoClientHandler: SsoClientHandler?,
) : AuthenticationManager {
    override fun login(
        loginMethod: LoginMethod,
        authContext: PlatformAuthContext,
        additionalScopes: List<String>,
        additionalParameters: Map<String, String>,
    ): Flow<LoginState> = loginStrategy.login(loginMethod, authContext, additionalScopes, additionalParameters)

    /** Delegates to [LogoutHandler.logout]. */
    override suspend fun logout(logoutType: LogoutType): LogoutResult = logoutHandler.logout(logoutType)

    /**
     * Routes to the underlying [BackChannelLogoutCapable] logout handler.
     * Returns [SdkResult.Failure] with [SrgLoginError.InvalidConfiguration] if the platform
     * does not support back-channel logout (e.g., TV platforms without a browser).
     */
    override fun registerBackChannelLogoutListener(listener: BackChannelLogoutListener): SdkResult<Unit> {
        val capable = logoutHandler as? BackChannelLogoutCapable
        if (capable == null) {
            val message = "Back-channel logout is not supported on this platform."
            SdkLogger.w(LogCategory.AUTHENTICATION) { message }
            return SdkResult.Failure(SrgLoginError.InvalidConfiguration(message))
        }
        capable.registerBackChannelLogoutListener(listener)
        return SdkResult.Success(Unit)
    }

    /**
     * Routes to the underlying [BackChannelLogoutCapable] logout handler.
     * Returns [SdkResult.Failure] if the platform does not support back-channel logout.
     */
    override fun unregisterBackChannelLogoutListener(listener: BackChannelLogoutListener): SdkResult<Unit> {
        val capable = logoutHandler as? BackChannelLogoutCapable
        if (capable == null) {
            val message = "Back-channel logout is not supported on this platform."
            SdkLogger.w(LogCategory.AUTHENTICATION) { message }
            return SdkResult.Failure(SrgLoginError.InvalidConfiguration(message))
        }
        capable.unregisterBackChannelLogoutListener(listener)
        return SdkResult.Success(Unit)
    }

    /**
     * Validates that a [SsoClientHandler] is present (not all platforms support SSO client),
     * then delegates to [SsoClientHandler.open]. HTTPS-scheme validation is performed inside
     * [SsoClientHandler.open].
     */
    override suspend fun openSsoClient(
        ssoClientUrl: String,
        authContext: PlatformAuthContext,
    ): SdkResult<Unit> {
        if (ssoClientHandler == null) {
            SdkLogger.w(LogCategory.AUTHENTICATION) {
                "openSsoClient is not supported on this platform."
            }
            return SdkResult.Failure(
                SrgLoginError.InvalidConfiguration("openSsoClient is not supported on this platform."),
            )
        }
        return ssoClientHandler.open(ssoClientUrl, authContext)
    }
}
