package ch.srg.login.sdk.data.api

import ch.srg.login.sdk.auth.OAuthErrorMapper
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.internal.SecurityUtils
import ch.srg.login.sdk.logging.ErrorHandler
import ch.srg.login.sdk.logging.ErrorHandlerRegistry
import ch.srg.login.sdk.logging.LogCategory
import ch.srg.login.sdk.logging.SdkLogger
import ch.srg.login.sdk.model.DeviceAuthorizationResponse
import ch.srg.login.sdk.model.JwkSet
import ch.srg.login.sdk.model.OAuthErrorResponse
import ch.srg.login.sdk.model.OpenIdConfig
import ch.srg.login.sdk.model.TokenResponseDto
import ch.srg.login.sdk.result.SdkResult
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.plugins.ClientRequestException
import io.ktor.client.plugins.ServerResponseException
import io.ktor.client.request.forms.FormDataContent
import io.ktor.client.request.get
import io.ktor.client.request.headers
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.client.statement.bodyAsText
import io.ktor.http.Parameters
import kotlinx.serialization.json.Json

/**
 * Implementation of [SrgAuthApiService].
 *
 * @property httpClient The pre-configured Ktor HttpClient.
 * @property securityUtils Security utilities for error message sanitization.
 */
internal class SrgAuthApiServiceImpl(
    private val httpClient: HttpClient,
    private val securityUtils: SecurityUtils,
) : SrgAuthApiService {
    override suspend fun getOpenIdConfiguration(baseUrl: String): OpenIdConfig {
        try {
            validateUrl(baseUrl)
            val url = "$baseUrl/.well-known/openid-configuration"
            return httpClient.get(url).body()
        } catch (e: Exception) {
            // Report to error tracking
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "get_openid_configuration",
                        "endpoint" to "well_known_openid_configuration",
                        "base_url" to baseUrl,
                        "critical" to true,
                        "impact" to "sdk_initialization_failure",
                        "exception_type" to e::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.FATAL,
            )

            throw e
        }
    }

    override suspend fun exchangeCodeForToken(
        tokenEndpoint: String,
        code: String,
        redirectUri: String,
        clientId: String,
        codeVerifier: String,
    ): TokenResponseDto {
        try {
            val response =
                httpClient.post(tokenEndpoint) {
                    headers {
                        append("Content-Type", "application/x-www-form-urlencoded")
                        append("Accept", "application/json")
                    }
                    setBody(
                        FormDataContent(
                            Parameters.build {
                                append("grant_type", "authorization_code")
                                append("code", code)
                                append("redirect_uri", redirectUri)
                                append("client_id", clientId)
                                append("code_verifier", codeVerifier)
                            },
                        ),
                    )
                }
            return response.body()
        } catch (e: Exception) {
            val sanitizedMessage = securityUtils.sanitizeErrorMessage(e.message ?: "Unknown error")
            SdkLogger.e(LogCategory.NETWORK, throwable = e) { "Failed to exchange code for token: $sanitizedMessage" }

            // Report to error tracking
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "exchange_code_for_token",
                        "endpoint" to "token_endpoint",
                        "grant_type" to "authorization_code",
                        "stage" to "post_authentication",
                        "exception_type" to e::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.ERROR,
            )

            throw e
        }
    }

    override suspend fun getJwks(jwksUri: String): JwkSet {
        validateJwksUri(jwksUri)
        return httpClient.get(jwksUri).body()
    }

    override suspend fun exchangePasswordForToken(
        tokenEndpoint: String,
        username: String,
        password: String,
        clientId: String,
        clientSecret: String?,
        scope: String,
        additionalParameters: Map<String, String>,
    ): TokenResponseDto {
        try {
            val response =
                httpClient.post(tokenEndpoint) {
                    headers {
                        append("Content-Type", "application/x-www-form-urlencoded")
                        append("Accept", "application/json")
                    }
                    setBody(
                        FormDataContent(
                            Parameters.build {
                                append("grant_type", "password")
                                append("username", username)
                                append("password", password)
                                append("client_id", clientId)
                                if (!clientSecret.isNullOrBlank()) {
                                    append("client_secret", clientSecret)
                                }
                                append("scope", scope)
                                additionalParameters.forEach { (key, value) ->
                                    append(key, value)
                                }
                            },
                        ),
                    )
                }
            return response.body()
        } catch (e: ClientRequestException) {
            SdkLogger.e(LogCategory.NETWORK, throwable = e) { "ROPC token exchange failed" }
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "exchange_password_for_token",
                        "endpoint" to "token_endpoint",
                        "grant_type" to "password",
                        "exception_type" to e::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.ERROR,
            )
            throw e
        } catch (e: Exception) {
            val sanitizedMessage = securityUtils.sanitizeErrorMessage(e.message ?: "Unknown error")
            SdkLogger.e(LogCategory.NETWORK, throwable = e) { "ROPC token exchange failed: $sanitizedMessage" }
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "exchange_password_for_token",
                        "endpoint" to "token_endpoint",
                        "grant_type" to "password",
                        "exception_type" to e::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.ERROR,
            )
            throw e
        }
    }

    override suspend fun refreshAccessToken(
        tokenEndpoint: String,
        refreshToken: String,
        clientId: String,
    ): TokenResponseDto {
        try {
            val response =
                httpClient.post(tokenEndpoint) {
                    headers {
                        append("Content-Type", "application/x-www-form-urlencoded")
                        append("Accept", "application/json")
                    }
                    setBody(
                        FormDataContent(
                            Parameters.build {
                                append("grant_type", "refresh_token")
                                append("refresh_token", refreshToken)
                                append("client_id", clientId)
                            },
                        ),
                    )
                }
            return response.body()
        } catch (e: Exception) {
            val sanitizedMessage = securityUtils.sanitizeErrorMessage(e.message ?: "Unknown error")
            SdkLogger.e(LogCategory.NETWORK, throwable = e) { "Failed to refresh access token: $sanitizedMessage" }

            // Report to error tracking
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "refresh_access_token",
                        "endpoint" to "token_endpoint",
                        "grant_type" to "refresh_token",
                        "critical" to true,
                        "exception_type" to e::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.ERROR,
            )

            throw e
        }
    }

    override suspend fun requestDeviceAuthorization(
        deviceAuthorizationEndpoint: String,
        clientId: String,
        scope: String,
        additionalParameters: Map<String, String>,
    ): SdkResult<DeviceAuthorizationResponse> =
        try {
            val response =
                httpClient.post(deviceAuthorizationEndpoint) {
                    headers {
                        append("Content-Type", "application/x-www-form-urlencoded")
                        append("Accept", "application/json")
                    }
                    setBody(
                        FormDataContent(
                            Parameters.build {
                                append("client_id", clientId)
                                append("scope", scope)
                                val reservedParams = setOf("client_id", "scope", "grant_type")
                                additionalParameters
                                    .filterKeys { it.lowercase() !in reservedParams }
                                    .forEach { (key, value) ->
                                        if (value.isNotEmpty()) {
                                            append(key, value)
                                        }
                                    }
                            },
                        ),
                    )
                }
            SdkResult.Success(response.body())
        } catch (e: ClientRequestException) {
            val error = OAuthErrorMapper.mapClientRequestException(e)
            SdkLogger.e(LogCategory.NETWORK, throwable = e) { "Device authorization request failed" }
            captureDeviceFlowException(e, "request_device_authorization", "device_authorization_endpoint")
            SdkResult.Failure(error)
        } catch (e: ServerResponseException) {
            val error = OAuthErrorMapper.mapServerResponseException(e)
            SdkLogger.e(LogCategory.NETWORK, throwable = e) { "Device authorization server error" }
            captureDeviceFlowException(e, "request_device_authorization", "device_authorization_endpoint")
            SdkResult.Failure(error)
        } catch (e: Exception) {
            val sanitizedMessage = securityUtils.sanitizeErrorMessage(e.message ?: "Unknown error")
            SdkLogger.e(LogCategory.NETWORK, throwable = e) { "Device authorization failed: $sanitizedMessage" }
            captureDeviceFlowException(e, "request_device_authorization", "device_authorization_endpoint")
            SdkResult.Failure(SrgLoginError.NetworkError(details = sanitizedMessage, cause = e))
        }

    override suspend fun exchangeDeviceCodeForToken(
        tokenEndpoint: String,
        deviceCode: String,
        clientId: String,
    ): SdkResult<TokenResponseDto> =
        try {
            val response =
                httpClient.post(tokenEndpoint) {
                    headers {
                        append("Content-Type", "application/x-www-form-urlencoded")
                        append("Accept", "application/json")
                    }
                    setBody(
                        FormDataContent(
                            Parameters.build {
                                append("grant_type", "urn:ietf:params:oauth:grant-type:device_code")
                                append("device_code", deviceCode)
                                append("client_id", clientId)
                            },
                        ),
                    )
                }
            SdkResult.Success(response.body())
        } catch (e: ClientRequestException) {
            // RFC 8628 §3.5: Parse polling error codes from 4xx responses
            val error = mapDeviceTokenError(e)
            SdkLogger.d(LogCategory.NETWORK) { "Device token exchange: ${error::class.simpleName}" }
            // Only capture terminal errors, not expected polling responses
            if (error !is SrgLoginError.InvalidDataError) {
                captureDeviceFlowException(e, "exchange_device_code", "token_endpoint")
            }
            SdkResult.Failure(error)
        } catch (e: ServerResponseException) {
            val error = OAuthErrorMapper.mapServerResponseException(e)
            SdkLogger.e(LogCategory.NETWORK, throwable = e) { "Device token server error" }
            captureDeviceFlowException(e, "exchange_device_code", "token_endpoint")
            SdkResult.Failure(error)
        } catch (e: Exception) {
            val sanitizedMessage = securityUtils.sanitizeErrorMessage(e.message ?: "Unknown error")
            SdkLogger.e(LogCategory.NETWORK, throwable = e) { "Device token exchange failed: $sanitizedMessage" }
            captureDeviceFlowException(e, "exchange_device_code", "token_endpoint")
            SdkResult.Failure(SrgLoginError.NetworkError(details = sanitizedMessage, cause = e))
        }

    /**
     * Maps a client request exception from the device token endpoint.
     *
     * RFC 8628 §3.5 defines polling-specific error codes:
     * - `authorization_pending`: User has not yet authorized. Continue polling.
     * - `slow_down`: Polling too fast. Increase interval by 5s.
     * - `access_denied`: User denied authorization. Terminal.
     * - `expired_token`: Device code expired. Terminal.
     *
     * These polling errors are returned as [SrgLoginError.InvalidDataError] with the
     * raw error code as the reason so the polling loop can distinguish them.
     */
    private suspend fun mapDeviceTokenError(e: ClientRequestException): SrgLoginError {
        val oauthError = parseDeviceOAuthError(e) ?: return OAuthErrorMapper.mapClientRequestException(e)
        return mapDeviceOAuthErrorCode(oauthError, e)
    }

    /** Parses the OAuth error body from a device token endpoint response, or null on parse failure. */
    private suspend fun parseDeviceOAuthError(e: ClientRequestException): OAuthErrorResponse? =
        runCatching { e.response.bodyAsText() }
            .getOrNull()
            ?.takeIf { it.trim().startsWith("{") }
            ?.let { bodyText ->
                runCatching { deviceFlowJson.decodeFromString<OAuthErrorResponse>(bodyText) }.getOrNull()
            }

    /** Maps a parsed RFC 8628 error code to the appropriate [SrgLoginError]. */
    private suspend fun mapDeviceOAuthErrorCode(
        oauthError: OAuthErrorResponse,
        e: ClientRequestException,
    ): SrgLoginError =
        when (oauthError.error) {
            // Polling continuation errors — encoded as InvalidDataError with the raw code
            "authorization_pending", "slow_down" -> {
                SrgLoginError.InvalidDataError(oauthError.error)
            }

            // Terminal errors
            "access_denied" -> {
                SrgLoginError.UserCancelled(
                    reason = oauthError.errorDescription ?: "User denied device authorization",
                )
            }

            "expired_token" -> {
                SrgLoginError.TokenExpired
            }

            "invalid_grant" -> {
                SrgLoginError.InvalidGrant(
                    errorDescription = oauthError.errorDescription,
                    errorCode = oauthError.error,
                )
            }

            // Fall through to standard mapper for any other error
            else -> {
                OAuthErrorMapper.mapClientRequestException(e)
            }
        }

    private val deviceFlowJson =
        Json {
            ignoreUnknownKeys = true
            isLenient = true
        }

    private fun validateUrl(baseUrl: String) {
        SdkLogger.d(LogCategory.NETWORK) { "Validating baseUrl='$baseUrl'" }
        require(baseUrl.isNotBlank()) { "Base URL cannot be blank" }
        require(baseUrl.startsWith("https://")) { "Base URL must use HTTPS" }
        require(!baseUrl.endsWith("/")) { "Base URL should not end with /" }
        SdkLogger.d(LogCategory.NETWORK) { "URL validation passed for baseUrl='$baseUrl'" }
    }

    private fun validateJwksUri(jwksUri: String) {
        require(jwksUri.isNotBlank()) { "JWKS URI cannot be blank" }
        require(jwksUri.startsWith("https://")) { "JWKS URI must use HTTPS for security" }
    }

    /** Reports a device flow exception to the error tracking registry. */
    private fun captureDeviceFlowException(
        e: Exception,
        operation: String,
        endpoint: String,
    ) {
        ErrorHandlerRegistry.captureException(
            throwable = e,
            context =
                mapOf(
                    "operation" to operation,
                    "endpoint" to endpoint,
                    "exception_type" to e::class.simpleName,
                ),
            level = ErrorHandler.ErrorLevel.ERROR,
        )
    }
}
