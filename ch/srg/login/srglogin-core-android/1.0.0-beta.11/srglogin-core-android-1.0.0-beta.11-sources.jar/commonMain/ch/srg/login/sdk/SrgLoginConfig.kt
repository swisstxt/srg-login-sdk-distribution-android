package ch.srg.login.sdk

/**
 * Configuration for automatic token refresh behavior.
 *
 * This class allows customization of token refresh strategy including:
 * - When to refresh tokens (threshold before expiration)
 * - Retry behavior on network failures
 * - Proactive refresh to maintain valid tokens
 * - Automatic background token monitoring (opt-in)
 * - Security monitoring thresholds
 *
 * **Default Configuration**:
 * The defaults are suitable for most applications and follow OAuth 2.0 best practices.
 *
 * **Example - Basic Configuration**:
 * ```kotlin
 * val config = SrgLoginConfig(
 *     clientId = "your-client-id",
 *     redirectUri = "app://callback",
 *     environment = Environment.PROD,
 *     tokenRefreshConfig = TokenRefreshConfig(
 *         refreshThresholdSeconds = 600,    // Refresh 10 min before expiry
 *         maxRetryAttempts = 5,             // Retry 5 times on failure
 *         enableProactiveRefresh = true     // Auto-refresh on token access
 *     )
 * )
 * ```
 *
 * **Example - With Automatic Monitoring** (Opt-in):
 * ```kotlin
 * val config = SrgLoginConfig(
 *     clientId = "your-client-id",
 *     redirectUri = "app://callback",
 *     environment = Environment.PROD,
 *     tokenRefreshConfig = TokenRefreshConfig(
 *         enableProactiveRefresh = true,
 *         enableAutomaticTokenMonitoring = true  // Enable smart background monitoring
 *     )
 * )
 *
 * // After successful login:
 * srgLogin.tokenManager.startTokenMonitoring()
 *
 * // Observe token state in UI:
 * srgLogin.observeTokenState().collect { state ->
 *     when (state) {
 *         TokenState.Valid -> showMainContent()
 *         TokenState.ExpiringSoon -> showWarning()
 *         TokenState.Expired -> showReauthenticate()
 *     }
 * }
 * ```
 *
 * @property refreshThresholdSeconds Refresh token when this many seconds remain before expiry.
 *                                   Default: 300 seconds (5 minutes).
 *                                   Prevents token expiration during API calls.
 *
 *                                   **With Automatic Monitoring**: Adaptive thresholds apply automatically:
 *                                   - Tokens < 5 min: Use 50% of token lifetime (min 10s)
 *                                   - Tokens ≥ 5 min: Use this configured value (capped at 25% of lifetime)
 *
 * @property maxRetryAttempts Maximum retry attempts for failed refresh due to network errors.
 *                            Default: 3 attempts.
 *                            Non-network errors (invalid_grant) are not retried.
 *
 * @property initialRetryDelayMs Initial retry delay in milliseconds for exponential backoff.
 *                               Default: 1000ms (1 second).
 *                               Each retry doubles the delay up to maxRetryDelayMs.
 *
 * @property maxRetryDelayMs Maximum retry delay in milliseconds for exponential backoff.
 *                           Default: 30000ms (30 seconds).
 *                           Prevents excessive wait times during outages.
 *
 * @property enableProactiveRefresh Enable automatic proactive refresh before token expiration.
 *                                  Default: true.
 *                                  When enabled, SDK automatically refreshes tokens before they expire,
 *                                  providing seamless user experience without interruptions.
 *
 * @property enableAutomaticTokenMonitoring Enable automatic background token state monitoring.
 *                                          Default: false (opt-in feature).
 *
 *                                          When enabled, the SDK automatically monitors token expiration in the background
 *                                          using adaptive thresholds and smart scheduling for battery efficiency.
 *
 *                                          **How to use**:
 *                                          1. Set `enableAutomaticTokenMonitoring = true` in config
 *                                          2. Call `tokenManager.startTokenMonitoring()` after successful login
 *                                          3. Observe token state via `observeTokenState()` for UI updates
 *                                          4. Call `tokenManager.stopTokenMonitoring()` on logout
 *
 *                                          **Benefits**:
 *                                          - Automatic proactive refresh before expiration (when enableProactiveRefresh = true)
 *                                          - Reactive StateFlow updates via `observeTokenState()` for UI observation
 *                                          - Battery-efficient smart scheduling (80-98% fewer checks vs fixed interval)
 *                                          - Adaptive thresholds work with any token lifetime (1 min to 24h+)
 *
 *                                          **Requires**: enableProactiveRefresh = true for automatic refresh
 *
 *                                          **Documentation**: See docs/features/background-token-monitoring.md
 *
 * @property monitoringIntervalSeconds Interval in seconds for automatic token monitoring.
 *                                     Default: 60 seconds.
 *
 *                                     **Note**: This value is IGNORED when enableAutomaticTokenMonitoring = true.
 *                                     Smart scheduling calculates optimal intervals dynamically (30s to 15 min).
 *                                     Kept for backward compatibility.
 *
 * @property maxRefreshTokenUses Maximum number of refresh token uses before warning.
 *                               Default: 1000.
 *                               Used to detect potential token compromise (excessive usage).
 *                               Very high value suitable for long-lived sessions.
 */
data class TokenRefreshConfig(
    val refreshThresholdSeconds: Long = 300,
    val maxRetryAttempts: Int = 3,
    val initialRetryDelayMs: Long = 1000,
    val maxRetryDelayMs: Long = 30000,
    val enableProactiveRefresh: Boolean = true,
    val enableAutomaticTokenMonitoring: Boolean = false,
    val monitoringIntervalSeconds: Long = 60,
    val maxRefreshTokenUses: Int = 1000,
) {
    init {
        // Validation
        require(refreshThresholdSeconds >= 0) {
            "refreshThresholdSeconds must be non-negative, got: $refreshThresholdSeconds"
        }
        require(maxRetryAttempts >= 0) {
            "maxRetryAttempts must be non-negative, got: $maxRetryAttempts"
        }
        require(initialRetryDelayMs >= 0) {
            "initialRetryDelayMs must be non-negative, got: $initialRetryDelayMs"
        }
        require(maxRetryDelayMs >= initialRetryDelayMs) {
            "maxRetryDelayMs ($maxRetryDelayMs) must be >= initialRetryDelayMs ($initialRetryDelayMs)"
        }
        require(monitoringIntervalSeconds > 0) {
            "monitoringIntervalSeconds must be positive, got: $monitoringIntervalSeconds"
        }
        require(maxRefreshTokenUses > 0) {
            "maxRefreshTokenUses must be positive, got: $maxRefreshTokenUses"
        }
    }
}

/**
 * Identity of the host application embedding the SRG Login SDK.
 *
 * This information is used for Sentry error attribution, allowing
 * filtering and grouping errors by host application and business unit
 * in a multi-tenant environment (SRF, RTS, RSI, RTR, SWI).
 *
 * **Example**:
 * ```kotlin
 * val identity = AppIdentity(
 *     appId = "ch.srf.news",
 *     appName = "SRF News",
 *     appVersion = "2.5.3",
 *     businessUnit = "SRF",
 *     businessUnitName = "Schweizer Radio und Fernsehen",
 * )
 * ```
 *
 * @property appId Application package identifier (e.g., "ch.srf.news")
 * @property appName Human-readable application name (e.g., "SRF News")
 * @property appVersion Application version string (e.g., "2.5.3")
 * @property businessUnit Business unit identifier (e.g., "SRF", "RTS", "RSI", "RTR", "SWI")
 * @property businessUnitName Business unit full name (e.g., "Schweizer Radio und Fernsehen")
 */
data class AppIdentity(
    val appId: String,
    val appName: String,
    val appVersion: String,
    val businessUnit: String,
    val businessUnitName: String,
) {
    init {
        require(appId.isNotBlank()) { "appId cannot be blank" }
        require(appName.isNotBlank()) { "appName cannot be blank" }
        require(appVersion.isNotBlank()) { "appVersion cannot be blank" }
        require(businessUnit.isNotBlank()) { "businessUnit cannot be blank" }
        require(businessUnitName.isNotBlank()) { "businessUnitName cannot be blank" }
    }
}

/**
 * Represents the configuration for the SRG Login SDK.
 *
 * @property clientId The client ID for your application.
 * @property redirectUri The redirect URI for your application.
 * @property appIdentity The identity of the host application for Sentry error attribution.
 * @property postLogoutRedirectUri The redirect URI after logout (optional).
 * @property environment The target environment for authentication.
 * @property enableLogging A flag to enable or disable logging within the SDK.
 * @property tokenRefreshConfig Configuration for automatic token refresh behavior.
 * @property enableErrorTracking A flag to enable or disable internal error tracking with Sentry.
 *   Default is `true` (enabled). Set to `false` to disable error tracking entirely.
 *   When disabled, SDK errors will not be reported to Sentry.
 *
 *   **When to disable**:
 *   - Debug/development builds (errors logged to console only)
 *   - Privacy-sensitive applications
 *   - During testing/QA
 *   - If your organization has compliance requirements
 *
 *   **Example**:
 *   ```kotlin
 *   val config = SrgLoginConfig(
 *       clientId = "client-id",
 *       redirectUri = "app://callback",
 *       appIdentity = AppIdentity(
 *           appId = "ch.srf.news",
 *           appName = "SRF News",
 *           appVersion = "2.5.3",
 *           businessUnit = "SRF",
 *           businessUnitName = "Schweizer Radio und Fernsehen",
 *       ),
 *       environment = Environment.PROD,
 *       enableErrorTracking = false  // Disable error tracking
 *   )
 *   ```
 */
data class SrgLoginConfig(
    val clientId: String,
    val redirectUri: String,
    val appIdentity: AppIdentity,
    val environment: Environment,
    val postLogoutRedirectUri: String? = null,
    val enableLogging: Boolean = false,
    val tokenRefreshConfig: TokenRefreshConfig = TokenRefreshConfig(),
    val enableErrorTracking: Boolean = true,
    /**
     * Enables the Resource Owner Password Credentials (ROPC) grant type.
     *
     * **SECURITY WARNING**: ROPC is deprecated by RFC 9700 Section 2.4 because it exposes
     * the user's plaintext password to the client application. Only enable as a last-resort
     * fallback (e.g., tvOS where no browser is available for authorization code flow).
     *
     * When enabled, [ch.srg.login.sdk.auth.LoginMethod.UserPassword] can be used with
     * [ch.srg.login.sdk.SrgLogin.login] to authenticate directly with username and password.
     *
     * Default: `false` (disabled)
     */
    val enableRopcFlow: Boolean = false,
    /**
     * The client secret for the ROPC grant type.
     *
     * Required when the OAuth client is registered as a confidential client on the IDP.
     * Only used when [enableRopcFlow] is `true`.
     *
     * **SECURITY WARNING**: Embedding a client secret in a native app is generally discouraged
     * (it can be extracted from the binary). Only use when required by the IDP configuration.
     *
     * Default: `null` (public client, no secret sent)
     */
    val clientSecret: String? = null,
) {
    init {
        // Validation for clientId
        require(clientId.isNotBlank()) {
            "clientId cannot be blank"
        }

        // Validation for redirectUri
        require(redirectUri.isNotBlank()) {
            "redirectUri cannot be blank"
        }
        require(redirectUri.contains("://")) {
            "redirectUri must be a valid URI with scheme (e.g., 'myapp://callback')"
        }

        // Validation for postLogoutRedirectUri (only if provided)
        postLogoutRedirectUri?.let { uri ->
            require(uri.isNotBlank()) {
                "postLogoutRedirectUri cannot be blank if provided"
            }
            require(uri.contains("://")) {
                "postLogoutRedirectUri must be a valid URI with scheme (e.g., 'myapp://logout')"
            }
        }
    }

    /**
     * The URL to fetch the OpenID configuration from.
     */
    val openIdConfigurationUrl: String by lazy {
        "${environment.baseUrl}/.well-known/openid-configuration"
    }

    internal companion object {
        /**
         * Creates a configuration for the development environment.
         */
        fun dev(
            appIdentity: AppIdentity,
            clientId: String = "dev-client-id",
            redirectUri: String = "ch.swisstxt.sdktestapplication://oauth/callback",
            postLogoutRedirectUri: String? = null,
            enableLogging: Boolean = true,
        ): SrgLoginConfig =
            SrgLoginConfig(
                clientId = clientId,
                redirectUri = redirectUri,
                appIdentity = appIdentity,
                postLogoutRedirectUri = postLogoutRedirectUri,
                environment = Environment.DEV,
                enableLogging = enableLogging,
            )

        /**
         * Creates a configuration for the integration environment.
         */
        fun int(
            appIdentity: AppIdentity,
            clientId: String = "int-client-id",
            redirectUri: String = "ch.swisstxt.sdktestapplication://oauth/callback",
            postLogoutRedirectUri: String? = null,
        ): SrgLoginConfig =
            SrgLoginConfig(
                clientId = clientId,
                redirectUri = redirectUri,
                appIdentity = appIdentity,
                postLogoutRedirectUri = postLogoutRedirectUri,
                environment = Environment.INT,
            )

        /**
         * Creates a configuration for the production environment.
         */
        fun prod(
            appIdentity: AppIdentity,
            clientId: String = "prod-client-id",
            redirectUri: String = "ch.swisstxt.sdktestapplication://oauth/callback",
            postLogoutRedirectUri: String? = null,
        ): SrgLoginConfig =
            SrgLoginConfig(
                clientId = clientId,
                redirectUri = redirectUri,
                appIdentity = appIdentity,
                postLogoutRedirectUri = postLogoutRedirectUri,
                environment = Environment.PROD,
            )
    }
}

// Extension functions for improved developer experience with SrgLoginConfig.

/**
 * Creates a copy of this configuration with the specified logout redirect URI.
 *
 * @param uri The post-logout redirect URI to set
 * @return A new SrgLoginConfig instance with the updated logout redirect URI
 */
fun SrgLoginConfig.withLogoutRedirect(uri: String): SrgLoginConfig = copy(postLogoutRedirectUri = uri)

/**
 * Creates a copy of this configuration with the specified logout redirect URI if the condition is true.
 *
 * @param condition The condition to check
 * @param uri The post-logout redirect URI to set if condition is true
 * @return A new SrgLoginConfig instance, potentially with updated logout redirect URI
 */
fun SrgLoginConfig.withLogoutRedirectIf(
    condition: Boolean,
    uri: String,
): SrgLoginConfig = if (condition) copy(postLogoutRedirectUri = uri) else this

/**
 * Creates a copy of this configuration with logging enabled.
 *
 * @return A new SrgLoginConfig instance with logging enabled
 */
fun SrgLoginConfig.withLogging(): SrgLoginConfig = copy(enableLogging = true)

/**
 * Creates a copy of this configuration with the specified token refresh configuration.
 *
 * **Example - Replace entire configuration**:
 * ```kotlin
 * val config = SrgLoginConfig.dev()
 *     .withTokenRefreshConfig(
 *         TokenRefreshConfig(
 *             refreshThresholdSeconds = 600,
 *             maxRetryAttempts = 5,
 *             enableProactiveRefresh = true
 *         )
 *     )
 * ```
 *
 * @param config The token refresh configuration to set
 * @return A new SrgLoginConfig instance with the updated token refresh configuration
 */
fun SrgLoginConfig.withTokenRefreshConfig(config: TokenRefreshConfig): SrgLoginConfig = copy(tokenRefreshConfig = config)

/**
 * Creates a copy of this configuration with modified token refresh configuration.
 *
 * This extension function allows inline configuration using a builder-style lambda,
 * which is convenient for modifying specific properties without recreating the entire config.
 *
 * **Example - Modify specific properties**:
 * ```kotlin
 * val config = SrgLoginConfig.dev()
 *     .configureTokenRefresh {
 *         copy(
 *             refreshThresholdSeconds = 600,
 *             enableAutomaticTokenMonitoring = true
 *         )
 *     }
 * ```
 *
 * **Example - Enable automatic monitoring**:
 * ```kotlin
 * val config = SrgLoginConfig.prod()
 *     .configureTokenRefresh {
 *         copy(
 *             enableProactiveRefresh = true,
 *             enableAutomaticTokenMonitoring = true
 *         )
 *     }
 * ```
 *
 * @param configure A lambda that receives the current TokenRefreshConfig and returns a modified copy
 * @return A new SrgLoginConfig instance with the updated token refresh configuration
 */
fun SrgLoginConfig.configureTokenRefresh(configure: TokenRefreshConfig.() -> TokenRefreshConfig): SrgLoginConfig =
    copy(tokenRefreshConfig = tokenRefreshConfig.configure())

/**
 * Creates a copy of this configuration with the ROPC flow enabled.
 *
 * **SECURITY WARNING**: ROPC is deprecated by RFC 9700 Section 2.4. Only enable as a
 * last-resort fallback (e.g., tvOS where no browser is available for authorization code flow).
 *
 * **Confidential clients**: If the OAuth client is registered as a confidential client on the IDP,
 * provide the [clientSecret]. For public clients, omit it (defaults to `null`).
 *
 * **Example**:
 * ```kotlin
 * val config = SrgLoginConfig(
 *     clientId = "your-client-id",
 *     redirectUri = "app://callback",
 *     appIdentity = appIdentity,
 *     environment = Environment.INT,
 * ).withRopcFlow(clientSecret = "your-client-secret")
 * ```
 *
 * @param clientSecret The client secret for confidential clients, or `null` for public clients.
 * @return A new SrgLoginConfig instance with ROPC enabled and the client secret set.
 */
fun SrgLoginConfig.withRopcFlow(clientSecret: String? = null): SrgLoginConfig = copy(enableRopcFlow = true, clientSecret = clientSecret)

/**
 * Represents the available authentication environments.
 *
 * @property baseUrl The base URL of the environment.
 */
enum class Environment(
    val baseUrl: String,
) {
    /**
     * Development environment.
     */
    DEV("https://account-dev.srgssr.ch"),

    /**
     * Integration environment.
     */
    INT("https://account-int.srgssr.ch"),

    /**
     * Production environment.
     */
    PROD("https://account.srgssr.ch"),
}
