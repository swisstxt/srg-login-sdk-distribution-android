package ch.srg.login.sdk.auth

import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.result.SdkResult

/**
 * Handles SSO client browser navigation, delegating to the platform [WebAuthenticator].
 *
 * Only available on platforms with browser support (iOS, Android — not TV).
 */
internal class SsoClientHandler(
    private val webAuthenticator: WebAuthenticator,
) {
    suspend fun open(
        ssoClientUrl: String,
        authContext: PlatformAuthContext,
    ): SdkResult<Unit> {
        val configError =
            when {
                !ssoClientUrl.startsWith("https://") -> {
                    val sanitizedUrl = ssoClientUrl.substringBefore("?")
                    SrgLoginError.InvalidConfiguration(
                        "SSO client URL must use HTTPS scheme (RFC 8252 §8.3). Got: $sanitizedUrl",
                    )
                }

                authContext !is WebAuthCapable -> {
                    SrgLoginError.InvalidConfiguration(
                        "SSO client requires a WebAuthCapable authentication context.",
                    )
                }

                else -> {
                    null
                }
            }
        return if (configError != null) {
            SdkResult.Failure(configError)
        } else {
            webAuthenticator.openSsoClient(ssoClientUrl, authContext)
        }
    }
}
