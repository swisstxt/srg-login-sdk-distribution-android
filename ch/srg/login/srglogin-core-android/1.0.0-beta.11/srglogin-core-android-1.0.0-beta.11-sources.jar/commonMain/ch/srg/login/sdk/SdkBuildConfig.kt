package ch.srg.login.sdk

internal object SdkBuildConfig {
    const val VERSION: String = "1.0.0-beta.11"
    const val GROUP: String = "ch.srg.login"
}
