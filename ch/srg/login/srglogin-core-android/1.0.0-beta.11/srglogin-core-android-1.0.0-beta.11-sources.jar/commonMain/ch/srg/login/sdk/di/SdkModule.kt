package ch.srg.login.sdk.di

import ch.srg.login.sdk.SrgLoginConfig
import ch.srg.login.sdk.auth.JwtValidationService
import ch.srg.login.sdk.auth.TokenManager
import ch.srg.login.sdk.auth.TokenManagerImpl
import ch.srg.login.sdk.data.OpenIdConfigRepository
import ch.srg.login.sdk.data.OpenIdConfigRepositoryImpl
import ch.srg.login.sdk.data.api.SrgAuthApiService
import ch.srg.login.sdk.data.api.SrgAuthApiServiceImpl
import ch.srg.login.sdk.events.EventEmitter
import ch.srg.login.sdk.events.SdkEventEmitter
import ch.srg.login.sdk.internal.SecurityUtils
import io.ktor.client.HttpClient
import org.koin.core.module.Module
import org.koin.dsl.module

/**
 * Koin DI module for the SRG Login SDK.
 * Provides all necessary dependencies for the SDK components.
 */
internal val sdkModule =
    module {

        // Security utilities for PKCE generation and sanitization
        single { SecurityUtils(get()) }

        // Event emitter for SDK lifecycle events - factory for per-instance isolation
        // Each SrgLogin instance gets its own EventEmitter to avoid cross-instance event pollution
        // MUST be defined BEFORE platformModule (which depends on it for AppLifecycleObserver)
        // Binds EventEmitter interface to SdkEventEmitter implementation (Dependency Inversion Principle)
        factory<EventEmitter> { SdkEventEmitter() }

        // Include platform-specific dependencies
        includes(platformModule)

        // HttpClient configuration - singleton shared across SDK instances
        single<HttpClient> {
            createHttpClient(
                enableLogging = true,
                // Lazy injection to avoid circular dependency
                securityUtilsProvider = { get<SecurityUtils>() },
            )
        }

        // API Service - bind interface to implementation
        single<SrgAuthApiService> { SrgAuthApiServiceImpl(get(), get()) }

        // JWT Validation Service - singleton for JWKS caching
        single { JwtValidationService(get(), get()) }

        // Token Manager - factory to allow different configs per instance
        // Receives openIdConfigRepository and eventEmitter as parameters to avoid duplication
        factory<TokenManager> { (config: SrgLoginConfig, openIdConfigRepository: OpenIdConfigRepository, eventEmitter: EventEmitter) ->
            TokenManagerImpl(
                config = config,
                openIdConfigRepository = openIdConfigRepository,
                apiService = get(),
                tokenStorage = get(),
                // JwtValidationService also implements TokenStateProvider
                jwtValidationService = get(),
                cryptoService = get(),
                eventEmitter = eventEmitter,
            )
        }

        // Repository - bind interface to implementation
        factory<OpenIdConfigRepository> { (config: SrgLoginConfig) ->
            OpenIdConfigRepositoryImpl(get(), config, get())
        }
    }

/**
 * Platform-specific module.
 * This is an `expect` value that requires each platform to provide an `actual` Koin module
 * containing platform-specific dependencies (like the `WebAuthenticator`).
 */
internal expect val platformModule: Module

/**
 * Creates a configured HttpClient instance with platform-specific engine.
 *
 * @param enableLogging Whether to enable HTTP request/response logging
 * @param securityUtilsProvider Lazy provider for SecurityUtils to avoid circular dependencies
 * @return Configured HttpClient instance
 */
internal expect fun createHttpClient(
    enableLogging: Boolean,
    securityUtilsProvider: () -> SecurityUtils,
): HttpClient
