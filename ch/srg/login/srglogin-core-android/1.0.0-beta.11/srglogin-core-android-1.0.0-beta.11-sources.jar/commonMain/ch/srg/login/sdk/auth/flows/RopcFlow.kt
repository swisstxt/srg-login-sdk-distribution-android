package ch.srg.login.sdk.auth.flows

import ch.srg.login.sdk.SrgLoginConfig
import ch.srg.login.sdk.auth.LoginMethod
import ch.srg.login.sdk.auth.LoginState
import ch.srg.login.sdk.auth.PlatformAuthContext
import ch.srg.login.sdk.auth.handler.LoginFailureEmitter
import ch.srg.login.sdk.auth.handler.TokenSuccessHandler
import ch.srg.login.sdk.data.OpenIdConfigRepository
import ch.srg.login.sdk.data.api.SrgAuthApiService
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.events.EventEmitter
import ch.srg.login.sdk.events.SdkLifecycleEvent
import ch.srg.login.sdk.logging.ErrorHandler
import ch.srg.login.sdk.logging.ErrorHandlerRegistry
import ch.srg.login.sdk.logging.LogCategory
import ch.srg.login.sdk.logging.SdkLogger
import ch.srg.login.sdk.result.SdkResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.datetime.Clock

/**
 * Login flow for the Resource Owner Password Credentials (ROPC) grant (RFC 6749 §4.3).
 *
 * Validates [LoginMethod.UserPassword] + ROPC config enablement, fetches OpenID configuration,
 * exchanges username/password for tokens, and delegates token handling to [TokenSuccessHandler].
 *
 * @Security ROPC is deprecated (RFC 9700 Section 2.4). See [SrgLoginConfig.enableRopcFlow].
 */
@Suppress("LongParameterList")
internal class RopcFlow(
    private val config: SrgLoginConfig,
    private val openIdConfigRepository: OpenIdConfigRepository,
    private val authApiService: SrgAuthApiService,
    private val tokenSuccessHandler: TokenSuccessHandler,
    private val loginFailureEmitter: LoginFailureEmitter,
    private val eventEmitter: EventEmitter,
    private val clock: Clock = Clock.System,
) : LoginFlow {
    /**
     * Executes the ROPC grant flow (RFC 6749 §4.3): validates config enablement +
     * [LoginMethod.UserPassword], fetches OIDC config, exchanges username/password for tokens,
     * and delegates success/failure handling to [TokenSuccessHandler].
     *
     * @param loginMethod Must be [LoginMethod.UserPassword]; any other type returns [LoginState.Failure].
     */
    @Suppress("LongMethod", "TooGenericExceptionCaught", "CyclomaticComplexMethod")
    override fun login(
        loginMethod: LoginMethod,
        authContext: PlatformAuthContext,
        additionalScopes: List<String>,
        additionalParameters: Map<String, String>,
    ): Flow<LoginState> =
        flow {
            val loginStartedTimestamp = clock.now().toEpochMilliseconds()
            eventEmitter.tryEmit(SdkLifecycleEvent.LoginStarted(loginStartedTimestamp))

            // Validate ROPC is enabled in config
            if (!config.enableRopcFlow) {
                SdkLogger.d(LogCategory.AUTHENTICATION) { "ROPC flow is disabled in configuration" }
                emit(
                    loginFailureEmitter.emit(
                        SrgLoginError.InvalidConfiguration(
                            "ROPC flow is disabled. Set enableRopcFlow = true in SrgLoginConfig to enable.",
                        ),
                    ),
                )
                return@flow
            }

            // Validate login method type
            if (loginMethod !is LoginMethod.UserPassword) {
                SdkLogger.d(LogCategory.AUTHENTICATION) { "RopcFlow only supports UserPassword login method" }
                emit(
                    loginFailureEmitter.emit(
                        SrgLoginError.InvalidConfiguration(
                            "RopcFlow only supports the UserPassword login method.",
                        ),
                    ),
                )
                return@flow
            }

            // Validate non-empty username/password
            if (loginMethod.username.isBlank() || loginMethod.password.isBlank()) {
                SdkLogger.d(LogCategory.AUTHENTICATION) { "ROPC: empty username or password" }
                emit(
                    loginFailureEmitter.emit(
                        SrgLoginError.InvalidConfiguration("Username and password must not be blank."),
                    ),
                )
                return@flow
            }

            SdkLogger.d(LogCategory.AUTHENTICATION) { "ROPC login flow started" }

            // Fetch OpenID configuration
            val openIdConfig =
                when (val result = openIdConfigRepository.getConfiguration()) {
                    is SdkResult.Success -> {
                        result.data
                    }

                    is SdkResult.Failure -> {
                        val throwable =
                            when (val error = result.error) {
                                is SrgLoginError.NetworkError -> {
                                    error.cause ?: Exception(error.details ?: "Network error")
                                }

                                is SrgLoginError.HttpError -> {
                                    Exception("HTTP ${error.code}: ${error.message}")
                                }

                                else -> {
                                    Exception(error.toString())
                                }
                            }
                        ErrorHandlerRegistry.captureException(
                            throwable = throwable,
                            context =
                                mapOf(
                                    "operation" to "fetch_openid_config",
                                    "stage" to "ropc_login_init",
                                    "error_type" to result.error::class.simpleName,
                                ),
                            level = ErrorHandler.ErrorLevel.ERROR,
                        )
                        emit(loginFailureEmitter.emit(result.error))
                        return@flow
                    }
                }

            // Build scopes
            val scope = (listOf("openid") + additionalScopes).distinct().joinToString(" ")

            // Exchange credentials for tokens
            try {
                val tokenResponse =
                    authApiService.exchangePasswordForToken(
                        tokenEndpoint = openIdConfig.tokenEndpoint,
                        username = loginMethod.username,
                        password = loginMethod.password,
                        clientId = config.clientId,
                        clientSecret = config.clientSecret,
                        scope = scope,
                        additionalParameters = additionalParameters,
                    )

                SdkLogger.d(LogCategory.AUTHENTICATION) { "ROPC token exchange successful" }
                val result =
                    tokenSuccessHandler.handle(
                        tokenResponse = tokenResponse,
                        clientId = config.clientId,
                        issuer = openIdConfig.issuer,
                        jwksUri = openIdConfig.jwksUri,
                    )
                emit(result)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val error = openIdConfigRepository.mapExceptionToError(e)
                ErrorHandlerRegistry.captureException(
                    throwable = e,
                    context =
                        mapOf(
                            "operation" to "exchange_password_for_token",
                            "stage" to "ropc_token_exchange",
                            "error_type" to e::class.simpleName,
                            "error_mapped_to" to error::class.simpleName,
                        ),
                    level = ErrorHandler.ErrorLevel.ERROR,
                )
                emit(loginFailureEmitter.emit(error))
            }
        }.catch { e ->
            val exception = e as? Exception ?: throw e
            val error = openIdConfigRepository.mapExceptionToError(exception)
            ErrorHandlerRegistry.captureException(
                throwable = exception,
                context =
                    mapOf(
                        "operation" to "ropc_login_flow",
                        "stage" to "unhandled_exception",
                        "error_type" to e::class.simpleName,
                        "error_mapped_to" to error::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.ERROR,
            )
            emit(loginFailureEmitter.emit(error))
        }
}
