package ch.srg.login.sdk.model

import kotlinx.serialization.json.JsonObject

/**
 * DTO for the OIDC `/userinfo` endpoint response (OIDC Core §5.3).
 *
 * INTERNAL: not part of the public SDK API.
 *
 * The on-wire shape is a flat JSON object — claims (`sub`, `name`, `email`, …)
 * sit at the top level, alongside any IDP-specific custom claims. This DTO
 * holds the raw payload in a single field; the API service implementation
 * deserialises the HTTP response as a [JsonObject] and constructs this wrapper
 * explicitly at the call site.
 *
 * **No `@Serializable` annotation by design**: kotlinx-serialization is *not*
 * used to build this type directly (the wire shape has no `claims` key — a
 * naive `@Serializable` annotation would expect one and fail at runtime). The
 * wrapping is performed explicitly in [ch.srg.login.sdk.data.api.SrgAuthApiServiceImpl]
 * so the layering is visible to readers without hidden surrogate magic.
 *
 * The wrapper exists (rather than returning [JsonObject] directly from the API
 * service) to:
 * - Provide a typed return value across the internal API service boundary.
 * - Leave room for future fields — signed-JWT variants (OIDC §5.3.2,
 *   `userinfo_signed_response_alg`), aggregated/distributed claims (OIDC §5.6),
 *   HTTP response metadata — without churning every call site.
 *
 * Not to be confused with [UserInfoDto], which is the **storage** DTO (uses a
 * `custom_claims` wrapper to drive kotlinx-serialization auto-generation for
 * persistent storage; that one *is* `@Serializable`).
 */
internal data class UserInfoResponseDto(
    val claims: JsonObject,
)
