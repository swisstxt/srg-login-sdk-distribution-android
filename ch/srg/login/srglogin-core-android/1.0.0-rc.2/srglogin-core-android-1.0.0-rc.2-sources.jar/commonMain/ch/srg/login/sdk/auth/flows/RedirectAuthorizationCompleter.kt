package ch.srg.login.sdk.auth.flows

import ch.srg.login.sdk.auth.LoginState

/**
 * A login flow that can complete a redirect-based authorization from a callback URL,
 * independently of the coroutine that started it.
 *
 * This is the second half of the begin/complete split (see [AuthorizationCodeFlow]). It
 * exists for the web target, where a full-page redirect destroys the page and the login
 * coroutine: the callback arrives on a fresh page load, so completion must be re-driven
 * from the persisted authorization transaction rather than by resuming a suspended call.
 *
 * On mobile the callback is delivered inline to the still-alive login coroutine, so this
 * entry point is unused there.
 */
internal interface RedirectAuthorizationCompleter {
    /**
     * Completes the authorization-code flow for the given IDP [callbackUrl]: reloads the
     * transaction by `state`, exchanges the code, validates and persists the tokens, and
     * returns the terminal [LoginState] (the corresponding lifecycle event is emitted).
     */
    suspend fun completeAuthorization(callbackUrl: String): LoginState
}
