package ch.srg.login.sdk.model

/**
 * Returns a human-readable display name derived from [UserInfo], using a documented
 * fallback chain.
 *
 * **Opt-in convenience** — this is an extension function (not a property on
 * [UserInfo]) because the fallback chain encodes an opinionated choice that not
 * every consumer will agree with. Consumers that want a different policy can ignore
 * this extension and implement their own from the typed fields.
 *
 * Fallback chain (first non-blank value wins):
 *  1. [UserInfo.name]
 *  2. [UserInfo.givenName] joined with [UserInfo.familyName] (if either is present)
 *  3. [UserInfo.preferredUsername]
 *  4. [UserInfo.email]
 *  5. [UserInfo.subject] (always non-null — last-resort fallback)
 */
public fun UserInfo.defaultDisplayName(): String =
    name?.takeIf { it.isNotBlank() }
        ?: listOfNotNull(givenName, familyName).joinToString(" ").takeIf { it.isNotBlank() }
        ?: preferredUsername?.takeIf { it.isNotBlank() }
        ?: email?.takeIf { it.isNotBlank() }
        ?: subject
