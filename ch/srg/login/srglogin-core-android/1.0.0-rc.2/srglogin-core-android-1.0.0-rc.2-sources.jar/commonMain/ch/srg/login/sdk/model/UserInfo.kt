package ch.srg.login.sdk.model

import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.longOrNull

/**
 * End-User profile information (OIDC Core 1.0 §5.1 Standard Claims, plus phone scope).
 *
 * Represents the **current profile state** of the authenticated user, as exposed by
 * the IdP. Unlike [IdTokenClaims] — which is a snapshot of auth-proof claims at the
 * moment of login (`iss`, `aud`, `exp`, `nonce`, `azp`, `acr`, …) — [UserInfo] is
 * the canonical type for user identity that can be refreshed at any time during the
 * session via `srgLogin.getUserInfo()`.
 *
 * **Source of values**:
 * - At login, populated from the validated ID Token's profile claims (subject to
 *   the granted scopes: `profile`, `email`, `address`, `phone`).
 * - At runtime, refreshable via `srgLogin.getUserInfo(forceRefresh = true)`, which
 *   calls the OIDC `/userinfo` endpoint (OIDC Core 1.0 §5.3) and replaces the
 *   cached value.
 *
 * **Validation gate** enforced at the type system level: the primary constructor is
 * `internal`, and [@ConsistentCopyVisibility][kotlin.ConsistentCopyVisibility]
 * propagates that visibility to the generated `copy()` method. Instances can only
 * be obtained from the SDK after either successful ID Token validation (at login or
 * refresh) or a successful `/userinfo` round-trip with a `sub`-matching response
 * (OIDC §5.3.2 subject identifier mismatch protection).
 *
 * Standard OIDC profile claims are exposed as typed properties. Non-standard or
 * IDP-specific claims are available via [rawClaims], using the type-safe accessors
 * inherited from [ClaimContainer] (`getStringClaim`, `getLongClaim`,
 * `getBooleanClaim`, `getStringListClaim`, `getObjectClaim`, `getArrayClaim`,
 * `hasCustomClaim`).
 *
 * @see defaultDisplayName For an opt-in convenience that derives a human-readable
 *   display name from the claims, with a documented fallback chain.
 */
@ConsistentCopyVisibility
public data class UserInfo internal constructor(
    /**
     * Stable, non-reassigned subject identifier of the authenticated user
     * (`sub` claim). Always present — when sourced from `/userinfo`, the SDK
     * additionally verifies it matches the access token's `sub` (OIDC §5.3.2).
     */
    val subject: String,
    /** End-User's full name (`name` claim) in displayable form. Granted by `profile` scope. */
    val name: String? = null,
    /** Given name(s) or first name(s) of the End-User (`given_name` claim). Granted by `profile` scope. */
    val givenName: String? = null,
    /** Surname(s) or last name(s) of the End-User (`family_name` claim). Granted by `profile` scope. */
    val familyName: String? = null,
    /**
     * Shorthand name by which the End-User wishes to be referred to
     * (`preferred_username` claim). Granted by `profile` scope. Not guaranteed
     * to be unique by the IDP.
     */
    val preferredUsername: String? = null,
    /** URL of the End-User's profile picture (`picture` claim). Granted by `profile` scope. */
    val picture: String? = null,
    /**
     * End-User's locale (`locale` claim) as a BCP47 language tag (e.g. `fr-CH`).
     * Granted by `profile` scope.
     */
    val locale: String? = null,
    /**
     * Time when the End-User's profile information was last updated (`updated_at`
     * claim) as epoch seconds. Granted by `profile` scope.
     */
    val updatedAt: Long? = null,
    /** End-User's preferred email address (`email` claim). Granted by `email` scope. */
    val email: String? = null,
    /**
     * `true` if the IDP has verified the email belongs to the End-User
     * (`email_verified` claim). Granted by `email` scope.
     */
    val emailVerified: Boolean? = null,
    /**
     * End-User's preferred postal address (`address` claim) as a structured
     * [Address] object. Granted by `address` scope.
     */
    val address: Address? = null,
    /**
     * End-User's preferred telephone number (`phone_number` claim) in E.164 format
     * (e.g. `+41791234567`). Granted by `phone` scope.
     */
    val phoneNumber: String? = null,
    /**
     * `true` if the IDP has verified the phone number belongs to the End-User
     * (`phone_number_verified` claim). Granted by `phone` scope.
     */
    val phoneNumberVerified: Boolean? = null,
    /**
     * IDP-specific or non-standard claims preserved as [ClaimValue] (lossless,
     * platform-agnostic). Standard OIDC claims are pulled out into the typed
     * properties above; only the residual claims appear here. Access via the typed
     * accessors inherited from [ClaimContainer].
     */
    override val rawClaims: Map<String, ClaimValue> = emptyMap(),
) : ClaimContainer {
    // Type-safe accessors for non-standard claims (getStringClaim, getLongClaim, …)
    // are inherited from [ClaimContainer].

    internal companion object {
        /**
         * Creates a [UserInfo] instance from already-validated [JwtClaims] (the
         * parsed ID Token at login or refresh).
         *
         * INTERNAL: only called by the SDK after successful OIDC validation
         * (`JwtValidationService.validateIdToken`). The required `sub` claim is
         * dereferenced unsafely (`!!`) — if absent, upstream validation has a bug
         * and a NullPointerException is preferable to silent data corruption.
         *
         * Standard OIDC profile claims are pulled out of [JwtClaims.rawClaims] into
         * typed properties. The remaining claims flow unchanged into
         * [UserInfo.rawClaims] for consumer access via the type-safe accessors.
         */
        internal fun fromJwtClaims(jwtClaims: JwtClaims): UserInfo {
            val raw = jwtClaims.rawClaims
            return UserInfo(
                subject = jwtClaims.sub!!,
                name = jwtClaims.stringClaim("name"),
                givenName = jwtClaims.stringClaim("given_name"),
                familyName = jwtClaims.stringClaim("family_name"),
                preferredUsername = jwtClaims.stringClaim("preferred_username"),
                picture = jwtClaims.stringClaim("picture"),
                locale = jwtClaims.stringClaim("locale"),
                updatedAt =
                    (raw["updated_at"] as? JsonPrimitive)
                        ?.takeIf { !it.isString }
                        ?.longOrNull,
                email = jwtClaims.stringClaim("email"),
                emailVerified =
                    (raw["email_verified"] as? JsonPrimitive)
                        ?.takeIf { !it.isString }
                        ?.booleanOrNull,
                address = jwtClaims.jsonObjectClaim("address")?.let(::parseAddress),
                phoneNumber = jwtClaims.stringClaim("phone_number"),
                phoneNumberVerified =
                    (raw["phone_number_verified"] as? JsonPrimitive)
                        ?.takeIf { !it.isString }
                        ?.booleanOrNull,
                rawClaims =
                    raw
                        .filterKeys { it !in STANDARD_OIDC_TYPED_CLAIMS }
                        .mapValues { (_, value) -> value.toClaimValue() },
            )
        }

        /**
         * Creates a [UserInfo] instance from the OIDC `/userinfo` endpoint response
         * (OIDC Core 1.0 §5.3).
         *
         * INTERNAL: only called by `UserInfoServiceImpl` after a successful HTTP
         * round-trip to `/userinfo`.
         *
         * Per OIDC §5.3.2, `sub` MUST be present in the response — its absence is a
         * spec violation, surfaced as [IllegalArgumentException] so the caller maps
         * it to a typed [ch.srg.login.sdk.errors.SrgLoginError]. The caller is
         * **additionally** responsible for verifying that this `sub` matches the
         * access token's `sub` (OIDC §5.3.2 subject identifier mismatch
         * protection) — this method only asserts presence, not match.
         *
         * Standard OIDC §5.1 profile claims are pulled out of [UserInfoResponseDto.claims]
         * into typed properties. The remaining claims flow unchanged into
         * [UserInfo.rawClaims].
         *
         * **Note**: this method duplicates the parsing logic of [fromJwtClaims] on
         * purpose — [fromJwtClaims] is on a hot path (login + every refresh) and
         * left untouched to avoid regression risk. If you add a new typed §5.1
         * claim, you MUST update both factories AND [STANDARD_OIDC_TYPED_CLAIMS].
         */
        internal fun fromUserInfoResponse(dto: UserInfoResponseDto): UserInfo {
            val raw = dto.claims
            val subject =
                (raw["sub"] as? JsonPrimitive)
                    ?.takeIf { it.isString }
                    ?.content
                    ?.takeUnless { it.isBlank() }
                    ?: throw IllegalArgumentException(
                        "OIDC §5.3.2: /userinfo response missing or blank 'sub' claim",
                    )
            return UserInfo(
                subject = subject,
                name = (raw["name"] as? JsonPrimitive)?.takeIf { it.isString }?.content,
                givenName = (raw["given_name"] as? JsonPrimitive)?.takeIf { it.isString }?.content,
                familyName = (raw["family_name"] as? JsonPrimitive)?.takeIf { it.isString }?.content,
                preferredUsername = (raw["preferred_username"] as? JsonPrimitive)?.takeIf { it.isString }?.content,
                picture = (raw["picture"] as? JsonPrimitive)?.takeIf { it.isString }?.content,
                locale = (raw["locale"] as? JsonPrimitive)?.takeIf { it.isString }?.content,
                updatedAt =
                    (raw["updated_at"] as? JsonPrimitive)
                        ?.takeIf { !it.isString }
                        ?.longOrNull,
                email = (raw["email"] as? JsonPrimitive)?.takeIf { it.isString }?.content,
                emailVerified =
                    (raw["email_verified"] as? JsonPrimitive)
                        ?.takeIf { !it.isString }
                        ?.booleanOrNull,
                address = (raw["address"] as? JsonObject)?.let(::parseAddress),
                phoneNumber = (raw["phone_number"] as? JsonPrimitive)?.takeIf { it.isString }?.content,
                phoneNumberVerified =
                    (raw["phone_number_verified"] as? JsonPrimitive)
                        ?.takeIf { !it.isString }
                        ?.booleanOrNull,
                rawClaims =
                    raw
                        .filterKeys { it !in STANDARD_OIDC_TYPED_CLAIMS }
                        .mapValues { (_, value) -> value.toClaimValue() },
            )
        }

        private fun parseAddress(obj: JsonObject): Address =
            Address(
                formatted =
                    (obj["formatted"] as? JsonPrimitive)
                        ?.takeIf { it.isString }
                        ?.content,
                streetAddress =
                    (obj["street_address"] as? JsonPrimitive)
                        ?.takeIf { it.isString }
                        ?.content,
                locality =
                    (obj["locality"] as? JsonPrimitive)
                        ?.takeIf { it.isString }
                        ?.content,
                region =
                    (obj["region"] as? JsonPrimitive)
                        ?.takeIf { it.isString }
                        ?.content,
                postalCode =
                    (obj["postal_code"] as? JsonPrimitive)
                        ?.takeIf { it.isString }
                        ?.content,
                country =
                    (obj["country"] as? JsonPrimitive)
                        ?.takeIf { it.isString }
                        ?.content,
            )

        /**
         * Reconstructs a [UserInfo] from its persisted [UserInfoDto] representation.
         *
         * INTERNAL: called by the SDK when reading from secure storage. The
         * conversion is exact and lossless — every typed property maps 1:1, and
         * the persisted `custom_claims` [JsonObject] is converted back to
         * `Map<String, ClaimValue>` via the existing [toClaimValue] extension.
         */
        internal fun fromDto(dto: UserInfoDto): UserInfo =
            UserInfo(
                subject = dto.subject,
                name = dto.name,
                givenName = dto.givenName,
                familyName = dto.familyName,
                preferredUsername = dto.preferredUsername,
                picture = dto.picture,
                locale = dto.locale,
                updatedAt = dto.updatedAt,
                email = dto.email,
                emailVerified = dto.emailVerified,
                address =
                    dto.address?.let {
                        Address(
                            formatted = it.formatted,
                            streetAddress = it.streetAddress,
                            locality = it.locality,
                            region = it.region,
                            postalCode = it.postalCode,
                            country = it.country,
                        )
                    },
                phoneNumber = dto.phoneNumber,
                phoneNumberVerified = dto.phoneNumberVerified,
                rawClaims = dto.customClaims.mapValues { (_, value) -> value.toClaimValue() },
            )
    }
}

/**
 * Converts this [UserInfo] to its serialisable [UserInfoDto] representation for
 * persistent storage. Inverse of [UserInfo.Companion.fromDto].
 *
 * INTERNAL: called by [ch.srg.login.sdk.token.TokenStorage] implementations on
 * each platform. The conversion is exact and lossless: typed properties map 1:1,
 * `rawClaims: Map<String, ClaimValue>` is converted to a [JsonObject] via
 * [toJsonElement].
 */
internal fun UserInfo.toDto(): UserInfoDto =
    UserInfoDto(
        subject = subject,
        name = name,
        givenName = givenName,
        familyName = familyName,
        preferredUsername = preferredUsername,
        picture = picture,
        locale = locale,
        updatedAt = updatedAt,
        email = email,
        emailVerified = emailVerified,
        address =
            address?.let {
                AddressDto(
                    formatted = it.formatted,
                    streetAddress = it.streetAddress,
                    locality = it.locality,
                    region = it.region,
                    postalCode = it.postalCode,
                    country = it.country,
                )
            },
        phoneNumber = phoneNumber,
        phoneNumberVerified = phoneNumberVerified,
        customClaims = JsonObject(rawClaims.mapValues { (_, value) -> value.toJsonElement() }),
    )

/**
 * Standard OIDC claims that are exposed as typed properties on [IdTokenClaims] or
 * [UserInfo]. Both factories filter these out of [JwtClaims.rawClaims] when building
 * the typed value's own [rawClaims] map, so that custom IDP-specific claims appear
 * in `rawClaims` exactly once and never duplicate a typed property.
 *
 * Kept as a single shared constant — adding a new typed claim on either type must
 * update this set.
 *
 * **Intentionally excluded: the RFC 7519 §4.1 registered claims**
 * (`iss`, `sub`, `aud`, `exp`, `nbf`, `iat`, `jti`). This is a deliberate
 * two-layer split, not an oversight:
 *  - The **JWT layer** ([ch.srg.login.sdk.auth.JwtValidationService]) already
 *    strips the registered claims from [JwtClaims.rawClaims] (they are surfaced
 *    via the typed `JwtClaims.iss/sub/aud/exp/nbf/iat/jti` fields). By the time
 *    this set is applied on the JWT path, those claims are already gone — so
 *    listing them here would be redundant and would duplicate the RFC 7519
 *    knowledge across two constants/layers.
 *  - This set's scope is therefore exactly "OIDC typed claims that *survive*
 *    into [JwtClaims.rawClaims]" (security + §5.1 profile claims).
 *
 * **Known consequence on the `/userinfo` path**: [UserInfo.Companion.fromUserInfoResponse]
 * parses the raw `/userinfo` JSON, which never passes through
 * `JwtValidationService`. The registered claims are therefore *not* stripped on
 * that path — notably `sub` (always present per OIDC §5.3.2) will also appear in
 * [UserInfo.rawClaims] there, alongside the typed [UserInfo.subject]. This is
 * accepted as-is: `sub` carries no extra information beyond `subject`, and
 * consumers read identity via the typed property. Documented here so it is a
 * known, deliberate trade-off rather than a silent inconsistency
 * (PR #83 review #6).
 */
internal val STANDARD_OIDC_TYPED_CLAIMS: Set<String> =
    setOf(
        // Security claims typed on IdTokenClaims
        "azp",
        "nonce",
        "auth_time",
        "sid",
        "acr",
        "amr",
        // Profile claims typed on UserInfo
        "name",
        "given_name",
        "family_name",
        "preferred_username",
        "picture",
        "locale",
        "updated_at",
        "email",
        "email_verified",
        "address",
        "phone_number",
        "phone_number_verified",
    )
