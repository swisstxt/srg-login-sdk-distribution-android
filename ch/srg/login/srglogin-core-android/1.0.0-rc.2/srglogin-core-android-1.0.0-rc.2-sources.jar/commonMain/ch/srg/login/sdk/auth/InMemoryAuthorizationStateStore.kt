package ch.srg.login.sdk.auth

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.datetime.Clock
import kotlin.time.Duration
import kotlin.time.Duration.Companion.minutes

/**
 * In-memory [AuthorizationStateStore] used on mobile / JVM.
 *
 * The full login runs in a single coroutine that stays alive across the browser hop
 * (Chrome Custom Tabs / `ASWebAuthenticationSession`), so an in-process map is all that
 * is required — this reproduces the previous behaviour where the PKCE verifier and nonce
 * were coroutine locals, while exposing the same seam the web target fills with a
 * `sessionStorage`-backed store.
 *
 * Transactions expire after [ttl] (mirrors the 5-minute auth-flow timeout); expired
 * entries are evicted lazily on [load]. Access is guarded by a [Mutex] so concurrent
 * logins (which use distinct `state` keys) can share one store safely.
 *
 * @property ttl How long a saved transaction remains valid. Defaults to 5 minutes.
 * @property clock Time source, injectable for tests.
 */
internal class InMemoryAuthorizationStateStore(
    private val ttl: Duration = DEFAULT_TTL,
    private val clock: Clock = Clock.System,
) : AuthorizationStateStore {
    private val mutex = Mutex()
    private val transactions = mutableMapOf<String, AuthorizationTransaction>()

    override suspend fun save(transaction: AuthorizationTransaction) {
        mutex.withLock {
            // Sweep expired entries: abandoned logins (back-button, cancel) never reload their
            // `state`, so without this they would accumulate for the app's lifetime.
            val now = clock.now()
            transactions.values.removeAll { now - it.createdAt > ttl }
            transactions[transaction.state] = transaction
        }
    }

    override suspend fun loadAndRemove(state: String): AuthorizationTransaction? =
        mutex.withLock {
            // Consume atomically under the Mutex: two concurrent completions with the same
            // `state` (double-mounted callback route) cannot both pass CSRF validation.
            val transaction = transactions.remove(state) ?: return@withLock null
            if (clock.now() - transaction.createdAt > ttl) {
                // Expired — treat as a miss (CSRF/replay signal to the caller).
                null
            } else {
                transaction
            }
        }

    override suspend fun remove(state: String) {
        mutex.withLock {
            transactions.remove(state)
        }
    }

    companion object {
        private val DEFAULT_TTL = 5.minutes
    }
}
