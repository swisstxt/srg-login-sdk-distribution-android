package ch.srg.login.sdk.auth.flows

import ch.srg.login.sdk.SrgLoginConfig
import ch.srg.login.sdk.auth.AuthorizationStateStore
import ch.srg.login.sdk.auth.AuthorizationTransaction
import ch.srg.login.sdk.auth.LoginMethod
import ch.srg.login.sdk.auth.LoginState
import ch.srg.login.sdk.auth.PlatformAuthContext
import ch.srg.login.sdk.auth.WebAuthCapable
import ch.srg.login.sdk.auth.WebAuthenticator
import ch.srg.login.sdk.auth.handler.LoginFailureEmitter
import ch.srg.login.sdk.auth.handler.TokenSuccessHandler
import ch.srg.login.sdk.data.OpenIdConfigRepository
import ch.srg.login.sdk.data.api.SrgAuthApiService
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.events.EventEmitter
import ch.srg.login.sdk.events.SdkLifecycleEvent
import ch.srg.login.sdk.internal.SecurityUtils
import ch.srg.login.sdk.logging.ErrorHandler
import ch.srg.login.sdk.logging.ErrorHandlerRegistry
import ch.srg.login.sdk.logging.LogCategory
import ch.srg.login.sdk.logging.SdkLogger
import ch.srg.login.sdk.model.OpenIdConfig
import ch.srg.login.sdk.result.SdkResult
import io.ktor.http.decodeURLQueryComponent
import io.ktor.http.encodeURLParameter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow

/**
 * Login flow for web-based OIDC authorization code flow with PKCE.
 *
 * Validates [LoginMethod.Web] + [WebAuthCapable] context, generates PKCE parameters,
 * builds authorization URL, launches browser, validates state (CSRF), exchanges code
 * for tokens, validates tokens, and delegates success/failure handling.
 *
 * The orchestration is split into two reusable halves around a persisted
 * [AuthorizationTransaction] (keyed by `state`):
 * - [beginAuthorization] builds the authorization URL and saves the transaction
 *   (PKCE verifier + nonce) to the [AuthorizationStateStore].
 * - [completeAuthorization] handles the IDP callback URL: it reloads the transaction
 *   by `state`, exchanges the code, validates the tokens, and clears the transaction.
 *
 * On mobile/JVM [login] composes `begin → authenticate → complete` inline within a
 * single coroutine (in-memory store; behaviour identical to before). The same two halves
 * let the web target drive `complete` from a `handleRedirect` entry point after a
 * full-page redirect, where the original coroutine no longer exists.
 */
@Suppress("LongParameterList")
internal class AuthorizationCodeFlow(
    private val config: SrgLoginConfig,
    private val openIdConfigRepository: OpenIdConfigRepository,
    private val authApiService: SrgAuthApiService,
    private val webAuthenticator: WebAuthenticator,
    private val securityUtils: SecurityUtils,
    private val authorizationStateStore: AuthorizationStateStore,
    private val tokenSuccessHandler: TokenSuccessHandler,
    private val loginFailureEmitter: LoginFailureEmitter,
    private val eventEmitter: EventEmitter,
) : LoginFlow,
    RedirectAuthorizationCompleter {
    companion object {
        private const val FLOW_ID_LENGTH = 6
    }

    /**
     * Completes a redirect-based authorization from a callback URL (web target), where the
     * original login coroutine no longer exists. Re-drives the second half of the flow,
     * reloading the persisted transaction by `state` from the [authorizationStateStore].
     *
     * Unlike [login], this standalone entry point is not wrapped in a Flow `.catch`, so it
     * carries its own error envelope: the token exchange runs an HTTP call with
     * `expectSuccess = true`, so a token-endpoint 4xx (the common `invalid_grant` on a
     * reloaded/replayed callback) throws. Without this, the JS Promise would reject with a raw
     * (unsanitized) Ktor exception, no `LoginFailure` would be emitted, and Sentry context
     * would be lost. Mirrors the Flow `.catch`: rethrow [CancellationException], map + capture
     * the error, and emit a terminal [LoginState.Failure]. Non-[Exception] throwables keep
     * propagating.
     */
    @Suppress("TooGenericExceptionCaught") // Intentional error envelope (see KDoc) — mirrors the Flow .catch.
    override suspend fun completeAuthorization(callbackUrl: String): LoginState {
        val flowId = newFlowId()
        return try {
            completeAuthorization(callbackUrl, flowId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            val error = openIdConfigRepository.mapExceptionToError(e)
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "complete_authorization",
                        "stage" to "unhandled_exception",
                        "error_type" to (e::class.simpleName ?: "Unknown"),
                        "error_mapped_to" to (error::class.simpleName ?: "Unknown"),
                    ),
                level = ErrorHandler.ErrorLevel.ERROR,
            )
            loginFailureEmitter.emit(error)
        }
    }

    /** Short, time-based id used to correlate the log lines of a single login attempt. */
    private fun newFlowId(): String =
        kotlinx.datetime.Clock.System
            .now()
            .toEpochMilliseconds()
            .toString()
            .takeLast(FLOW_ID_LENGTH)

    /** Outcome of [beginAuthorization]: either an authorization URL to launch, or a terminal failure state. */
    private sealed interface BeginResult {
        data class Started(
            val authUrl: String,
            /** The OAuth `state` key of the saved transaction, so the browser-failure path can clean it up. */
            val state: String,
        ) : BeginResult

        data class Failed(
            val state: LoginState,
        ) : BeginResult
    }

    /**
     * Executes the PKCE Authorization Code Flow: generates state (CSRF) + nonce (OIDC replay
     * defense) + PKCE parameters, builds the authorization URL, launches the browser,
     * validates state on callback, and exchanges the code for tokens.
     *
     * @param loginMethod Must be [LoginMethod.Web]; any other type returns [LoginState.Failure].
     * @param authContext Must be [WebAuthCapable]; TV contexts are rejected.
     */
    @Suppress("LongMethod")
    override fun login(
        loginMethod: LoginMethod,
        authContext: PlatformAuthContext,
        additionalScopes: List<String>,
        additionalParameters: Map<String, String>,
    ): Flow<LoginState> =
        flow {
            val flowId = newFlowId()
            SdkLogger.d(LogCategory.AUTHENTICATION) {
                "Login flow started (Flow-$flowId) with scopes: $additionalScopes, " +
                    "additionalParams: ${additionalParameters.keys}"
            }

            // Emit LoginStarted before validation — consistent with DeviceAuthorizationFlow and RopcFlow.
            // Ensures all 3 flows emit LoginStarted as the first action, so event observers (analytics,
            // monitoring) always see a LoginStarted regardless of whether subsequent validation passes.
            val loginStartedTimestamp =
                kotlinx.datetime.Clock.System
                    .now()
                    .toEpochMilliseconds()
            eventEmitter.tryEmit(SdkLifecycleEvent.LoginStarted(loginStartedTimestamp))

            // Validate login method type
            if (loginMethod !is LoginMethod.Web) {
                SdkLogger.d(LogCategory.AUTHENTICATION) { "Invalid login method type (Flow-$flowId)" }
                emit(
                    loginFailureEmitter.emit(
                        SrgLoginError.InvalidConfiguration("AuthorizationCodeFlow only supports the Web login method."),
                    ),
                )
                return@flow
            }

            // Validate platform context capabilities
            if (authContext !is WebAuthCapable) {
                SdkLogger.d(LogCategory.AUTHENTICATION) { "Invalid auth context - not WebAuthCapable (Flow-$flowId)" }
                emit(
                    loginFailureEmitter.emit(
                        SrgLoginError.InvalidConfiguration(
                            "Web authentication requires a WebAuthCapable context. " +
                                "TV platforms should use LoginMethod.Device instead of LoginMethod.Web.",
                        ),
                    ),
                )
                return@flow
            }

            SdkLogger.d(LogCategory.AUTHENTICATION) { "LoginMethod and context validated (Flow-$flowId)" }

            // 1-3. Fetch config, generate security params, build URL, persist the transaction.
            val begin = beginAuthorization(additionalScopes, additionalParameters, flowId)
            if (begin is BeginResult.Failed) {
                emit(begin.state)
                return@flow
            }
            val started = begin as BeginResult.Started
            val authUrl = started.authUrl

            SdkLogger.d(LogCategory.AUTHENTICATION) { "Opening browser for authentication (Flow-$flowId)" }

            // 4. Launch browser and await the callback (mobile: inline, same coroutine).
            when (val authResult = webAuthenticator.authenticate(authUrl, authContext)) {
                is SdkResult.Failure -> {
                    // The browser never delivered a callback (user cancel, browser error): the saved
                    // transaction will never be consumed by completeAuthorization, so remove it now
                    // rather than leaving it to expire (finding J: abandoned-login cleanup).
                    authorizationStateStore.remove(started.state)
                    captureBrowserError(authResult.error)
                    emit(loginFailureEmitter.emit(authResult.error))
                }

                is SdkResult.Success -> {
                    // 5. Handle the callback URL: state validation, code exchange, token handling.
                    emit(completeAuthorization(authResult.data, flowId))
                }
            }
        }.catch { e ->
            if (e is CancellationException) throw e
            val exception = e as? Exception ?: throw e
            val error = openIdConfigRepository.mapExceptionToError(exception)
            ErrorHandlerRegistry.captureException(
                throwable = exception,
                context =
                    mapOf(
                        "operation" to "login_flow",
                        "stage" to "unhandled_exception",
                        "error_type" to exception::class.simpleName,
                        "error_mapped_to" to error::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.ERROR,
            )
            emit(loginFailureEmitter.emit(error))
        }

    /**
     * First half of the flow: fetches the OpenID configuration, generates the PKCE pair,
     * `state`, and `nonce`, builds the authorization URL, and persists the
     * [AuthorizationTransaction] under `state` so [completeAuthorization] can reload it.
     *
     * @return [BeginResult.Started] with the URL to launch, or [BeginResult.Failed] if the
     *   OpenID configuration could not be fetched (the failure event is already emitted).
     */
    private suspend fun beginAuthorization(
        additionalScopes: List<String>,
        additionalParameters: Map<String, String>,
        flowId: String,
    ): BeginResult {
        // 1. Get OpenID Configuration
        val openIdConfig =
            when (val openIdConfigResult = openIdConfigRepository.getConfiguration()) {
                is SdkResult.Success -> {
                    openIdConfigResult.data
                }

                is SdkResult.Failure -> {
                    captureOpenIdConfigError(openIdConfigResult.error)
                    return BeginResult.Failed(loginFailureEmitter.emit(openIdConfigResult.error))
                }
            }

        // 2. Generate PKCE, state, and nonce
        val pkce = securityUtils.generatePkce()
        val state = securityUtils.generateState()
        val nonce = securityUtils.generateState()

        SdkLogger.d(LogCategory.AUTHENTICATION) {
            "Generated security params (Flow-$flowId): " +
                "state=[REDACTED], " +
                "nonce=[REDACTED], " +
                "code_verifier=[REDACTED], " +
                "code_challenge=[REDACTED]"
        }

        // 3. Build Authorization URL
        val authUrl =
            buildAuthorizationUrl(
                openIdConfig = openIdConfig,
                state = state,
                nonce = nonce,
                codeChallenge = pkce.codeChallenge,
                additionalScopes = additionalScopes,
                additionalParameters = additionalParameters,
                flowId = flowId,
            )

        val sanitizedUrl = SecurityUtils.sanitizeUrl(authUrl)
        SdkLogger.d(LogCategory.AUTHENTICATION) { "Authorization URL: $sanitizedUrl (Flow-$flowId)" }

        // Persist the transaction so the callback can reload the PKCE verifier + nonce by state.
        authorizationStateStore.save(
            AuthorizationTransaction(
                state = state,
                codeVerifier = pkce.codeVerifier,
                nonce = nonce,
                createdAt =
                    kotlinx.datetime.Clock.System
                        .now(),
            ),
        )

        return BeginResult.Started(authUrl = authUrl, state = state)
    }

    /**
     * Second half of the flow: handles the IDP callback URL.
     *
     * Re-fetches the OpenID configuration (so it is callable standalone — e.g. from the web
     * `handleRedirect` after a full-page redirect), parses the callback, reloads the
     * [AuthorizationTransaction] by `state` (a miss is the CSRF/replay rejection), exchanges
     * the authorization code, validates and persists the tokens, and clears the transaction.
     *
     * @return the terminal [LoginState] (success or failure); the corresponding lifecycle
     *   event has already been emitted by the time it returns.
     */
    @Suppress("ReturnCount", "CyclomaticComplexMethod", "LongMethod")
    private suspend fun completeAuthorization(
        callbackUrl: String,
        flowId: String,
    ): LoginState {
        val openIdConfig =
            when (val openIdConfigResult = openIdConfigRepository.getConfiguration()) {
                is SdkResult.Success -> {
                    openIdConfigResult.data
                }

                is SdkResult.Failure -> {
                    captureOpenIdConfigError(openIdConfigResult.error)
                    return loginFailureEmitter.emit(openIdConfigResult.error)
                }
            }

        val code = getQueryParameter(callbackUrl, "code")
        val receivedState = getQueryParameter(callbackUrl, "state")
        val oauthError = getQueryParameter(callbackUrl, "error")

        SdkLogger.d(LogCategory.AUTHENTICATION) {
            "Callback received (Flow-$flowId): " +
                "URL=${SecurityUtils.sanitizeUrl(callbackUrl)}, code=[REDACTED], " +
                "receivedStateIsNull=${receivedState == null}" +
                if (oauthError != null) ", oauthError=$oauthError" else ""
        }

        // 5a. Check for OAuth error response from IDP (RFC 6749 §4.1.2.1).
        // Must be checked before state validation: some IDPs omit `state` in error
        // responses, which would otherwise trigger a misleading CSRF alarm.
        if (oauthError != null) {
            val errorDescription = getQueryParameter(callbackUrl, "error_description")
            SdkLogger.d(LogCategory.AUTHENTICATION) {
                "IDP returned error response: $oauthError (Flow-$flowId)"
            }
            receivedState?.let { authorizationStateStore.remove(it) }
            return loginFailureEmitter.emit(
                SrgLoginError.InvalidDataError(
                    errorDescription ?: "Authorization failed: $oauthError",
                ),
            )
        }

        // 5b. Verify state (CSRF): reload AND consume the transaction saved in beginAuthorization.
        // loadAndRemove makes `state` single-use (RFC 6749 §10.12) — a replayed callback finds
        // nothing. A null state or an unknown/expired transaction means we never issued this state.
        val transaction = receivedState?.let { authorizationStateStore.loadAndRemove(it) }
        if (transaction == null) {
            SdkLogger.d(LogCategory.AUTHENTICATION) {
                "State validation FAILED - possible CSRF attack (Flow-$flowId)"
            }
            return loginFailureEmitter.emit(
                SrgLoginError.InvalidDataError(
                    "Invalid state received from callback. Possible CSRF attack.",
                ),
            )
        }

        SdkLogger.d(LogCategory.AUTHENTICATION) { "State validation SUCCESS (Flow-$flowId)" }

        if (code == null) {
            // Transaction already consumed by loadAndRemove above.
            return loginFailureEmitter.emit(
                SrgLoginError.InvalidDataError("Authorization code not found in callback URL."),
            )
        }

        // 5c. Exchange code for token
        val tokenResponse =
            authApiService.exchangeCodeForToken(
                tokenEndpoint = openIdConfig.tokenEndpoint,
                code = code,
                redirectUri = config.redirectUri,
                clientId = config.clientId,
                codeVerifier = transaction.codeVerifier,
            )

        // 5d. Validate tokens, persist, and emit success via shared handler.
        // The transaction was already consumed by loadAndRemove (finding J): consume-on-load
        // means no post-success remove is needed, and a cancellation between handle() and here
        // can no longer leave a still-replayable transaction behind.
        return tokenSuccessHandler.handle(
            tokenResponse = tokenResponse,
            clientId = config.clientId,
            issuer = openIdConfig.issuer,
            jwksUri = openIdConfig.jwksUri,
            nonce = transaction.nonce,
        )
    }

    /**
     * Builds the OAuth 2.0 / OIDC authorization request URL. Reserved OAuth parameters in
     * [additionalParameters] are ignored (logged) so callers cannot override the SDK's own
     * `client_id`, `state`, PKCE challenge, etc.
     */
    @Suppress("LongParameterList")
    private fun buildAuthorizationUrl(
        openIdConfig: OpenIdConfig,
        state: String,
        nonce: String,
        codeChallenge: String,
        additionalScopes: List<String>,
        additionalParameters: Map<String, String>,
        flowId: String,
    ): String {
        val allScopes = (listOf("openid") + additionalScopes).distinct()
        return buildString {
            append(openIdConfig.authorizationEndpoint)
            append("?client_id=${config.clientId}")
            // redirect_uri is a full URL on web (and may carry a query); scope is space-delimited.
            // Both must be percent-encoded as query-parameter values (RFC 6749 §3.1) — the existing
            // generated values (state/nonce/code_challenge) are already URL-safe base64url.
            // encodeURLParameter() has encodeURIComponent semantics: it percent-encodes reserved
            // delimiters (incl. `%`, `&`, `=`, `/`, `:`, space) and non-ASCII UTF-8, while leaving the
            // RFC 3986 unreserved set (`-._~`) intact; decodeURLQueryComponent() is the inverse.
            append("&redirect_uri=${config.redirectUri.encodeURLParameter()}")
            append("&response_type=code")
            append("&scope=${allScopes.joinToString(" ").encodeURLParameter()}")
            append("&state=$state")
            append("&nonce=$nonce")
            append("&code_challenge=$codeChallenge")
            append("&code_challenge_method=S256")

            val reservedParams =
                setOf(
                    "client_id",
                    "redirect_uri",
                    "response_type",
                    "state",
                    "nonce",
                    "code_challenge",
                    "code_challenge_method",
                    "scope",
                )
            val filteredParams =
                additionalParameters.filterKeys { key ->
                    val isReserved = key.lowercase() in reservedParams
                    if (isReserved) {
                        SdkLogger.d(LogCategory.AUTHENTICATION) {
                            "Ignoring reserved OAuth parameter '$key' in additionalParameters (Flow-$flowId)"
                        }
                    }
                    !isReserved
                }
            filteredParams.forEach { (key, value) ->
                if (value.isEmpty()) {
                    SdkLogger.d(LogCategory.AUTHENTICATION) {
                        "Ignoring parameter '$key' with empty value (Flow-$flowId)"
                    }
                } else {
                    append("&${key.encodeURLParameter()}=${value.encodeURLParameter()}")
                }
            }
        }
    }

    /** Reports a failure to fetch the OpenID configuration to the error handler. */
    private fun captureOpenIdConfigError(error: SrgLoginError) {
        ErrorHandlerRegistry.captureException(
            throwable =
                when (error) {
                    is SrgLoginError.NetworkError -> error.cause ?: Exception(error.details ?: "Network error")
                    is SrgLoginError.HttpError -> Exception("HTTP ${error.code}: ${error.message}")
                    else -> Exception(error.toString())
                },
            context =
                mapOf(
                    "operation" to "fetch_openid_config",
                    "stage" to "login_init",
                    "error_type" to error::class.simpleName,
                ),
            level = ErrorHandler.ErrorLevel.ERROR,
        )
    }

    /** Reports a browser/authentication failure to the error handler (cancellation is INFO, not ERROR). */
    private fun captureBrowserError(error: SrgLoginError) {
        ErrorHandlerRegistry.captureException(
            throwable =
                when (error) {
                    is SrgLoginError.UserCancelled -> Exception("User cancelled authentication")
                    is SrgLoginError.NetworkError -> error.cause ?: Exception(error.details ?: "Network error")
                    else -> Exception(error.toString())
                },
            context =
                mapOf(
                    "operation" to "browser_authentication",
                    "stage" to "login_browser",
                    "error_type" to error::class.simpleName,
                ),
            level =
                if (error is SrgLoginError.UserCancelled) {
                    ErrorHandler.ErrorLevel.INFO
                } else {
                    ErrorHandler.ErrorLevel.ERROR
                },
        )
    }

    /**
     * Extracts the named query parameter from [url] and URL-decodes its value.
     * Returns `null` if the parameter is absent or the URL has no query string.
     */
    private fun getQueryParameter(
        url: String,
        name: String,
    ): String? {
        // Strip the fragment BEFORE the query (RFC 3986: fragment always follows the query).
        // A hash-router SPA (Vue/Angular hash mode) rewrites the callback URL to append its
        // route (…?code=A&state=B#/home); without this, the last param would absorb "#/home"
        // and the state lookup would miss → a legitimate login misreported as a CSRF attack.
        // Scheme-agnostic: works for https and mobile custom-scheme deep links alike.
        val query = url.substringBefore('#').substringAfter('?', "")
        return query
            .split('&')
            .mapNotNull { pair ->
                val parts = pair.split('=', limit = 2)
                if (parts.size == 2 && parts[0] == name) {
                    parts[1].decodeURLQueryComponent()
                } else {
                    null
                }
            }.firstOrNull()
    }
}
