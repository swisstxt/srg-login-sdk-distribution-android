package ch.srg.login.sdk.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Represents the OpenID Connect Provider Metadata.
 *
 * Required fields follow OpenID Connect Discovery 1.0:
 * https://openid.net/specs/openid-connect-discovery-1_0.html
 *
 * Optional fields from RFC 8414 (OAuth 2.0 Authorization Server Metadata):
 * https://datatracker.ietf.org/doc/html/rfc8414
 */
@Serializable
internal data class OpenIdConfig(
    // --- REQUIRED (OpenID Connect Discovery 1.0) ---
    @SerialName("issuer")
    val issuer: String,
    @SerialName("authorization_endpoint")
    val authorizationEndpoint: String,
    @SerialName("jwks_uri")
    val jwksUri: String,
    @SerialName("response_types_supported")
    val responseTypesSupported: List<String>,
    @SerialName("subject_types_supported")
    val subjectTypesSupported: List<String>,
    @SerialName("id_token_signing_alg_values_supported")
    val idTokenSigningAlgValuesSupported: List<String>,
    // REQUIRED unless only Implicit Flow is used
    @SerialName("token_endpoint")
    val tokenEndpoint: String,
    // --- RECOMMENDED (OpenID Connect Discovery 1.0) ---
    @SerialName("userinfo_endpoint")
    val userInfoEndpoint: String? = null,
    @SerialName("registration_endpoint")
    val registrationEndpoint: String? = null,
    @SerialName("scopes_supported")
    val scopesSupported: List<String>? = null,
    @SerialName("claims_supported")
    val claimsSupported: List<String>? = null,
    // --- OPTIONAL (OpenID Connect Discovery 1.0) ---
    @SerialName("response_modes_supported")
    val responseModesSupported: List<String>? = null,
    @SerialName("grant_types_supported")
    val grantTypesSupported: List<String>? = null,
    @SerialName("acr_values_supported")
    val acrValuesSupported: List<String>? = null,
    @SerialName("token_endpoint_auth_methods_supported")
    val tokenEndpointAuthMethodsSupported: List<String>? = null,
    @SerialName("token_endpoint_auth_signing_alg_values_supported")
    val tokenEndpointAuthSigningAlgValuesSupported: List<String>? = null,
    @SerialName("id_token_encryption_alg_values_supported")
    val idTokenEncryptionAlgValuesSupported: List<String>? = null,
    @SerialName("id_token_encryption_enc_values_supported")
    val idTokenEncryptionEncValuesSupported: List<String>? = null,
    @SerialName("userinfo_signing_alg_values_supported")
    val userInfoSigningAlgValuesSupported: List<String>? = null,
    @SerialName("userinfo_encryption_alg_values_supported")
    val userInfoEncryptionAlgValuesSupported: List<String>? = null,
    @SerialName("userinfo_encryption_enc_values_supported")
    val userInfoEncryptionEncValuesSupported: List<String>? = null,
    @SerialName("request_object_signing_alg_values_supported")
    val requestObjectSigningAlgValuesSupported: List<String>? = null,
    @SerialName("request_object_encryption_alg_values_supported")
    val requestObjectEncryptionAlgValuesSupported: List<String>? = null,
    @SerialName("request_object_encryption_enc_values_supported")
    val requestObjectEncryptionEncValuesSupported: List<String>? = null,
    @SerialName("display_values_supported")
    val displayValuesSupported: List<String>? = null,
    @SerialName("claim_types_supported")
    val claimTypesSupported: List<String>? = null,
    @SerialName("claims_locales_supported")
    val claimsLocalesSupported: List<String>? = null,
    @SerialName("ui_locales_supported")
    val uiLocalesSupported: List<String>? = null,
    @SerialName("claims_parameter_supported")
    val claimsParameterSupported: Boolean? = null,
    @SerialName("request_parameter_supported")
    val requestParameterSupported: Boolean? = null,
    @SerialName("request_uri_parameter_supported")
    val requestUriParameterSupported: Boolean? = null,
    @SerialName("require_request_uri_registration")
    val requireRequestUriRegistration: Boolean? = null,
    @SerialName("service_documentation")
    val serviceDocumentation: String? = null,
    @SerialName("op_policy_uri")
    val opPolicyUri: String? = null,
    @SerialName("op_tos_uri")
    val opTosUri: String? = null,
    // --- OPTIONAL (Session Management) ---
    @SerialName("check_session_iframe")
    val checkSessionIframe: String? = null,
    @SerialName("end_session_endpoint")
    val endSessionEndpoint: String? = null,
    // --- OPTIONAL (RFC 8414 — OAuth 2.0 Authorization Server Metadata) ---
    @SerialName("revocation_endpoint")
    val revocationEndpoint: String? = null,
    @SerialName("revocation_endpoint_auth_methods_supported")
    val revocationEndpointAuthMethodsSupported: List<String>? = null,
    @SerialName("revocation_endpoint_auth_signing_alg_values_supported")
    val revocationEndpointAuthSigningAlgValuesSupported: List<String>? = null,
    @SerialName("introspection_endpoint")
    val introspectionEndpoint: String? = null,
    @SerialName("introspection_endpoint_auth_methods_supported")
    val introspectionEndpointAuthMethodsSupported: List<String>? = null,
    @SerialName("introspection_endpoint_auth_signing_alg_values_supported")
    val introspectionEndpointAuthSigningAlgValuesSupported: List<String>? = null,
    @SerialName("code_challenge_methods_supported")
    val codeChallengeMethodsSupported: List<String>? = null,
    // --- OPTIONAL (RFC 8628 — Device Authorization Grant) ---
    @SerialName("device_authorization_endpoint")
    val deviceAuthorizationEndpoint: String? = null,
    // --- OPTIONAL (Back-Channel Logout) ---
    @SerialName("backchannel_logout_supported")
    val backchannelLogoutSupported: Boolean? = null,
    // --- OPTIONAL (Provider-specific extensions) ---
    @SerialName("https://discovery.netid.de/properties/status_endpoint")
    val statusEndpoint: String? = null,
    @SerialName("social_provider_token_resolver_endpoint")
    val socialProviderTokenResolverEndpoint: String? = null,
    @SerialName("introspection_async_update_endpoint")
    val introspectionAsyncUpdateEndpoint: String? = null,
    @SerialName("scim_endpoint")
    val scimEndpoint: String? = null,
)
