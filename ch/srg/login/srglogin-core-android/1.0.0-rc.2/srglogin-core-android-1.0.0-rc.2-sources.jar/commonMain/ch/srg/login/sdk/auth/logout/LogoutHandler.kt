package ch.srg.login.sdk.auth.logout

import ch.srg.login.sdk.auth.LogoutResult
import ch.srg.login.sdk.auth.LogoutType
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.events.EventEmitter
import ch.srg.login.sdk.events.SdkLifecycleEvent
import ch.srg.login.sdk.events.StorageOperation
import ch.srg.login.sdk.token.TokenStorage
import kotlinx.datetime.Clock
import kotlin.coroutines.cancellation.CancellationException

/**
 * Abstract base class for logout handling using the Template Method pattern.
 *
 * Routes [LogoutType] to the appropriate handler, checking for capability support.
 * Subclasses gain additional logout methods by implementing capability interfaces
 * ([BackChannelLogoutCapable], [FrontChannelLogoutCapable]).
 *
 * The [performLocalLogout] method is shared by all handlers and capability interfaces.
 */
internal abstract class LogoutHandler(
    protected open val tokenStorage: TokenStorage,
    protected val eventEmitter: EventEmitter,
    protected val clock: Clock = Clock.System,
) {
    /**
     * Template method — routes by [LogoutType], checks capability, emits events.
     * Not open — subclasses customize behavior via capability interfaces.
     */
    suspend fun logout(logoutType: LogoutType): LogoutResult {
        emitLogoutStarted(logoutType)

        val result =
            when (logoutType) {
                is LogoutType.LocalOnly -> {
                    performLocalLogout()
                }

                is LogoutType.FrontChannel -> {
                    (this as? FrontChannelLogoutCapable)?.performFrontChannelLogout(logoutType)
                        ?: notSupported("FrontChannel")
                }

                is LogoutType.BackChannel -> {
                    (this as? BackChannelLogoutCapable)?.performBackChannelLogout(logoutType)
                        ?: notSupported("BackChannel")
                }
            }

        emitLogoutResult(logoutType, result)
        return result
    }

    /**
     * Clears local session state: removes stored tokens and emits [SdkLifecycleEvent.TokensCleared].
     * Declared in [BackChannelLogoutCapable] and [FrontChannelLogoutCapable] so capability interfaces
     * can call it directly without an unsafe cast.
     *
     * **Single funnel for all logout paths.** Every logout route reaches this method exactly once:
     * the `LocalOnly` route, [BackChannelLogoutCapable], [FrontChannelLogoutCapable], and the
     * Web/Tv handlers via the template method. So the cleanup below runs once per logout, uniformly,
     * on every path.
     *
     * **Scope expansion (LOGIN-1881, deliberate).** Before LOGIN-1881 this method cleared only the
     * tokens. It now *additionally* clears three secondary caches: the persisted `UserInfo` profile
     * snapshot, the anti-replay JWT-ID cache, and the refresh-token rotation metadata. This is **not**
     * a duplicate of clears happening elsewhere — the only other call sites are unrelated triggers
     * (`TokenManagerImpl.clearAllTokensAndMetadata()` on a *terminal refresh failure*, and
     * `ReplayAttackCache.clear()` for cache maintenance), never the logout flow. Each clear is an
     * idempotent key-removal wrapped in [bestEffortClear], so running it redundantly is a safe no-op
     * and a secondary-cache failure never fails the logout (tokens already gone = effectively logged
     * out). Reviewed in PR #83 (review #3).
     */
    suspend fun performLocalLogout(): LogoutResult {
        // Tokens clearing is the critical operation — its result drives the LogoutResult.
        val clearResult = tokenStorage.clearTokens()

        // Best-effort cleanup of secondary caches/metadata (LOGIN-1881 audit β):
        // - UserInfo: profile cache (`srgLogin.getUserInfo()` should not see stale data after logout)
        // - JwtIds: anti-replay cache for back-channel logout tokens (irrelevant once logged out)
        // - RefreshTokenMetadata: rotation/usage monitoring (no value once tokens are gone)
        // These are intentionally swallowed: the user is effectively logged out as soon as
        // tokens are cleared. Both a returned Result.failure AND a thrown exception are
        // treated as failure (via getOrThrow) and ignored. CancellationException is rethrown
        // so coroutine cancellation still propagates (structured concurrency).
        // Production impls already capture their own failures via Sentry.
        bestEffortClear { tokenStorage.clearUserInfo() }
        bestEffortClear { tokenStorage.clearJwtIds() }
        bestEffortClear { tokenStorage.clearRefreshTokenMetadata() }

        return if (clearResult.isSuccess) {
            val timestamp = clock.now().toEpochMilliseconds()
            eventEmitter.tryEmit(
                SdkLifecycleEvent.TokensCleared(
                    reason = "logout",
                    timestamp = timestamp,
                ),
            )
            LogoutResult.Success(
                clearedLocalSession = true,
                terminatedServerSession = false,
            )
        } else {
            val storageException = clearResult.exceptionOrNull() ?: Exception("Failed to clear local tokens")
            val storageError = SrgLoginError.UnknownError(storageException)
            eventEmitter.tryEmit(
                SdkLifecycleEvent.StorageError(
                    operation = StorageOperation.CLEAR,
                    error = storageError,
                    timestamp = clock.now().toEpochMilliseconds(),
                ),
            )
            LogoutResult.Failure(
                clearedLocalSession = false,
                serverLogoutAttempted = false,
                error = storageError,
            )
        }
    }

    /** Emits [SdkLifecycleEvent.LogoutStarted] with the current timestamp. */
    private fun emitLogoutStarted(logoutType: LogoutType) {
        val timestamp = clock.now().toEpochMilliseconds()
        eventEmitter.tryEmit(SdkLifecycleEvent.LogoutStarted(logoutType, timestamp))
    }

    /** Emits [SdkLifecycleEvent.LogoutSuccess] or [SdkLifecycleEvent.LogoutFailure] based on [result]. */
    private fun emitLogoutResult(
        logoutType: LogoutType,
        result: LogoutResult,
    ) {
        val timestamp = clock.now().toEpochMilliseconds()
        when (result) {
            is LogoutResult.Success -> {
                eventEmitter.tryEmit(SdkLifecycleEvent.LogoutSuccess(logoutType, timestamp))
            }

            is LogoutResult.Failure -> {
                eventEmitter.tryEmit(SdkLifecycleEvent.LogoutFailure(result.error, timestamp))
            }
        }
    }

    /**
     * Runs a best-effort secondary-cache clear during local logout.
     *
     * A returned [Result.failure] is promoted to a thrown exception via [Result.getOrThrow]
     * so it is handled consistently with impls that throw directly. All such failures are
     * swallowed (production impls already report via Sentry). [CancellationException] is
     * rethrown so coroutine cancellation propagates correctly (structured concurrency).
     */
    private suspend fun bestEffortClear(clear: suspend () -> Result<Unit>) {
        try {
            clear().getOrThrow()
        } catch (e: CancellationException) {
            throw e
        } catch (_: Throwable) {
            // Best-effort: secondary cache only — user is already logged out.
        }
    }

    /** Returns [LogoutResult.Failure] with [SrgLoginError.InvalidConfiguration] for unsupported logout types. */
    private fun notSupported(type: String): LogoutResult =
        LogoutResult.Failure(
            clearedLocalSession = false,
            serverLogoutAttempted = false,
            error =
                SrgLoginError.InvalidConfiguration(
                    "$type logout is not supported on this platform.",
                ),
        )
}
