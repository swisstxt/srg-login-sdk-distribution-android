package ch.srg.login.sdk.model

import kotlinx.datetime.Clock
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.longOrNull

/**
 * Validated claims from an OIDC ID Token (JWT payload) — **auth-proof claims only**.
 *
 * Represents the security-relevant claims that prove **how, when, and for whom** the
 * session was opened: issuer, audience, expiration, nonce, authorized party,
 * authentication time, session id, ACR / AMR. Profile claims (`name`, `email`,
 * `picture`, `address`, `phone_number`, …) are NOT exposed here since LOGIN-1881 —
 * they live on [UserInfo], which is refreshable at any time via
 * `srgLogin.getUserInfo()`. The split mirrors the OIDC protocol model: §3.1.3.7 ID
 * Token validation is about auth proof, §5.3 UserInfo endpoint is about profile
 * state. (LOGIN-1881)
 *
 * **Validation gate enforced at the type system level**: the primary constructor
 * is `internal`, and [@ConsistentCopyVisibility][kotlin.ConsistentCopyVisibility]
 * propagates that visibility to the generated `copy()` method. Consumers therefore
 * cannot construct or mutate an [IdTokenClaims] from outside the SDK — the only
 * way to obtain an instance is via [TokenSet.idTokenClaims], which the SDK
 * populates only after successful cryptographic validation (signature, issuer,
 * audience, expiration, nonce, azp). The existence of an instance is a
 * compile-time-checked proof of validation. (PR #77 review #8)
 *
 * Standard OIDC §2 ID Token claims are exposed as typed properties. Non-standard
 * or IDP-specific claims (custom audit/auth-context extensions) are available via
 * [rawClaims], using the type-safe accessors inherited from [ClaimContainer]
 * (`getStringClaim`, `getLongClaim`, `getBooleanClaim`, `getStringListClaim`,
 * `getObjectClaim`, `getArrayClaim`, `hasCustomClaim`).
 *
 * **Cross-platform note:** [rawClaims] uses the SDK's own [ClaimValue] sealed
 * class instead of `kotlinx.serialization.json.JsonElement`. This keeps the
 * public API platform-agnostic — Swift consumers (iOS, tvOS) get a native `enum`
 * via SKIE, TypeScript consumers via Kotlin/JS get a clean discriminated union,
 * and Java consumers get sealed-class pattern matching. (PR #77 review #4)
 *
 * For end-user profile information (display name, email, picture, …) see [UserInfo].
 */
@ConsistentCopyVisibility
public data class IdTokenClaims internal constructor(
    /** Issuer Identifier — URL of the IDP that issued the token (`iss` claim). Always present. */
    val issuer: String,
    /** Stable, non-reassigned subject identifier of the authenticated user (`sub` claim). Always present. */
    val subject: String,
    /**
     * Audience(s) the token is intended for (`aud` claim, normalized to a list per RFC 7519 §4.1.3).
     * For multi-audience tokens, the SDK additionally enforces OIDC §3.1.3.7 azp validation.
     */
    val audience: List<String>,
    /** Expiration time (`exp` claim) as epoch seconds. Always present. */
    val expiresAt: Long,
    /** Issuance time (`iat` claim) as epoch seconds. Always present. */
    val issuedAt: Long,
    /**
     * Authorized Party (`azp` claim) — client_id of the party the token was issued to.
     * Required by OIDC §3.1.3.7 when [audience] contains more than one value.
     */
    val authorizedParty: String? = null,
    /**
     * String value used to associate a Client session with an ID Token (`nonce` claim).
     * Validated by the SDK against the nonce sent in the authorization request.
     */
    val nonce: String? = null,
    /**
     * Time when the End-User authenticated (`auth_time` claim) as epoch seconds.
     * Useful for re-authentication policies (e.g. step-up authentication).
     */
    val authTime: Long? = null,
    /**
     * Session identifier (`sid` claim) used for back-channel and front-channel logout.
     */
    val sessionId: String? = null,
    /**
     * Authentication Context Class Reference (`acr` claim) — assurance level
     * (e.g. `urn:mace:incommon:iap:silver`).
     */
    val acr: String? = null,
    /**
     * Authentication Methods References (`amr` claim) — methods used for authentication
     * (e.g. `["pwd", "mfa"]`). Values are IDP-specific (RFC 8176 is extensible).
     */
    val amr: List<String>? = null,
    /**
     * IDP-specific or non-standard claims preserved as [ClaimValue] (lossless, platform-agnostic).
     * Standard OIDC §2 ID Token claims and §5.1 profile claims (the latter typed on [UserInfo])
     * are filtered out here so consumers see them in exactly one place. Access via the typed
     * accessors inherited from [ClaimContainer].
     */
    override val rawClaims: Map<String, ClaimValue> = emptyMap(),
) : ClaimContainer {
    // ===== Expiration =====

    /**
     * `true` if the ID token is expired according to the system clock (no clock skew tolerance).
     * For TV / set-top devices with potentially unsynchronized clocks, prefer [isExpiredWithSkew] with a tolerance.
     */
    val isExpired: Boolean
        get() = Clock.System.now().epochSeconds >= expiresAt

    /**
     * Returns `true` if the ID token is expired, applying [clockSkewSeconds] of tolerance.
     * Default tolerance is 30 seconds — recommended for devices that may have
     * clock drift (TV / set-top boxes).
     *
     * Named distinctly from the [isExpired] property to avoid the silent property-vs-function
     * call ambiguity (`claims.isExpired` strict vs `claims.isExpired()` 30s tolerance) that
     * arises when both share the same identifier.
     *
     * This extends the acceptance window **after** the nominal [expiresAt] — it accepts the ID
     * token as still valid for up to [clockSkewSeconds] seconds after it appears expired, to
     * tolerate a device clock that runs fast.
     *
     * For **proactive refresh** (refresh before tokens expire), use the access token instead:
     * `if (tokenSet.accessToken.expiresIn < 30) refresh()`. ID-token expiry is not the
     * appropriate trigger for refresh — the access token drives session lifetime.
     */
    public fun isExpiredWithSkew(clockSkewSeconds: Long = 30): Boolean {
        val now = Clock.System.now().epochSeconds
        return now >= expiresAt + clockSkewSeconds
    }

    // ===== Session =====

    /**
     * Duration in seconds since the user authenticated, derived from [authTime].
     * `null` if [authTime] is absent (the IDP did not include it).
     */
    val sessionAge: Long?
        get() = authTime?.let { Clock.System.now().epochSeconds - it }

    // ===== Audience =====

    /**
     * Returns `true` if [clientId] is one of the granted audiences.
     */
    public fun hasAudience(clientId: String): Boolean = clientId in audience

    // Type-safe accessors for non-standard claims (getStringClaim, getLongClaim, …)
    // are inherited from [ClaimContainer].

    internal companion object {
        /**
         * Creates an [IdTokenClaims] instance from already-validated [JwtClaims].
         *
         * INTERNAL: only called by the SDK after successful OIDC validation
         * (`JwtValidationService.validateIdToken`). The required claims
         * (iss, sub, aud, exp, iat) are dereferenced unsafely (`!!`) — if any are
         * absent, upstream validation has a bug and a NullPointerException is
         * preferable to silent data corruption.
         *
         * Only auth-proof claims (OIDC §2) are pulled out as typed properties.
         * Profile claims (`name`, `email`, `picture`, `address`, `phone_number`, …)
         * are typed on [UserInfo] instead — built from the same [JwtClaims] in
         * parallel by [TokenSet.fromDto]. All standard OIDC typed claims (security
         * and profile) are filtered out of [IdTokenClaims.rawClaims] via
         * [STANDARD_OIDC_TYPED_CLAIMS], so consumers see each claim in exactly one
         * place. The conversion `JsonElement → ClaimValue` happens here, at the
         * public-API boundary, so kotlinx-serialization types never leak out of
         * the SDK.
         */
        internal fun fromJwtClaims(jwtClaims: JwtClaims): IdTokenClaims {
            val raw = jwtClaims.rawClaims
            return IdTokenClaims(
                // Required claims (validated upstream — non-null guaranteed)
                issuer = jwtClaims.iss!!,
                subject = jwtClaims.sub!!,
                audience = jwtClaims.aud,
                expiresAt = jwtClaims.exp!!,
                issuedAt = jwtClaims.iat!!,
                // Security claims
                authorizedParty = jwtClaims.stringClaim("azp"),
                nonce = jwtClaims.stringClaim("nonce"),
                authTime = (raw["auth_time"] as? JsonPrimitive)?.takeIf { !it.isString }?.longOrNull,
                sessionId = jwtClaims.stringClaim("sid"),
                acr = jwtClaims.stringClaim("acr"),
                amr = extractStringList(raw["amr"]),
                // Drop standard typed claims so consumers don't see duplicates, and convert
                // remaining JsonElement values to platform-agnostic ClaimValue at the boundary.
                rawClaims =
                    raw
                        .filterKeys { it !in STANDARD_OIDC_TYPED_CLAIMS }
                        .mapValues { (_, value) -> value.toClaimValue() },
            )
        }

        private fun extractStringList(element: JsonElement?): List<String>? =
            (element as? JsonArray)?.mapNotNull { item ->
                (item as? JsonPrimitive)?.takeIf { it.isString }?.content
            }
    }
}

/**
 * Converts a kotlinx-serialization [JsonElement] to the SDK's platform-agnostic [ClaimValue].
 *
 * Internal — the SDK applies this once at the [IdTokenClaims.fromJwtClaims] boundary so that
 * kotlinx-serialization types never appear in the public API.
 *
 * Type mapping:
 * - [JsonNull] → [ClaimValue.Null]
 * - JSON string primitive → [ClaimValue.Text]
 * - JSON boolean primitive (`true` / `false`) → [ClaimValue.Bool]
 * - JSON integer primitive (parses as Long) → [ClaimValue.Integer]
 * - JSON fractional / out-of-Long-range numeric → [ClaimValue.Decimal]
 * - [JsonArray] → [ClaimValue.Array] (recursively converted)
 * - [JsonObject] → [ClaimValue.Object] (recursively converted)
 *
 * The check order on [JsonPrimitive] matters: `isString` must be checked first to prevent
 * `kotlinx.serialization`'s lenient `booleanOrNull` / `longOrNull` from coercing JSON-string
 * `"true"` or `"42"` into the corresponding non-string ClaimValue branch.
 */
internal fun JsonElement.toClaimValue(): ClaimValue =
    when (this) {
        is JsonNull -> {
            ClaimValue.Null
        }

        is JsonPrimitive -> {
            when {
                this.isString -> ClaimValue.Text(this.content)
                this.content == "true" -> ClaimValue.Bool(true)
                this.content == "false" -> ClaimValue.Bool(false)
                this.longOrNull != null -> ClaimValue.Integer(this.longOrNull!!)
                this.doubleOrNull != null -> ClaimValue.Decimal(this.doubleOrNull!!)
                else -> ClaimValue.Text(this.content)
            }
        }

        is JsonArray -> {
            ClaimValue.Array(this.map { it.toClaimValue() })
        }

        is JsonObject -> {
            ClaimValue.Object(this.mapValues { (_, v) -> v.toClaimValue() })
        }
    }
