package ch.srg.login.sdk.auth

import kotlinx.datetime.Instant

/**
 * The in-flight state of a single authorization-code-flow login attempt.
 *
 * This is the data that must survive between launching the authorization request
 * (`beginAuthorization`) and handling the IDP callback (`completeAuthorization`),
 * keyed by the OAuth 2.0 `state` parameter (RFC 6749 §10.12):
 * - [codeVerifier]: the PKCE verifier (RFC 7636) needed to exchange the auth code.
 * - [nonce]: the OIDC nonce used to validate the returned ID token against replay.
 * - [createdAt]: issue time, used by stores to expire stale transactions.
 *
 * On mobile/JVM the whole login runs in a single coroutine, so today this lives in
 * local variables. The store abstraction exists so that on the web — where a full-page
 * redirect destroys the page and that coroutine — the transaction can be persisted
 * (sessionStorage) and reloaded when the IDP redirects back.
 *
 * @property state The OAuth 2.0 `state` parameter; the key under which this transaction is stored.
 * @property codeVerifier The PKCE `code_verifier` (kept secret until the token exchange).
 * @property nonce The OIDC `nonce` echoed back in the ID token for replay protection.
 * @property createdAt When the transaction was created (for TTL/expiry).
 */
internal data class AuthorizationTransaction(
    val state: String,
    val codeVerifier: String,
    val nonce: String,
    val createdAt: Instant,
)

/**
 * Pluggable store for [AuthorizationTransaction]s, keyed by the OAuth 2.0 `state`.
 *
 * Decouples *what is remembered between request and callback* from *how the callback
 * is delivered*:
 * - **mobile / JVM**: an in-memory store ([InMemoryAuthorizationStateStore]); the
 *   callback is delivered inline to the still-alive login coroutine. Equivalent to the
 *   previous behaviour where these values were coroutine locals.
 * - **web** (future, LOGIN-1734): a `sessionStorage`-backed store; the callback arrives
 *   on page reload via `handleRedirect`, where [load] re-hydrates the transaction.
 *
 * A [load] returning `null` (unknown or expired `state`) is the CSRF / replay rejection
 * signal for the caller — it means the SDK never issued that `state`, or it has expired.
 *
 * Implementations must be safe to call concurrently (independent logins use distinct
 * `state` keys, but the backing storage is shared).
 */
internal interface AuthorizationStateStore {
    /**
     * Persists [transaction] under its [AuthorizationTransaction.state]. Implementations may
     * also sweep expired entries here (abandoned logins never reload their `state`, so lazy
     * per-key eviction alone would let them accumulate). May throw if the backing storage
     * rejects the write (e.g. web `sessionStorage` unavailable/full) — callers run under the
     * login flow's error envelope; the in-memory implementation cannot fail.
     */
    suspend fun save(transaction: AuthorizationTransaction)

    /**
     * Atomically returns **and removes** the transaction previously saved under [state], or
     * `null` if no such transaction exists or it has expired. The OAuth `state` is single-use
     * (RFC 6749 §10.12): a completed or replayed callback finds nothing, and a retry after a
     * failed exchange is a brand-new login with a fresh `state`. A `null` result is the
     * CSRF/replay signal.
     */
    suspend fun loadAndRemove(state: String): AuthorizationTransaction?

    /** Removes the transaction stored under [state], if any. Safe to call for unknown states. */
    suspend fun remove(state: String)
}
