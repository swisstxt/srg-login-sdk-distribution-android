package ch.srg.login.sdk

internal object SdkBuildConfig {
    const val VERSION: String = "1.0.0-rc.2"
    const val GROUP: String = "ch.srg.login"
}
