package ch.srg.login.sdk

import ch.srg.login.sdk.auth.AuthenticationManager
import ch.srg.login.sdk.auth.TokenManager
import ch.srg.login.sdk.auth.UserInfoService
import ch.srg.login.sdk.auth.UserInfoServiceImpl
import ch.srg.login.sdk.config.SdkSentryConfig
import ch.srg.login.sdk.crypto.CryptoService
import ch.srg.login.sdk.data.OpenIdConfigRepository
import ch.srg.login.sdk.di.sdkModule
import ch.srg.login.sdk.events.EventEmitter
import ch.srg.login.sdk.internal.PlatformInfo
import ch.srg.login.sdk.internal.SecurityUtils
import ch.srg.login.sdk.lifecycle.AppLifecycleObserver
import ch.srg.login.sdk.logging.ErrorHandlerRegistry
import ch.srg.login.sdk.logging.LogCategory
import ch.srg.login.sdk.logging.LogSeverity
import ch.srg.login.sdk.logging.SdkErrorReporter
import ch.srg.login.sdk.logging.SdkLogger
import ch.srg.login.sdk.logging.TelemetryContext
import ch.srg.login.sdk.logging.UserContextMode
import ch.srg.login.sdk.token.TokenStorageConfig
import io.ktor.client.HttpClient
import org.koin.core.Koin
import org.koin.core.KoinApplication
import org.koin.core.parameter.parametersOf
import org.koin.dsl.koinApplication
import kotlin.uuid.ExperimentalUuidApi
import kotlin.uuid.Uuid

/**
 * Internal core implementation of the SRG Login SDK.
 *
 * This object manages the SDK's internal lifecycle, including:
 * - Koin dependency injection container initialization
 * - SdkLogger initialization with platform information
 * - SDK instance creation and management
 * - Resource cleanup
 *
 * ## Why is this internal?
 *
 * This API exposes low-level configuration options (like Koin debug logging)
 * that are only useful for SDK developers during internal testing and debugging.
 * Application developers should use [SrgLoginSdk] instead, which provides
 * a clean, stable public API.
 *
 * ## Design Rationale
 *
 * **Separation of Concerns:**
 * - [SrgLoginSdk] = Public facade (simple, stable API for SDK users)
 * - [SdkCore] = Internal implementation (flexible, detailed control for SDK developers)
 *
 * This separation allows:
 * 1. ✅ Clean public API without confusing parameters
 * 2. ✅ Full control for SDK developers in tests (e.g., enabling Koin debug logs)
 * 3. ✅ API evolution without breaking changes
 * 4. ✅ Clear distinction between public contract and internal implementation
 *
 * ## Visibility Rules (Kotlin Multiplatform)
 *
 * **`internal` visibility means:**
 * - ✅ Accessible anywhere in `srglogin-core` module (production code + tests)
 * - ❌ Not accessible from app modules (compilation error)
 *
 * **Example Usage:**
 * ```kotlin
 * // ✅ In SDK tests (srglogin-core/src/commonTest/)
 * SdkCore.initialize(
 *     enableKoinDebugLogging = true,  // Enable DI debug logs for testing
 *     platformContext = mockContext,
 *     isDebugBuild = true
 * )
 *
 * // ❌ In app module (app/src/main/)
 * SdkCore.initialize(...)  // Compilation error: Cannot access 'internal' in different module
 * ```
 *
 * ## Logging Configuration
 *
 * This class distinguishes between two types of debug logging:
 *
 * ### 1. Koin Debug Logging (`enableKoinDebugLogging`)
 * - **Purpose**: Internal dependency injection framework logs
 * - **Example**: `"[Koin] : inject instance for 'SecurityUtils'"`
 * - **Use Case**: SDK developers debugging DI container issues
 * - **User Value**: None (internal implementation detail)
 * - **Public API**: Hidden (always `false`)
 *
 * ### 2. SDK Application Logging (`isDebugBuild`)
 * - **Purpose**: SDK business logic and OAuth flow logs
 * - **Example**: `"INFO [TOKEN_MONITORING] Token state changed: ExpiringSoon"`
 * - **Use Case**: SDK users troubleshooting authentication flows
 * - **User Value**: High (helps debug OAuth, tokens, network issues)
 * - **Public API**: Exposed via [SrgLoginSdk.initialize]
 *
 * @since 1.0.0
 * @see SrgLoginSdk The public API facade for SDK users
 */
internal object SdkCore {
    /**
     * Internal Koin application instance.
     *
     * **Lifecycle:**
     * - `null` = SDK not initialized
     * - `!= null` = SDK initialized and ready
     *
     * **Thread Safety**: This is accessed only during SDK initialization,
     * which should happen once at app startup on the main thread.
     */
    private var koinApp: KoinApplication? = null

    /**
     * Initializes the SDK's internal infrastructure.
     *
     * This method sets up:
     * 1. Koin dependency injection container
     * 2. SdkLogger with platform information
     * 3. Platform-specific components (token storage, crypto, etc.)
     *
     * **Idempotency**: Calling this multiple times is safe (no-op after first call).
     *
     * @param enableKoinDebugLogging If `true`, enables Koin DI framework debug logs.
     *   **For SDK developers only** (e.g., debugging DI issues in tests).
     *   Defaults to `false` in public API.
     *
     * @param tokenStorageConfig Configuration for secure token storage.
     *   Defaults to [TokenStorageConfig.default()].
     *
     * @param platformContext Platform-specific context required for initialization:
     *   - **Android**: `Context` (typically `ApplicationContext`)
     *   - **iOS**: Not required (pass `null`)
     *   - **JVM**: Not required (pass `null`)
     *   - **JS**: Not required (pass `null`)
     *
     * @param isDebugBuild If `true`, sets SDK logging to DEBUG level (all logs visible).
     *   If `false`, sets SDK logging to INFO level (only INFO/WARNING/ERROR/ASSERT visible).
     *   **Recommendation**: Pass `BuildConfig.DEBUG` on Android, equivalent on other platforms.
     *
     * @throws IllegalArgumentException If platform requirements are not met
     *   (e.g., missing `Context` on Android).
     *
     * @see SrgLoginSdk.initialize Public API wrapper (hides `enableKoinDebugLogging`)
     */
    internal fun initialize(
        enableKoinDebugLogging: Boolean = false,
        tokenStorageConfig: TokenStorageConfig = TokenStorageConfig(),
        platformContext: Any? = null,
        isDebugBuild: Boolean = false,
    ) {
        // Idempotency: Only initialize once
        if (koinApp != null) {
            return
        }

        // Validate platform-specific requirements
        validatePlatformRequirements(platformContext)

        // Initialize Koin DI container
        koinApp =
            koinApplication {
                // Enable Koin debug logging if requested (SDK developers only)
                if (enableKoinDebugLogging) {
                    printLogger()
                }

                // Declare token storage configuration
                koin.declare(tokenStorageConfig)

                // Declare platform context (Android requires ApplicationContext)
                platformContext?.let { context ->
                    declarePlatformContext(koin, context)
                }

                // Load SDK modules (generated by Koin KSP)
                modules(sdkModule)
            }

        // Initialize SdkLogger with platform information
        initializeSdkLogger(isDebugBuild)
    }

    /**
     * Creates a new [SrgLogin] instance with the given configuration.
     *
     * **Prerequisite**: [initialize] must be called first, otherwise this will throw an exception.
     *
     * This method resolves all required dependencies from the Koin DI container and
     * constructs a fully-configured [SrgLogin] instance with:
     * - Shared EventEmitter (for authentication, token, and lifecycle events)
     * - Shared OpenIdConfigRepository (for OIDC discovery)
     * - AuthenticationManager (for login/logout operations)
     * - TokenManager (for token lifecycle and automatic refresh)
     * - AppLifecycleObserver (for platform-specific lifecycle hooks)
     *
     * @param config The OAuth 2.0/OIDC configuration for this SDK instance.
     *   Each [SrgLogin] instance is isolated (separate Koin scope, separate event bus).
     *
     * @return A new [SrgLogin] instance ready for authentication operations.
     *
     * @throws IllegalStateException If SDK is not initialized.
     *
     * @see SrgLoginSdk.create Public API wrapper
     */
    internal fun create(config: SrgLoginConfig): SrgLogin {
        SdkLogger.i(LogCategory.SDK_CREATION) { "SrgLogin instance creation started" }

        val koin =
            requireNotNull(koinApp?.koin) {
                "SRG Login SDK is not initialized. Call SrgLoginSdk.initialize() first."
            }

        // Resolve shared dependencies ONCE to avoid duplication
        SdkLogger.d(LogCategory.SDK_CREATION) { "Resolving shared dependencies..." }

        // EventEmitter - ONE instance shared across AuthenticationManager, TokenManager, AppLifecycleObserver
        val eventEmitter: EventEmitter = koin.get()
        SdkLogger.d(LogCategory.SDK_CREATION) { "EventEmitter resolved (hashCode=${eventEmitter.hashCode()})" }

        // OpenIdConfigRepository - ONE instance shared across AuthenticationManager and TokenManager
        val openIdConfigRepository: OpenIdConfigRepository =
            koin.get { parametersOf(config) }
        SdkLogger.d(LogCategory.SDK_CREATION) { "OpenIdConfigRepository resolved (hashCode=${openIdConfigRepository.hashCode()})" }

        // Get AuthenticationManager with shared dependencies
        SdkLogger.d(LogCategory.SDK_CREATION) { "Resolving AuthenticationManager..." }
        val authManager: AuthenticationManager =
            koin.get { parametersOf(config, openIdConfigRepository, eventEmitter) }
        SdkLogger.d(LogCategory.SDK_CREATION) { "AuthenticationManager resolved (hashCode=${authManager.hashCode()})" }

        // Get TokenManager with shared dependencies
        SdkLogger.d(LogCategory.SDK_CREATION) { "Resolving TokenManager..." }
        val tokenManager: TokenManager =
            koin.get { parametersOf(config, openIdConfigRepository, eventEmitter) }
        SdkLogger.d(LogCategory.SDK_CREATION) { "TokenManager resolved (hashCode=${tokenManager.hashCode()})" }

        // Construct UserInfoService inline — all its deps are already resolved
        // locally (tokenManager, openIdConfigRepository), and the singles
        // (SrgAuthApiService, TokenStorage) are pulled via koin.get(). No Koin
        // binding is needed: this service is constructed once per SrgLogin
        // instance and lives inside the facade. (LOGIN-1881 Block E)
        val userInfoService: UserInfoService =
            UserInfoServiceImpl(
                tokenManager = tokenManager,
                apiService = koin.get(),
                tokenStorage = koin.get(),
                openIdConfigRepository = openIdConfigRepository,
            )
        SdkLogger.d(LogCategory.SDK_CREATION) { "UserInfoService resolved (hashCode=${userInfoService.hashCode()})" }

        // Get AppLifecycleObserver with shared dependencies
        // IMPORTANT: Pass already-resolved tokenManager and eventEmitter to avoid duplicates
        SdkLogger.d(LogCategory.SDK_CREATION) { "Resolving AppLifecycleObserver..." }
        val lifecycleObserver: AppLifecycleObserver =
            koin.get { parametersOf(tokenManager, eventEmitter) }
        SdkLogger.d(LogCategory.SDK_CREATION) { "AppLifecycleObserver resolved (hashCode=${lifecycleObserver.hashCode()})" }

        val srgLogin = SrgLogin(config, authManager, tokenManager, userInfoService, lifecycleObserver)
        SdkLogger.i(LogCategory.SDK_CREATION) { "SrgLogin instance created (hashCode=${srgLogin.hashCode()})" }

        // Initialize internal error tracking (if DSN available for this environment)
        initializeErrorTracking(koin, config)

        // Note: TokenManagerImpl performs its initial state evaluation in its own init {}
        // block (via monitoringScope.launch { emitCurrentStateFromStorage() }), replacing
        // TokenState.Uninitialized with a real state. No event emission needed here.

        return srgLogin
    }

    /**
     * Shuts down the SDK and releases all resources.
     *
     * **WARNING**: After calling this:
     * - All existing [SrgLogin] instances become invalid
     * - You must call [initialize] again before creating new instances
     *
     * **Use Case**: Testing scenarios where you need to reset SDK state.
     * In production apps, this is rarely needed (SDK lifecycle = app lifecycle).
     *
     * @see SrgLoginSdk.shutdown Public API wrapper
     */
    internal fun shutdown() {
        koinApp?.close()
        koinApp = null
    }

    /**
     * Checks if the SDK has been initialized.
     *
     * @return `true` if [initialize] has been called and SDK is ready,
     *   `false` otherwise.
     *
     * @see SrgLoginSdk.isInitialized Public API wrapper
     */
    internal fun isInitialized(): Boolean = koinApp != null

    /**
     * Initializes the [SdkLogger] with platform information and severity level.
     *
     * This method configures the global SDK logger instance with:
     * - Automatic PII/token sanitization via [SecurityUtils.sanitizeErrorMessage] (companion)
     * - TelemetryContext for GDPR-compliant log enrichment
     * - Minimum severity based on build type (DEBUG or INFO)
     *
     * @param koin The Koin dependency injection container.
     * @param isDebugBuild If `true`, sets minimum severity to DEBUG.
     *   If `false`, sets minimum severity to INFO.
     */
    @OptIn(ExperimentalUuidApi::class)
    private fun initializeSdkLogger(isDebugBuild: Boolean) {
        // Create TelemetryContext for SDK logging
        val telemetryContext =
            TelemetryContext.create(
                appId = "ch.srg.login.sdk",
                appName = "SRG Login SDK",
                appVersion = TelemetryContext.SDK_VERSION,
                businessUnit = "sdk",
                businessUnitName = "SDK",
                platform = PlatformInfo.getPlatformName(),
                osVersion = PlatformInfo.getOsVersion(),
                deviceModel = PlatformInfo.getDeviceModel(),
                sessionId = Uuid.random().toString(),
                environment = if (isDebugBuild) "DEBUG" else "PROD",
            )

        // Determine minimum severity based on build type
        val minSeverity = LogSeverity.getDefaultForBuild(isDebugBuild)

        // Initialize SdkLogger
        SdkLogger.initialize(telemetryContext, minSeverity)

        // Log successful initialization
        SdkLogger.i(LogCategory.SDK_CREATION) {
            "SdkLogger initialized " +
                "(minSeverity=$minSeverity, " +
                "platform=${telemetryContext.platform}, " +
                "environment=${telemetryContext.environment})"
        }
    }

    /**
     * Initializes internal error tracking with SdkErrorReporter.
     *
     * This method configures the SDK's internal error tracking by:
     * 1. Checking if error tracking is enabled in config
     * 2. Retrieving the environment-specific DSN from [SdkSentryConfig]
     * 3. If DSN is available (INT/PROD environment), creating and registering [SdkErrorReporter]
     * 4. If DSN is null (DEV) or disabled by config, error tracking remains disabled
     *
     * **Privacy**: Uses HASHED_SUB mode for user anonymization (GDPR-compliant).
     *
     * @param koin The Koin dependency injection container
     * @param config The SDK configuration (determines environment and enable flag)
     */
    @OptIn(ExperimentalUuidApi::class)
    private fun initializeErrorTracking(
        koin: Koin,
        config: SrgLoginConfig,
    ) {
        // Check if error tracking is enabled in config
        if (!config.enableErrorTracking) {
            SdkLogger.d(LogCategory.SDK_CREATION) { "SDK error tracking disabled by configuration" }
            return
        }

        // Get environment-specific DSN
        val dsn = SdkSentryConfig.getDsn(config)

        if (dsn != null) {
            SdkLogger.d(LogCategory.SDK_CREATION) { "Initializing SDK error tracking for ${config.environment} environment" }

            // Resolve dependencies from Koin
            val httpClient: HttpClient = koin.get()
            val cryptoService: CryptoService = koin.get()

            // Create TelemetryContext for error tracking using host app identity
            // This enables multi-tenant Sentry filtering by host application (SRF, RTS, RSI, etc.)
            val telemetryContext =
                TelemetryContext.create(
                    appId = config.appIdentity.appId,
                    appName = config.appIdentity.appName,
                    appVersion = config.appIdentity.appVersion,
                    businessUnit = config.appIdentity.businessUnit,
                    businessUnitName = config.appIdentity.businessUnitName,
                    platform = PlatformInfo.getPlatformName(),
                    osVersion = PlatformInfo.getOsVersion(),
                    deviceModel = PlatformInfo.getDeviceModel(),
                    sessionId = Uuid.random().toString(),
                    environment = config.environment.name,
                )

            // Get environment-specific salt
            val salt = SdkSentryConfig.getSalt(config)

            // Create SdkErrorReporter with internal configuration
            val errorReporter =
                SdkErrorReporter(
                    dsn = dsn,
                    httpClient = httpClient,
                    telemetryContext = telemetryContext,
                    cryptoService = cryptoService,
                    userContextMode = UserContextMode.HASHED_SUB,
                    salt = salt,
                )

            // Register with ErrorHandlerRegistry
            ErrorHandlerRegistry.setHandler(errorReporter)

            SdkLogger.i(LogCategory.SDK_CREATION) { "SDK error tracking initialized (environment=${config.environment})" }
        } else {
            SdkLogger.d(LogCategory.SDK_CREATION) { "SDK error tracking disabled for ${config.environment} environment" }
        }
    }
}
