package ch.srg.login.sdk.auth

import ch.srg.login.sdk.SrgLogin
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.model.TokenSet
import ch.srg.login.sdk.result.SdkResult
import kotlinx.coroutines.flow.Flow

/**
 * Selects the login flow to use for a login attempt.
 *
 * [Web] and [Device] select a flow — they carry no actual credentials.
 * [UserPassword] carries real credentials for the ROPC flow.
 * [Biometric] is reserved for future use.
 * [Migration] carries an existing refresh token for seamless migration from another SDK or OAuth integration.
 */
sealed class LoginMethod {
    /** Triggers the web-based OIDC authorization code flow (PKCE) via a browser. */
    data object Web : LoginMethod()

    /** Triggers the device authorization flow for TVs and limited-input devices. */
    data object Device : LoginMethod()

    /**
     * Reserved for future biometric-based login.
     * Not yet implemented — do not use.
     */
    data object Biometric : LoginMethod()

    /** Provides a username and password for a direct, non-web-based login. */
    data class UserPassword(
        val username: String,
        val password: String,
    ) : LoginMethod()

    /**
     * Migrates an existing session from another SDK or plain OAuth API integration without
     * requiring the user to re-authenticate.
     *
     * Calls the token refresh endpoint with [refreshToken] to obtain a fresh, fully validated
     * token set, then seeds the SDK's secure storage with the result.
     *
     * If the SDK already holds tokens in storage, call [ch.srg.login.sdk.SrgLogin.localLogout] first
     * to clear SDK storage before migrating; otherwise [LoginState.Failure] is emitted immediately.
     * After a successful migration, the app must clear its own legacy token storage —
     * the SDK only manages its own secure storage (Keychain / EncryptedSharedPreferences).
     */
    data class Migration(
        val refreshToken: String,
    ) : LoginMethod()
}

/**
 * Represents the various states that can occur during a login flow.
 * A login flow can emit multiple states over time, especially for complex flows like the device flow.
 */
sealed class LoginState {
    /** Intermediate state for the TV/Device flow. The UI must display this info. */
    data class AwaitingDeviceActivation(
        val userCode: String,
        val verificationUri: String,
        val verificationUriComplete: String? = null,
        val expiresIn: Long = 0L,
    ) : LoginState()

    /** Final success state for any flow, containing the token set with parsed AccessToken. */
    data class Success(
        val tokenSet: TokenSet,
    ) : LoginState()

    /** Final failure state for any flow, containing a specific error. */
    data class Failure(
        val error: SrgLoginError,
    ) : LoginState()
}

/**
 * Defines the contract for an authentication strategy.
 * Each implementation will handle a specific login method (e.g., Web, Device, Biometric).
 *
 * This interface is internal to the SDK. External users should interact with [SrgLogin]
 * which provides a stable public API facade over this internal interface.
 */
internal interface AuthenticationManager {
    /**
     * Initiates a login flow using the specified login method and platform context.
     *
     * @param loginMethod The type of login to perform.
     * @param authContext The platform-specific authentication context.
     * @param additionalScopes Additional OAuth scopes to request beyond "openid".
     *                         The "openid" scope is automatically included for OIDC compliance.
     * @param additionalParameters Additional OAuth/OIDC parameters to include in the authorization request.
     *                             Common parameters (OIDC Core 1.0, Section 3.1.2.1):
     *                             - "ui_locales": "fr" - Preferred user interface language
     *                             - "prompt": "login" | "consent" | "none" | "select_account" - Authentication/consent control
     *                             - "display": "page" | "popup" | "touch" | "wap" - Display mode for authentication UI
     *                             - "max_age": "3600" - Maximum authentication age in seconds
     *                             - "login_hint": "user@example.com" - Pre-fills username
     *                             - "acr_values": "level2" - Requested authentication context
     *
     *                             All parameter values are automatically URL-encoded.
     *                             Specification: https://openid.net/specs/openid-connect-core-1_0.html#AuthRequest
     * @return A [Flow] that emits [LoginState] updates throughout the authentication process.
     */
    fun login(
        loginMethod: LoginMethod,
        authContext: PlatformAuthContext,
        additionalScopes: List<String> = emptyList(),
        additionalParameters: Map<String, String> = emptyMap(),
    ): Flow<LoginState>

    /**
     * Completes a redirect-based authorization from an IDP [callbackUrl].
     *
     * Used by the web target, where the login is started by [login] (which redirects the page
     * away) and finished here on the callback page — reloading the persisted authorization
     * transaction, exchanging the code, and persisting the tokens. Returns a failure
     * [LoginState] on platforms whose login flow does not support redirect completion.
     *
     * @param callbackUrl The full IDP callback URL (e.g. `window.location.href`).
     * @return The terminal [LoginState] (success or failure).
     */
    suspend fun completeAuthorization(callbackUrl: String): LoginState

    /**
     * Logs the user out using the specified logout type.
     *
     * Defaults to [LogoutType.LocalOnly] which clears stored tokens and session data locally.
     *
     * For [LogoutType.FrontChannel]: The platform auth context is embedded in the type itself,
     * e.g. `logout(LogoutType.FrontChannel(authContext, postLogoutRedirectUri))`.
     *
     * For [LogoutType.BackChannel]: Validates the logout token JWT and clears the local session.
     *
     * @param logoutType The type of logout to perform (defaults to [LogoutType.LocalOnly])
     * @return [LogoutResult] with details about what was cleared/terminated
     */
    suspend fun logout(logoutType: LogoutType = LogoutType.LocalOnly): LogoutResult

    /**
     * Registers a listener for back-channel logout notifications.
     *
     * @param listener The listener to receive back-channel logout events
     * @return [SdkResult.Success] if registered, [SdkResult.Failure] if not supported on this platform
     */
    fun registerBackChannelLogoutListener(listener: BackChannelLogoutListener): SdkResult<Unit>

    /**
     * Unregisters a back-channel logout listener.
     *
     * @param listener The listener to remove
     * @return [SdkResult.Success] if unregistered, [SdkResult.Failure] if not supported on this platform
     */
    fun unregisterBackChannelLogoutListener(listener: BackChannelLogoutListener): SdkResult<Unit>

    /**
     * Opens another SSO client URL in platform-specific browser and suspends until user returns.
     * Leverages the current authenticated session cookies for seamless SSO experience.
     *
     * Perfect for displaying profile pages, settings, admin panels, or any other SSO client
     * that shares the same authentication system.
     *
     * Note: The method suspends until the user completes navigation and returns to the app,
     * providing reliable confirmation of the SSO client interaction.
     *
     * @param ssoClientUrl URL of the SSO client to display
     * @param authContext The platform-specific authentication context
     * @return A [SdkResult] indicating success or failure of the complete SSO client navigation
     */
    suspend fun openSsoClient(
        ssoClientUrl: String,
        authContext: PlatformAuthContext,
    ): SdkResult<Unit>
}
