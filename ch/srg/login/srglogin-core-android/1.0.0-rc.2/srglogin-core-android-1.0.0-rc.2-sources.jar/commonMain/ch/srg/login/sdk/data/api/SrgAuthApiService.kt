package ch.srg.login.sdk.data.api

import ch.srg.login.sdk.model.DeviceAuthorizationResponse
import ch.srg.login.sdk.model.JwkSet
import ch.srg.login.sdk.model.OpenIdConfig
import ch.srg.login.sdk.model.TokenResponseDto
import ch.srg.login.sdk.model.UserInfoResponseDto
import ch.srg.login.sdk.result.SdkResult

/**
 * Defines the contract for the SRG authentication API service.
 * This is analogous to a Retrofit interface.
 *
 * INTERNAL: This interface is not part of the public SDK API.
 */
internal interface SrgAuthApiService {
    /**
     * Fetches the OpenID Connect configuration from a given base URL.
     */
    suspend fun getOpenIdConfiguration(baseUrl: String): OpenIdConfig

    /**
     * Exchanges an authorization code for access and refresh tokens.
     *
     * @param tokenEndpoint The URL of the token endpoint.
     * @param code The authorization code received from the redirect.
     * @param redirectUri The original redirect URI.
     * @param clientId The client ID.
     * @param codeVerifier The PKCE code verifier.
     * @return A [TokenResponseDto] containing the tokens.
     */
    suspend fun exchangeCodeForToken(
        tokenEndpoint: String,
        code: String,
        redirectUri: String,
        clientId: String,
        codeVerifier: String,
    ): TokenResponseDto

    /**
     * Fetches the JSON Web Key Set (JWKS) used for JWT signature validation.
     *
     * @param jwksUri The URI of the JWKS endpoint from OpenID configuration
     * @return A [JwkSet] containing the public keys for JWT validation
     */
    suspend fun getJwks(jwksUri: String): JwkSet

    /**
     * Requests device authorization from the device authorization endpoint (RFC 8628 §3.1).
     *
     * @param deviceAuthorizationEndpoint The URL of the device authorization endpoint.
     * @param clientId The client ID for this application.
     * @param scope The OAuth scopes to request (space-separated).
     * @return An [SdkResult] containing the [DeviceAuthorizationResponse] on success.
     */
    suspend fun requestDeviceAuthorization(
        deviceAuthorizationEndpoint: String,
        clientId: String,
        scope: String,
        additionalParameters: Map<String, String> = emptyMap(),
    ): SdkResult<DeviceAuthorizationResponse>

    /**
     * Exchanges a device code for access and refresh tokens (RFC 8628 §3.4).
     *
     * @param tokenEndpoint The URL of the token endpoint.
     * @param deviceCode The device code from [requestDeviceAuthorization].
     * @param clientId The client ID for this application.
     * @return An [SdkResult] containing the [TokenResponseDto] on success, or an error on failure.
     *         The error may be an [ch.srg.login.sdk.errors.SrgLoginError.InvalidDataError] wrapping
     *         RFC 8628 error codes such as `authorization_pending`, `slow_down`, `access_denied`,
     *         or `expired_token`.
     */
    suspend fun exchangeDeviceCodeForToken(
        tokenEndpoint: String,
        deviceCode: String,
        clientId: String,
    ): SdkResult<TokenResponseDto>

    /**
     * Exchanges a username and password for tokens using the ROPC grant (RFC 6749 §4.3).
     *
     * **SECURITY WARNING**: ROPC is deprecated by RFC 9700 Section 2.4. This method exposes
     * the user's plaintext credentials to the client. Only use as a last-resort fallback
     * (e.g., tvOS where no browser is available for authorization code flow).
     *
     * @param tokenEndpoint The URL of the token endpoint.
     * @param username The resource owner's username.
     * @param password The resource owner's password.
     * @param clientId The client ID for this application.
     * @param scope The OAuth scopes to request (space-separated).
     * @return A [TokenResponseDto] containing the tokens.
     * @throws Exception if the credentials are invalid or the server rejects the request.
     */
    @Suppress("LongParameterList")
    suspend fun exchangePasswordForToken(
        tokenEndpoint: String,
        username: String,
        password: String,
        clientId: String,
        clientSecret: String?,
        scope: String,
        additionalParameters: Map<String, String> = emptyMap(),
    ): TokenResponseDto

    /**
     * Refreshes an access token using a refresh token.
     *
     * Implements OAuth 2.0 token refresh flow (RFC 6749 Section 6).
     * Exchanges a valid refresh token for a new access token and optionally a new refresh token.
     *
     * **Token Rotation**:
     * If the authorization server implements refresh token rotation, the response will contain
     * a new refresh token. The old refresh token should be considered invalid after use.
     *
     * **Security Note**:
     * - Always use the new refresh token from the response if provided
     * - Track token usage metadata to detect potential theft
     * - Implement exponential backoff for network failures
     *
     * @param tokenEndpoint The URL of the token endpoint from OpenID configuration
     * @param refreshToken The refresh token to exchange
     * @param clientId The client ID for this application
     * @return A [TokenResponseDto] containing new access token and optionally new refresh token
     * @throws Exception if the refresh token is invalid, expired, or revoked
     */
    suspend fun refreshAccessToken(
        tokenEndpoint: String,
        refreshToken: String,
        clientId: String,
    ): TokenResponseDto

    /**
     * Calls the OIDC `/userinfo` endpoint (OIDC Core 1.0 §5.3) to fetch the
     * current End-User profile claims using the supplied access token.
     *
     * The endpoint is expected to come from a validated
     * [ch.srg.login.sdk.model.OpenIdConfig.userInfoEndpoint]; the implementation
     * defensively re-validates HTTPS before sending the Bearer token, to prevent
     * credential leakage in the event of stale/corrupt discovery data.
     *
     * The access token is sent in the `Authorization` header per RFC 6750 §2.1
     * (recommended form). The query-parameter form (§2.3) is deprecated and
     * never used here, to avoid token leakage via URL logs, HTTP referrers, or
     * shell history.
     *
     * @param endpoint The HTTPS URL of the `/userinfo` endpoint.
     * @param accessToken The OAuth access token used to authenticate the request.
     * @return [SdkResult.Success] wrapping the raw [UserInfoResponseDto] on HTTP 2xx,
     *         or [SdkResult.Failure] with a mapped
     *         [ch.srg.login.sdk.errors.SrgLoginError]:
     *         - `InvalidConfiguration` if `endpoint` is blank or not HTTPS.
     *         - `HttpError` for HTTP 4xx / 5xx (including 401 — caller decides retry).
     *         - `SerializationError` for malformed JSON / unexpected response shape.
     *         - `NetworkError` for transport failures (timeout, DNS, no connectivity)
     *           OR any other unexpected exception. The `cause` field preserves the
     *           original throwable so callers can inspect it if needed.
     *         Coroutine cancellation (`CancellationException`) propagates as-is
     *         and is never mapped to a failure.
     */
    suspend fun getUserInfo(
        endpoint: String,
        accessToken: String,
    ): SdkResult<UserInfoResponseDto>
}
