package ch.srg.login.sdk.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject

/**
 * Internal serialisable representation of [UserInfo], used for persisting the typed
 * profile to secure storage (`EncryptedSharedPreferences` on Android, Keychain on
 * iOS).
 *
 * Follows the project convention of separating SDK-internal persistence DTOs from
 * the public typed models (e.g. [TokenResponseDto] ↔ [TokenSet]). Field names use
 * OIDC §5.1 wire-format snake_case via [SerialName] so the stored JSON is human-
 * readable and aligned with the protocol.
 *
 * **Custom claims layout**: standard OIDC claims live at the top level; non-
 * standard IDP-specific claims are grouped under a nested [customClaims]
 * [JsonObject]. Keeping the latter wrapped avoids the need for a hand-written
 * `KSerializer` and decouples storage shape from the OIDC `/userinfo` network
 * response shape (the latter has custom claims at the top level — handled by a
 * separate DTO in the network layer).
 *
 * @see UserInfo for the public typed model and its `internal fun toDto()` /
 *   `fromDto(dto)` conversion helpers.
 */
@Serializable
internal data class UserInfoDto(
    @SerialName("sub") val subject: String,
    @SerialName("name") val name: String? = null,
    @SerialName("given_name") val givenName: String? = null,
    @SerialName("family_name") val familyName: String? = null,
    @SerialName("preferred_username") val preferredUsername: String? = null,
    @SerialName("picture") val picture: String? = null,
    @SerialName("locale") val locale: String? = null,
    @SerialName("updated_at") val updatedAt: Long? = null,
    @SerialName("email") val email: String? = null,
    @SerialName("email_verified") val emailVerified: Boolean? = null,
    @SerialName("address") val address: AddressDto? = null,
    @SerialName("phone_number") val phoneNumber: String? = null,
    @SerialName("phone_number_verified") val phoneNumberVerified: Boolean? = null,
    @SerialName("custom_claims") val customClaims: JsonObject = JsonObject(emptyMap()),
)

/**
 * Internal serialisable representation of [Address] (OIDC §5.1.1).
 *
 * Defined separately from [Address] to keep the public type free of
 * `kotlinx.serialization` annotations and to avoid expanding the public BCV
 * surface with a `@Serializable`-derived companion object.
 */
@Serializable
internal data class AddressDto(
    @SerialName("formatted") val formatted: String? = null,
    @SerialName("street_address") val streetAddress: String? = null,
    @SerialName("locality") val locality: String? = null,
    @SerialName("region") val region: String? = null,
    @SerialName("postal_code") val postalCode: String? = null,
    @SerialName("country") val country: String? = null,
)
