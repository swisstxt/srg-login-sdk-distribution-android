package ch.srg.login.sdk.auth

import ch.srg.login.sdk.SrgLoginConfig
import ch.srg.login.sdk.TokenRefreshConfig
import ch.srg.login.sdk.TokenRefreshMode
import ch.srg.login.sdk.crypto.CryptoService
import ch.srg.login.sdk.data.OpenIdConfigRepository
import ch.srg.login.sdk.data.api.SrgAuthApiService
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.events.EventEmitter
import ch.srg.login.sdk.events.SdkLifecycleEvent
import ch.srg.login.sdk.events.StorageOperation
import ch.srg.login.sdk.internal.mapPlatformException
import ch.srg.login.sdk.logging.ErrorHandler
import ch.srg.login.sdk.logging.ErrorHandlerRegistry
import ch.srg.login.sdk.logging.LogCategory
import ch.srg.login.sdk.logging.SdkLogger
import ch.srg.login.sdk.model.AccessToken
import ch.srg.login.sdk.model.IdTokenClaims
import ch.srg.login.sdk.model.JwtClaims
import ch.srg.login.sdk.model.RefreshTokenMetadata
import ch.srg.login.sdk.model.TokenResponseDto
import ch.srg.login.sdk.model.TokenSet
import ch.srg.login.sdk.model.UserInfo
import ch.srg.login.sdk.result.SdkResult
import ch.srg.login.sdk.token.TokenStorage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.datetime.Clock
import kotlin.math.min
import kotlin.math.pow

/**
 * Default implementation of [TokenManager].
 *
 * Orchestrates OAuth 2.0 token lifecycle management including:
 * - Token access with automatic refresh (based on [TokenRefreshMode] config)
 * - Manual token refresh operations
 * - Authentication status checks
 * - Token state monitoring
 * - Automatic retry with exponential backoff for transient errors
 * - Terminal error handling for invalid_grant (clears tokens, requires re-auth)
 * - Thread-safe concurrent request handling with mutex
 * - Comprehensive metadata tracking for debugging/analytics
 * - Proper error classification using SrgLoginError
 *
 * **Retry Strategy**:
 * - Network errors (connection failures, timeouts): Retry with exponential backoff
 * - Server errors (5xx): Retry with exponential backoff
 * - invalid_grant error: Terminal, clear all tokens, require re-authentication
 * - Storage errors: Terminal, clear tokens
 *
 * **Thread Safety**:
 * Uses a mutex to ensure only one refresh operation happens at a time.
 * Concurrent calls will wait for the active refresh to complete.
 *
 * @property config SDK configuration containing client ID and environment settings
 * @property openIdConfigRepository Repository for fetching OpenID Connect configuration (token endpoint, etc.)
 * @property apiService Service for making token endpoint requests
 * @property tokenStorage Secure storage for tokens and metadata
 * @property jwtValidationService Service for parsing and validating JWT tokens
 * @property cryptoService Service for cryptographic operations (SHA-256 hashing)
 * @property eventEmitter Event emitter for SDK lifecycle events (event-driven communication)
 * @param monitoringDispatcher Dispatcher for background monitoring and init coroutines.
 *   Defaults to [Dispatchers.Default]. Tests pass a `TestDispatcher` so coroutines are
 *   controlled by the test scheduler, eliminating flaky `Thread.sleep` hacks.
 */
internal class TokenManagerImpl(
    private val config: SrgLoginConfig,
    private val openIdConfigRepository: OpenIdConfigRepository,
    private val apiService: SrgAuthApiService,
    private val tokenStorage: TokenStorage,
    private val jwtValidationService: JwtValidationService,
    private val cryptoService: CryptoService,
    private val eventEmitter: EventEmitter,
    monitoringDispatcher: CoroutineDispatcher = Dispatchers.Default,
) : TokenManager {
    companion object {
        private const val MONITORING_TAG = "SDK-TokenMonitoring"
    }

    // Convenience accessor for refresh configuration
    private val refreshConfig: TokenRefreshConfig
        get() = config.tokenRefreshConfig

    /**
     * Mutex to ensure only one refresh operation at a time.
     * Prevents race conditions when multiple requests attempt to refresh simultaneously.
     */
    private val refreshMutex = Mutex()

    /**
     * Mutable state flow for token state monitoring.
     * Initialized lazily with actual storage state.
     */
    @Suppress("ktlint:standard:backing-property-naming")
    private val _tokenStateFlow = MutableStateFlow<TokenState>(TokenState.Uninitialized)

    /**
     * Coroutine scope for background token monitoring.
     * Uses the injected dispatcher (Dispatchers.Default in production, TestDispatcher
     * in tests) and SupervisorJob to prevent child coroutine failures from cancelling
     * the entire scope.
     */
    private val monitoringScope = CoroutineScope(monitoringDispatcher + SupervisorJob())

    /**
     * Background monitoring job.
     * Null when monitoring is not active.
     */
    private var monitoringJob: Job? = null

    init {
        // Log TokenManager instantiation to detect multiple instances
        SdkLogger.d(LogCategory.TOKEN_MONITORING) { "TokenManagerImpl instance created (hashCode=${this.hashCode()})" }
        SdkLogger.i(LogCategory.TOKEN_MONITORING) { "Token monitoring will start via AppForegrounded event (no automatic start in init{})" }

        // One-shot initial state evaluation — replaces TokenState.Uninitialized with a real
        // state based on current storage contents. Runs in both Automatic and Manual modes.
        // Launched directly (not via an event) to avoid a race condition with replay=0
        // SharedFlow where the event could be dropped before the collector starts. (Bug B fix)
        monitoringScope.launch {
            emitCurrentStateFromStorage()
            SdkLogger.i(LogCategory.TOKEN_MONITORING) {
                "Initial state evaluation complete (${_tokenStateFlow.value})"
            }
        }

        // Listen to SDK lifecycle events for automatic token management
        monitoringScope.launch {
            eventEmitter.events.collect { event ->
                when (event) {
                    is SdkLifecycleEvent.LoginSuccess -> {
                        if (refreshConfig.mode is TokenRefreshMode.Automatic) {
                            SdkLogger.i(LogCategory.TOKEN_MONITORING) { "LoginSuccess received, starting token monitoring" }
                            startTokenMonitoring()
                        } else {
                            // Manual mode: sync state immediately so observers see the new
                            // token without waiting for the first getAccessToken() call.
                            emitCurrentStateFromStorage()
                            SdkLogger.i(LogCategory.TOKEN_MONITORING) {
                                "LoginSuccess received in Manual mode, emitted state (${_tokenStateFlow.value})"
                            }
                        }
                    }

                    is SdkLifecycleEvent.LogoutSuccess -> {
                        // Always stop monitoring on logout (defensive, no tokens left)
                        SdkLogger.i(LogCategory.TOKEN_MONITORING) { "LogoutSuccess received, stopping token monitoring" }
                        stopTokenMonitoring()
                        // Sync state immediately in both modes. In Automatic, the monitoring
                        // loop would eventually catch up, but emitting now gives observers
                        // instant feedback. In Manual, this is the ONLY way NoTokens reaches
                        // the StateFlow on logout (no monitoring loop, no getAccessToken call).
                        emitCurrentStateFromStorage()
                    }

                    is SdkLifecycleEvent.AppForegrounded -> {
                        // Only restart monitoring if automatic monitoring is enabled and tokens exist
                        if (refreshConfig.mode is TokenRefreshMode.Automatic) {
                            SdkLogger.d(LogCategory.TOKEN_MONITORING) { "AppForegrounded received, checking for tokens" }
                            val tokens = tokenStorage.getTokens()
                            if (tokens != null) {
                                SdkLogger.i(LogCategory.TOKEN_MONITORING) { "Tokens found, restarting token monitoring" }
                                startTokenMonitoring()
                            }
                        }
                    }

                    is SdkLifecycleEvent.AppBackgrounded -> {
                        // Only stop monitoring if automatic monitoring is enabled (consistency with start)
                        if (refreshConfig.mode is TokenRefreshMode.Automatic) {
                            SdkLogger.i(
                                LogCategory.TOKEN_MONITORING,
                            ) { "AppBackgrounded received, stopping token monitoring to save battery" }
                            stopTokenMonitoring()
                        }
                    }

                    is SdkLifecycleEvent.TokenRefreshSuccess -> {
                        // Restart monitoring so the next cycle is immediately scheduled against
                        // the new token's expiry, rather than sleeping out the interval that was
                        // calculated for the old (expired/expiring) token.
                        if (refreshConfig.mode is TokenRefreshMode.Automatic) {
                            SdkLogger.i(LogCategory.TOKEN_MONITORING) {
                                "TokenRefreshSuccess received, restarting monitoring for fresh token evaluation"
                            }
                            startTokenMonitoring()
                        }
                    }

                    is SdkLifecycleEvent.SessionInvalidated -> {
                        // Tokens have been cleared. Stop monitoring — there is nothing left to
                        // monitor and the user must re-authenticate.
                        SdkLogger.i(LogCategory.TOKEN_MONITORING) {
                            "SessionInvalidated received, stopping token monitoring"
                        }
                        stopTokenMonitoring()
                    }

                    is SdkLifecycleEvent.TokenRefreshFailure -> {
                        // Restart monitoring immediately only for terminal invalid_grant failures.
                        // The SessionInvalidated handler above already stopped monitoring; this
                        // restart triggers one final cycle that reads empty storage and emits
                        // NoTokens right away instead of waiting out the Expired interval sleep.
                        //
                        // For transient errors (NetworkError, HttpError) do NOT restart — the
                        // Expired-state sleep serves as the outer cooldown between macro retries
                        // and restarting here would create an infinite retry loop.
                        if (event.error is SrgLoginError.InvalidGrant && refreshConfig.mode is TokenRefreshMode.Automatic) {
                            SdkLogger.i(LogCategory.TOKEN_MONITORING) {
                                "TokenRefreshFailure(InvalidGrant) received, restarting monitoring to emit NoTokens"
                            }
                            startTokenMonitoring()
                        }
                    }

                    else -> {
                        // Ignore other events (not relevant for TokenManager)
                    }
                }
            }
        }
    }

    /**
     * Refreshes access and refresh tokens via the IDP token endpoint.
     *
     * **Visibility note**: `internal` instead of `private` solely for test access —
     * tests call this directly to verify refresh event sequences without going through
     * [getAccessToken]. Production code should always use [getAccessToken] with
     * `forceRefresh = true` instead of calling this method directly. (PR #71 review #13)
     *
     * It is the **Single Source of Truth** for refresh state transitions (ADR-010):
     * emits [TokenState.Refreshing] before the network call, [TokenState.Refreshed] on success,
     * and [TokenState.RefreshFailed] on failure. A freshness check inside the mutex skips
     * the network call if another caller just refreshed successfully — unless
     * [skipFreshnessCheck] is true, in which case the network call is always made.
     *
     * Visible for testing — would be private if tests didn't need direct access.
     *
     * @param skipFreshnessCheck When true, bypasses the freshness check and always performs
     *   a network refresh. Used by [getAccessToken] with `forceRefresh = true` to honour
     *   the caller's explicit intent. Defaults to false for all other call sites
     *   (monitoring loop, expired-token path) where deduplication is desirable.
     */
    @Suppress("LongMethod", "CyclomaticComplexMethod")
    internal suspend fun refreshTokens(skipFreshnessCheck: Boolean = false): SdkResult<TokenSet> =
        refreshMutex.withLock {
            try {
                // Freshness check: if another caller refreshed while we waited on the mutex,
                // the token is now Valid — skip the network call.
                // This is a performance optimization, not a security guard: the mutex already
                // serializes refresh calls, preventing concurrent double-refresh. The freshness
                // check avoids an unnecessary sequential network call. (ADR-010)
                // Bypassed when skipFreshnessCheck = true to honour an explicit forceRefresh call.
                if (!skipFreshnessCheck) {
                    val freshTokens = tokenStorage.getTokens()
                    if (freshTokens != null) {
                        val freshState = evaluateTokenState(freshTokens, refreshConfig)
                        if (freshState == EvaluatedTokenState.Valid) {
                            // Freshness check rebuild: tokens in encrypted storage were validated at
                            // first receipt (login or previous refresh). We parse without re-validating
                            // signature/issuer/audience to avoid an unnecessary JWKS round-trip — the
                            // storage threat model already mitigates tampering. Documented assumption.
                            //
                            // If parsing fails (storage corruption, truncation, SDK downgrade), we
                            // skip the freshness optimization and fall through to the network refresh
                            // below — a malformed stored token must not abort the whole refresh when
                            // a fresh server-side refresh would recover. (PR #77 review #2)
                            val freshAccessParseResult = jwtValidationService.parseJwt(freshTokens.accessToken)
                            if (freshAccessParseResult.isSuccess) {
                                val freshAccessClaims = freshAccessParseResult.getOrThrow().claims
                                val freshIdJwtClaims: JwtClaims? =
                                    freshTokens.idToken?.let { idToken ->
                                        jwtValidationService
                                            .parseJwt(idToken)
                                            .getOrNull()
                                            ?.claims
                                    }
                                val freshIdClaims = freshIdJwtClaims?.let(IdTokenClaims.Companion::fromJwtClaims)
                                val freshUserInfo = freshIdJwtClaims?.let(UserInfo.Companion::fromJwtClaims)
                                val tokenSet =
                                    TokenSet.fromDto(
                                        dto = freshTokens,
                                        accessTokenClaims = freshAccessClaims,
                                        idTokenClaims = freshIdClaims,
                                        userInfo = freshUserInfo,
                                    )
                                SdkLogger.d(LogCategory.TOKEN_MONITORING) {
                                    "Freshness check: token is Valid after mutex acquisition, skipping network refresh"
                                }
                                // Seed/refresh the UserInfo cache from the freshly-parsed storage
                                // tokens (LOGIN-1881 D1). The competing coroutine that performed
                                // the actual refresh would have populated it, but cold-start
                                // scenarios (or upgrades from a pre-D1 SDK) reach this path
                                // with empty UserInfo storage. Best-effort.
                                freshUserInfo?.let { tokenStorage.saveUserInfo(it) }
                                return@withLock SdkResult.Success(tokenSet)
                            } else {
                                SdkLogger.w(
                                    LogCategory.TOKEN_MONITORING,
                                    throwable = freshAccessParseResult.exceptionOrNull(),
                                ) {
                                    "Freshness check parse failed for stored access token — " +
                                        "falling back to network refresh"
                                }
                                // Fall through to the network refresh path below.
                            }
                        }
                    }
                }

                // Token is expired or missing — proceed with network refresh.
                // Emit Refreshing on the StateFlow so ALL callers (monitoring, getAccessToken,
                // forceRefresh) trigger the same state transition. Single source of truth (ADR-010).
                updateTokenStateAndEmitEvent(TokenState.Refreshing)

                // Emit TokenRefreshStarted event on the event bus
                val timestamp = Clock.System.now().toEpochMilliseconds()
                eventEmitter.emit(SdkLifecycleEvent.TokenRefreshStarted(timestamp))

                // Step 0: Fetch OpenID configuration for token endpoint
                val openIdConfigResult = openIdConfigRepository.getConfiguration()
                if (openIdConfigResult is SdkResult.Failure) {
                    val error = openIdConfigResult.error
                    updateTokenStateAndEmitEvent(TokenState.RefreshFailed(error))
                    val configFailureTimestamp = Clock.System.now().toEpochMilliseconds()
                    eventEmitter.emit(SdkLifecycleEvent.TokenRefreshFailure(error, configFailureTimestamp))
                    return openIdConfigResult
                }
                val openIdConfig = (openIdConfigResult as SdkResult.Success).data

                // Step 1: Retrieve current tokens and metadata
                // Tokens may be absent if they were cleared by a concurrent refresh that failed
                // (e.g. invalid_grant + clearAllTokensAndMetadata). Emit RefreshFailed so the
                // state does not stay stuck at Refreshing. (LOGIN-1846)
                val currentTokens =
                    tokenStorage.getTokens()
                        ?: run {
                            updateTokenStateAndEmitEvent(TokenState.RefreshFailed(SrgLoginError.TokenExpired))
                            val ts = Clock.System.now().toEpochMilliseconds()
                            eventEmitter.emit(SdkLifecycleEvent.TokenRefreshFailure(SrgLoginError.TokenExpired, ts))
                            return SdkResult.Failure(SrgLoginError.TokenExpired)
                        }

                val refreshToken =
                    currentTokens.refreshToken
                        ?: run {
                            updateTokenStateAndEmitEvent(TokenState.RefreshFailed(SrgLoginError.TokenExpired))
                            val ts = Clock.System.now().toEpochMilliseconds()
                            eventEmitter.emit(SdkLifecycleEvent.TokenRefreshFailure(SrgLoginError.TokenExpired, ts))
                            return SdkResult.Failure(SrgLoginError.TokenExpired)
                        }

                // Step 2: Get current metadata (may be null for first refresh in session)
                val currentMetadata = tokenStorage.getRefreshTokenMetadata()

                // Step 3: Hash the current refresh token for rotation tracking
                val currentRefreshTokenHash = hashRefreshToken(refreshToken)

                // Step 4: Attempt refresh with retry logic
                val refreshResult =
                    attemptRefreshWithRetry(
                        tokenEndpoint = openIdConfig.tokenEndpoint,
                        clientId = config.clientId,
                        refreshToken = refreshToken,
                        currentMetadata = currentMetadata,
                    )

                // Handle refresh failure
                if (refreshResult is SdkResult.Failure) {
                    val error = refreshResult.error

                    // Report unexpected errors to error tracking.
                    // InvalidGrant is intentionally excluded — a revoked or expired refresh token
                    // is an expected operational condition, not a bug. Reporting it as FATAL would
                    // generate noise in Sentry and obscure real errors.
                    if (error !is SrgLoginError.InvalidGrant) {
                        ErrorHandlerRegistry.captureException(
                            throwable =
                                when (error) {
                                    is SrgLoginError.NetworkError -> {
                                        error.cause ?: Exception(error.details ?: "Network error")
                                    }

                                    is SrgLoginError.HttpError -> {
                                        Exception("HTTP ${error.code}: ${error.message}")
                                    }

                                    else -> {
                                        Exception(error.toString())
                                    }
                                },
                            context =
                                mapOf(
                                    "operation" to "token_refresh",
                                    "error_type" to error::class.simpleName,
                                ),
                            level = ErrorHandler.ErrorLevel.ERROR,
                        )
                    }

                    // If it's invalid_grant, clear all tokens (terminal error) and signal
                    // session end. SessionInvalidated is emitted before TokenRefreshFailure
                    // so listeners can stop monitoring before the failure is reported.
                    if (error is SrgLoginError.InvalidGrant) {
                        clearAllTokensAndMetadata()
                        val invalidatedTimestamp = Clock.System.now().toEpochMilliseconds()
                        eventEmitter.emit(SdkLifecycleEvent.SessionInvalidated(error, invalidatedTimestamp))
                    }

                    // Emit RefreshFailed on StateFlow + TokenRefreshFailure on event bus
                    updateTokenStateAndEmitEvent(TokenState.RefreshFailed(error))
                    val failureTimestamp = Clock.System.now().toEpochMilliseconds()
                    eventEmitter.emit(SdkLifecycleEvent.TokenRefreshFailure(error, failureTimestamp))

                    return refreshResult
                }

                val newTokens = (refreshResult as SdkResult.Success).data

                // Step 5: Update metadata after successful refresh
                val now = Clock.System.now()
                val nowSeconds = now.epochSeconds
                val nowMillis = now.toEpochMilliseconds()

                val updatedMetadata =
                    if (currentMetadata != null) {
                        // Update existing metadata
                        currentMetadata.withSuccessfulRefresh(
                            newLastUsedAt = nowSeconds,
                            newLastRefreshAt = nowMillis,
                            newPreviousTokenHash = currentRefreshTokenHash,
                        )
                    } else {
                        // Create new metadata (first refresh in session or metadata was cleared)
                        RefreshTokenMetadata(
                            sessionCreatedAt = nowMillis,
                            issuedAt = nowSeconds,
                            lastUsedAt = nowSeconds,
                            lastRefreshAt = nowMillis,
                            // First refresh
                            sessionRefreshCount = 1,
                            lastRefreshError = null,
                            previousTokenHash = currentRefreshTokenHash,
                        )
                    }

                // Step 6: Persist new tokens and updated metadata
                SdkLogger.i(LogCategory.TOKEN_MONITORING) {
                    "Attempting to save refreshed tokens " +
                        "(accessToken length: ${newTokens.accessToken.length}, " +
                        "refreshToken present: ${newTokens.refreshToken != null}, " +
                        "expiresIn: ${newTokens.expiresIn}s)"
                }

                val saveTokensResult = tokenStorage.saveTokens(newTokens)
                if (saveTokensResult.isFailure) {
                    // Emit StorageError event
                    val storageErrorTimestamp = Clock.System.now().toEpochMilliseconds()
                    val storageException = saveTokensResult.exceptionOrNull() ?: Exception("Failed to save refreshed tokens")
                    val storageError =
                        SrgLoginError.TokenStorageError(
                            message = "Failed to save refreshed tokens",
                            cause = storageException,
                        )
                    SdkLogger.e(LogCategory.TOKEN_MONITORING, throwable = storageException) { "Failed to save tokens" }

                    // Report to error tracking
                    ErrorHandlerRegistry.captureException(
                        throwable = storageException,
                        context =
                            mapOf(
                                "operation" to "save_refreshed_tokens",
                                "critical" to true,
                                "action" to "clearing_all_tokens",
                                "error_message" to "Token save failed - tokens will be cleared",
                            ),
                        level = ErrorHandler.ErrorLevel.FATAL,
                    )

                    eventEmitter.tryEmit(
                        SdkLifecycleEvent.StorageError(
                            operation = StorageOperation.SAVE,
                            error = storageError,
                            timestamp = storageErrorTimestamp,
                        ),
                    )

                    // Token save failed - clear everything as we're in inconsistent state
                    clearAllTokensAndMetadata()
                    updateTokenStateAndEmitEvent(TokenState.RefreshFailed(storageError))
                    val saveFailureTimestamp = Clock.System.now().toEpochMilliseconds()
                    eventEmitter.emit(SdkLifecycleEvent.TokenRefreshFailure(storageError, saveFailureTimestamp))
                    return SdkResult.Failure(storageError)
                }

                SdkLogger.i(LogCategory.TOKEN_MONITORING) { "Tokens successfully saved to storage" }

                // Parse the access token claims (already implicitly validated by the IDP returning it).
                // On parse failure (malformed JWT from IDP — typically an IDP bug), surface a typed
                // InvalidDataError instead of letting the exception fall through to the catch-all
                // and become a generic UnknownError. (PR #77 review #2)
                val refreshedAccessParseResult = jwtValidationService.parseJwt(newTokens.accessToken)
                if (refreshedAccessParseResult.isFailure) {
                    val cause = refreshedAccessParseResult.exceptionOrNull()
                    val parseError =
                        SrgLoginError.InvalidDataError(
                            reason = "Malformed access token returned by IDP: ${cause?.message ?: "JWT parse failed"}",
                        )
                    SdkLogger.e(LogCategory.TOKEN_MONITORING, throwable = cause) {
                        "Failed to parse fresh access token returned by IDP — possible IDP bug"
                    }
                    // Clear the just-saved malformed tokens to break the tight retry loop:
                    // the next getAccessToken() would otherwise see the same unparseable token
                    // in storage, trigger another network refresh, receive the same malformed
                    // response, and loop. (PR #77 round 2 review)
                    clearAllTokensAndMetadata()
                    // Emit RefreshFailed on StateFlow + TokenRefreshFailure on event bus,
                    // matching the network-failure path above. Without the StateFlow update,
                    // collectLatest observers waiting on Refreshed/RefreshFailed would hang
                    // on Refreshing indefinitely. (PR #77 round 2 review)
                    updateTokenStateAndEmitEvent(TokenState.RefreshFailed(parseError))
                    val parseFailureTimestamp = Clock.System.now().toEpochMilliseconds()
                    eventEmitter.emit(SdkLifecycleEvent.TokenRefreshFailure(parseError, parseFailureTimestamp))
                    return@withLock SdkResult.Failure(parseError)
                }
                val refreshedAccessClaims = refreshedAccessParseResult.getOrThrow().claims

                // Revalidate the ID token if a fresh one was returned (OIDC §12 — nonce check is
                // optional at refresh). On revalidation failure, we degrade gracefully: the access
                // token is still usable, but idTokenClaims becomes null. This avoids breaking
                // refresh flows on transient JWKS issues or key rotation between login and refresh.
                val refreshedIdJwtClaims: JwtClaims? =
                    newTokens.idToken?.let { idToken ->
                        val result =
                            jwtValidationService.validateIdToken(
                                idToken = idToken,
                                clientId = config.clientId,
                                issuer = openIdConfig.issuer,
                                jwksUri = openIdConfig.jwksUri,
                                nonce = null,
                            )
                        if (result.isFailure) {
                            SdkLogger.w(
                                LogCategory.TOKEN_MONITORING,
                                throwable = result.exceptionOrNull(),
                            ) {
                                "ID token revalidation failed at refresh — idTokenClaims will be null"
                            }
                            null
                        } else {
                            result.getOrThrow()
                        }
                    }
                val refreshedIdClaims = refreshedIdJwtClaims?.let(IdTokenClaims.Companion::fromJwtClaims)
                val refreshedUserInfo = refreshedIdJwtClaims?.let(UserInfo.Companion::fromJwtClaims)

                // Convert TokenResponseDto to TokenSet with the validated claims.
                val tokenSet =
                    TokenSet.fromDto(
                        dto = newTokens,
                        accessTokenClaims = refreshedAccessClaims,
                        idTokenClaims = refreshedIdClaims,
                        userInfo = refreshedUserInfo,
                    )

                // Refresh the UserInfo cache with the newly-validated snapshot so
                // `srgLogin.getUserInfo(forceRefresh = false)` reflects the most
                // recent state (the IdP-side profile may have changed since the
                // last login). Best-effort (LOGIN-1881 D1).
                refreshedUserInfo?.let { tokenStorage.saveUserInfo(it) }

                // Step 7: Emit Refreshed on StateFlow + TokenRefreshSuccess on event bus.
                // Refreshed is a signal (data object) — no token payload on the StateFlow
                // to prevent refresh token leakage via observers. (PR #71 review #7)
                updateTokenStateAndEmitEvent(TokenState.Refreshed)
                val successTimestamp = Clock.System.now().toEpochMilliseconds()
                eventEmitter.emit(SdkLifecycleEvent.TokenRefreshSuccess(tokenSet, successTimestamp))

                // Emit TokensSaved event after (tokens persisted to storage)
                val tokensSavedTimestamp = Clock.System.now().toEpochMilliseconds()
                eventEmitter.tryEmit(
                    SdkLifecycleEvent.TokensSaved(
                        hasRefreshToken = newTokens.refreshToken != null,
                        timestamp = tokensSavedTimestamp,
                    ),
                )

                val saveMetadataResult = tokenStorage.saveRefreshTokenMetadata(updatedMetadata)
                if (saveMetadataResult.isFailure) {
                    // Metadata save failed but tokens saved - not critical, just log
                    // Metadata is for debugging/analytics, not critical for auth flow
                    SdkLogger.w(LogCategory.TOKEN_MONITORING, throwable = saveMetadataResult.exceptionOrNull()) {
                        "Failed to save refresh token metadata"
                    }
                }

                SdkResult.Success(tokenSet)
            } catch (e: CancellationException) {
                // Coroutine cancellation must propagate so that structured concurrency works.
                // Mapping it to UnknownError would emit a fake TokenRefreshFailure event,
                // pollute Sentry with cancellation noise, and break callers that rely on
                // cancellation semantics. (PR #77 review #2 — same commit)
                throw e
            } catch (e: Exception) {
                // Unexpected exception - wrap in UnknownError
                val error =
                    SrgLoginError.UnknownError(
                        cause = e,
                        context = "Unexpected error during token refresh",
                    )

                val failureTimestamp = Clock.System.now().toEpochMilliseconds()
                updateTokenStateAndEmitEvent(TokenState.RefreshFailed(error))
                eventEmitter.emit(SdkLifecycleEvent.TokenRefreshFailure(error, failureTimestamp))

                SdkResult.Failure(error)
            }
        }

    /**
     * Attempts to refresh tokens with retry logic and exponential backoff.
     *
     * **Retry Strategy**:
     * - Network errors: Retry up to maxRetryAttempts times with exponential backoff
     * - Server errors (5xx): Retry up to maxRetryAttempts times
     * - invalid_grant: No retry (terminal error)
     * - Other errors: No retry
     *
     * @param tokenEndpoint Token endpoint URL from OpenID configuration
     * @param clientId OAuth 2.0 client identifier
     * @param refreshToken The refresh token to use
     * @param currentMetadata Current metadata (for error tracking)
     * @return SdkResult with new tokens or error
     */
    private suspend fun attemptRefreshWithRetry(
        tokenEndpoint: String,
        clientId: String,
        refreshToken: String,
        currentMetadata: RefreshTokenMetadata?,
    ): SdkResult<TokenResponseDto> {
        var lastError: SrgLoginError? = null
        var attemptNumber = 0

        while (attemptNumber <= refreshConfig.maxRetryAttempts) {
            try {
                // Attempt the refresh
                val newTokens =
                    apiService.refreshAccessToken(
                        tokenEndpoint = tokenEndpoint,
                        refreshToken = refreshToken,
                        clientId = clientId,
                    )

                // Success!
                return SdkResult.Success(newTokens)
            } catch (e: CancellationException) {
                // Coroutine cancellation must propagate; otherwise the retry loop would
                // misclassify it as a refresh error, capture noise to Sentry, and continue
                // retrying despite the caller having cancelled. (PR #77 review #2 — same commit)
                throw e
            } catch (e: Exception) {
                // Classify the error
                val error = classifyRefreshError(e)
                lastError = error

                // Report to error tracking
                ErrorHandlerRegistry.captureException(
                    throwable = e,
                    context =
                        mapOf(
                            "operation" to "token_refresh_attempt",
                            "attempt_number" to (attemptNumber + 1),
                            "max_attempts" to refreshConfig.maxRetryAttempts,
                            "error_type" to error::class.simpleName,
                            "is_retryable" to isRetryableError(error),
                        ),
                    level = ErrorHandler.ErrorLevel.ERROR,
                )

                // Update metadata with error (for debugging)
                currentMetadata?.let { metadata ->
                    val updatedMetadata =
                        metadata.withFailedRefresh(
                            errorMessage =
                                when (error) {
                                    is SrgLoginError.InvalidGrant -> {
                                        "invalid_grant: ${error.errorDescription ?: "Refresh token invalid/expired/revoked"}"
                                    }

                                    is SrgLoginError.NetworkError -> {
                                        "Network error: ${error.details ?: error.cause?.message ?: "Unknown"}"
                                    }

                                    is SrgLoginError.HttpError -> {
                                        "Server error: HTTP ${error.code} - ${error.message ?: "Unknown"}"
                                    }

                                    else -> {
                                        error.toString()
                                    }
                                },
                        )
                    tokenStorage.saveRefreshTokenMetadata(updatedMetadata)
                }

                // Check if error is retryable
                if (!isRetryableError(error) || attemptNumber >= refreshConfig.maxRetryAttempts) {
                    return SdkResult.Failure(error)
                }

                // Calculate backoff delay
                val delayMs = calculateBackoffDelay(attemptNumber)

                // Log retry attempt
                SdkLogger.e(LogCategory.TOKEN_MONITORING) {
                    "Token refresh attempt ${attemptNumber + 1} failed, retrying in ${delayMs}ms: $error"
                }

                // Wait before retry
                delay(delayMs)

                attemptNumber++
            }
        }

        // Should never reach here, but just in case
        return SdkResult.Failure(
            lastError ?: SrgLoginError.UnknownError(
                cause = Exception("Token refresh failed after all retries"),
                context = "Exhausted all retry attempts",
            ),
        )
    }

    /**
     * Classifies an exception from token refresh into appropriate SrgLoginError.
     *
     * Uses Ktor exception types and OAuth error response parsing for accurate classification:
     * - [ClientRequestException] (4xx) → Parsed for OAuth errors like invalid_grant
     * - [ServerResponseException] (5xx) → Mapped to retryable HTTP errors
     * - Platform-specific exceptions → Mapped using [mapPlatformException]
     * - Generic exceptions with message patterns → Fallback string matching (for testing compatibility)
     *
     * @param exception The exception that occurred
     * @return Classified SrgLoginError
     */
    private suspend fun classifyRefreshError(exception: Exception): SrgLoginError {
        // First, try platform-specific exception mapping (network errors, timeouts, etc.)
        mapPlatformException(exception)?.let { return it }

        // Then, handle Ktor HTTP exceptions
        return when (exception) {
            // 4xx client errors - may contain OAuth errors like invalid_grant
            is io.ktor.client.plugins.ClientRequestException -> {
                OAuthErrorMapper.mapClientRequestException(exception)
            }

            // 5xx server errors - retryable
            is io.ktor.client.plugins.ServerResponseException -> {
                OAuthErrorMapper.mapServerResponseException(exception)
            }

            // Fallback: Check message for common error patterns (for testing and legacy compatibility)
            else -> {
                val errorMessage = exception.message ?: ""

                when {
                    // Check for invalid_grant (OAuth 2.0 error)
                    errorMessage.contains("invalid_grant", ignoreCase = true) -> {
                        SrgLoginError.InvalidGrant(
                            errorDescription = errorMessage,
                            errorCode = "invalid_grant",
                        )
                    }

                    // Network errors
                    errorMessage.contains("network", ignoreCase = true) ||
                        errorMessage.contains("connection", ignoreCase = true) ||
                        errorMessage.contains("timeout", ignoreCase = true) ||
                        errorMessage.contains("unreachable", ignoreCase = true) -> {
                        SrgLoginError.NetworkError(
                            details = errorMessage,
                            cause = exception,
                        )
                    }

                    // Fallback to unknown error
                    else -> {
                        SrgLoginError.UnknownError(
                            cause = exception,
                            context = "Token refresh failed with unexpected exception",
                        )
                    }
                }
            }
        }
    }

    /**
     * Determines if an error is retryable.
     *
     * **Retryable errors**:
     * - NetworkError
     * - HttpError with 5xx status code
     *
     * **Non-retryable (terminal) errors**:
     * - InvalidGrant
     * - TokenStorageError
     * - HttpError with 4xx status code
     * - Other errors
     *
     * @param error The error to check
     * @return true if error is retryable, false otherwise
     */
    private fun isRetryableError(error: SrgLoginError): Boolean =
        when (error) {
            is SrgLoginError.NetworkError -> true
            is SrgLoginError.HttpError -> error.code in 500..599
            is SrgLoginError.InvalidGrant -> false
            is SrgLoginError.TokenStorageError -> false
            else -> false
        }

    /**
     * Calculates the backoff delay for retry attempt.
     *
     * Uses exponential backoff: delay = min(initialDelay * (2^attempt), maxDelay)
     *
     * @param attemptNumber The retry attempt number (0-indexed)
     * @return Delay in milliseconds
     */
    private fun calculateBackoffDelay(attemptNumber: Int): Long {
        val exponentialDelay =
            refreshConfig.initialRetryDelayMs *
                (2.0.pow(attemptNumber)).toLong()
        return min(exponentialDelay, refreshConfig.maxRetryDelayMs)
    }

    /**
     * Clears all tokens and metadata from storage.
     *
     * Called when terminal errors occur (invalid_grant, storage errors).
     * This ensures clean state for re-authentication.
     */
    private suspend fun clearAllTokensAndMetadata() {
        tokenStorage.clearTokens()
        tokenStorage.clearRefreshTokenMetadata()
    }

    /**
     * Evaluates the current state of tokens for refresh decision-making.
     *
     * This method determines whether tokens are valid, expired, or expiring soon
     * based on JWT expiration claims and refresh configuration.
     *
     * @param tokenResponse The token response to evaluate, or null if no tokens exist
     * @param refreshConfig The refresh configuration with thresholds
     * @return The current TokenState
     */
    private suspend fun evaluateTokenState(
        tokenResponse: TokenResponseDto?,
        refreshConfig: TokenRefreshConfig,
    ): EvaluatedTokenState {
        // No tokens available
        if (tokenResponse == null) {
            return EvaluatedTokenState.NoTokens
        }

        // Check if access token is expired
        if (jwtValidationService.isAccessTokenExpired(tokenResponse.accessToken)) {
            return EvaluatedTokenState.Expired
        }

        // Check if access token is expiring soon.
        // Use the adaptive threshold so that short-lived IDP tokens (e.g. 60s) are not
        // permanently stuck in ExpiringSoon when the SDK default threshold (300s) exceeds
        // the token lifetime. calculateAdaptiveThreshold handles that fallback.
        val threshold =
            calculateAdaptiveThreshold(
                tokenLifetime = tokenResponse.expiresIn,
                configuredThreshold = refreshConfig.refreshThresholdSeconds,
            )
        if (jwtValidationService.isAccessTokenExpiringSoon(tokenResponse.accessToken, threshold)) {
            return EvaluatedTokenState.ExpiringSoon
        }

        // Token is valid and not expiring soon
        return EvaluatedTokenState.Valid
    }

    override suspend fun getCurrentTokenState(): TokenState {
        val tokens = tokenStorage.getTokens()
        return evaluateTokenState(tokens, refreshConfig).toTokenState()
    }

    override suspend fun hasRefreshToken(): Boolean {
        val tokens = tokenStorage.getTokens()
        return tokens?.refreshToken != null
    }

    override suspend fun getRefreshToken(): String? = tokenStorage.getTokens()?.refreshToken

    override suspend fun getAccessToken(forceRefresh: Boolean): SdkResult<AccessToken> {
        // Step 1: Check tokens exist.
        // Emit NoTokens immediately so observers (especially in Manual mode) see the
        // real state instead of being stuck on the StateFlow's stale value.
        val tokens = tokenStorage.getTokens()
        if (tokens == null) {
            updateTokenStateAndEmitEvent(TokenState.NoTokens)
            return SdkResult.Failure(SrgLoginError.NotAuthenticated)
        }

        val accessTokenString = tokens.accessToken

        // Step 2: Force refresh path — bypass local evaluation and the freshness check,
        // go straight to a network refresh. The caller has explicitly requested a refresh
        // (e.g. after a 401), so the freshness check must not short-circuit it. (ADR-010)
        if (forceRefresh) {
            val refreshResult = refreshTokens(skipFreshnessCheck = true)
            return when (refreshResult) {
                is SdkResult.Success -> SdkResult.Success(refreshResult.data.accessToken)
                is SdkResult.Failure -> refreshResult
            }
        }

        // Step 3: Evaluate current state and emit it on the StateFlow.
        // This is the "interactive view" mechanism for Manual mode (ADR-010):
        // observeTokenState() must reflect the latest evaluation, and the only non-time-based
        // opportunity to do so is when the app calls getAccessToken().
        // In Automatic mode this is redundant with the monitoring loop's emissions — but harmless,
        // because StateFlow deduplicates identical values.
        val tokenState = evaluateTokenState(tokens, refreshConfig)
        updateTokenStateAndEmitEvent(tokenState.toTokenState())

        // Step 4: Return the token or refresh if expired.
        return when (tokenState) {
            EvaluatedTokenState.Valid, EvaluatedTokenState.ExpiringSoon -> {
                // Current token is still usable. In Automatic mode, the monitoring loop
                // will handle proactive refresh for ExpiringSoon. In Manual mode, the app
                // may choose to call getAccessToken(forceRefresh = true) later.
                parseAndReturnAccessToken(accessTokenString)
            }

            EvaluatedTokenState.Expired -> {
                // Token is expired — refresh synchronously before returning.
                // refreshTokens() emits Refreshing → Refreshed/RefreshFailed internally.
                val refreshResult = refreshTokens()
                when (refreshResult) {
                    is SdkResult.Success -> SdkResult.Success(refreshResult.data.accessToken)
                    is SdkResult.Failure -> refreshResult
                }
            }

            EvaluatedTokenState.NoTokens -> {
                // Defensive: evaluateTokenState() may reach this if tokens were cleared
                // between the null check above and the evaluation.
                SdkResult.Failure(SrgLoginError.NotAuthenticated)
            }
        }
    }

    /**
     * Helper function to parse JWT and return AccessToken.
     *
     * @param tokenString Raw JWT token string
     * @return SdkResult with AccessToken on success, or error on parsing failure
     */
    private suspend fun parseAndReturnAccessToken(tokenString: String): SdkResult<AccessToken> =
        try {
            val parseResult = jwtValidationService.parseJwt(tokenString)
            if (parseResult.isSuccess) {
                val parsedJwt = parseResult.getOrThrow()
                val accessToken = AccessToken.fromJwt(tokenString, parsedJwt.claims)
                SdkResult.Success(accessToken)
            } else {
                // JWT parsing failed
                val error =
                    SrgLoginError.UnknownError(
                        cause = parseResult.exceptionOrNull() ?: Exception("Failed to parse JWT"),
                        context = "Failed to parse access token JWT",
                    )

                ErrorHandlerRegistry.captureException(
                    throwable = parseResult.exceptionOrNull() ?: Exception("JWT parsing failed"),
                    context =
                        mapOf(
                            "operation" to "parse_access_token",
                            "stage" to "jwt_parsing",
                        ),
                    level = ErrorHandler.ErrorLevel.ERROR,
                )

                SdkResult.Failure(error)
            }
        } catch (e: Exception) {
            val error =
                SrgLoginError.UnknownError(
                    cause = e,
                    context = "Error parsing access token JWT",
                )

            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "parse_access_token",
                        "exception_type" to e::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.ERROR,
            )

            SdkResult.Failure(error)
        }

    override suspend fun isAuthenticated(): Boolean {
        SdkLogger.d(LogCategory.TOKEN_MONITORING) { "Checking authentication status" }

        // If the last refresh failed with invalid_grant, the session is definitively over.
        // clearAllTokensAndMetadata() is called before SessionInvalidated is emitted, so
        // storage is already empty by the time StateFlow reaches RefreshFailed(InvalidGrant).
        // This guard closes any residual inconsistency window and makes isAuthenticated()
        // consistent with the observable StateFlow value for this terminal error type.
        //
        // Note: RefreshFailed(NetworkError) is intentionally excluded — tokens are NOT
        // cleared for transient failures, so isAuthenticated() should still return true
        // and let the storage check below provide the authoritative answer.
        val currentStateFlowValue = _tokenStateFlow.value
        val isInvalidGrantFailure =
            currentStateFlowValue is TokenState.RefreshFailed &&
                currentStateFlowValue.error is SrgLoginError.InvalidGrant

        val tokens = tokenStorage.getTokens()

        // Strict semantics (LOGIN-1883): a user is authenticated only when a
        // non-expired access token is in storage. The presence of a refresh
        // token is NOT enough — refresh tokens can be revoked server-side
        // (admin revocation, password change, refresh-token-rotation reuse
        // detection) without the SDK being able to detect it locally.
        // Callers who want to know whether a silent refresh is possible
        // should use hasRefreshToken() instead.
        val hasAccessToken = tokens?.accessToken?.isNotEmpty() ?: false
        val accessTokenExpired = tokens?.let { jwtValidationService.isAccessTokenExpired(it.accessToken) } ?: true
        val hasValidAccessToken = hasAccessToken && !accessTokenExpired
        val hasRefreshToken = tokens?.refreshToken != null

        SdkLogger.d(LogCategory.TOKEN_MONITORING) {
            "Access token present: $hasAccessToken, expired: $accessTokenExpired, " +
                "valid: $hasValidAccessToken, has refresh: $hasRefreshToken, " +
                "invalid_grant failure: $isInvalidGrantFailure"
        }

        val isAuthenticated = !isInvalidGrantFailure && hasValidAccessToken
        SdkLogger.i(LogCategory.TOKEN_MONITORING) { "Authentication check result: $isAuthenticated" }

        return isAuthenticated
    }

    override fun observeTokenState(): StateFlow<TokenState> {
        // The StateFlow update cadence depends on TokenRefreshMode (ADR-010):
        //
        // - Initial value: TokenState.Uninitialized — replaced by a real state
        //   (Valid/ExpiringSoon/Expired/NoTokens) within milliseconds of construction
        //   via a one-shot storage evaluation launched in init {}.
        //   Observers should treat Uninitialized as "not yet known" (show splash).
        //
        // - Subsequent updates:
        //   * Automatic: updated continuously by the background monitoring loop.
        //   * Manual: updated on each getAccessToken() call + on login/logout events.
        //
        // In both modes, refreshTokens() is the single source of truth for
        // Refreshing → Refreshed/RefreshFailed transitions.
        return _tokenStateFlow.asStateFlow()
    }

    override suspend fun startTokenMonitoring() {
        // Check if automatic monitoring is enabled
        if (refreshConfig.mode !is TokenRefreshMode.Automatic) {
            SdkLogger.w(LogCategory.TOKEN_MONITORING) { "Automatic token monitoring is disabled in config" }
            return
        }

        // Cancel any existing monitoring job so the new cycle begins with an immediate
        // updateTokenState() call. This guarantees that any caller — LoginSuccess,
        // AppForegrounded, TokenRefreshSuccess, etc. — always triggers a fresh evaluation
        // rather than waiting out the remainder of a previously-scheduled sleep interval.
        if (monitoringJob?.isActive == true) {
            SdkLogger.d(LogCategory.TOKEN_MONITORING) { "Restarting token monitoring for immediate re-evaluation" }
            monitoringJob?.cancel()
            monitoringJob = null
        }

        SdkLogger.i(LogCategory.TOKEN_MONITORING) {
            "Launching automatic token monitoring " +
                "(mode: ${refreshConfig.mode}, " +
                "refreshThresholdSeconds: ${refreshConfig.refreshThresholdSeconds}s, " +
                "maxRetryAttempts: ${refreshConfig.maxRetryAttempts})"
        }

        // Launch monitoring coroutine in background scope
        monitoringJob =
            monitoringScope.launch {
                var cycleCount = 0
                while (isActive) {
                    try {
                        cycleCount++
                        SdkLogger.d(LogCategory.TOKEN_MONITORING) { "Monitoring cycle #$cycleCount - Checking token state" }

                        // Update token state and get next check interval
                        val nextIntervalSeconds = updateTokenState()

                        SdkLogger.i(LogCategory.TOKEN_MONITORING) {
                            "Next check scheduled in ${nextIntervalSeconds}s (${nextIntervalSeconds / 60}m)"
                        }

                        // Wait for calculated interval (in milliseconds)
                        delay(nextIntervalSeconds * 1000L)
                    } catch (e: CancellationException) {
                        // Monitoring job was intentionally cancelled (e.g. startTokenMonitoring()
                        // restart). Rethrow so the coroutine exits cleanly instead of logging
                        // a spurious "Monitoring error".
                        throw e
                    } catch (e: Exception) {
                        // Log error but continue monitoring
                        SdkLogger.w(LogCategory.TOKEN_MONITORING, throwable = e) { "Monitoring error, retrying in 60s" }

                        // Report to error tracking
                        ErrorHandlerRegistry.captureException(
                            throwable = e,
                            context =
                                mapOf(
                                    "operation" to "token_monitoring",
                                    "cycle" to cycleCount,
                                    "recovery_action" to "retry_after_60s",
                                ),
                            level = ErrorHandler.ErrorLevel.WARNING,
                        )

                        // Wait default interval before retrying
                        delay(60_000L) // 60 seconds
                    }
                }
            }
    }

    override fun stopTokenMonitoring() {
        SdkLogger.i(LogCategory.TOKEN_MONITORING) { "Stopping automatic token monitoring" }

        // Cancel monitoring job if active
        monitoringJob?.cancel()
        monitoringJob = null
    }

    /**
     * Reads the current token storage and emits the evaluated state on the StateFlow.
     *
     * Used by lifecycle event handlers to keep the observable state in sync with storage
     * changes, particularly in Manual mode where no background monitoring loop exists.
     * In Automatic mode, this provides immediate feedback instead of waiting for the
     * next monitoring loop iteration.
     *
     * StateFlow deduplicates identical values, so calling this when the state hasn't
     * changed is harmless.
     */
    private suspend fun emitCurrentStateFromStorage() {
        val tokens = tokenStorage.getTokens()
        val state =
            if (tokens == null) {
                EvaluatedTokenState.NoTokens
            } else {
                evaluateTokenState(tokens, refreshConfig)
            }
        updateTokenStateAndEmitEvent(state.toTokenState())
    }

    /**
     * Updates the token state in [_tokenStateFlow] and emits [SdkLifecycleEvent.TokenStateChanged]
     * on the event bus — but **only when the state actually changes**.
     *
     * `MutableStateFlow` deduplicates identical values automatically (no notification to
     * collectors when `value = sameValue`). The event bus, by contrast, has no built-in
     * deduplication: every `emit()` reaches every subscriber. Without this guard, callers
     * that re-evaluate the state without it changing — e.g. the monitoring loop running
     * a check while the token is still `Valid`, or repeated `getAccessToken()` calls in
     * a burst — would generate duplicate `TokenStateChanged` events on the bus, polluting
     * analytics, logs, and Sentry breadcrumbs while the StateFlow stays silent.
     *
     * Comparing `previousState != newState` before emitting the event aligns the bus with
     * the StateFlow's "changed only" semantic and makes the `TokenStateChanged` event name
     * truthful: it now signals an actual transition, not a re-evaluation. (PR #71 review #8)
     *
     * @param newState The new token state
     */
    private suspend fun updateTokenStateAndEmitEvent(newState: TokenState) {
        val previousState = _tokenStateFlow.value
        _tokenStateFlow.value = newState
        if (previousState != newState) {
            val timestamp = Clock.System.now().toEpochMilliseconds()
            eventEmitter.emit(SdkLifecycleEvent.TokenStateChanged(newState, timestamp))
        }
    }

    /**
     * Updates the token state and triggers refresh if needed.
     *
     * This is the core monitoring logic that:
     * 1. Reads current tokens from storage
     * 2. Calculates adaptive threshold based on token lifetime
     * 3. Determines current token state
     * 4. Triggers proactive refresh for ExpiringSoon/Expired states
     * 5. Updates StateFlow for UI observation
     * 6. Returns next check interval for smart scheduling
     *
     * **Adaptive Threshold**:
     * - Short tokens (< 5 min): Use 50% of lifetime (min 10s)
     * - Long tokens (≥ 5 min): Use configured threshold (capped at 25% of lifetime)
     *
     * **Smart Scheduling**:
     * - Valid: Check halfway to threshold (30s - 15min)
     * - ExpiringSoon: Check every 30s
     * - Expired/NoTokens: Check every 5min
     * - Refreshing: Check every 10s
     *
     * @return Next check interval in seconds
     */
    private suspend fun updateTokenState(): Long {
        // Step 1: Read current tokens
        val tokens = tokenStorage.getTokens()

        if (tokens == null) {
            // No tokens available
            updateTokenStateAndEmitEvent(TokenState.NoTokens)
            return 300L // Check again in 5 minutes
        }

        // Step 2: Calculate token lifetime and adaptive threshold
        val tokenLifetime = tokens.expiresIn

        val adaptiveThreshold =
            calculateAdaptiveThreshold(
                tokenLifetime = tokenLifetime,
                configuredThreshold = refreshConfig.refreshThresholdSeconds,
            )

        // Step 3: Determine current token state
        val currentState = evaluateTokenState(tokens, refreshConfig)

        // Step 4: Calculate time until expiration (for smart scheduling)
        // Use JWT exp claim as authoritative source — TokenResponseDto.expiresAt is a
        // computed getter (now + expiresIn), not a stored timestamp, so it cannot be
        // used to measure remaining time.
        val now = Clock.System.now().epochSeconds
        val expFromJwt =
            jwtValidationService
                .parseJwt(tokens.accessToken)
                .getOrNull()
                ?.claims
                ?.exp
        val timeUntilExpiration =
            if (expFromJwt != null) {
                (expFromJwt - now).coerceAtLeast(0L)
            } else {
                tokenLifetime // Fallback: conservative, treats token as just-issued
            }

        // Step 5: Trigger proactive refresh if needed (Automatic mode only).
        // In Automatic mode, the monitoring loop always refreshes proactively on
        // ExpiringSoon/Expired. There is no "observe without refresh" sub-option —
        // that use case is served by Manual mode. (ADR-010, YAGNI simplification)
        if (refreshConfig.mode is TokenRefreshMode.Automatic) {
            when (currentState) {
                EvaluatedTokenState.ExpiringSoon, EvaluatedTokenState.Expired -> {
                    // Emit the actual current state before launching the background refresh.
                    updateTokenStateAndEmitEvent(currentState.toTokenState())

                    // Launch refresh in background (don't block monitoring loop).
                    // refreshTokens() is the Single Source of Truth for state transitions:
                    // it emits Refreshing → Refreshed/RefreshFailed internally (ADR-010).
                    monitoringScope.launch {
                        SdkLogger.i(LogCategory.TOKEN_MONITORING) {
                            "Auto-refresh triggered (state=$currentState, timeUntilExpiration=${timeUntilExpiration}s)"
                        }
                        refreshTokens()
                    }
                }

                else -> {
                    // No refresh needed, just update state
                    updateTokenStateAndEmitEvent(currentState.toTokenState())
                }
            }
        } else {
            // Manual mode should never reach here (monitoring doesn't run),
            // but defensive: just update state without refresh.
            updateTokenStateAndEmitEvent(currentState.toTokenState())
        }

        // Step 6: Calculate next check interval using smart scheduling
        val nextInterval =
            calculateNextCheckInterval(
                currentState = currentState,
                timeUntilExpiration = timeUntilExpiration,
                threshold = adaptiveThreshold,
            )

        SdkLogger.d(LogCategory.TOKEN_MONITORING) {
            "Token state: $currentState | Next check: ${nextInterval}s (${nextInterval / 60}m) | Adaptive threshold: ${adaptiveThreshold}s"
        }

        return nextInterval
    }

    /**
     * Returns the effective threshold for ExpiringSoon detection.
     *
     * The threshold is an independent SDK configuration ([TokenRefreshConfig.refreshThresholdSeconds])
     * and is used as-is. The only fallback applies when the configured threshold equals or exceeds
     * the token lifetime — which can happen when the IDP issues short-lived tokens (e.g. 60s for
     * testing) against an SDK default of 300s. In that case the threshold is capped at half the
     * token lifetime so the token still progresses through Valid → ExpiringSoon → Expired.
     *
     * Examples:
     * - 3600s token, 300s config → 300s  (normal case, config used as-is)
     * - 60s token,   300s config → 30s   (fallback: 300 >= 60, so 60/2)
     * - 8s token,    300s config → 4s    (fallback: 300 >= 8,  so 8/2)
     *
     * @param tokenLifetime Original token lifetime in seconds (from [TokenResponseDto.expiresIn])
     * @param configuredThreshold Configured threshold from [TokenRefreshConfig.refreshThresholdSeconds]
     * @return Effective threshold in seconds
     */
    private fun calculateAdaptiveThreshold(
        tokenLifetime: Long,
        configuredThreshold: Long,
    ): Long {
        // Use the configured threshold as-is. The only fallback is when the threshold
        // equals or exceeds the token lifetime (e.g. SDK default 300s threshold with a
        // short-lived IDP test token of 60s). In that case cap at half the lifetime so
        // the token can still pass through Valid → ExpiringSoon → Expired rather than
        // starting in ExpiringSoon immediately.
        return if (configuredThreshold >= tokenLifetime) {
            (tokenLifetime / 2).coerceAtLeast(1L)
        } else {
            configuredThreshold
        }
    }

    /**
     * Schedules the next monitoring cycle at the exact moment of the next state transition.
     *
     * - **Valid**: fires at `timeUntilExpiration - threshold` — the instant the token enters
     *   ExpiringSoon. Capped at 900s so very long-lived tokens still get a periodic check.
     * - **ExpiringSoon**: fires at `timeUntilExpiration` — the instant the token expires.
     *   This handles any remaining time correctly, including app restarts mid-lifetime
     *   (e.g. 28s left on a 3600s token is detected and fires in exactly 28s).
     * - **Expired/NoTokens**: 300s — infrequent polling while waiting for re-authentication.
     *
     * Both Valid and ExpiringSoon intervals are floored at 1s to prevent tight loops.
     *
     * @param currentState Current evaluated token state (storage-derived, 4 values only)
     * @param timeUntilExpiration Seconds until the token expires (from JWT exp claim)
     * @param threshold Effective threshold in seconds (from [calculateAdaptiveThreshold])
     * @return Next check interval in seconds
     */
    private fun calculateNextCheckInterval(
        currentState: EvaluatedTokenState,
        timeUntilExpiration: Long,
        threshold: Long,
    ): Long =
        when (currentState) {
            EvaluatedTokenState.Valid -> {
                // Schedule exactly at the Valid → ExpiringSoon transition point.
                // Cap at 900s so very long-lived tokens (e.g. 5h) still get a periodic
                // check, and floor at 1s to avoid a tight loop.
                val timeUntilExpiringSoon = timeUntilExpiration - threshold
                timeUntilExpiringSoon.coerceIn(1L, 900L)
            }

            EvaluatedTokenState.ExpiringSoon -> {
                // Schedule exactly at the ExpiringSoon → Expired transition point.
                // Floor at 1s to avoid a tight loop on already-expired tokens.
                timeUntilExpiration.coerceAtLeast(1L)
            }

            EvaluatedTokenState.Expired, EvaluatedTokenState.NoTokens -> {
                // Check every 5min (infrequent, waiting for manual re-auth)
                300L
            }
        }

    override fun dispose() {
        SdkLogger.i(LogCategory.TOKEN_MONITORING) { "Cleaning up TokenManager resources" }

        // Stop monitoring
        stopTokenMonitoring()

        // Cancel monitoring scope (cleanup all background jobs)
        monitoringScope.cancel()

        SdkLogger.i(LogCategory.TOKEN_MONITORING) { "TokenManager cleanup complete" }
    }

    /**
     * Computes SHA-256 hash of the refresh token for rotation tracking.
     *
     * Used for debugging token rotation issues. The hash is stored in metadata
     * instead of the actual token value for security and privacy.
     *
     * **Security Note**: This hash is for debugging/analytics purposes only,
     * not for authentication. It helps detect token rotation issues without
     * storing the actual refresh token value in metadata.
     *
     * @param refreshToken The refresh token to hash
     * @return SHA-256 hash of the token as lowercase hex string (64 characters)
     */
    private fun hashRefreshToken(refreshToken: String): String {
        val tokenBytes = refreshToken.encodeToByteArray()
        val hashBytes = cryptoService.sha256(tokenBytes)

        // Convert bytes to lowercase hex string
        return hashBytes.joinToString("") { byte ->
            byte.toUByte().toString(16).padStart(2, '0')
        }
    }
}
