package ch.srg.login.sdk.model

/**
 * Common shape for types that expose a map of OIDC claims with type-safe accessors.
 *
 * Implemented by [IdTokenClaims] (auth-proof claims) and [UserInfo] (profile claims).
 * Both types carry a [rawClaims] map of non-standard / IDP-specific claims — the
 * accessors here let consumers read those claims without dealing with the
 * platform-agnostic [ClaimValue] sealed class directly. Implementation lives in
 * one place via default methods, eliminating duplication across the two types.
 *
 * **Type strictness**: the accessors apply **strict** JSON type checks — a JSON
 * string `"42"` is NOT coerced to a Long, a JSON string `"true"` is NOT coerced
 * to a Boolean. This preserves the semantic distinction between "missing",
 * "wrong type", and "valid value" for downstream code.
 *
 * **Cross-platform note**: SKIE exposes this as a Swift `protocol` with default
 * implementations on iOS / tvOS; Kotlin/JS surfaces it as a TypeScript interface;
 * Java consumers get a regular interface with default methods (Java 8+).
 */
public interface ClaimContainer {
    /**
     * IDP-specific or non-standard claims preserved as [ClaimValue]
     * (lossless, platform-agnostic). Standard OIDC typed claims are filtered out
     * by the SDK so consumers see each claim in exactly one place — either as a
     * typed property on the implementing type, or here.
     */
    public val rawClaims: Map<String, ClaimValue>

    /**
     * Returns the string content of a JSON string claim, or `null` if the claim
     * is absent or not a JSON string. Numeric / boolean / array / object values
     * return `null` — no coercion.
     */
    public fun getStringClaim(name: String): String? = rawClaims[name]?.asText

    /**
     * Returns the Long value of a JSON integer claim, or `null` if the claim is
     * absent or is not an integer. Fractional ([ClaimValue.Decimal]) and
     * JSON-string values return `null` — strict type check.
     */
    public fun getLongClaim(name: String): Long? = rawClaims[name]?.asInteger

    /**
     * Returns the boolean value of a JSON boolean claim, or `null` if the claim
     * is absent or not a JSON boolean. JSON strings (even `"true"` / `"false"`)
     * return `null` — strict type check.
     */
    public fun getBooleanClaim(name: String): Boolean? = rawClaims[name]?.asBoolean

    /**
     * Returns the list of JSON-string elements from a JSON array claim, or `null`
     * if the claim is absent or not a JSON array.
     *
     * The [strict] parameter controls how mixed-type arrays are handled:
     * - `strict = false` (default, lenient): non-string elements are filtered out.
     *   An array `["admin", 2, "editor"]` returns `["admin", "editor"]`.
     *   **Note**: a non-empty array containing **only** non-string elements
     *   returns an empty list, indistinguishable from a genuinely empty array
     *   `[]`. Use `strict = true` if you need to detect this case.
     * - `strict = true`: returns `null` if **any** element is a non-string
     *   (including [ClaimValue.Null]). Same `["admin", 2, "editor"]` returns
     *   `null`. Useful for monitoring IDP data quality or failing closed.
     *
     * Empty array claim returns an empty list (not `null`) in both modes.
     * Returns `null` only if the claim is absent or not a JSON array.
     */
    public fun getStringListClaim(
        name: String,
        strict: Boolean = false,
    ): List<String>? {
        val array = rawClaims[name]?.asArray ?: return null
        val strings = array.mapNotNull { it.asText }
        return when {
            !strict -> strings
            strings.size == array.size -> strings
            else -> null
        }
    }

    /**
     * Returns the fields of a JSON object claim as `Map<String, ClaimValue>`, or
     * `null` if the claim is absent or not a JSON object.
     */
    public fun getObjectClaim(name: String): Map<String, ClaimValue>? = rawClaims[name]?.asObject

    /**
     * Returns the items of a JSON array claim as `List<ClaimValue>`, or `null`
     * if the claim is absent or not a JSON array.
     */
    public fun getArrayClaim(name: String): List<ClaimValue>? = rawClaims[name]?.asArray

    /**
     * Returns `true` if [name] is present in [rawClaims] (i.e. is a non-standard
     * / IDP-specific claim), regardless of its value type (including
     * [ClaimValue.Null]).
     *
     * **Standard OIDC claims are NOT covered by this function** — they are
     * exposed as typed properties on the implementing type and removed from
     * [rawClaims] to avoid duplication.
     */
    public fun hasCustomClaim(name: String): Boolean = name in rawClaims
}
