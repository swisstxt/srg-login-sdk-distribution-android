package ch.srg.login.sdk.errors

import ch.srg.login.sdk.internal.SecurityUtils

/**
 * Maps a [SrgLoginError] to a stable, consumer-facing error **code** — the string equivalent of
 * the mobile `when (error)` branch, so JS/TS consumers can branch programmatically instead of
 * parsing free text.
 *
 * Explicit and exhaustive on purpose: never `::class.simpleName` (DCE/minification can drop or
 * mangle it in production JS, exactly where stability is the point), and adding a new
 * [SrgLoginError] variant breaks compilation here — naming its public code becomes a conscious
 * API decision rather than a silent leak.
 *
 * Lives in commonMain (not the jsMain facade) so it is testable on every target without the JS
 * test harness and reusable by any future facade that flattens the sealed hierarchy.
 */
@Suppress("CyclomaticComplexMethod") // Exhaustive when over the sealed hierarchy — that exhaustiveness IS the point.
internal fun SrgLoginError.toPublicErrorCode(): String =
    when (this) {
        is SrgLoginError.InvalidConfiguration -> "InvalidConfiguration"
        is SrgLoginError.NetworkError -> "NetworkError"
        is SrgLoginError.HttpError -> "HttpError"
        is SrgLoginError.SerializationError -> "SerializationError"
        is SrgLoginError.InvalidDataError -> "InvalidDataError"
        SrgLoginError.TokenExpired -> "TokenExpired"
        SrgLoginError.NotAuthenticated -> "NotAuthenticated"
        is SrgLoginError.InvalidGrant -> "InvalidGrant"
        is SrgLoginError.TokenStorageError -> "TokenStorageError"
        is SrgLoginError.UserCancelled -> "UserCancelled"
        is SrgLoginError.AuthenticationTimeout -> "AuthenticationTimeout"
        is SrgLoginError.UnsupportedPlatform -> "UnsupportedPlatform"
        is SrgLoginError.PlatformError -> "PlatformError"
        is SrgLoginError.InvalidLogoutToken -> "InvalidLogoutToken"
        is SrgLoginError.UnknownError -> "UnknownError"
    }

/**
 * A human-readable, **sanitized** message safe to expose across a stringifying boundary (the
 * `@JsExport` facade, where the SDK itself produces the consumer-facing text).
 *
 * Built from each variant's SAFE fields only — never the data-class `toString()`, which would
 * dump `cause` (the full underlying exception, incl. Ktor request URLs / response-body
 * excerpts), `HttpError.url`, or `SerializationError.originalMessage` (raw parser text possibly
 * embedding token-response JSON) — then passed through [SecurityUtils.sanitizeErrorMessage] as
 * a second defensive layer.
 */
@Suppress("CyclomaticComplexMethod") // Exhaustive when over the sealed hierarchy — that exhaustiveness IS the point.
internal fun SrgLoginError.toSanitizedPublicMessage(): String {
    // Safe fields only (see KDoc): HttpError omits `url`, SerializationError omits
    // `originalMessage`, and *Error variants with a `cause` never surface it.
    val raw =
        when (this) {
            is SrgLoginError.InvalidConfiguration -> reason
            is SrgLoginError.NetworkError -> details ?: "Network request failed"
            is SrgLoginError.HttpError -> "HTTP $code"
            is SrgLoginError.SerializationError -> "Malformed server response"
            is SrgLoginError.InvalidDataError -> reason
            SrgLoginError.TokenExpired -> "Session expired, please sign in again"
            SrgLoginError.NotAuthenticated -> "Not authenticated"
            is SrgLoginError.InvalidGrant -> errorDescription ?: "Authorization was revoked or expired"
            is SrgLoginError.TokenStorageError -> message
            is SrgLoginError.UserCancelled -> reason
            is SrgLoginError.AuthenticationTimeout -> message
            is SrgLoginError.UnsupportedPlatform -> message
            is SrgLoginError.PlatformError -> message
            is SrgLoginError.InvalidLogoutToken -> message
            is SrgLoginError.UnknownError -> "Unexpected error"
        }
    return SecurityUtils.sanitizeErrorMessage(raw)
}
