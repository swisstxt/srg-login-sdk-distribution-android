package ch.srg.login.sdk.model

/**
 * OIDC Address Claim (OIDC Core 1.0 §5.1.1).
 *
 * All fields are optional per the spec — only [formatted] is "RECOMMENDED" but not required.
 * Populated only when the IDP grants the `address` scope.
 *
 * Exposed via [UserInfo.address] (after login from the validated ID Token, or after a call
 * to `srgLogin.getUserInfo()` from the OIDC `/userinfo` endpoint).
 *
 * The primary constructor and the generated `copy()` are `internal` — consistent with
 * [UserInfo] and [IdTokenClaims]. Consumers obtain an [Address] only via [UserInfo.address],
 * which guarantees the value was produced from a cryptographically validated ID Token or
 * from a `/userinfo` response with a `sub`-matched access token.
 *
 * @property formatted Full mailing address, formatted for display or use on a mailing label.
 * @property streetAddress Full street address component (house number, street name, etc.).
 * @property locality City or locality component.
 * @property region State, province, or region component.
 * @property postalCode Zip code or postal code component.
 * @property country Country name component.
 */
@ConsistentCopyVisibility
public data class Address internal constructor(
    val formatted: String? = null,
    val streetAddress: String? = null,
    val locality: String? = null,
    val region: String? = null,
    val postalCode: String? = null,
    val country: String? = null,
)
