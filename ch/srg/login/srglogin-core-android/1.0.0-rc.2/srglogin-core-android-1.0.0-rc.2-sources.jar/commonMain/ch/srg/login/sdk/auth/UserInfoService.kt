package ch.srg.login.sdk.auth

import ch.srg.login.sdk.data.OpenIdConfigRepository
import ch.srg.login.sdk.data.api.SrgAuthApiService
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.logging.ErrorHandler
import ch.srg.login.sdk.logging.ErrorHandlerRegistry
import ch.srg.login.sdk.logging.LogCategory
import ch.srg.login.sdk.logging.SdkLogger
import ch.srg.login.sdk.model.UserInfo
import ch.srg.login.sdk.result.SdkResult
import ch.srg.login.sdk.token.TokenStorage
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * Internal service exposing the End-User profile information ([UserInfo]) at
 * any time during the session.
 *
 * INTERNAL: not part of the public SDK API. Consumers interact via
 * [ch.srg.login.sdk.SrgLogin.getUserInfo].
 *
 * ## Two paths
 *
 * - `forceRefresh = false` → returns the cached snapshot from [TokenStorage],
 *   populated automatically at the last login or token refresh (see
 *   `TokenSuccessHandler` and `TokenManagerImpl`). Fast (no network call).
 * - `forceRefresh = true` → fetches the current profile from the OIDC
 *   `/userinfo` endpoint (OIDC Core §5.3), validates the `sub` matches the
 *   access token's `sub` (§5.3.2 mismatch protection), and replaces the cache.
 *
 * ## Composition contract for the network path (option B hybrid)
 *
 * - The access token is obtained via [TokenManager.getAccessToken] — which
 *   transparently refreshes on `Expired`, identical contract to
 *   [ch.srg.login.sdk.SrgLogin.getAccessToken]. **No retry-on-401** is
 *   performed inside; on 401 from `/userinfo`, the failure surfaces to the
 *   caller, who decides whether to compose `getAccessToken(forceRefresh = true)`
 *   + retry. This keeps the SDK contract symmetric.
 * - Concurrent network calls are serialised by an internal [Mutex] so they
 *   do not overlap and cannot race each other into a last-write-wins on the
 *   cache. Calls are serialised, **not de-duplicated** — each concurrent
 *   caller still triggers its own `/userinfo` round-trip, just one after the
 *   other. The cache path (forceRefresh = false) bypasses the mutex — pure
 *   reads from secure storage are safe to run in parallel.
 *
 * ## Error catalog
 *
 * - [SrgLoginError.NotAuthenticated] — `forceRefresh = true` and no tokens
 *   available to obtain an access token (genuinely no session).
 * - [SrgLoginError.InvalidDataError] with a "No cached UserInfo" reason —
 *   `forceRefresh = false` and the cache is empty. This is **not** a
 *   "no session" signal: it also occurs for a valid session without the
 *   `openid` scope, or before the first login/refresh. Do not redirect to
 *   login on this error without checking session state.
 * - [SrgLoginError.InvalidConfiguration] — `/userinfo` endpoint blank or not
 *   HTTPS (misconfigured discovery document).
 * - [SrgLoginError.HttpError] — HTTP 4xx/5xx from `/userinfo`. A 401 typically
 *   means the access token was rejected (revoked, scope issue, clock skew);
 *   the caller may retry with `srgLogin.getAccessToken(forceRefresh = true)`
 *   followed by a fresh `getUserInfo(forceRefresh = true)`.
 * - [SrgLoginError.SerializationError] — `/userinfo` response malformed
 *   (invalid JSON) or missing the required `sub` claim (OIDC §5.3.2).
 * - [SrgLoginError.InvalidDataError] with `reason == "OIDC §5.3.2: userinfo
 *   sub mismatch"` — the `sub` returned by `/userinfo` does not match the
 *   access token's `sub`. The cache is **not** updated; the response is
 *   discarded. The reason string is stable across versions and forms a
 *   partial public contract — pattern-matching on it is supported.
 * - [SrgLoginError.NetworkError] — transport failure (timeout, DNS, no
 *   connectivity).
 *
 * ## Cancellation
 *
 * `CancellationException` propagates as-is at every level (cache read, token
 * fetch, HTTP call). Cancelled coroutines never produce spurious failures.
 */
internal interface UserInfoService {
    /**
     * Returns the End-User profile information.
     *
     * @param forceRefresh `true` to call `/userinfo` and replace the cache;
     *   `false` to return the cached value (fast path).
     */
    suspend fun getUserInfo(forceRefresh: Boolean): SdkResult<UserInfo>
}

/**
 * Production implementation of [UserInfoService].
 *
 * @property tokenManager Used on the network path to obtain a valid access
 *   token (auto-refresh on `Expired`).
 * @property apiService HTTP layer for `/userinfo` (handles HTTPS validation,
 *   error mapping, sanitisation).
 * @property tokenStorage Secure storage for the [UserInfo] cache (read +
 *   write).
 * @property openIdConfigRepository Source of the `/userinfo` endpoint URL.
 */
internal class UserInfoServiceImpl(
    private val tokenManager: TokenManager,
    private val apiService: SrgAuthApiService,
    private val tokenStorage: TokenStorage,
    private val openIdConfigRepository: OpenIdConfigRepository,
) : UserInfoService {
    /**
     * Serialises concurrent `/userinfo` calls. Only the network path holds the
     * mutex — cache reads (forceRefresh = false) bypass it entirely.
     */
    private val networkMutex = Mutex()

    override suspend fun getUserInfo(forceRefresh: Boolean): SdkResult<UserInfo> =
        if (forceRefresh) {
            networkMutex.withLock { fetchFromNetwork() }
        } else {
            readFromCache()
        }

    /**
     * Cache-only path: returns the snapshot persisted at the last login or
     * token refresh.
     *
     * An empty cache is reported as [SrgLoginError.InvalidDataError], **not**
     * [SrgLoginError.NotAuthenticated]: a missing UserInfo snapshot does not
     * imply "no session" — it also happens for a valid session where the
     * `openid` scope was not granted (no ID Token → nothing to seed), or
     * before the first login/refresh of a process. Returning
     * `NotAuthenticated` here would mislead callers into redirecting an
     * authenticated user to the login screen.
     */
    private suspend fun readFromCache(): SdkResult<UserInfo> {
        val cached = tokenStorage.getUserInfo()
        return if (cached != null) {
            SdkResult.Success(cached)
        } else {
            SdkResult.Failure(
                SrgLoginError.InvalidDataError(
                    "No cached UserInfo (cache empty — e.g. openid scope not " +
                        "granted, or no login/refresh yet). Not necessarily unauthenticated.",
                ),
            )
        }
    }

    /**
     * Network path: obtains an access token (transparent refresh on Expired),
     * resolves the `/userinfo` endpoint, calls it, validates sub-match
     * (§5.3.2), and persists the new snapshot in the cache.
     */
    @Suppress(
        "ReturnCount", // 7 early-returns are the fail-fast contract — each represents a
        //                distinct upstream failure (token fetch, config fetch, blank
        //                endpoint, HTTP layer, factory IAE, sub mismatch) propagated to
        //                the caller without further processing. Folding them into a
        //                single return would degrade readability and introduce nested
        //                state machines.
    )
    private suspend fun fetchFromNetwork(): SdkResult<UserInfo> {
        // 1. Access token — transparently refreshed on Expired by TokenManager.
        val tokenResult = tokenManager.getAccessToken()
        if (tokenResult is SdkResult.Failure) return tokenResult
        val accessToken = (tokenResult as SdkResult.Success).data

        // 2. Endpoint URL from the (cached) OpenID configuration.
        val configResult = openIdConfigRepository.getConfiguration()
        if (configResult is SdkResult.Failure) return configResult
        val endpoint = (configResult as SdkResult.Success).data.userInfoEndpoint
        // Validation ownership (PR #83 review #5):
        //  - HERE (service layer): only the common misconfiguration — the
        //    discovery document advertises no `userinfo_endpoint` at all.
        //    Fast-fails with a discovery-oriented message.
        //  - SrgAuthApiServiceImpl.getUserInfo (API layer): the AUTHORITATIVE
        //    blank + HTTPS gate, enforced right before the Bearer token is put
        //    on the wire (defense-in-depth — must stay there).
        // A non-blank but non-HTTPS endpoint therefore passes this check and is
        // rejected by the API layer with a different InvalidConfiguration
        // message. This is intentional: the two messages describe two distinct
        // concerns (endpoint-not-advertised vs endpoint-not-HTTPS).
        if (endpoint.isNullOrBlank()) {
            return SdkResult.Failure(
                SrgLoginError.InvalidConfiguration(
                    "OpenID configuration does not advertise a userinfo_endpoint",
                ),
            )
        }

        // 3. HTTP call. Transport-level errors (HTTPS validation, HTTP 4xx/5xx,
        //    JSON parse, IO) are already mapped to SrgLoginError by the
        //    SrgAuthApiServiceImpl layer.
        val apiResult = apiService.getUserInfo(endpoint, accessToken.value)
        if (apiResult is SdkResult.Failure) return apiResult
        val dto = (apiResult as SdkResult.Success).data

        // 4. DTO → typed UserInfo. The catch is intentionally narrow: it only
        //    intercepts IllegalArgumentException thrown by the factory itself
        //    on `sub` missing / non-string / blank (OIDC §5.3.2 validity).
        //    Catching IAE more broadly here would mask programming errors.
        val userInfo =
            try {
                UserInfo.fromUserInfoResponse(dto)
            } catch (e: IllegalArgumentException) {
                return SdkResult.Failure(
                    SrgLoginError.SerializationError(
                        originalMessage = e.message ?: "Invalid /userinfo response",
                        responseBody = null,
                    ),
                )
            }

        // 5. Sub-mismatch protection (OIDC §5.3.2). Only performed when the
        //    access token carries a `sub` claim (typical for JWT access
        //    tokens). For opaque access tokens with no parseable subject the
        //    check is silently skipped — the protection is a defence-in-depth
        //    layer here, not the primary security boundary (the resource
        //    server already validates the token server-side).
        val expectedSub = accessToken.subject
        if (expectedSub != null && userInfo.subject != expectedSub) {
            SdkLogger.e(LogCategory.AUTHENTICATION) {
                "$SUB_MISMATCH_REASON — response rejected, cache not updated"
            }
            // Sub hashes only (PII protection — never log the raw `sub`).
            ErrorHandlerRegistry.captureException(
                throwable = IllegalStateException(SUB_MISMATCH_REASON),
                context =
                    mapOf(
                        "operation" to "get_userinfo",
                        "violation" to "sub_mismatch",
                        "expected_sub_hash" to expectedSub.hashCode().toString(),
                        "received_sub_hash" to userInfo.subject.hashCode().toString(),
                    ),
                level = ErrorHandler.ErrorLevel.ERROR,
            )
            return SdkResult.Failure(SrgLoginError.InvalidDataError(SUB_MISMATCH_REASON))
        }

        // 6. Persist the new snapshot. Best-effort: a storage hiccup must not
        //    fail an otherwise-successful /userinfo fetch. Storage impls
        //    already capture persistence failures to Sentry internally.
        tokenStorage.saveUserInfo(userInfo)

        return SdkResult.Success(userInfo)
    }

    private companion object {
        /**
         * Stable, documented reason string for the OIDC §5.3.2 sub-mismatch
         * protection (D2 discipline 1). Pattern-matching on this exact string
         * is supported as a partial public contract. Modifying the wording
         * requires a CHANGELOG entry.
         */
        private const val SUB_MISMATCH_REASON = "OIDC §5.3.2: userinfo sub mismatch"
    }
}
