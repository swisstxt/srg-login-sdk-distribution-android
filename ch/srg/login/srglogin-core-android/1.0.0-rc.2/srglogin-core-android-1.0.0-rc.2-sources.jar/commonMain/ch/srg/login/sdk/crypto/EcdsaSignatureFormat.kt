package ch.srg.login.sdk.crypto

/** ASN.1/DER tag for a SEQUENCE. */
private const val DER_SEQUENCE_TAG = 0x30

/** ASN.1/DER tag for an INTEGER. */
private const val DER_INTEGER_TAG = 0x02

/**
 * DER lengths below this threshold use the short form (single byte); at or above it,
 * the long form (`0x80 or byteCount`, then the big-endian length bytes) is required.
 * P-521 (ES512) signatures produce a ~138-byte SEQUENCE and are the only JWT curve
 * that reaches the long form.
 */
private const val DER_LONG_FORM_THRESHOLD = 0x80

/** Mask selecting the high (sign) bit of a byte / the low 8 bits of an Int. */
private const val HIGH_BIT_MASK = 0x80
private const val BYTE_MASK = 0xFF
private const val BITS_PER_BYTE = 8

/**
 * Converts an ECDSA signature from IEEE P1363 format (`r ‖ s`, two fixed-length
 * big-endian integers — the raw form JWTs carry per RFC 7518 §3.4) to DER/X9.62
 * (`SEQUENCE { INTEGER r, INTEGER s }`), which the platform verifiers require
 * (`java.security.Signature` on Android, `SecKeyVerifySignature` X962 on Apple).
 *
 * Pure, deterministic, platform-independent — implemented once for all platforms
 * (same rationale as [CryptoService.sha256]). Canonical body taken from the iOS
 * implementation (PR #97): generic long-form length loop (any length), input
 * validation, nullable return; the named threshold constant comes from Android
 * (PR #98). The two previous per-platform copies had drifted in correctness —
 * Android's hardcoded single-length-byte long form silently rejected every ES512
 * token (LOGIN-1940) while iOS handled it (LOGIN-1969).
 *
 * @param ieeeSignature signature bytes in IEEE P1363 format (must be non-empty and even length)
 * @return the DER-encoded signature, or null if the input length is invalid
 */
internal fun convertEcdsaP1363ToDer(ieeeSignature: ByteArray): ByteArray? {
    // P1363 is r || s with both components of equal, fixed length.
    if (ieeeSignature.isEmpty() || ieeeSignature.size % 2 != 0) return null

    // Encodes a DER length: short form (< 128) as a single byte, otherwise long
    // form (0x80 | byteCount followed by the big-endian length bytes).
    fun encodeDerLength(length: Int): ByteArray {
        if (length < DER_LONG_FORM_THRESHOLD) return byteArrayOf(length.toByte())
        val lengthBytes = mutableListOf<Byte>()
        var remaining = length
        while (remaining > 0) {
            lengthBytes.add(0, (remaining and BYTE_MASK).toByte())
            remaining = remaining shr BITS_PER_BYTE
        }
        return byteArrayOf((DER_LONG_FORM_THRESHOLD or lengthBytes.size).toByte()) + lengthBytes.toByteArray()
    }

    // Encodes a component as a DER INTEGER (0x02 [length] [content]), stripping
    // leading zero bytes and prepending 0x00 when the high bit is set so the
    // integer stays positive.
    fun toDerInteger(value: ByteArray): ByteArray {
        var start = 0
        while (start < value.size - 1 && value[start] == 0.toByte()) {
            start++
        }
        val trimmed = value.copyOfRange(start, value.size)
        val content =
            if (trimmed.isNotEmpty() && (trimmed[0].toInt() and HIGH_BIT_MASK) != 0) {
                byteArrayOf(0x00) + trimmed
            } else {
                trimmed
            }
        return byteArrayOf(DER_INTEGER_TAG.toByte()) + encodeDerLength(content.size) + content
    }

    val componentLength = ieeeSignature.size / 2
    val derR = toDerInteger(ieeeSignature.copyOfRange(0, componentLength))
    val derS = toDerInteger(ieeeSignature.copyOfRange(componentLength, ieeeSignature.size))

    val content = derR + derS
    return byteArrayOf(DER_SEQUENCE_TAG.toByte()) + encodeDerLength(content.size) + content
}
