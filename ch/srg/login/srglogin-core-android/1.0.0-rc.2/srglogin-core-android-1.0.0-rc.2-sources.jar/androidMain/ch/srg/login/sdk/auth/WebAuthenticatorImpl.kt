package ch.srg.login.sdk.auth

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.browser.customtabs.CustomTabsIntent
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.internal.SecurityUtils
import ch.srg.login.sdk.logging.LogCategory
import ch.srg.login.sdk.logging.SdkLogger
import ch.srg.login.sdk.result.SdkResult
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Android implementation of [WebAuthenticator] using Custom Tabs.
 *
 * The browser is resolved dynamically and browser-agnostically — the user's default
 * Custom Tabs browser, no vendor preference (see [AndroidBrowserResolver]) — rather than
 * forcing Chrome. The same resolved browser is reused across auth, SSO and logout so the
 * session cookie store stays consistent (SSO). Falls back to a plain browser when no
 * Custom Tabs provider is available.
 *
 * @property securityUtils Security utilities for state generation.
 */
internal class WebAuthenticatorImpl(
    private val securityUtils: SecurityUtils,
) : BaseWebAuthenticator() {
    /** Resolves the Custom Tabs browser dynamically (browser-agnostic, default-first). */
    private val browserResolver = AndroidBrowserResolver()

    companion object {
        private const val CREATION_TAG = "SDK-Creation"
        private const val TAG_SSO = "WebAuth-SSO"

        /**
         * Logs which browser the SDK launches for a given [flow] (auth / SSO / logout).
         *
         * Reports the package targeted by [intent]; if none is set (implicit launch),
         * resolves the browser the system will use. Kept for field observability — once
         * dynamic browser resolution lands, [intent] already carries the resolved package,
         * so this reports the dynamically selected browser with no change needed.
         */
        private fun logSelectedBrowser(
            context: Context,
            intent: Intent,
            flow: String,
        ) {
            val selected =
                intent.`package`
                    ?: runCatching {
                        context.packageManager
                            .resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
                            ?.activityInfo
                            ?.packageName
                    }.getOrNull()
                    ?: "system default (unresolved)"

            SdkLogger.i(LogCategory.AUTHENTICATION) {
                "🌐 [BROWSER] flow=$flow selectedBrowser=$selected"
            }
        }
    }

    init {
        println("$CREATION_TAG: 🏗️ CONSTRUCTOR - WebAuthenticatorImpl created (hashCode=${this.hashCode()})")
    }

    override suspend fun authenticatePlatform(
        authUrl: String,
        authContext: PlatformAuthContext,
    ): SdkResult<String> =
        when (authContext) {
            is AndroidAuthContext -> {
                authenticateWithCustomTabs(authUrl, authContext)
            }

            is AndroidTvAuthContext -> {
                // TV platforms should use Device Code Flow, not web authentication
                SdkResult.Failure(
                    SrgLoginError.UnsupportedPlatform(
                        "Android TV requires Device Code Flow authentication. " +
                            "Use LoginMethod.Device instead of LoginMethod.Web for TV platforms.",
                    ),
                )
            }

            else -> {
                SdkResult.Failure(
                    SrgLoginError.InvalidConfiguration(
                        "Android WebAuthenticator requires AndroidAuthContext, " +
                            "received: ${authContext::class.simpleName}",
                    ),
                )
            }
        }

    override suspend fun logoutPlatform(
        logoutUrl: String,
        authContext: PlatformAuthContext,
    ): SdkResult<Unit> =
        when (authContext) {
            is AndroidAuthContext -> {
                logoutWithCustomTabs(logoutUrl, authContext)
            }

            is AndroidTvAuthContext -> {
                // TV platforms should handle logout differently
                SdkResult.Failure(
                    SrgLoginError.UnsupportedPlatform(
                        "Android TV logout should use LogoutType.LocalOnly instead of front-channel logout.",
                    ),
                )
            }

            else -> {
                SdkResult.Failure(
                    SrgLoginError.InvalidConfiguration(
                        "Android WebAuthenticator requires AndroidAuthContext, " +
                            "received: ${authContext::class.simpleName}",
                    ),
                )
            }
        }

    private suspend fun authenticateWithCustomTabs(
        authUrl: String,
        authContext: AndroidAuthContext,
    ): SdkResult<String> {
        return try {
            suspendCancellableCoroutine { continuation ->

                if (!authContext.isValid()) {
                    continuation.resume(
                        SdkResult.Failure(
                            SrgLoginError.InvalidConfiguration("Invalid Android context provided"),
                        ),
                    )
                    return@suspendCancellableCoroutine
                }

                // Extract OIDC state parameter from auth URL
                val state = extractStateFromUrl(authUrl)
                if (state == null) {
                    continuation.resume(
                        SdkResult.Failure(
                            SrgLoginError.InvalidConfiguration("Missing state parameter in authorization URL"),
                        ),
                    )
                    return@suspendCancellableCoroutine
                }

                // Register continuation with OIDC state
                StateContinuationRegistry.registerLoginContinuation(state, continuation)

                // Detect browser dismissal: onPause fires when the Custom Tab opens,
                // onResume fires when the user returns — with or without a redirect.
                // cancelLogin() is a no-op if completeLogin() already consumed the flow.
                (authContext.activity as? LifecycleOwner)?.lifecycle?.addObserver(
                    object : DefaultLifecycleObserver {
                        private var browserOpened = false

                        override fun onPause(owner: LifecycleOwner) {
                            browserOpened = true
                        }

                        override fun onResume(owner: LifecycleOwner) {
                            if (browserOpened) {
                                browserOpened = false
                                owner.lifecycle.removeObserver(this)
                                StateContinuationRegistry.cancelLogin(
                                    state,
                                    "User dismissed the browser without completing authentication",
                                )
                            }
                        }

                        override fun onDestroy(owner: LifecycleOwner) {
                            owner.lifecycle.removeObserver(this)
                        }
                    },
                )

                val customTabsIntent = createCustomTabsIntent()

                val success = launchCustomTabs(customTabsIntent, authUrl, authContext)

                if (!success) {
                    val fallbackSuccess = launchFallbackBrowser(authUrl, authContext)

                    if (!fallbackSuccess) {
                        StateContinuationRegistry.cancelLogin(state, "No suitable browser found for authentication")
                        return@suspendCancellableCoroutine
                    }
                }

                // Set up cancellation handling
                continuation.invokeOnCancellation {
                    StateContinuationRegistry.cancelLogin(state, "Authentication was cancelled")
                }
            }
        } catch (e: Exception) {
            SdkResult.Failure(
                SrgLoginError.PlatformError(
                    message = "Failed to launch browser for authentication: ${e.message}",
                    cause = e,
                    platform = "Android",
                ),
            )
        }
    }

    private fun createCustomTabsIntent(): CustomTabsIntent =
        CustomTabsIntent
            .Builder()
            .setShowTitle(true)
            .setUrlBarHidingEnabled(true)
            .build()

    /**
     * Launches [buildIntent] with the dynamically resolved Custom Tabs browser. If the launch
     * throws [ActivityNotFoundException] — the resolved browser was uninstalled or disabled
     * since it was cached — invalidates the resolver cache, re-resolves once, and retries
     * before the caller falls back to a plain browser. This keeps a stale cached package from
     * silently degrading auth/SSO/logout to the plain-browser fallback.
     *
     * @param flow short diagnostics label ("auth" / "logout" / "sso").
     * @param buildIntent builds the launch intent for a given resolved package (null → implicit).
     * @return `true` if either the first attempt or the retry started an activity.
     */
    private fun launchWithResolvedBrowser(
        launchContext: Context,
        flow: String,
        buildIntent: (resolvedBrowser: String?) -> Intent,
    ): Boolean {
        // null result = ActivityNotFoundException (resolved browser gone) → invalidate + retry once.
        val first = attemptLaunch(launchContext, flow, buildIntent)
        if (first != null) return first
        browserResolver.invalidate()
        return attemptLaunch(launchContext, "$flow-retry", buildIntent) ?: false
    }

    /**
     * One launch attempt. @return `true` if an activity started, `false` on a non-recoverable
     * failure, or `null` on [ActivityNotFoundException] (the caller re-resolves and retries).
     */
    private fun attemptLaunch(
        launchContext: Context,
        flow: String,
        buildIntent: (resolvedBrowser: String?) -> Intent,
    ): Boolean? =
        try {
            val intent = buildIntent(browserResolver.resolvePackage(launchContext))
            logSelectedBrowser(launchContext, intent, flow)
            launchContext.startActivity(intent)
            true
        } catch (e: ActivityNotFoundException) {
            SdkLogger.w(LogCategory.AUTHENTICATION) {
                "[$flow] resolved browser not launchable; re-resolving once: ${e.message}"
            }
            null
        } catch (e: Exception) {
            SdkLogger.e(LogCategory.AUTHENTICATION) {
                "[$flow] Custom Tab launch failed: ${e::class.simpleName}: ${e.message}"
            }
            false
        }

    private fun launchCustomTabs(
        customTabsIntent: CustomTabsIntent,
        authUrl: String,
        authContext: AndroidAuthContext,
    ): Boolean {
        val launchContext = authContext.getBestContext() as Context
        return launchWithResolvedBrowser(launchContext, "auth") { resolvedBrowser ->
            customTabsIntent.intent.apply {
                data = Uri.parse(authUrl)
                // Dynamically resolved Custom Tabs browser (user's default when capable; see
                // AndroidBrowserResolver). Reused across auth + SSO + logout so the cookie store
                // stays consistent (SSO). Null → implicit launch (plain fallback).
                setPackage(resolvedBrowser)
                if (!authContext.hasActivity()) {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
        }
    }

    private fun launchFallbackBrowser(
        authUrl: String,
        authContext: AndroidAuthContext,
    ): Boolean =
        try {
            val launchContext = authContext.getBestContext() as Context
            val intent =
                Intent(Intent.ACTION_VIEW, Uri.parse(authUrl)).apply {
                    if (!authContext.hasActivity()) {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                }

            logSelectedBrowser(launchContext, intent, "auth-fallback")
            launchContext.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }

    private suspend fun logoutWithCustomTabs(
        logoutUrl: String,
        authContext: AndroidAuthContext,
    ): SdkResult<Unit> {
        return try {
            suspendCancellableCoroutine { continuation ->

                if (!authContext.isValid()) {
                    continuation.resume(
                        SdkResult.Failure(
                            SrgLoginError.InvalidConfiguration("Invalid Android context provided"),
                        ),
                    )
                    return@suspendCancellableCoroutine
                }

                // Extract or generate state parameter for logout URL
                val state = extractStateFromUrl(logoutUrl) ?: generateStateForLogout()

                // Build final logout URL with state if not present
                val finalLogoutUrl =
                    if (!logoutUrl.contains("state=")) {
                        "$logoutUrl${if (logoutUrl.contains("?")) "&" else "?"}state=$state"
                    } else {
                        logoutUrl
                    }

                // Register logout continuation with OIDC state
                StateContinuationRegistry.registerLogoutContinuation(state, continuation)

                // Detect browser dismissal during logout (same mechanism as login).
                (authContext.activity as? LifecycleOwner)?.lifecycle?.addObserver(
                    object : DefaultLifecycleObserver {
                        private var browserOpened = false

                        override fun onPause(owner: LifecycleOwner) {
                            browserOpened = true
                        }

                        override fun onResume(owner: LifecycleOwner) {
                            if (browserOpened) {
                                browserOpened = false
                                owner.lifecycle.removeObserver(this)
                                StateContinuationRegistry.cancelLogout(
                                    state,
                                    "User dismissed the browser without completing logout",
                                )
                            }
                        }

                        override fun onDestroy(owner: LifecycleOwner) {
                            owner.lifecycle.removeObserver(this)
                        }
                    },
                )

                val customTabsIntent = createLogoutCustomTabsIntent()

                val success = launchCustomTabsForLogout(customTabsIntent, finalLogoutUrl, authContext)

                if (!success) {
                    val fallbackSuccess = launchFallbackBrowserForLogout(finalLogoutUrl, authContext)

                    if (!fallbackSuccess) {
                        StateContinuationRegistry.cancelLogout(state, "No suitable browser found for logout")
                        return@suspendCancellableCoroutine
                    }
                }

                // Set up cancellation handling
                continuation.invokeOnCancellation {
                    StateContinuationRegistry.cancelLogout(state, "Logout was cancelled")
                }
            }
        } catch (e: Exception) {
            SdkResult.Failure(
                SrgLoginError.PlatformError(
                    message = "Failed to launch browser for logout: ${e.message}",
                    cause = e,
                    platform = "Android",
                ),
            )
        }
    }

    private fun createLogoutCustomTabsIntent(): CustomTabsIntent =
        CustomTabsIntent
            .Builder()
            .setShowTitle(true)
            .setUrlBarHidingEnabled(false) // Show URL bar for logout transparency
            .build()

    private fun launchCustomTabsForLogout(
        customTabsIntent: CustomTabsIntent,
        logoutUrl: String,
        authContext: AndroidAuthContext,
    ): Boolean {
        val launchContext = authContext.getBestContext() as Context
        return launchWithResolvedBrowser(launchContext, "logout") { resolvedBrowser ->
            customTabsIntent.intent.apply {
                data = Uri.parse(logoutUrl)
                // Reuse the same resolved browser as auth/SSO for a consistent session.
                setPackage(resolvedBrowser)
                if (!authContext.hasActivity()) {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                // Clear browser state so a stale session view is not shown after logout.
                addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
                addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
            }
        }
    }

    private fun launchFallbackBrowserForLogout(
        logoutUrl: String,
        authContext: AndroidAuthContext,
    ): Boolean =
        try {
            val launchContext = authContext.getBestContext() as Context
            val intent =
                Intent(Intent.ACTION_VIEW, Uri.parse(logoutUrl)).apply {
                    if (!authContext.hasActivity()) {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
                    addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
                }

            logSelectedBrowser(launchContext, intent, "logout-fallback")
            launchContext.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }

    /**
     * Extracts the OIDC state parameter from a URL.
     *
     * @param url The URL containing the state parameter
     * @return The state value or null if not found
     */
    private fun extractStateFromUrl(url: String): String? =
        try {
            val uri = Uri.parse(url)
            uri.getQueryParameter("state")
        } catch (e: Exception) {
            null
        }

    override suspend fun openSsoClientPlatform(
        ssoClientUrl: String,
        authContext: PlatformAuthContext,
    ): SdkResult<Unit> {
        // Vérification WebAuthCapable pour éviter Android TV
        if (authContext !is WebAuthCapable) {
            return SdkResult.Failure(
                SrgLoginError.InvalidConfiguration(
                    "SSO client opening requires a WebAuthCapable context. " +
                        "TV platforms should use different approaches for web content display.",
                ),
            )
        }

        return when (authContext) {
            is AndroidAuthContext -> {
                openSsoClientWithCustomTabs(ssoClientUrl, authContext)
            }

            else -> {
                SdkResult.Failure(
                    SrgLoginError.InvalidConfiguration(
                        "Android WebAuthenticator requires AndroidAuthContext, " +
                            "received: ${authContext::class.simpleName}",
                    ),
                )
            }
        }
    }

    /**
     * Opens an SSO client URL in a Custom Tab, with a plain-browser fallback.
     *
     * Main entry point for SSO client access (e.g. opening profile settings after login).
     * Two-tier launch strategy:
     *
     * ## Launch Strategy
     *
     * 1. **Primary**: a Custom Tab in the dynamically resolved browser (the user's default
     *    when Custom Tabs-capable; see [AndroidBrowserResolver]). Reusing the same browser
     *    as the login flow shares its cookie store, enabling SSO without re-authentication.
     *
     * 2. **Fallback**: a plain browser (`ACTION_VIEW`), used when no Custom Tabs provider
     *    can be launched. SSO cookie sharing may not apply, but SSO access still works.
     *
     * ## Fire-and-Forget Pattern
     *
     * This method returns immediately after launching the browser (no callback expected).
     * The browser session is independent from the app — the user can close the tab, switch
     * back to the app, or navigate freely.
     *
     * ## Usage Example
     *
     * ```kotlin
     * val result = srgLogin.openSsoClient(
     *     url = "https://settings.srgssr.ch/profile",
     *     context = this,
     * )
     * when (result) {
     *     is SdkResult.Success -> { /* Browser launched — user can access the SSO client */ }
     *     is SdkResult.Failure -> { /* No browser available or context invalid */ }
     * }
     * ```
     *
     * @param ssoClientUrl The SSO service URL to open (e.g. profile settings, account management)
     * @param authContext Android authentication context (activity or application context)
     * @return [SdkResult.Success] if a browser launched, [SdkResult.Failure] if none available
     *
     * @see launchCustomTabsForSsoClient Primary Custom Tabs launch
     * @see launchFallbackBrowserForSsoClient Plain-browser fallback
     */
    private suspend fun openSsoClientWithCustomTabs(
        ssoClientUrl: String,
        authContext: AndroidAuthContext,
    ): SdkResult<Unit> {
        return try {
            SdkLogger.d(LogCategory.AUTHENTICATION) {
                "Starting SSO client launch for URL: ${ssoClientUrl.take(50)}..."
            }

            // Validate Android context
            if (!authContext.isValid()) {
                SdkLogger.e(LogCategory.AUTHENTICATION) {
                    "SSO client launch failed: Invalid Android context provided"
                }
                return SdkResult.Failure(
                    SrgLoginError.InvalidConfiguration("Invalid Android context provided"),
                )
            }

            // Create Custom Tabs intent
            val customTabsIntent = createSsoClientCustomTabsIntent()

            // Attempt to launch a Custom Tab with the resolved browser
            val success = launchCustomTabsForSsoClient(customTabsIntent, ssoClientUrl, authContext)

            if (!success) {
                // Fallback to a plain browser if no Custom Tabs provider could be launched
                val fallbackSuccess = launchFallbackBrowserForSsoClient(ssoClientUrl, authContext)

                if (!fallbackSuccess) {
                    SdkLogger.e(LogCategory.AUTHENTICATION) {
                        "SSO client launch failed: no browser available on device. " +
                            "Both the Custom Tabs and the plain-browser fallback attempts failed."
                    }
                    return SdkResult.Failure(
                        SrgLoginError.PlatformError(
                            message = "No suitable browser found for SSO client",
                            platform = "Android",
                        ),
                    )
                }
            }

            SdkLogger.i(LogCategory.AUTHENTICATION) {
                "SSO client launched successfully. Browser opened for user interaction."
            }

            // Fire-and-forget: Return success immediately after launching browser
            SdkResult.Success(Unit)
        } catch (e: Exception) {
            SdkLogger.e(LogCategory.AUTHENTICATION) {
                "SSO client launch exception: ${e.message}. Exception: ${e::class.simpleName}"
            }
            SdkResult.Failure(
                SrgLoginError.PlatformError(
                    message = "Failed to launch browser for SSO client: ${e.message}",
                    cause = e,
                    platform = "Android",
                ),
            )
        }
    }

    private fun createSsoClientCustomTabsIntent(): CustomTabsIntent =
        CustomTabsIntent
            .Builder()
            .setShowTitle(true)
            .setUrlBarHidingEnabled(false) // Show URL bar for transparency
            .build()

    /**
     * Launches a Custom Tab for the SSO client using the dynamically resolved browser.
     *
     * The browser is resolved by [AndroidBrowserResolver] (the user's default when Custom
     * Tabs-capable; no vendor preference). Reusing the same browser resolved for the login
     * flow shares its cookie store, so the SSO client opens without re-authentication:
     *
     * ```
     * Login      → Custom Tab (resolved browser) → cookies in that browser's profile
     * SSO client → Custom Tab (same browser)     → reuses cookies → direct access
     * ```
     *
     * Delegates the launch — and a re-resolve + single retry if the resolved browser is no
     * longer launchable — to [launchWithResolvedBrowser]. Returns `false` if no Custom Tab
     * could be launched, so the caller falls back to a plain browser (SSO cookie sharing
     * may not apply then).
     *
     * @param customTabsIntent The Custom Tabs intent configured for the SSO client
     * @param ssoClientUrl The SSO service URL to open (e.g. profile settings)
     * @param authContext Android authentication context for activity/application context
     * @return `true` if a Custom Tab launched, `false` to trigger the plain-browser fallback
     *
     * @see launchFallbackBrowserForSsoClient Plain-browser fallback
     * @see openSsoClientWithCustomTabs Parent method orchestrating the SSO flow
     */
    private fun launchCustomTabsForSsoClient(
        customTabsIntent: CustomTabsIntent,
        ssoClientUrl: String,
        authContext: AndroidAuthContext,
    ): Boolean {
        val launchContext = authContext.getBestContext() as Context
        return launchWithResolvedBrowser(launchContext, "sso") { resolvedBrowser ->
            customTabsIntent.intent.apply {
                data = Uri.parse(ssoClientUrl)
                // Reuse the browser resolved for auth so the SSO session cookies are shared.
                // Null → implicit launch (plain fallback; SSO cookie sharing not guaranteed).
                setPackage(resolvedBrowser)
                if (!authContext.hasActivity()) {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
            }
        }
    }

    private fun launchFallbackBrowserForSsoClient(
        ssoClientUrl: String,
        authContext: AndroidAuthContext,
    ): Boolean =
        try {
            SdkLogger.w(LogCategory.AUTHENTICATION) {
                "Using a plain browser for SSO client: no Custom Tabs provider could be launched. " +
                    "⚠️ SSO cookie sharing will not apply - the user may be prompted to authenticate."
            }

            val launchContext = authContext.getBestContext() as Context
            val intent =
                Intent(Intent.ACTION_VIEW, Uri.parse(ssoClientUrl)).apply {
                    if (!authContext.hasActivity()) {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                }

            logSelectedBrowser(launchContext, intent, "sso-fallback")
            launchContext.startActivity(intent)

            SdkLogger.i(LogCategory.AUTHENTICATION) {
                "Fallback browser launched successfully. User may need to authenticate."
            }

            true
        } catch (e: Exception) {
            SdkLogger.e(LogCategory.AUTHENTICATION) {
                "Fallback browser launch failed: ${e.message}. " +
                    "No browser available on device. Exception: ${e::class.simpleName}"
            }
            false
        }

    /**
     * Generates a cryptographically secure state parameter for logout flows.
     * Uses the same security standards as login flows.
     *
     * @return A secure random state string
     */
    private fun generateStateForLogout(): String = securityUtils.generateState()
}
