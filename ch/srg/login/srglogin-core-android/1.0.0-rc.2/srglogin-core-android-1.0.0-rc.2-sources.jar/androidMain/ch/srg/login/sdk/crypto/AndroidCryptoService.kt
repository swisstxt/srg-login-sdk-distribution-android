package ch.srg.login.sdk.crypto

import ch.srg.login.sdk.model.JsonWebKey
import java.math.BigInteger
import java.security.KeyFactory
import java.security.Signature
import java.security.interfaces.ECPublicKey
import java.security.interfaces.RSAPublicKey
import java.security.spec.ECFieldFp
import java.security.spec.ECParameterSpec
import java.security.spec.ECPoint
import java.security.spec.ECPublicKeySpec
import java.security.spec.EllipticCurve
import java.security.spec.RSAPublicKeySpec
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi

/**
 * Android implementation of [CryptoService] using Java Security API.
 *
 * This implementation provides cryptographic operations for JWT signature verification
 * using Android's built-in security providers. It supports:
 * - SHA-256 hashing for PKCE
 * - RSA signature verification (RS256, RS384, RS512)
 * - ECDSA signature verification (ES256, ES384, ES512)
 *
 * **Thread Safety**: This class is stateless and thread-safe. All methods can be
 * called concurrently from multiple threads.
 *
 * **Error Handling**: All methods return `false` or throw exceptions on errors
 * rather than silently failing, ensuring security-critical operations don't succeed
 * on invalid input.
 */
internal class AndroidCryptoService : CryptoService {
    // sha256() is inherited from CryptoService (shared KotlinCrypto implementation).

    /**
     * Verifies RSA signature using Java Security API.
     *
     * Converts JWK RSA parameters (n, e) to Java PublicKey and verifies
     * the signature using the appropriate SHA hash algorithm.
     *
     * @return false on any error (invalid key, unsupported algorithm, verification failure)
     */
    @OptIn(ExperimentalEncodingApi::class)
    override suspend fun verifyRsaSignature(
        data: ByteArray,
        signature: ByteArray,
        jwk: JsonWebKey,
        algorithm: String,
    ): Boolean {
        return try {
            // Validate this is an RSA key with required parameters
            if (jwk.keyType != "RSA") {
                return false
            }
            if (jwk.rsaModulus.isNullOrBlank() || jwk.rsaExponent.isNullOrBlank()) {
                return false
            }

            // Convert JWK parameters to Java RSA PublicKey
            // JWT/JWK uses Base64URL encoding without padding, so we need to add padding
            val modulus = BigInteger(1, Base64.UrlSafe.decode(addBase64Padding(jwk.rsaModulus)))
            val exponent = BigInteger(1, Base64.UrlSafe.decode(addBase64Padding(jwk.rsaExponent)))
            val keySpec = RSAPublicKeySpec(modulus, exponent)
            val keyFactory = KeyFactory.getInstance("RSA")
            val publicKey = keyFactory.generatePublic(keySpec) as RSAPublicKey

            // Map JWT algorithm to Java Signature algorithm
            val signatureAlgorithm =
                when (algorithm) {
                    "RS256" -> "SHA256withRSA"
                    "RS384" -> "SHA384withRSA"
                    "RS512" -> "SHA512withRSA"
                    else -> return false
                }

            // Verify the signature
            val verifier = Signature.getInstance(signatureAlgorithm)
            verifier.initVerify(publicKey)
            verifier.update(data)
            verifier.verify(signature)
        } catch (e: Exception) {
            // Any exception during verification means invalid signature
            // This includes: invalid key parameters, unsupported algorithms,
            // signature format errors, etc.
            false
        }
    }

    /**
     * Verifies ECDSA signature using Java Security API.
     *
     * Converts JWK EC parameters (x, y, crv) to Java ECPublicKey and verifies
     * the signature. Handles the conversion between JWT's IEEE P1363 format
     * and Java's expectation (some providers expect DER format).
     *
     * @return false on any error (invalid key, unsupported curve/algorithm, verification failure)
     */
    @OptIn(ExperimentalEncodingApi::class)
    override suspend fun verifyEcdsaSignature(
        data: ByteArray,
        signature: ByteArray,
        jwk: JsonWebKey,
        algorithm: String,
    ): Boolean {
        return try {
            // Validate this is an EC key with required parameters
            if (jwk.keyType != "EC") {
                return false
            }
            if (jwk.ecXCoordinate.isNullOrBlank() ||
                jwk.ecYCoordinate.isNullOrBlank() ||
                jwk.ellipticCurve.isNullOrBlank()
            ) {
                return false
            }

            // Get EC curve parameters
            val curveSpec = getEcCurveSpec(jwk.ellipticCurve)
            if (curveSpec == null) {
                return false
            }

            // Convert JWK parameters to Java EC PublicKey
            // JWT/JWK uses Base64URL encoding without padding, so we need to add padding
            val x = BigInteger(1, Base64.UrlSafe.decode(addBase64Padding(jwk.ecXCoordinate)))
            val y = BigInteger(1, Base64.UrlSafe.decode(addBase64Padding(jwk.ecYCoordinate)))
            val point = ECPoint(x, y)
            val keySpec = ECPublicKeySpec(point, curveSpec)
            val keyFactory = KeyFactory.getInstance("EC")
            val publicKey = keyFactory.generatePublic(keySpec) as ECPublicKey

            // Map JWT algorithm to Java Signature algorithm
            val signatureAlgorithm =
                when (algorithm) {
                    "ES256" -> "SHA256withECDSA"
                    "ES384" -> "SHA384withECDSA"
                    "ES512" -> "SHA512withECDSA"
                    else -> return false
                }

            // Convert IEEE P1363 format (used by JWT) to DER format (expected by Java Security API)
            // JWT signatures are in IEEE P1363 format: r || s (two fixed-length integers concatenated)
            // Java Security API expects DER format: 0x30 [total-length] 0x02 [r-length] [r] 0x02 [s-length] [s]
            val derSignature = convertEcdsaP1363ToDer(signature) ?: return false

            // Verify the signature
            val verifier = Signature.getInstance(signatureAlgorithm)
            verifier.initVerify(publicKey)
            verifier.update(data)
            verifier.verify(derSignature)
        } catch (e: Exception) {
            // Any exception during verification means invalid signature
            false
        }
    }

    /**
     * Gets the ECParameterSpec for the specified curve name.
     *
     * Supports the three standard NIST curves used by JWT:
     * - P-256 (secp256r1): 256-bit prime field Weierstrass curve
     * - P-384 (secp384r1): 384-bit prime field Weierstrass curve
     * - P-521 (secp521r1): 521-bit prime field Weierstrass curve
     *
     * @param curveName The JWT curve name ("P-256", "P-384", or "P-521")
     * @return The ECParameterSpec or null if curve is not supported
     */
    private fun getEcCurveSpec(curveName: String): ECParameterSpec? =
        when (curveName) {
            "P-256" -> {
                // NIST P-256 curve (secp256r1)
                // Prime: 2^256 - 2^224 + 2^192 + 2^96 - 1
                val p =
                    BigInteger(
                        "FFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF",
                        16,
                    )
                val a =
                    BigInteger(
                        "FFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFC",
                        16,
                    )
                val b =
                    BigInteger(
                        "5AC635D8AA3A93E7B3EBBD55769886BC651D06B0CC53B0F63BCE3C3E27D2604B",
                        16,
                    )
                val gx =
                    BigInteger(
                        "6B17D1F2E12C4247F8BCE6E563A440F277037D812DEB33A0F4A13945D898C296",
                        16,
                    )
                val gy =
                    BigInteger(
                        "4FE342E2FE1A7F9B8EE7EB4A7C0F9E162BCE33576B315ECECBB6406837BF51F5",
                        16,
                    )
                val order =
                    BigInteger(
                        "FFFFFFFF00000000FFFFFFFFFFFFFFFFBCE6FAADA7179E84F3B9CAC2FC632551",
                        16,
                    )
                val cofactor = 1

                val curve = EllipticCurve(ECFieldFp(p), a, b)
                val generator = ECPoint(gx, gy)
                ECParameterSpec(curve, generator, order, cofactor)
            }

            "P-384" -> {
                // NIST P-384 curve (secp384r1)
                val p =
                    BigInteger(
                        "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE" +
                            "FFFFFFFF0000000000000000FFFFFFFF",
                        16,
                    )
                val a =
                    BigInteger(
                        "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFE" +
                            "FFFFFFFF0000000000000000FFFFFFFC",
                        16,
                    )
                val b =
                    BigInteger(
                        "B3312FA7E23EE7E4988E056BE3F82D19181D9C6EFE8141120314088F5013875A" +
                            "C656398D8A2ED19D2A85C8EDD3EC2AEF",
                        16,
                    )
                val gx =
                    BigInteger(
                        "AA87CA22BE8B05378EB1C71EF320AD746E1D3B628BA79B9859F741E082542A38" +
                            "5502F25DBF55296C3A545E3872760AB7",
                        16,
                    )
                val gy =
                    BigInteger(
                        "3617DE4A96262C6F5D9E98BF9292DC29F8F41DBD289A147CE9DA3113B5F0B8C0" +
                            "0A60B1CE1D7E819D7A431D7C90EA0E5F",
                        16,
                    )
                val order =
                    BigInteger(
                        "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC7634D81F4372DDF58" +
                            "1A0DB248B0A77AECEC196ACCC52973",
                        16,
                    )
                val cofactor = 1

                val curve = EllipticCurve(ECFieldFp(p), a, b)
                val generator = ECPoint(gx, gy)
                ECParameterSpec(curve, generator, order, cofactor)
            }

            "P-521" -> {
                // NIST P-521 curve (secp521r1)
                val p =
                    BigInteger(
                        "01FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF" +
                            "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF",
                        16,
                    )
                val a =
                    BigInteger(
                        "01FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF" +
                            "FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFC",
                        16,
                    )
                val b =
                    BigInteger(
                        "0051953EB9618E1C9A1F929A21A0B68540EEA2DA725B99B315F3B8B489918EF109" +
                            "E156193951EC7E937B1652C0BD3BB1BF073573DF883D2C34F1EF451FD46B503F00",
                        16,
                    )
                val gx =
                    BigInteger(
                        "00C6858E06B70404E9CD9E3ECB662395B4429C648139053FB521F828AF606B4D3D" +
                            "BAA14B5E77EFE75928FE1DC127A2FFA8DE3348B3C1856A429BF97E7E31C2E5BD66",
                        16,
                    )
                val gy =
                    BigInteger(
                        "011839296A789A3BC0045C8A5FB42C7D1BD998F54449579B446817AFBD17273E66" +
                            "2C97EE72995EF42640C550B9013FAD0761353C7086A272C24088BE94769FD16650",
                        16,
                    )
                val order =
                    BigInteger(
                        "01FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFA" +
                            "51868783BF2F966B7FCC0148F709A5D03BB5C9B8899C47AEBB6FB71E91386409",
                        16,
                    )
                val cofactor = 1

                val curve = EllipticCurve(ECFieldFp(p), a, b)
                val generator = ECPoint(gx, gy)
                ECParameterSpec(curve, generator, order, cofactor)
            }

            else -> {
                null
            } // Unsupported curve
        }

    /**
     * Adds padding to Base64URL encoded string if needed.
     *
     * JWT/JWK uses Base64URL encoding without padding (no = characters).
     * Kotlin's Base64.UrlSafe.decode() expects properly padded input.
     *
     * @param base64 The Base64URL string without padding
     * @return The same string with padding added if needed
     */
    private fun addBase64Padding(base64: String): String =
        when (base64.length % 4) {
            2 -> base64 + "=="
            3 -> base64 + "="
            else -> base64
        }
}
