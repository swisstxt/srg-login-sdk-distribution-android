package ch.srg.login.sdk.auth

import android.content.Context
import androidx.browser.customtabs.CustomTabsClient
import ch.srg.login.sdk.logging.LogCategory
import ch.srg.login.sdk.logging.SdkLogger

/**
 * Resolves which browser package the SDK should launch Custom Tabs with, delegating to
 * AndroidX's [CustomTabsClient.getPackageName].
 *
 * Browser-agnostic, default-first (issue #103, RFC 8252 — prefer the user's own browser,
 * no vendor mandate): [CustomTabsClient.getPackageName] returns the user's default browser
 * when it is Custom Tabs-capable, otherwise another Custom Tabs provider, otherwise `null`
 * (→ the caller falls back to a plain browser). There is no Chrome preference.
 *
 * Requires the browser `<queries>` declared in the SDK manifest to enumerate providers on
 * Android 11+ (otherwise `PackageManager` — which `getPackageName` uses internally — reports
 * nothing).
 *
 * The result is cached for the process lifetime so the same browser is reused across
 * auth + SSO + logout, keeping the cookie store consistent (SSO). [invalidate] drops the
 * cache when a resolved browser turns out to be no longer launchable.
 */
internal class AndroidBrowserResolver {
    private val lock = Any()

    @Volatile private var resolved = false

    @Volatile private var cachedPackage: String? = null

    /** @return the Custom Tabs browser package, or `null` to fall back to a plain browser. */
    fun resolvePackage(context: Context): String? {
        if (resolved) return cachedPackage
        return synchronized(lock) {
            if (resolved) {
                cachedPackage
            } else {
                val pkg = CustomTabsClient.getPackageName(context, null, false)
                if (pkg != null) {
                    SdkLogger.d(LogCategory.AUTHENTICATION) { "Resolved Custom Tabs browser: $pkg" }
                } else {
                    SdkLogger.w(LogCategory.AUTHENTICATION) {
                        "No Custom Tabs-capable browser found (getPackageName returned null). " +
                            "Falling back to a plain browser; SSO cookie sharing will not apply. " +
                            "Verify a browser is installed and the SDK <queries> manifest merged into the app."
                    }
                }
                cachedPackage = pkg
                resolved = true
                cachedPackage
            }
        }
    }

    /**
     * Drops the cached selection so the next [resolvePackage] re-resolves against the
     * device's current state. Called when a previously-resolved browser is no longer
     * launchable (uninstalled/disabled since it was cached).
     */
    fun invalidate() {
        synchronized(lock) { resolved = false }
    }
}
