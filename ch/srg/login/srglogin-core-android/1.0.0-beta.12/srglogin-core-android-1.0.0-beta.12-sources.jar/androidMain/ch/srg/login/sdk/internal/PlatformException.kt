package ch.srg.login.sdk.internal

import ch.srg.login.sdk.errors.SrgLoginError
import io.ktor.client.plugins.HttpRequestTimeoutException
import java.net.ConnectException
import java.net.UnknownHostException

/**
 * Android/JVM-specific implementation for mapping platform exceptions.
 * This function performs type-safe checks for common JVM network exceptions.
 */
internal actual fun mapPlatformException(e: Exception): SrgLoginError? =
    when (e) {
        // Type-safe checks for specific JVM network exceptions
        is UnknownHostException, is ConnectException -> {
            SrgLoginError.NetworkError(
                details = "A network connectivity error occurred: ${e.message}",
                cause = e,
            )
        }

        // Ktor's timeout is also a clear network-level failure
        is HttpRequestTimeoutException -> {
            SrgLoginError.NetworkError(
                details = "The network request timed out.",
                cause = e,
            )
        }

        // Fallback for other potential network issues by checking class name,
        // e.g., Android's internal GaiException, without a hard dependency.
        else -> {
            if (e.javaClass.simpleName == "GaiException") {
                SrgLoginError.NetworkError(
                    details = "DNS resolution failed.",
                    cause = e,
                )
            } else {
                // If we can't map it, return null to let common code decide.
                null
            }
        }
    }
