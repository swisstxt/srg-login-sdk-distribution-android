package ch.srg.login.sdk.token

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import ch.srg.login.sdk.logging.ErrorHandler
import ch.srg.login.sdk.logging.ErrorHandlerRegistry
import ch.srg.login.sdk.model.RefreshTokenMetadata
import ch.srg.login.sdk.model.TokenResponseDto
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/**
 * Android implementation of [TokenStorage] using EncryptedSharedPreferences.
 *
 * This implementation provides secure token storage on Android using:
 * - Android Keystore for key management
 * - AES256-GCM encryption for data
 * - EncryptedSharedPreferences for storage
 *
 * INTERNAL: This class is not part of the public SDK API.
 */
internal class AndroidEncryptedTokenStorage(
    private val context: Context,
    private val config: TokenStorageConfig = TokenStorageConfig(),
) : TokenStorage {
    init {
        android.util.Log.d("TokenStorage", "AndroidEncryptedTokenStorage initialized with context: $context")
    }

    private val json = Json { ignoreUnknownKeys = true }

    private val masterKey by lazy {
        try {
            android.util.Log.d("TokenStorage", "Creating MasterKey with context: $context, alias: ${config.keystoreAlias}")
            MasterKey
                .Builder(context, config.keystoreAlias)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
        } catch (e: Exception) {
            android.util.Log.e("TokenStorage", "Failed to create MasterKey", e)
            throw TokenStorageException.EncryptionException("Failed to create master key", e)
        }
    }

    private val encryptedPrefs by lazy {
        createEncryptedPreferencesWithRecovery()
    }

    /**
     * Creates EncryptedSharedPreferences with automatic recovery from corruption.
     * This handles the common production scenario where keystore data becomes
     * inaccessible due to OS updates, factory resets, or keystore corruption.
     */
    private fun createEncryptedPreferencesWithRecovery(): android.content.SharedPreferences =
        try {
            EncryptedSharedPreferences.create(
                context,
                config.fileName,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
            )
        } catch (e: Exception) {
            // Check if this is a known recoverable encryption error
            if (isRecoverableEncryptionError(e)) {
                android.util.Log.w(
                    "TokenStorage",
                    "Encrypted storage corrupted, attempting recovery. This can happen after OS updates or keystore issues.",
                )
                recoverFromCorruptedStorage(e)
            } else {
                android.util.Log.e("TokenStorage", "Non-recoverable encryption error", e)
                throw TokenStorageException.EncryptionException("Failed to initialize secure storage", e)
            }
        }

    /**
     * Determines if an encryption error is recoverable by clearing corrupted data.
     */
    private fun isRecoverableEncryptionError(exception: Exception): Boolean =
        when {
            exception is java.security.GeneralSecurityException -> true
            exception.cause is javax.crypto.AEADBadTagException -> true
            exception.cause is java.security.GeneralSecurityException -> true
            exception.message?.contains("KeyStore") == true -> true
            exception.message?.contains("Signature/MAC verification failed") == true -> true
            else -> false
        }

    /**
     * Recovers from corrupted encrypted storage by safely clearing and recreating.
     * This preserves app functionality at the cost of requiring user re-authentication.
     */
    private fun recoverFromCorruptedStorage(originalException: Exception): android.content.SharedPreferences =
        try {
            // Step 1: Clear corrupted SharedPreferences data
            clearCorruptedPreferencesData()

            // Step 2: Try to recreate EncryptedSharedPreferences
            EncryptedSharedPreferences
                .create(
                    context,
                    config.fileName,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
                ).also {
                    android.util.Log.i("TokenStorage", "Successfully recovered encrypted storage. User will need to re-authenticate.")
                }
        } catch (recoveryException: Exception) {
            android.util.Log.e("TokenStorage", "Recovery failed", recoveryException)

            // If recovery fails, provide a fallback or escalate
            throw TokenStorageException.EncryptionException(
                "Secure storage is corrupted and cannot be recovered. Please reinstall the app.",
                recoveryException,
            )
        }

    /**
     * Safely clears corrupted preferences data without affecting other app data.
     */
    private fun clearCorruptedPreferencesData() {
        try {
            // Clear the specific SharedPreferences
            val prefs = context.getSharedPreferences(config.fileName, android.content.Context.MODE_PRIVATE)
            prefs.edit().clear().apply()

            // Also remove the physical file to ensure clean slate
            val sharedPrefsDir = java.io.File(context.applicationInfo.dataDir, "shared_prefs")
            val prefsFile = java.io.File(sharedPrefsDir, "${config.fileName}.xml")
            if (prefsFile.exists() && prefsFile.delete()) {
                android.util.Log.d("TokenStorage", "Removed corrupted preferences file")
            }
        } catch (e: Exception) {
            android.util.Log.w("TokenStorage", "Could not fully clear corrupted data", e)
            // Continue anyway - EncryptedSharedPreferences.create might still work
        }
    }

    override suspend fun saveTokens(tokens: TokenResponseDto): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val tokenJson = json.encodeToString(tokens)
                val success =
                    encryptedPrefs
                        .edit()
                        .putString(TOKEN_KEY, tokenJson)
                        .commit() // Use commit() instead of apply() for synchronous save

                if (!success) {
                    android.util.Log.e("TokenStorage", "Failed to save tokens: commit() returned false")
                    return@withContext Result.failure(TokenStorageException.FileAccessException("Failed to commit tokens to storage"))
                }

                android.util.Log.d("TokenStorage", "Tokens saved successfully")
                Result.success(Unit)
            } catch (e: Exception) {
                android.util.Log.e("TokenStorage", "Error saving tokens", e)

                // Report to error tracking
                ErrorHandlerRegistry.captureException(
                    throwable = e,
                    context =
                        mapOf(
                            "operation" to "save_tokens",
                            "storage_type" to "android_encrypted_shared_prefs",
                            "exception_type" to e::class.simpleName,
                            "is_security_exception" to (e is java.security.GeneralSecurityException),
                        ),
                    level =
                        if (e is java.security.GeneralSecurityException) {
                            ErrorHandler.ErrorLevel.FATAL
                        } else {
                            ErrorHandler.ErrorLevel.ERROR
                        },
                )

                when (e) {
                    is java.security.GeneralSecurityException -> {
                        Result.failure(TokenStorageException.EncryptionException(cause = e))
                    }

                    is kotlinx.serialization.SerializationException -> {
                        Result.failure(TokenStorageException.CorruptedDataException("Failed to serialize tokens", e))
                    }

                    else -> {
                        Result.failure(TokenStorageException.FileAccessException("Failed to save tokens", e))
                    }
                }
            }
        }

    override suspend fun getTokens(): TokenResponseDto? =
        withContext(Dispatchers.IO) {
            try {
                val tokenJson = encryptedPrefs.getString(TOKEN_KEY, null) ?: return@withContext null
                json.decodeFromString<TokenResponseDto>(tokenJson)
            } catch (e: Exception) {
                // Report to error tracking
                ErrorHandlerRegistry.captureException(
                    throwable = e,
                    context =
                        mapOf(
                            "operation" to "get_tokens",
                            "storage_type" to "android_encrypted_shared_prefs",
                            "exception_type" to e::class.simpleName,
                            "recovery_action" to
                                when (e) {
                                    is java.security.GeneralSecurityException -> "clear_corrupted_data"
                                    is kotlinx.serialization.SerializationException -> "clear_corrupted_data"
                                    else -> "return_null"
                                },
                        ),
                    level =
                        when (e) {
                            is java.security.GeneralSecurityException -> ErrorHandler.ErrorLevel.ERROR
                            is kotlinx.serialization.SerializationException -> ErrorHandler.ErrorLevel.WARNING
                            else -> ErrorHandler.ErrorLevel.WARNING
                        },
                )

                when (e) {
                    is java.security.GeneralSecurityException -> {
                        // Encryption error during read - clear corrupted data and return null
                        clearTokensInternal()
                        android.util.Log.i("TokenStorage", "Cleared corrupted token data due to encryption error")
                        null
                    }

                    is kotlinx.serialization.SerializationException -> {
                        // Corrupted JSON data - clear it
                        clearTokensInternal()
                        android.util.Log.i("TokenStorage", "Cleared corrupted token data due to serialization error")
                        null
                    }

                    else -> {
                        android.util.Log.w("TokenStorage", "Unexpected error reading tokens", e)
                        null
                    }
                }
            }
        }

    override suspend fun clearTokens(): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                clearTokensInternal()
                Result.success(Unit)
            } catch (e: Exception) {
                // Report to error tracking
                ErrorHandlerRegistry.captureException(
                    throwable = e,
                    context =
                        mapOf(
                            "operation" to "clear_tokens",
                            "storage_type" to "android_encrypted_shared_prefs",
                            "critical" to true,
                        ),
                    level = ErrorHandler.ErrorLevel.ERROR,
                )

                Result.failure(TokenStorageException.FileAccessException("Failed to clear tokens", e))
            }
        }

    override suspend fun saveJwtIds(usedIds: Map<String, Long>): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val jwtIdsJson = json.encodeToString(usedIds)
                val success =
                    encryptedPrefs
                        .edit()
                        .putString(JWT_IDS_KEY, jwtIdsJson)
                        .commit() // Use commit() instead of apply() for synchronous save

                if (!success) {
                    return@withContext Result.failure(TokenStorageException.FileAccessException("Failed to commit JWT IDs to storage"))
                }

                Result.success(Unit)
            } catch (e: Exception) {
                when (e) {
                    is java.security.GeneralSecurityException -> {
                        Result.failure(TokenStorageException.EncryptionException(cause = e))
                    }

                    is kotlinx.serialization.SerializationException -> {
                        Result.failure(TokenStorageException.CorruptedDataException("Failed to serialize JWT IDs", e))
                    }

                    else -> {
                        Result.failure(TokenStorageException.FileAccessException("Failed to save JWT IDs", e))
                    }
                }
            }
        }

    override suspend fun getJwtIds(): Map<String, Long>? =
        withContext(Dispatchers.IO) {
            try {
                val jwtIdsJson = encryptedPrefs.getString(JWT_IDS_KEY, null) ?: return@withContext null
                json.decodeFromString<Map<String, Long>>(jwtIdsJson)
            } catch (e: Exception) {
                when (e) {
                    is java.security.GeneralSecurityException -> {
                        // Encryption error - clear corrupted data
                        clearJwtIdsInternal()
                        null
                    }

                    is kotlinx.serialization.SerializationException -> {
                        // Corrupted data - clear it
                        clearJwtIdsInternal()
                        null
                    }

                    else -> {
                        null
                    }
                }
            }
        }

    override suspend fun clearJwtIds(): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                clearJwtIdsInternal()
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(TokenStorageException.FileAccessException("Failed to clear JWT IDs", e))
            }
        }

    private fun clearTokensInternal() {
        encryptedPrefs
            .edit()
            .remove(TOKEN_KEY)
            .apply()
    }

    private fun clearJwtIdsInternal() {
        encryptedPrefs
            .edit()
            .remove(JWT_IDS_KEY)
            .apply()
    }

    override suspend fun saveRefreshTokenMetadata(metadata: RefreshTokenMetadata): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                val metadataJson = json.encodeToString(metadata)
                val success =
                    encryptedPrefs
                        .edit()
                        .putString(REFRESH_TOKEN_METADATA_KEY, metadataJson)
                        .commit() // Use commit() instead of apply() for synchronous save

                if (!success) {
                    return@withContext Result.failure(
                        TokenStorageException.FileAccessException("Failed to commit refresh token metadata to storage"),
                    )
                }

                Result.success(Unit)
            } catch (e: Exception) {
                // Report to error tracking
                ErrorHandlerRegistry.captureException(
                    throwable = e,
                    context =
                        mapOf(
                            "operation" to "save_refresh_token_metadata",
                            "storage_type" to "android_encrypted_shared_prefs",
                            "exception_type" to e::class.simpleName,
                        ),
                    level = ErrorHandler.ErrorLevel.ERROR,
                )

                when (e) {
                    is java.security.GeneralSecurityException -> {
                        Result.failure(TokenStorageException.EncryptionException(cause = e))
                    }

                    is kotlinx.serialization.SerializationException -> {
                        Result.failure(TokenStorageException.CorruptedDataException("Failed to serialize refresh token metadata", e))
                    }

                    else -> {
                        Result.failure(TokenStorageException.FileAccessException("Failed to save refresh token metadata", e))
                    }
                }
            }
        }

    override suspend fun getRefreshTokenMetadata(): RefreshTokenMetadata? =
        withContext(Dispatchers.IO) {
            try {
                val metadataJson = encryptedPrefs.getString(REFRESH_TOKEN_METADATA_KEY, null) ?: return@withContext null
                json.decodeFromString<RefreshTokenMetadata>(metadataJson)
            } catch (e: Exception) {
                // Report to error tracking
                ErrorHandlerRegistry.captureException(
                    throwable = e,
                    context =
                        mapOf(
                            "operation" to "get_refresh_token_metadata",
                            "storage_type" to "android_encrypted_shared_prefs",
                            "exception_type" to e::class.simpleName,
                            "recovery_action" to
                                when (e) {
                                    is java.security.GeneralSecurityException -> "clear_corrupted_data"
                                    is kotlinx.serialization.SerializationException -> "clear_corrupted_data"
                                    else -> "return_null"
                                },
                        ),
                    level =
                        when (e) {
                            is java.security.GeneralSecurityException -> ErrorHandler.ErrorLevel.ERROR
                            else -> ErrorHandler.ErrorLevel.WARNING
                        },
                )

                when (e) {
                    is java.security.GeneralSecurityException -> {
                        // Encryption error - clear corrupted data
                        clearRefreshTokenMetadataInternal()
                        null
                    }

                    is kotlinx.serialization.SerializationException -> {
                        // Corrupted data - clear it
                        clearRefreshTokenMetadataInternal()
                        null
                    }

                    else -> {
                        null
                    }
                }
            }
        }

    override suspend fun clearRefreshTokenMetadata(): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                clearRefreshTokenMetadataInternal()
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(TokenStorageException.FileAccessException("Failed to clear refresh token metadata", e))
            }
        }

    private fun clearRefreshTokenMetadataInternal() {
        encryptedPrefs
            .edit()
            .remove(REFRESH_TOKEN_METADATA_KEY)
            .apply()
    }

    companion object {
        private const val TOKEN_KEY = "oauth_tokens"
        private const val JWT_IDS_KEY = "used_jwt_ids"
        private const val REFRESH_TOKEN_METADATA_KEY = "refresh_token_metadata"
    }
}
