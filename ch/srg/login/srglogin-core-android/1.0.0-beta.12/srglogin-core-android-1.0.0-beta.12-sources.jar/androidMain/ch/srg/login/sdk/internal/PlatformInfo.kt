package ch.srg.login.sdk.internal

import android.os.Build

/**
 * Android implementation of PlatformInfo.
 *
 * Provides accurate Android system information using Android Build APIs.
 */
internal actual object PlatformInfo {
    /**
     * Returns "Android" as the platform name.
     */
    actual fun getPlatformName(): String = "Android"

    /**
     * Returns the Android OS version.
     *
     * Format: "Android {VERSION.RELEASE}"
     *
     * Examples:
     * - "Android 14" (API 34)
     * - "Android 13" (API 33)
     * - "Android 12" (API 31)
     *
     * Note: In unit test environments (Robolectric), VERSION.RELEASE may be null.
     * In such cases, falls back to "Unknown".
     */
    actual fun getOsVersion(): String {
        val version = Build.VERSION.RELEASE ?: "Unknown"
        return "Android $version"
    }

    /**
     * Returns the Android device model.
     *
     * Format: "{MANUFACTURER} {MODEL}"
     *
     * Examples:
     * - "Google Pixel 8"
     * - "Samsung SM-S918B"
     * - "OnePlus LE2123"
     *
     * Note: MANUFACTURER is capitalized, MODEL is as-is from Build.
     * In unit test environments (Robolectric), MANUFACTURER/MODEL may be null.
     * In such cases, falls back to "Unknown Device".
     */
    actual fun getDeviceModel(): String {
        val manufacturer = (Build.MANUFACTURER ?: "Unknown").replaceFirstChar { it.uppercase() }
        val model = Build.MODEL ?: "Device"
        return "$manufacturer $model"
    }
}
