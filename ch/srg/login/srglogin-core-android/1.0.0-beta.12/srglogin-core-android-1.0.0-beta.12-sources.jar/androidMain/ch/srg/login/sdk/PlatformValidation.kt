package ch.srg.login.sdk

import android.content.Context

/**
 * Android-specific platform validation.
 * Ensures that a valid Android Context is provided for SDK initialization.
 */
internal actual fun validatePlatformRequirements(platformContext: Any?) {
    require(platformContext is Context) {
        """
        Android requires a Context for SDK initialization.

        Pass your Application's context to platformContext:
          SrgLoginSdk.initialize(
              platformContext = applicationContext,
              isDebugBuild = BuildConfig.DEBUG
          )

        Recommended: Initialize in Application.onCreate()

        Example:
        class MyApplication : Application() {
            override fun onCreate() {
                super.onCreate()
                SrgLoginSdk.initialize(
                    platformContext = applicationContext,
                    isDebugBuild = BuildConfig.DEBUG
                )
            }
        }

        Why Context is required:
        - Hardware-backed Keystore for secure token storage
        - Chrome Custom Tabs for OAuth flows
        - Lifecycle observation
        """.trimIndent()
    }
}
