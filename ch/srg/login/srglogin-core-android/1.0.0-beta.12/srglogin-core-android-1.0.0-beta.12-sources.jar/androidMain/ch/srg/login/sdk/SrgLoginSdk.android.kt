package ch.srg.login.sdk

import android.content.Context
import android.content.Intent
import android.net.Uri
import ch.srg.login.sdk.auth.StateContinuationRegistry
import org.koin.core.Koin

/**
 * Android-specific context declaration that ensures proper type binding.
 */
internal actual fun declarePlatformContext(
    koin: Koin,
    context: Any,
) {
    val androidContext = context as Context
    koin.declare(androidContext)
}

/**
 * Android-specific `actual` implementation for [handleRedirect].
 *
 * This implementation uses the OIDC state parameter to route callbacks
 * to the correct authentication flow. This approach is robust against
 * URL changes and supports concurrent authentication operations.
 */
actual fun handleRedirect(data: Any): Boolean {
    val intent = data as? Intent ?: return false
    val redirectUrl = intent.dataString ?: return false

    // Extract OIDC state parameter from the callback URL
    val state = extractStateFromRedirectUrl(redirectUrl)
    if (state == null) {
        // No state parameter found - this might not be an authentication callback
        return false
    }

    // Try to complete login flow first
    if (StateContinuationRegistry.completeLogin(state, redirectUrl)) {
        return true
    }

    // If not a login, try logout flow
    if (StateContinuationRegistry.completeLogout(state, redirectUrl)) {
        return true
    }

    // Note: SSO client flow uses fire-and-forget pattern (no callback expected)
    // Therefore, no need to check completeSsoClient() here

    // State was found but no matching flow was registered
    // This could indicate an expired flow or a malformed callback
    return false
}

/**
 * Extracts the OIDC state parameter from a callback URL.
 *
 * @param url The callback URL received from the browser
 * @return The state parameter value or null if not found
 */
private fun extractStateFromRedirectUrl(url: String): String? =
    try {
        val uri = Uri.parse(url)
        uri.getQueryParameter("state")
    } catch (e: Exception) {
        null
    }
