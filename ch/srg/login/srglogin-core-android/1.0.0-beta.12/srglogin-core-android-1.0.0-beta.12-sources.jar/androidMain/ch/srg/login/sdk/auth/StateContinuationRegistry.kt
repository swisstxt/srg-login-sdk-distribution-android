package ch.srg.login.sdk.auth

import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.result.SdkResult
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.datetime.Clock
import kotlinx.datetime.Instant
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.Continuation
import kotlin.coroutines.resume
import kotlin.time.Duration.Companion.minutes

/**
 * Thread-safe registry for managing OIDC state-based authentication flows.
 *
 * This replaces the centralized SdkAuthResultManager with a decentralized approach
 * that leverages the OIDC `state` parameter as the natural identifier for linking
 * requests to responses. Each authentication operation registers its continuation
 * with a unique, cryptographically secure state value.
 *
 * Key benefits:
 * - No shared state between login and logout operations
 * - Uses standard OIDC security mechanism (state parameter)
 * - Thread-safe with minimal locking
 * - Automatic cleanup and timeout handling
 * - Scales naturally for concurrent operations
 */
internal object StateContinuationRegistry {
    /**
     * Represents an active authentication flow with its associated data.
     */
    private data class ActiveFlow(
        val state: String,
        val flowType: FlowType,
        val createdAt: Instant,
        val loginContinuation: Continuation<SdkResult<String>>? = null,
        val logoutContinuation: Continuation<SdkResult<Unit>>? = null,
        val timeoutDuration: kotlin.time.Duration = 5.minutes,
    ) {
        fun isExpired(): Boolean = Clock.System.now() - createdAt > timeoutDuration
    }

    /**
     * Types of authentication flows supported.
     */
    private enum class FlowType {
        LOGIN,
        LOGOUT,
    }

    // Thread-safe storage for active flows
    private val activeFlows = ConcurrentHashMap<String, ActiveFlow>()

    // Mutex for cleanup operations only (not needed for ConcurrentHashMap operations)
    private val cleanupMutex = Mutex()

    // Track last cleanup to avoid excessive cleanup calls
    private var lastCleanup = Clock.System.now()

    /**
     * Registers a login flow continuation with the given OIDC state.
     *
     * @param state The OIDC state parameter from the authorization request
     * @param continuation The coroutine continuation to resume when callback received
     * @throws IllegalArgumentException if state is blank
     */
    fun registerLoginContinuation(
        state: String,
        continuation: Continuation<SdkResult<String>>,
    ) {
        require(state.isNotBlank()) { "OIDC state parameter cannot be blank" }

        val flow =
            ActiveFlow(
                state = state,
                flowType = FlowType.LOGIN,
                createdAt = Clock.System.now(),
                loginContinuation = continuation,
            )

        // Cancel any existing flow with the same state (should not happen with secure random states)
        activeFlows[state]?.let { existingFlow ->
            existingFlow.loginContinuation?.resume(
                SdkResult.Failure(SrgLoginError.UserCancelled("Authentication cancelled by new request with same state")),
            )
        }

        activeFlows[state] = flow

        // Trigger cleanup if needed
        cleanupExpiredFlowsIfNeeded()
    }

    /**
     * Registers a logout flow continuation with the given OIDC state.
     *
     * @param state The OIDC state parameter from the logout request
     * @param continuation The coroutine continuation to resume when logout completes
     * @throws IllegalArgumentException if state is blank
     */
    fun registerLogoutContinuation(
        state: String,
        continuation: Continuation<SdkResult<Unit>>,
    ) {
        require(state.isNotBlank()) { "OIDC state parameter cannot be blank" }

        val flow =
            ActiveFlow(
                state = state,
                flowType = FlowType.LOGOUT,
                createdAt = Clock.System.now(),
                logoutContinuation = continuation,
            )

        // Cancel any existing flow with the same state (should not happen with secure random states)
        activeFlows[state]?.let { existingFlow ->
            existingFlow.logoutContinuation?.resume(
                SdkResult.Failure(SrgLoginError.UserCancelled("Logout cancelled by new request with same state")),
            )
        }

        activeFlows[state] = flow

        // Trigger cleanup if needed
        cleanupExpiredFlowsIfNeeded()
    }

    /**
     * Completes a login flow by resuming the associated continuation.
     *
     * @param state The OIDC state parameter from the callback URL
     * @param callbackUrl The complete callback URL received from the browser
     * @return true if a matching login flow was found and completed, false otherwise
     */
    fun completeLogin(
        state: String,
        callbackUrl: String,
    ): Boolean {
        val flow = activeFlows.remove(state) ?: return false

        return if (flow.flowType == FlowType.LOGIN) {
            flow.loginContinuation?.resume(SdkResult.Success(callbackUrl))
            true
        } else {
            // Put it back if it's not a login flow
            activeFlows[state] = flow
            false
        }
    }

    /**
     * Completes a logout flow by resuming the associated continuation.
     *
     * @param state The OIDC state parameter from the callback URL
     * @param callbackUrl The complete callback URL received from the browser
     * @return true if a matching logout flow was found and completed, false otherwise
     */
    fun completeLogout(
        state: String,
        callbackUrl: String,
    ): Boolean {
        val flow = activeFlows.remove(state) ?: return false

        return if (flow.flowType == FlowType.LOGOUT) {
            flow.logoutContinuation?.resume(SdkResult.Success(Unit))
            true
        } else {
            // Put it back if it's not a logout flow
            activeFlows[state] = flow
            false
        }
    }

    /**
     * Cancels a login flow, typically due to user cancellation or timeout.
     *
     * @param state The OIDC state parameter of the flow to cancel
     * @param reason The reason for cancellation
     * @return true if a login flow was found and cancelled, false otherwise
     */
    fun cancelLogin(
        state: String,
        reason: String = "Authentication was cancelled",
    ): Boolean {
        val flow = activeFlows.remove(state) ?: return false

        return if (flow.flowType == FlowType.LOGIN) {
            flow.loginContinuation?.resume(SdkResult.Failure(SrgLoginError.UserCancelled(reason)))
            true
        } else {
            // Put it back if it's not a login flow
            activeFlows[state] = flow
            false
        }
    }

    /**
     * Cancels a logout flow, resuming the continuation with a cancellation error.
     *
     * @param state The OIDC state parameter of the flow to cancel
     * @param reason The reason for cancellation
     * @return true if a logout flow was found and cancelled, false otherwise
     */
    fun cancelLogout(
        state: String,
        reason: String = "Logout was cancelled",
    ): Boolean {
        val flow = activeFlows.remove(state) ?: return false

        return if (flow.flowType == FlowType.LOGOUT) {
            flow.logoutContinuation?.resume(SdkResult.Failure(SrgLoginError.UserCancelled(reason)))
            true
        } else {
            // Put it back if it's not a logout flow
            activeFlows[state] = flow
            false
        }
    }

    /**
     * Gets the current number of active flows for monitoring purposes.
     */
    fun getActiveFlowCount(): Int = activeFlows.size

    /**
     * Gets the number of active flows by type for monitoring purposes.
     * @return Pair of (loginCount, logoutCount)
     */
    fun getActiveFlowCounts(): Pair<Int, Int> {
        val flows = activeFlows.values
        val loginCount = flows.count { it.flowType == FlowType.LOGIN }
        val logoutCount = flows.count { it.flowType == FlowType.LOGOUT }
        return Pair(loginCount, logoutCount)
    }

    /**
     * Cleans up expired flows to prevent memory leaks.
     * This is called automatically but can also be called manually.
     */
    suspend fun cleanupExpiredFlows() =
        cleanupMutex.withLock {
            val now = Clock.System.now()
            val expiredStates = mutableListOf<String>()

            // Find expired flows
            for ((state, flow) in activeFlows) {
                if (flow.isExpired()) {
                    expiredStates.add(state)

                    // Cancel flows with appropriate timeout errors
                    when (flow.flowType) {
                        FlowType.LOGIN -> {
                            flow.loginContinuation?.resume(
                                SdkResult.Failure(
                                    SrgLoginError.AuthenticationTimeout("Authentication timed out after ${flow.timeoutDuration}"),
                                ),
                            )
                        }

                        FlowType.LOGOUT -> {
                            flow.logoutContinuation?.resume(
                                SdkResult.Failure(SrgLoginError.AuthenticationTimeout("Logout timed out after ${flow.timeoutDuration}")),
                            )
                        }
                    }
                }
            }

            // Remove expired flows
            expiredStates.forEach { state ->
                activeFlows.remove(state)
            }

            lastCleanup = now

            if (expiredStates.isNotEmpty()) {
                println("StateContinuationRegistry: Cleaned up ${expiredStates.size} expired flows")
            }
        }

    /**
     * Triggers cleanup if enough time has passed or if there are too many active flows.
     */
    private fun cleanupExpiredFlowsIfNeeded() {
        val now = Clock.System.now()
        val timeSinceLastCleanup = now - lastCleanup

        // Cleanup every 5 minutes or if we have too many flows
        if (timeSinceLastCleanup > 5.minutes || activeFlows.size > 100) {
            // Launch cleanup in background (don't block current operation)
            kotlinx.coroutines.GlobalScope.launch {
                cleanupExpiredFlows()
            }
        }
    }

    /**
     * Clears all active flows. Use with caution - mainly for testing.
     */
    fun clearAllFlows() {
        // Cancel all continuations before clearing
        activeFlows.values.forEach { flow ->
            when (flow.flowType) {
                FlowType.LOGIN -> {
                    flow.loginContinuation?.resume(
                        SdkResult.Failure(SrgLoginError.UserCancelled("All flows cleared")),
                    )
                }

                FlowType.LOGOUT -> {
                    flow.logoutContinuation?.resume(
                        SdkResult.Failure(SrgLoginError.UserCancelled("All flows cleared")),
                    )
                }
            }
        }

        activeFlows.clear()
        lastCleanup = Clock.System.now()
    }
}
