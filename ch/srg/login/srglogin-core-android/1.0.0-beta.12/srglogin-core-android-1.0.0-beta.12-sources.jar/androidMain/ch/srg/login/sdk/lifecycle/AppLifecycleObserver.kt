package ch.srg.login.sdk.lifecycle

import android.app.Application
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import ch.srg.login.sdk.auth.AndroidAuthContext
import ch.srg.login.sdk.auth.PlatformAuthContext
import ch.srg.login.sdk.auth.TokenManager
import ch.srg.login.sdk.events.EventEmitter
import ch.srg.login.sdk.events.SdkLifecycleEvent

/**
 * Android platform lifecycle observer.
 *
 * Automatically observes Android app lifecycle events via ProcessLifecycleOwner and:
 * - Stops token monitoring when app goes to background (onStop)
 * - Disposes SDK resources when app is destroyed (onDestroy)
 *
 * **Auto-registration**: This observer is automatically registered when the SDK is initialized.
 * The developer does not need to call any lifecycle methods manually.
 *
 * **Lifecycle events**:
 * - onStop: App goes to background → Stop token monitoring (save battery)
 * - onDestroy: App is destroyed → Dispose all SDK resources
 *
 * @property platformContext Platform authentication context (contains Android Context)
 * @property tokenManager TokenManager instance to observe
 * @property eventEmitter Event emitter for SDK lifecycle events (app lifecycle, token state)
 */
internal actual class AppLifecycleObserver actual constructor(
    platformContext: PlatformAuthContext,
    private val tokenManager: TokenManager,
    private val eventEmitter: EventEmitter,
) {
    companion object {
        private const val CREATION_TAG = "SDK-Creation"
    }

    init {
        println("$CREATION_TAG: 🏗️ CONSTRUCTOR - AppLifecycleObserver created (hashCode=${this.hashCode()})")
        println("$CREATION_TAG:    ├─ TokenManager hashCode=${tokenManager.hashCode()}")
        println("$CREATION_TAG:    └─ EventEmitter hashCode=${eventEmitter.hashCode()}")
    }

    // Extract Android Context from PlatformAuthContext
    private val context = (platformContext as AndroidAuthContext).context

    /**
     * ProcessLifecycleOwner observer for app-level lifecycle events.
     *
     * **Option A - Hybrid Approach** (Events + Direct calls):
     * - Emits lifecycle events for extensibility (analytics, logging, observability)
     * - Makes direct calls to TokenManager for guaranteed cleanup (defensive)
     */
    private val lifecycleObserver =
        object : DefaultLifecycleObserver {
            override fun onCreate(owner: LifecycleOwner) {
                // App started for the first time in this process
                val timestamp =
                    kotlinx.datetime.Clock.System
                        .now()
                        .toEpochMilliseconds()
                eventEmitter.tryEmit(SdkLifecycleEvent.AppStarted(timestamp))
            }

            override fun onStart(owner: LifecycleOwner) {
                // App comes to foreground
                val timestamp =
                    kotlinx.datetime.Clock.System
                        .now()
                        .toEpochMilliseconds()
                eventEmitter.tryEmit(SdkLifecycleEvent.AppForegrounded(timestamp))
                // Note: TokenManager listens to this event and restarts monitoring if needed
            }

            override fun onStop(owner: LifecycleOwner) {
                // App goes to background
                val timestamp =
                    kotlinx.datetime.Clock.System
                        .now()
                        .toEpochMilliseconds()
                eventEmitter.tryEmit(SdkLifecycleEvent.AppBackgrounded(timestamp))

                // HYBRID: Direct call for guaranteed cleanup (defensive)
                tokenManager.stopTokenMonitoring()
            }

            override fun onDestroy(owner: LifecycleOwner) {
                // App is destroyed
                val timestamp =
                    kotlinx.datetime.Clock.System
                        .now()
                        .toEpochMilliseconds()
                eventEmitter.tryEmit(SdkLifecycleEvent.AppTerminated(timestamp))

                // HYBRID: Direct call for guaranteed cleanup (defensive)
                tokenManager.dispose()
            }
        }

    init {
        // Get Application from Context
        val application = context.applicationContext as? Application

        if (application != null) {
            // Register to ProcessLifecycleOwner (observes entire app lifecycle)
            ProcessLifecycleOwner.get().lifecycle.addObserver(lifecycleObserver)
            println("✅ AppLifecycleObserver registered (Android)")
        } else {
            println("⚠️ AppLifecycleObserver: Application context not available")
        }
    }

    /**
     * Cleanup lifecycle observer.
     *
     * Unregisters the observer from ProcessLifecycleOwner.
     * Safe to call multiple times (idempotent).
     *
     * **Note**: Usually called automatically via onDestroy. Manual call is rarely needed
     * except in tests or special cleanup scenarios.
     */
    actual fun cleanup() {
        try {
            ProcessLifecycleOwner.get().lifecycle.removeObserver(lifecycleObserver)
            println("✅ AppLifecycleObserver unregistered (Android)")
        } catch (e: IllegalStateException) {
            // ProcessLifecycleOwner not available (e.g., in unit tests)
            // This is expected in certain scenarios, just log it
            println("⚠️ ProcessLifecycleOwner not available during cleanup: ${e.message}")
        } catch (e: IllegalArgumentException) {
            // Observer was not registered (cleanup called multiple times)
            // This is expected for idempotent cleanup, just log it
            println("⚠️ Observer not registered (cleanup called multiple times): ${e.message}")
        }
        // All other exceptions/errors propagate → indicates real bugs that need fixing
    }
}
