package ch.srg.login.sdk

import ch.srg.login.sdk.token.TokenStorageConfig
import org.koin.core.Koin

/**
 * Public API for the SRG Login SDK.
 *
 * This is the main entry point for SDK users to initialize the SDK and create
 * [SrgLogin] instances for OAuth 2.0/OIDC authentication flows.
 *
 * ## Quick Start
 *
 * ### Android
 * ```kotlin
 * class MyApplication : Application() {
 *     override fun onCreate() {
 *         super.onCreate()
 *
 *         // Initialize SDK once at app startup
 *         SrgLoginSdk.initialize(
 *             platformContext = applicationContext,
 *             isDebugBuild = BuildConfig.DEBUG
 *         )
 *     }
 * }
 *
 * // Later, create SDK instance with your OAuth configuration
 * val srgLogin = SrgLoginSdk.create(
 *     SrgLoginConfig(
 *         environment = Environment.PROD,
 *         clientId = "your-client-id",
 *         redirectUri = "your-app://callback"
 *     )
 * )
 * ```
 *
 * ### iOS (Swift)
 * ```swift
 * @main
 * struct MyApp: App {
 *     init() {
 *         // Initialize SDK once at app startup
 *         SrgLoginSdk.shared.initialize(
 *             platformContext: nil,
 *             isDebugBuild: true
 *         )
 *     }
 * }
 *
 * // Later, create SDK instance
 * let srgLogin = SrgLoginSdk.shared.create(
 *     config: SrgLoginConfig(
 *         environment: .prod,
 *         clientId: "your-client-id",
 *         redirectUri: "your-app://callback"
 *     )
 * )
 * ```
 *
 * ## Architecture
 *
 * This class is a **public facade** that delegates to [SdkCore] (internal implementation).
 *
 * **Why this separation?**
 * - ✅ **Clean API**: Users don't see confusing internal parameters (e.g., Koin debug logging)
 * - ✅ **Stability**: Public API remains stable while internal implementation can evolve
 * - ✅ **Testing**: SDK developers can use [SdkCore] directly in tests for fine-grained control
 * - ✅ **Documentation**: Focused documentation for each audience (users vs SDK developers)
 *
 * **What's hidden from users?**
 * - Koin dependency injection debug logging (internal implementation detail)
 * - Low-level DI container management
 * - Internal SDK lifecycle details
 *
 * **What's exposed to users?**
 * - Simple initialization API with minimal required parameters
 * - SDK application logging control (`isDebugBuild`)
 * - Token storage configuration
 * - Platform context (Android only)
 *
 * ## Logging Configuration
 *
 * The SDK provides structured logging through [SdkLogger].
 *
 * **Debug Builds** (`isDebugBuild = true`):
 * - **Log Level**: DEBUG and above (VERBOSE, DEBUG, INFO, WARNING, ERROR, ASSERT)
 * - **Use Case**: Development, troubleshooting OAuth flows, inspecting token lifecycle
 * - **Example**: `"DEBUG [TOKEN_MONITORING] Token expires in 120 seconds"`
 *
 * **Release Builds** (`isDebugBuild = false`):
 * - **Log Level**: INFO and above (INFO, WARNING, ERROR, ASSERT)
 * - **Use Case**: Production, high-level events only
 * - **Example**: `"INFO [AUTHENTICATION] Login completed successfully"`
 *
 * **Recommendation**: Pass your build configuration flag (e.g., `BuildConfig.DEBUG` on Android).
 *
 * ## Thread Safety
 *
 * - [initialize] should be called once at app startup on the main thread
 * - [create] can be called from any thread (but typically main thread)
 * - Multiple [SrgLogin] instances are supported and isolated from each other
 *
 * ## Platform Requirements
 *
 * ### Android
 * - **Required**: `platformContext` must be `ApplicationContext`
 * - **Minimum API**: 21+ (Android 5.0 Lollipop)
 * - **Dependencies**: Chrome Custom Tabs, Android Keystore
 *
 * ### iOS
 * - **Required**: None (`platformContext` can be `null`)
 * - **Minimum Version**: iOS 13.0+
 * - **Dependencies**: ASWebAuthenticationSession, Keychain
 *
 * ### JVM
 * - **Required**: None (`platformContext` can be `null`)
 * - **Minimum Version**: JVM 11+
 * - **Dependencies**: Platform-specific browser integration
 *
 * ### JavaScript
 * - **Required**: None (`platformContext` can be `null`)
 * - **Minimum Version**: ES2015+
 * - **Dependencies**: Browser APIs
 *
 * @since 1.0.0
 * @see SdkCore Internal implementation (SDK developers only)
 * @see SrgLogin SDK instance for authentication operations
 * @see SrgLoginConfig OAuth 2.0/OIDC configuration
 */
object SrgLoginSdk {
    /**
     * Initializes the SDK with the given configuration.
     *
     * This method must be called **once** at app startup before creating any [SrgLogin] instances.
     * It sets up the internal dependency injection container and logging infrastructure.
     *
     * **Idempotency**: Calling this multiple times is safe (no-op after first call).
     *
     * ## Parameters
     *
     * @param tokenStorageConfig Configuration for secure token storage.
     *   **Default**: Uses platform-specific secure storage (Android Keystore, iOS Keychain, etc.)
     *   **Custom**: Pass custom [TokenStorageConfig] to override encryption settings or storage location.
     *
     * @param platformContext Platform-specific context required for initialization:
     *   - **Android**: `Context` (typically `applicationContext`)
     *   - **iOS/JVM/JS**: Not required (pass `null`)
     *
     * @param isDebugBuild If `true`, sets SDK logging to DEBUG level (all logs visible).
     *   If `false`, sets SDK logging to INFO level (only INFO/WARNING/ERROR/ASSERT visible).
     *   **Recommendation**: Pass `BuildConfig.DEBUG` on Android, equivalent on other platforms.
     *
     * ## Example (Android)
     * ```kotlin
     * class MyApplication : Application() {
     *     override fun onCreate() {
     *         super.onCreate()
     *         SrgLoginSdk.initialize(
     *             platformContext = applicationContext,
     *             isDebugBuild = BuildConfig.DEBUG
     *         )
     *     }
     * }
     * ```
     *
     * ## Example (iOS/Swift)
     * ```swift
     * @main
     * struct MyApp: App {
     *     init() {
     *         SrgLoginSdk.shared.initialize(
     *             platformContext: nil,
     *             isDebugBuild: true
     *         )
     *     }
     * }
     * ```
     *
     * @throws IllegalArgumentException If platform requirements are not met
     *   (e.g., missing `Context` on Android).
     *
     * @see TokenStorageConfig Token storage configuration options
     * @see create Create SrgLogin instance after initialization
     */
    fun initialize(
        tokenStorageConfig: TokenStorageConfig = TokenStorageConfig(),
        platformContext: Any? = null,
        isDebugBuild: Boolean = false,
    ) {
        // Delegate to internal implementation with Koin debug logging disabled
        SdkCore.initialize(
            // Never exposed to users (internal DI detail)
            enableKoinDebugLogging = false,
            tokenStorageConfig = tokenStorageConfig,
            platformContext = platformContext,
            isDebugBuild = isDebugBuild,
        )
    }

    /**
     * Creates a new [SrgLogin] instance with the given OAuth 2.0/OIDC configuration.
     *
     * Each [SrgLogin] instance is fully isolated:
     * - Separate event bus (no cross-instance interference)
     * - Separate token storage scope
     * - Separate authentication state
     *
     * **Multiple instances** are supported for multi-tenant scenarios or different OAuth providers.
     *
     * ## Example (Single Instance)
     * ```kotlin
     * val srgLogin = SrgLoginSdk.create(
     *     SrgLoginConfig(
     *         environment = Environment.PROD,
     *         clientId = "your-client-id",
     *         redirectUri = "your-app://callback"
     *     )
     * )
     *
     * // Start authentication
     * srgLogin.login(context)
     * ```
     *
     * ## Example (Multi-Tenant)
     * ```kotlin
     * val prodSdk = SrgLoginSdk.create(
     *     SrgLoginConfig(environment = Environment.PROD, clientId = "prod-client")
     * )
     *
     * val stagingSdk = SrgLoginSdk.create(
     *     SrgLoginConfig(environment = Environment.STAGE, clientId = "stage-client")
     * )
     * ```
     *
     * @param config The OAuth 2.0/OIDC configuration for this SDK instance.
     *   See [SrgLoginConfig] for all available options.
     *
     * @return A new [SrgLogin] instance ready for authentication operations.
     *
     * @throws IllegalStateException If SDK is not initialized.
     *   Call [initialize] first at app startup.
     *
     * @see SrgLoginConfig OAuth 2.0/OIDC configuration options
     * @see SrgLogin Authentication operations (login, logout, token refresh)
     * @see initialize Initialize SDK before calling this method
     */
    fun create(config: SrgLoginConfig): SrgLogin = SdkCore.create(config)

    /**
     * Shuts down the SDK and releases all resources.
     *
     * **WARNING**: After calling this:
     * - All existing [SrgLogin] instances become invalid
     * - You must call [initialize] again before creating new instances
     *
     * **Use Case**: Testing scenarios where you need to reset SDK state.
     * In production apps, this is rarely needed (SDK lifecycle = app lifecycle).
     *
     * **Idempotency**: Calling this multiple times is safe (no-op if already shut down).
     *
     * ## Example (Testing)
     * ```kotlin
     * @After
     * fun tearDown() {
     *     SrgLoginSdk.shutdown()
     * }
     * ```
     *
     * @see initialize Reinitialize SDK after shutdown
     */
    fun shutdown() {
        SdkCore.shutdown()
    }

    /**
     * Checks if the SDK has been initialized.
     *
     * **Use Case**: Defensive checks in library code or testing.
     *
     * ## Example
     * ```kotlin
     * if (!SrgLoginSdk.isInitialized()) {
     *     SrgLoginSdk.initialize(
     *         platformContext = applicationContext,
     *         isDebugBuild = BuildConfig.DEBUG
     *     )
     * }
     * ```
     *
     * @return `true` if [initialize] has been called and SDK is ready,
     *   `false` otherwise.
     *
     * @see initialize Initialize the SDK
     */
    fun isInitialized(): Boolean = SdkCore.isInitialized()
}

/**
 * Handles the redirect from a web authentication flow. This must be called
 * by the host application from the Activity/UI component that receives the
 * redirect from the browser.
 *
 * @param data The platform-specific data object containing the redirect.
 *             On Android, this is an `Intent`. On iOS, this is an `NSURL`.
 * @return `true` if the SDK recognized and handled the redirect, `false` otherwise.
 */
expect fun handleRedirect(data: Any): Boolean

/**
 * Platform-specific context declaration in Koin.
 * Each platform can handle the context declaration according to its needs.
 */
internal expect fun declarePlatformContext(
    koin: Koin,
    context: Any,
)
