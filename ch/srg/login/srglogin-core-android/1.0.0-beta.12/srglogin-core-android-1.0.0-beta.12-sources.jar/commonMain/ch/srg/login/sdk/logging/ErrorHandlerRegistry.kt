package ch.srg.login.sdk.logging

import kotlin.concurrent.Volatile

/**
 * Global registry for error tracking.
 *
 * This singleton manages the active [ErrorHandler] instance and provides
 * convenient static methods for capturing errors throughout the SDK.
 *
 * ## Architecture
 *
 * ```
 * SDK Code                ErrorHandlerRegistry            ErrorHandler
 *    │                            │                            │
 *    ├─ captureException() ──────>│                            │
 *    │                            ├─ if handler != null ──────>│
 *    │                            │                            ├─ Send to Sentry
 *    │                            │<───────────────────────────┘
 *    │<───────────────────────────┘
 *    │
 *    └─ Continue (SDK never blocked)
 * ```
 *
 * ## Usage
 *
 * ### Automatic Setup (by SDK)
 *
 * Error tracking is automatically initialized by the SDK based on environment:
 * - **DEV**: No tracking (errors logged to console only)
 * - **INT**: Automatic tracking with SdkErrorReporter
 * - **PROD**: Automatic tracking with SdkErrorReporter
 *
 * No configuration needed from application code. The SDK manages its own
 * internal error tracking with hidden DSN.
 *
 * ### Capture errors (anywhere in SDK)
 *
 * ```kotlin
 * try {
 *     tokenManager.refreshTokens()
 * } catch (e: Exception) {
 *     // Log locally
 *     SdkLogger.e(LogCategory.TOKEN_MONITORING, throwable = e) {
 *         "Token refresh failed"
 *     }
 *
 *     // Report to error tracking (if configured)
 *     ErrorHandlerRegistry.captureException(
 *         throwable = e,
 *         context = mapOf("operation" to "token_refresh")
 *     )
 *
 *     throw e
 * }
 * ```
 *
 * ## Thread Safety
 *
 * This class is thread-safe. Multiple threads can call capture methods
 * concurrently without synchronization issues.
 *
 * ## Fail-Safe Design
 *
 * If no handler is configured, all capture methods are **no-ops**:
 * - No exceptions thrown
 * - No performance impact
 * - SDK continues functioning normally
 *
 * This ensures error tracking is **optional** and **never breaks the SDK**.
 *
 * @see ErrorHandler
 */
internal object ErrorHandlerRegistry {
    /**
     * Currently active error handler (null if not configured).
     *
     * Marked @Volatile to ensure visibility across threads in KMP.
     */
    @Volatile
    private var handler: ErrorHandler? = null

    /**
     * Sets the global error handler.
     *
     * **Internal use only**: This method is called automatically by the SDK during
     * initialization to configure internal error tracking based on environment (DEV/INT/PROD).
     *
     * Applications do not need to call this - error tracking is managed internally.
     *
     * **Thread Safety**: This method is thread-safe.
     *
     * @param errorHandler The error handler to use (null to disable error tracking)
     */
    fun setHandler(errorHandler: ErrorHandler?) {
        handler = errorHandler
    }

    /**
     * Gets the currently configured error handler.
     *
     * **Thread Safety**: This method is thread-safe.
     *
     * @return The active error handler, or null if not configured
     *
     * @example
     * ```kotlin
     * val handler = ErrorHandlerRegistry.getHandler()
     * if (handler != null) {
     *     // Error tracking is enabled
     *     handler.setTag("feature", "authentication")
     * }
     * ```
     */
    fun getHandler(): ErrorHandler? = handler

    /**
     * Captures an exception with optional context.
     *
     * If an error handler is configured, delegates to [ErrorHandler.captureException].
     * If no handler is configured, this is a **no-op** (does nothing).
     *
     * **Thread Safety**: This method is thread-safe.
     *
     * **Performance**: If no handler is configured, this has zero overhead.
     *
     * **Fail-Safe**: This method never throws exceptions. If the handler
     * throws an exception, it is silently caught to prevent breaking the SDK.
     *
     * @param throwable The exception to report
     * @param context Additional context for debugging
     * @param level Error severity level (defaults to ERROR)
     *
     * @example
     * ```kotlin
     * try {
     *     apiService.refreshToken()
     * } catch (e: NetworkException) {
     *     // Report error (no-op if handler not configured)
     *     ErrorHandlerRegistry.captureException(
     *         throwable = e,
     *         context = mapOf(
     *             "operation" to "token_refresh",
     *             "retry_count" to 3
     *         )
     *     )
     *     throw e
     * }
     * ```
     */
    fun captureException(
        throwable: Throwable,
        context: Map<String, Any?> = emptyMap(),
        level: ErrorHandler.ErrorLevel = ErrorHandler.ErrorLevel.ERROR,
    ) {
        try {
            handler?.captureException(throwable, context, level)
        } catch (e: Exception) {
            // Silently catch errors from handler to prevent breaking SDK
            // In production, we don't want error tracking failures to crash the app
        }
    }

    /**
     * Captures a message (non-exception error).
     *
     * If an error handler is configured, delegates to [ErrorHandler.captureMessage].
     * If no handler is configured, this is a **no-op** (does nothing).
     *
     * **Thread Safety**: This method is thread-safe.
     *
     * **Performance**: If no handler is configured, this has zero overhead.
     *
     * **Fail-Safe**: This method never throws exceptions.
     *
     * @param message The error message to report
     * @param context Additional context for debugging
     * @param level Error severity level (defaults to ERROR)
     *
     * @example
     * ```kotlin
     * if (config.clientId.isBlank()) {
     *     // Report configuration error
     *     ErrorHandlerRegistry.captureMessage(
     *         message = "SDK configuration invalid: clientId is blank",
     *         context = mapOf("config_source" to "initialization"),
     *         level = ErrorHandler.ErrorLevel.ERROR
     *     )
     * }
     * ```
     */
    fun captureMessage(
        message: String,
        context: Map<String, Any?> = emptyMap(),
        level: ErrorHandler.ErrorLevel = ErrorHandler.ErrorLevel.ERROR,
    ) {
        try {
            handler?.captureMessage(message, context, level)
        } catch (e: Exception) {
            // Silently catch errors from handler to prevent breaking SDK
        }
    }

    /**
     * Checks if error tracking is currently enabled.
     *
     * @return true if a handler is configured, false otherwise
     *
     * @example
     * ```kotlin
     * if (ErrorHandlerRegistry.isEnabled()) {
     *     // Error tracking is active
     *     println("Errors will be reported to error tracking service")
     * }
     * ```
     */
    fun isEnabled(): Boolean = handler != null
}
