package ch.srg.login.sdk.config

import ch.srg.login.sdk.Environment
import ch.srg.login.sdk.SrgLoginConfig
import kotlinx.datetime.Clock
import kotlinx.datetime.TimeZone
import kotlinx.datetime.toLocalDateTime

/**
 * Internal configuration for SDK error tracking with Sentry.
 *
 * This configuration is internal to the SDK and not exposed to applications.
 * It provides environment-specific Sentry DSNs and salts for user anonymization.
 *
 * ## DSN Security
 *
 * The Sentry DSN (Data Source Name) is intentionally embedded in the SDK code
 * and is considered "public" by Sentry's design. This is standard practice
 * for client-side error tracking SDKs.
 *
 * **Why is the DSN not secret?**
 * - The DSN only allows *sending* events to Sentry (write-only access)
 * - The DSN does NOT allow reading existing Sentry data
 * - Sentry protects projects via rate limiting, quotas, and inbound filters
 * - This is the same approach used by Firebase, Bugsnag, and other error tracking services
 *
 * **Can the DSN be extracted?**
 * Yes, through reverse engineering of the compiled SDK (APK/IPA). However:
 * - The impact is limited (data pollution, not data breach)
 * - Sentry provides server-side protection (rate limiting, quota alerts)
 * - This is an accepted trade-off in the error tracking industry
 *
 * See `docs/features/error-tracking-sentry.md` for detailed security analysis.
 *
 * ## Security Design
 *
 * - **Internal DSNs**: Sentry project DSNs are hidden from applications (not in public API)
 * - **Per-environment salts**: Different salts for DEV/INT/PROD environments
 * - **Client-specific salts**: Salts include clientId hash for additional isolation
 * - **Type-safe**: Exhaustive enum pattern matching ensures all environments handled
 *
 * ## Environment Strategy
 *
 * - **DEV**: Error tracking enabled - shares Sentry project with INT for development visibility
 * - **INT**: Integration tracking - shares Sentry project with DEV
 * - **PROD**: Production tracking - dedicated Sentry project (isolated from DEV/INT)
 *
 * @see ch.srg.login.sdk.logging.SdkErrorReporter
 * @see ch.srg.login.sdk.logging.ErrorHandlerRegistry
 * @see <a href="https://docs.sentry.io/product/sentry-basics/dsn-explainer/">Sentry DSN Documentation</a>
 */
internal object SdkSentryConfig {
    /**
     * Get Sentry DSN for the given configuration environment.
     *
     * DEV and INT share the same Sentry project for development visibility.
     * PROD uses a dedicated Sentry project to isolate production errors.
     *
     * @param config The SDK configuration
     * @return Sentry DSN string for the given environment
     */
    fun getDsn(config: SrgLoginConfig): String =
        when (config.environment) {
            Environment.DEV -> "https://869f4ab96f28dff1a193e4b616642c2c@o166386.ingest.us.sentry.io/4510742725066752"
            Environment.INT -> "https://869f4ab96f28dff1a193e4b616642c2c@o166386.ingest.us.sentry.io/4510742725066752"
            Environment.PROD -> "https://079a66ac9dd9350031676ec04de211af@o166386.ingest.us.sentry.io/4510906212286464"
        }

    /**
     * Get environment-specific salt for user ID hashing.
     *
     * Generates a unique salt per environment and client to prevent:
     * - Cross-environment user correlation (different salt per ENV)
     * - Cross-client user correlation (includes clientId hash)
     *
     * Salt format: `sdk-{env}-salt-{year}-{clientIdHash}`
     *
     * ## Security Rationale
     *
     * 1. **Year component**: Forces salt rotation annually (automatic)
     * 2. **Client hash**: Prevents correlation between different SDK consumers
     * 3. **Environment prefix**: Clearly identifies which environment generated the hash
     *
     * ## Automatic Salt Rotation
     *
     * The year component is calculated dynamically using the current system time,
     * ensuring automatic annual salt rotation without manual updates.
     *
     * @param config The SDK configuration
     * @return Salt string for SHA-256 hashing
     */
    fun getSalt(config: SrgLoginConfig): String {
        val clientIdHash = config.clientId.hashCode().toString(16)
        val year = getCurrentYear()
        return when (config.environment) {
            Environment.DEV -> "sdk-dev-salt-$year-$clientIdHash"
            Environment.INT -> "sdk-int-salt-$year-$clientIdHash"
            Environment.PROD -> "sdk-prod-salt-$year-$clientIdHash"
        }
    }

    /**
     * Get current year for salt generation.
     *
     * Uses system's current time in UTC timezone to determine the year.
     * This ensures consistent salt rotation across all devices.
     *
     * @return Current year (e.g., 2026, 2027)
     */
    private fun getCurrentYear(): Int =
        Clock.System
            .now()
            .toLocalDateTime(TimeZone.UTC)
            .year
}
