package ch.srg.login.sdk.model

import ch.srg.login.sdk.internal.SecurityUtils
import kotlinx.datetime.Clock

/**
 * Access token with parsed JWT claims.
 *
 * This type provides a type-safe wrapper around the raw JWT token string,
 * exposing parsed claims directly for easy access without manual JWT parsing.
 *
 * [expiresIn] and [isExpired] are computed properties that reflect the **current**
 * system clock — they are NOT frozen at construction. This protects consumers from
 * the post-persistence staleness bug: a token deserialized from storage and read
 * 10 minutes later returns the correct (smaller) `expiresIn`. For TV / set-top
 * devices that may have unsynchronized clocks, prefer [isExpiredWithSkew] with a tolerance.
 *
 * @property value Raw JWT token string for API authentication (use in Authorization header).
 * @property expiresAt Unix timestamp (seconds) when token expires — source of truth.
 * @property issuer Token issuer from 'iss' claim (typically IDP URL).
 * @property subject Token subject from 'sub' claim (typically user ID).
 * @property issuedAt Unix timestamp when token was issued from 'iat' claim.
 *
 * Usage:
 * ```kotlin
 * val result = srgLogin.getAccessToken()
 * when (result) {
 *     is SdkResult.Success -> {
 *         val token = result.data
 *         // Use token in API calls
 *         api.call("Bearer ${token.value}")
 *         // Display expiration
 *         println("Expires: ${token.formatExpiresIn()}")
 *         // Access user ID
 *         println("User: ${token.subject}")
 *     }
 *     is SdkResult.Failure -> { /* handle error */ }
 * }
 * ```
 */
public data class AccessToken(
    val value: String,
    val expiresAt: Long,
    val issuer: String?,
    val subject: String?,
    val issuedAt: Long?,
) {
    /**
     * Seconds until expiration (negative if already expired).
     * Recomputed on each access from the current system clock — never stale.
     */
    val expiresIn: Long
        get() = expiresAt - Clock.System.now().epochSeconds

    /**
     * `true` if the access token is expired according to the system clock (no clock skew tolerance).
     * For TV / set-top devices with potentially unsynchronized clocks, prefer [isExpiredWithSkew] with a tolerance.
     */
    val isExpired: Boolean
        get() = Clock.System.now().epochSeconds >= expiresAt

    /**
     * Returns `true` if the access token is expired, applying [clockSkewSeconds] of tolerance.
     * Default tolerance is 30 seconds — recommended for devices that may have
     * clock drift (TV / set-top boxes).
     *
     * Named distinctly from the [isExpired] property to avoid the silent property-vs-function
     * call ambiguity (`token.isExpired` strict vs `token.isExpired()` 30s tolerance) that arises
     * when both share the same identifier.
     *
     * This extends the acceptance window **after** the nominal [expiresAt] — it accepts a token
     * as still valid for up to [clockSkewSeconds] seconds after it appears expired, to tolerate
     * a device clock that runs fast.
     *
     * For **proactive refresh** (refresh before the token expires), compare [expiresIn] directly:
     * `if (token.expiresIn < 30) refresh()`. The SDK already does this internally based on
     * `TokenRefreshConfig.refreshThresholdSeconds`; this function is for client-side checks.
     */
    public fun isExpiredWithSkew(clockSkewSeconds: Long = 30): Boolean {
        val now = Clock.System.now().epochSeconds
        return now >= expiresAt + clockSkewSeconds
    }

    /**
     * Format expiration time as human-readable string.
     *
     * Returns a formatted string indicating how long until expiration,
     * or how long ago the token expired.
     *
     * Examples:
     * - "30s" - Expires in 30 seconds
     * - "5m 30s" - Expires in 5 minutes and 30 seconds
     * - "2h 15m" - Expires in 2 hours and 15 minutes
     * - "Expired 2m ago" - Expired 2 minutes ago
     * - "Expired 1h 30m ago" - Expired 1 hour and 30 minutes ago
     *
     * @return Human-readable expiration time string
     */
    public fun formatExpiresIn(): String {
        val seconds = expiresIn
        return when {
            seconds < 0 -> {
                val absSeconds = -seconds
                when {
                    absSeconds < 60 -> {
                        "Expired ${absSeconds}s ago"
                    }

                    absSeconds < 3600 -> {
                        val m = absSeconds / 60
                        val s = absSeconds % 60
                        if (s == 0L) {
                            "Expired ${m}m ago"
                        } else {
                            "Expired ${m}m ${s}s ago"
                        }
                    }

                    else -> {
                        val h = absSeconds / 3600
                        val m = (absSeconds % 3600) / 60
                        if (m == 0L) {
                            "Expired ${h}h ago"
                        } else {
                            "Expired ${h}h ${m}m ago"
                        }
                    }
                }
            }

            seconds < 60 -> {
                "${seconds}s"
            }

            seconds < 3600 -> {
                val m = seconds / 60
                val s = seconds % 60
                if (s == 0L) "${m}m" else "${m}m ${s}s"
            }

            else -> {
                val h = seconds / 3600
                val m = (seconds % 3600) / 60
                if (m == 0L) "${h}h" else "${h}h ${m}m"
            }
        }
    }

    /**
     * Returns a redacted, debug-friendly representation. **Never** the raw JWT.
     *
     * Output format: `AccessToken(value=[TOKEN], subject=user-123, expiresAt=1735689600)`.
     * The JWT is redacted via [SecurityUtils.sanitizeToken]; non-sensitive metadata
     * ([subject], [expiresAt]) is included for debug visibility. Safe to use in `Log.d`,
     * Sentry breadcrumbs, crash reports, and screenshots.
     *
     * **Security**: patterns that previously leaked the JWT now emit only `[TOKEN]`:
     * ```kotlin
     * Log.d("auth", "Got token: $accessToken")           // metadata only — no JWT
     * Sentry.captureMessage("login state: $accessToken") // safe
     * println("DEBUG: token = $accessToken")             // safe
     * ```
     *
     * For an Authorization header (the only place the raw value is needed), call [value]
     * explicitly:
     * ```kotlin
     * api.call("Bearer ${token.value}")  // explicit, intentional, raw value
     * ```
     *
     * Going through `.value` for the raw token makes intent visible at the call site and
     * prevents future regressions if [toString] were changed. (PR #77 review #6)
     *
     * @return A redacted string representation safe for logging.
     */
    override fun toString(): String {
        val redacted = SecurityUtils.sanitizeToken(value)
        return "AccessToken(value=$redacted, subject=$subject, expiresAt=$expiresAt)"
    }

    public companion object {
        /**
         * Create AccessToken from JWT token string and parsed claims.
         *
         * INTERNAL: Used internally by the SDK to convert OAuth token responses into
         * type-safe AccessToken instances. SDK users should obtain AccessToken via
         * `srgLogin.getAccessToken()`.
         *
         * @param tokenString Raw JWT token string.
         * @param jwtClaims Parsed JWT claims from token validation.
         * @return AccessToken with [expiresAt] sourced from the JWT `exp` claim
         *   (defaults to 0L if absent — token will be reported as expired).
         */
        internal fun fromJwt(
            tokenString: String,
            jwtClaims: JwtClaims,
        ): AccessToken =
            AccessToken(
                value = tokenString,
                expiresAt = jwtClaims.exp ?: 0L,
                issuer = jwtClaims.iss,
                subject = jwtClaims.sub,
                issuedAt = jwtClaims.iat,
            )
    }
}
