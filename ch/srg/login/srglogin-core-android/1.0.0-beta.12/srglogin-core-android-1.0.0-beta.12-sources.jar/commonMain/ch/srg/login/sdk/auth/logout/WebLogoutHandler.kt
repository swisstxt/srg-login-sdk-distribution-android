package ch.srg.login.sdk.auth.logout

import ch.srg.login.sdk.SrgLoginConfig
import ch.srg.login.sdk.auth.BackChannelLogoutListener
import ch.srg.login.sdk.auth.JwtValidationService
import ch.srg.login.sdk.auth.PersistentReplayCache
import ch.srg.login.sdk.auth.WebAuthenticator
import ch.srg.login.sdk.data.OpenIdConfigRepository
import ch.srg.login.sdk.data.api.SrgAuthApiService
import ch.srg.login.sdk.events.EventEmitter
import ch.srg.login.sdk.token.TokenStorage
import kotlinx.datetime.Clock
import kotlin.concurrent.Volatile

/**
 * Full-capability logout handler for platforms with a browser (iOS, Android).
 * Supports Local + BackChannel + FrontChannel logout.
 */
@Suppress("LongParameterList")
internal class WebLogoutHandler(
    override val tokenStorage: TokenStorage,
    eventEmitter: EventEmitter,
    override val config: SrgLoginConfig,
    override val openIdConfigRepository: OpenIdConfigRepository,
    override val jwtValidationService: JwtValidationService,
    override val authApiService: SrgAuthApiService,
    override val webAuthenticator: WebAuthenticator,
    override val replayCache: PersistentReplayCache = PersistentReplayCache(tokenStorage, maxAgeSeconds = 3600L),
    clock: Clock = Clock.System,
) : LogoutHandler(tokenStorage, eventEmitter, clock),
    BackChannelLogoutCapable,
    FrontChannelLogoutCapable {
    @Volatile
    private var _backChannelListeners: List<BackChannelLogoutListener> = emptyList()

    override val backChannelListeners: List<BackChannelLogoutListener>
        get() = _backChannelListeners

    /** Idempotent copy-on-write add — no-op if [listener] is already registered. */
    override fun registerBackChannelLogoutListener(listener: BackChannelLogoutListener) {
        if (listener !in _backChannelListeners) {
            _backChannelListeners = _backChannelListeners + listener
        }
    }

    /** Removes [listener] from the back-channel logout listener list (copy-on-write). */
    override fun unregisterBackChannelLogoutListener(listener: BackChannelLogoutListener) {
        _backChannelListeners = _backChannelListeners - listener
    }
}
