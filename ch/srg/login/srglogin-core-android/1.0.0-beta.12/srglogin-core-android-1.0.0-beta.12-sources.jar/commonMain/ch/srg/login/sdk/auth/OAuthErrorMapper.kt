package ch.srg.login.sdk.auth

import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.model.OAuthErrorResponse
import io.ktor.client.plugins.ClientRequestException
import io.ktor.client.plugins.ServerResponseException
import io.ktor.client.statement.bodyAsText
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json

/**
 * Maps HTTP exceptions from OAuth token endpoints to typed [SrgLoginError] instances.
 *
 * This mapper provides robust error classification for OAuth 2.0 token operations:
 * - Extracts structured OAuth error responses (error, error_description, error_uri)
 * - Handles invalid_grant errors (refresh token expired/revoked)
 * - Classifies HTTP errors (4xx client errors, 5xx server errors)
 * - Provides fallback error handling for malformed responses
 *
 * **OAuth Error Handling**:
 * - `invalid_grant` → [SrgLoginError.InvalidGrant] (terminal, requires re-authentication)
 * - Other OAuth errors → [SrgLoginError.HttpError] with OAuth details
 * - Malformed OAuth responses → [SrgLoginError.HttpError] with status info
 *
 * @see <a href="https://datatracker.ietf.org/doc/html/rfc6749#section-5.2">RFC 6749 Section 5.2</a>
 */
internal object OAuthErrorMapper {
    private val json =
        Json {
            ignoreUnknownKeys = true
            isLenient = true
        }

    /**
     * Maps a Ktor [ClientRequestException] (4xx) to an appropriate [SrgLoginError].
     *
     * Attempts to parse OAuth error response from the response body.
     * If the response contains a structured OAuth error, it extracts the error details.
     *
     * **Error Classification**:
     * - `invalid_grant` → [SrgLoginError.InvalidGrant] (terminal)
     * - Other OAuth errors → [SrgLoginError.HttpError] with error details
     * - Unparseable responses → [SrgLoginError.HttpError] with status code
     *
     * @param exception The client request exception (4xx error)
     * @return Classified [SrgLoginError]
     */
    suspend fun mapClientRequestException(exception: ClientRequestException): SrgLoginError {
        // Try to parse OAuth error response from body
        val oauthError = tryParseOAuthError(exception)

        return if (oauthError != null) {
            // Check for invalid_grant (terminal error requiring re-authentication)
            if (oauthError.error == "invalid_grant") {
                SrgLoginError.InvalidGrant(
                    errorDescription = oauthError.errorDescription,
                    errorCode = oauthError.error,
                )
            } else {
                // Other OAuth errors (invalid_request, invalid_client, etc.)
                SrgLoginError.HttpError(
                    code = exception.response.status.value,
                    message = "${oauthError.error}: ${oauthError.errorDescription ?: exception.response.status.description}",
                    url =
                        exception.response.call.request.url
                            .toString(),
                )
            }
        } else {
            // Fallback: couldn't parse OAuth error, use HTTP status
            SrgLoginError.HttpError(
                code = exception.response.status.value,
                message = exception.response.status.description,
                url =
                    exception.response.call.request.url
                        .toString(),
            )
        }
    }

    /**
     * Maps a Ktor [ServerResponseException] (5xx) to [SrgLoginError.HttpError].
     *
     * Server errors are typically retryable, so they're classified as HTTP errors
     * rather than terminal OAuth errors.
     *
     * @param exception The server response exception (5xx error)
     * @return [SrgLoginError.HttpError] with status details
     */
    fun mapServerResponseException(exception: ServerResponseException): SrgLoginError =
        SrgLoginError.HttpError(
            code = exception.response.status.value,
            message = exception.response.status.description,
            url =
                exception.response.call.request.url
                    .toString(),
        )

    /**
     * Attempts to parse an OAuth error response from an HTTP exception.
     *
     * Tries to extract structured OAuth error (error, error_description, error_uri)
     * from the response body. Returns null if parsing fails or body is not JSON.
     *
     * @param exception The HTTP client exception
     * @return Parsed [OAuthErrorResponse] or null if parsing failed
     */
    private suspend fun tryParseOAuthError(exception: ClientRequestException): OAuthErrorResponse? =
        try {
            // Try to get the response body as text first
            val bodyText = exception.response.bodyAsText()

            // Check if it looks like JSON (simple heuristic)
            if (bodyText.trim().startsWith("{")) {
                json.decodeFromString<OAuthErrorResponse>(bodyText)
            } else {
                null
            }
        } catch (e: SerializationException) {
            // Not a valid OAuth error response, return null
            null
        } catch (e: Exception) {
            // Any other error reading/parsing body, return null
            null
        }
}
