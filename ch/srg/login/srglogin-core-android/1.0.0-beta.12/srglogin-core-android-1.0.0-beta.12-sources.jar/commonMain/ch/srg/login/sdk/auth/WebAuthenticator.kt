package ch.srg.login.sdk.auth

import ch.srg.login.sdk.result.SdkResult

/**
 * Defines the contract for a platform-specific authenticator that handles the browser flow.
 */
interface WebAuthenticator {
    /**
     * Launches a web browser for the given URL and suspends until the flow
     * completes with a callback URL or fails.
     *
     * @param authUrl The full URL to open in the browser.
     * @param authContext The platform-specific authentication context.
     * @return A [SdkResult] containing the full callback URL on success, or an error on failure.
     */
    suspend fun authenticate(
        authUrl: String,
        authContext: PlatformAuthContext,
    ): SdkResult<String>

    /**
     * Launches a web browser for logout and suspends until the user completes or cancels the logout.
     * Returns success when user successfully completes logout and returns to the app,
     * or failure if user cancels, times out, or an error occurs.
     *
     * @param logoutUrl The logout endpoint URL to open in the browser.
     * @param authContext The platform-specific authentication context.
     * @return A [SdkResult] indicating success or failure of the complete logout flow.
     */
    suspend fun logout(
        logoutUrl: String,
        authContext: PlatformAuthContext,
    ): SdkResult<Unit>

    /**
     * Opens another SSO client URL in platform-specific browser and suspends until the user returns.
     * Leverages the current authenticated session cookies for seamless SSO experience.
     *
     * Perfect for displaying profile pages, settings, admin panels, or any other SSO client
     * that shares the same authentication system.
     *
     * @param ssoClientUrl URL of the SSO client to display
     * @param authContext The platform-specific authentication context
     * @return A [SdkResult] indicating success or failure of the complete SSO client navigation
     */
    suspend fun openSsoClient(
        ssoClientUrl: String,
        authContext: PlatformAuthContext,
    ): SdkResult<Unit>
}
