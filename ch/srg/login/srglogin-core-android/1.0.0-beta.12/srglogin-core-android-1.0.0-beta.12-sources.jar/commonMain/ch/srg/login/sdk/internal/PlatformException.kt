package ch.srg.login.sdk.internal

import ch.srg.login.sdk.errors.SrgLoginError

/**
 * Expects a platform-specific implementation for mapping platform-dependent
 * exceptions to a common [SrgLoginError] type.
 *
 * @return A [SrgLoginError] if the exception is recognized and mapped,
 * or `null` if it's a generic exception to be handled by common code.
 */
internal expect fun mapPlatformException(e: Exception): SrgLoginError?
