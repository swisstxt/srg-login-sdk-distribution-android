package ch.srg.login.sdk.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Internal DTO for OAuth 2.0 token endpoint responses.
 *
 * This is used for JSON serialization/deserialization only.
 * Public API uses [TokenSet] and [AccessToken] instead.
 *
 * INTERNAL: This type is not part of the public SDK API.
 * It's used internally to handle OAuth 2.0 protocol communication.
 *
 * @see TokenSet
 * @see AccessToken
 */
@Serializable
internal data class TokenResponseDto(
    @SerialName("access_token")
    val accessToken: String,
    @SerialName("refresh_token")
    val refreshToken: String? = null,
    @SerialName("id_token")
    val idToken: String? = null,
    @SerialName("token_type")
    val tokenType: String = "Bearer",
    @SerialName("expires_in")
    val expiresIn: Long,
    @SerialName("scope")
    val scope: String? = null,
)
