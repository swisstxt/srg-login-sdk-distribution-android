package ch.srg.login.sdk.auth.flows

import ch.srg.login.sdk.SrgLoginConfig
import ch.srg.login.sdk.auth.DeviceCodeCapable
import ch.srg.login.sdk.auth.LoginMethod
import ch.srg.login.sdk.auth.LoginState
import ch.srg.login.sdk.auth.PlatformAuthContext
import ch.srg.login.sdk.auth.handler.LoginFailureEmitter
import ch.srg.login.sdk.auth.handler.TokenSuccessHandler
import ch.srg.login.sdk.data.OpenIdConfigRepository
import ch.srg.login.sdk.data.api.SrgAuthApiService
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.events.EventEmitter
import ch.srg.login.sdk.events.SdkLifecycleEvent
import ch.srg.login.sdk.logging.ErrorHandler
import ch.srg.login.sdk.logging.ErrorHandlerRegistry
import ch.srg.login.sdk.logging.LogCategory
import ch.srg.login.sdk.logging.SdkLogger
import ch.srg.login.sdk.model.DeviceAuthorizationResponse
import ch.srg.login.sdk.model.OpenIdConfig
import ch.srg.login.sdk.result.SdkResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.datetime.Clock

/**
 * Login flow for the OAuth 2.0 Device Authorization Grant (RFC 8628).
 *
 * Validates [LoginMethod.Device] + [DeviceCodeCapable] context, requests device
 * authorization, emits [LoginState.AwaitingDeviceActivation], polls the token endpoint
 * until success or terminal error, and delegates token handling to [TokenSuccessHandler].
 *
 * @see <a href="https://www.rfc-editor.org/rfc/rfc8628">RFC 8628</a>
 */
@Suppress("LongParameterList")
internal class DeviceAuthorizationFlow(
    private val config: SrgLoginConfig,
    private val openIdConfigRepository: OpenIdConfigRepository,
    private val authApiService: SrgAuthApiService,
    private val tokenSuccessHandler: TokenSuccessHandler,
    private val loginFailureEmitter: LoginFailureEmitter,
    private val eventEmitter: EventEmitter,
    private val clock: Clock = Clock.System,
) : LoginFlow {
    companion object {
        internal const val RFC_ERROR_AUTHORIZATION_PENDING = "authorization_pending"
        internal const val RFC_ERROR_SLOW_DOWN = "slow_down"
        private const val SLOW_DOWN_INTERVAL_INCREMENT_SECONDS = 5L
        private const val MILLIS_PER_SECOND = 1000L
        private const val MIN_POLL_INTERVAL_SECONDS = 5L
        private const val DEADLINE_MARGIN_SECONDS = 5L
        private const val MAX_TRANSIENT_RETRIES = 3
    }

    private data class DeviceFlowSetup(
        val openIdConfig: OpenIdConfig,
        val deviceAuth: DeviceAuthorizationResponse,
    )

    /**
     * Executes the Device Authorization Grant flow (RFC 8628): validates prerequisites,
     * requests device authorization, emits [LoginState.AwaitingDeviceActivation] with the
     * user code, then polls until a token is issued or a terminal error occurs.
     *
     * @param loginMethod Must be [LoginMethod.Device]; any other type returns [LoginState.Failure].
     * @param authContext Must be [DeviceCodeCapable]; mobile contexts are rejected.
     */
    override fun login(
        loginMethod: LoginMethod,
        authContext: PlatformAuthContext,
        additionalScopes: List<String>,
        additionalParameters: Map<String, String>,
    ): Flow<LoginState> =
        flow {
            val loginStartedTimestamp = clock.now().toEpochMilliseconds()
            eventEmitter.tryEmit(SdkLifecycleEvent.LoginStarted(loginStartedTimestamp))

            when (val setup = prepareDeviceFlow(loginMethod, authContext, additionalScopes, additionalParameters)) {
                is SdkResult.Failure -> {
                    emit(loginFailureEmitter.emit(setup.error))
                }

                is SdkResult.Success -> {
                    val (openIdConfig, deviceAuth) = setup.data
                    emit(
                        LoginState.AwaitingDeviceActivation(
                            userCode = deviceAuth.userCode,
                            verificationUri = deviceAuth.verificationUri,
                            verificationUriComplete = deviceAuth.verificationUriComplete,
                            expiresIn = deviceAuth.expiresIn,
                        ),
                    )
                    emitAll(pollForToken(openIdConfig, deviceAuth))
                }
            }
        }.catch { e ->
            if (e is CancellationException) throw e
            val exception = e as? Exception ?: throw e
            val error = openIdConfigRepository.mapExceptionToError(exception)
            ErrorHandlerRegistry.captureException(
                throwable = exception,
                context =
                    mapOf(
                        "operation" to "device_login_flow",
                        "stage" to "unhandled_exception",
                        "error_type" to e::class.simpleName,
                        "error_mapped_to" to error::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.ERROR,
            )
            emit(loginFailureEmitter.emit(error))
        }

    /**
     * Validates prerequisites then fetches OIDC config and requests device authorization in sequence.
     * Returns [SdkResult.Failure] at the first failing step so the caller emits a single error.
     */
    private suspend fun prepareDeviceFlow(
        loginMethod: LoginMethod,
        authContext: PlatformAuthContext,
        additionalScopes: List<String>,
        additionalParameters: Map<String, String>,
    ): SdkResult<DeviceFlowSetup> {
        val validationError = validateForDeviceFlow(loginMethod, authContext)
        if (validationError != null) {
            ErrorHandlerRegistry.captureException(
                throwable = Exception(validationError.toString()),
                context =
                    mapOf(
                        "operation" to "validate_device_flow_prerequisites",
                        "stage" to "device_login_init",
                        "login_method_type" to loginMethod::class.simpleName,
                        "auth_context_type" to authContext::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.WARNING,
            )
            return SdkResult.Failure(validationError)
        }
        return fetchAndBuildSetup(additionalScopes, additionalParameters)
    }

    /**
     * Validates that [loginMethod] is [LoginMethod.Device] and [authContext] is [DeviceCodeCapable].
     * Returns a descriptive [SrgLoginError.InvalidConfiguration] on mismatch, `null` on success.
     */
    private fun validateForDeviceFlow(
        loginMethod: LoginMethod,
        authContext: PlatformAuthContext,
    ): SrgLoginError? =
        when {
            loginMethod !is LoginMethod.Device -> {
                SrgLoginError.InvalidConfiguration(
                    "DeviceAuthorizationFlow only supports the Device login method.",
                )
            }

            authContext !is DeviceCodeCapable -> {
                SrgLoginError.InvalidConfiguration(
                    "Device flow requires a DeviceCodeCapable context. " +
                        "Mobile platforms should use LoginMethod.Web instead.",
                )
            }

            else -> {
                null
            }
        }

    /**
     * Fetches the OIDC discovery document, verifies that `device_authorization_endpoint` is present,
     * then POSTs to it. Returns [SdkResult.Failure] if discovery fails or the endpoint is absent.
     */
    private suspend fun fetchAndBuildSetup(
        additionalScopes: List<String>,
        additionalParameters: Map<String, String>,
    ): SdkResult<DeviceFlowSetup> {
        val openIdConfig =
            when (val result = openIdConfigRepository.getConfiguration()) {
                is SdkResult.Success -> {
                    result.data
                }

                is SdkResult.Failure -> {
                    val throwable =
                        when (val error = result.error) {
                            is SrgLoginError.NetworkError -> error.cause ?: Exception(error.details ?: "Network error")
                            is SrgLoginError.HttpError -> Exception("HTTP ${error.code}: ${error.message}")
                            else -> Exception(error.toString())
                        }
                    ErrorHandlerRegistry.captureException(
                        throwable = throwable,
                        context =
                            mapOf(
                                "operation" to "fetch_openid_config",
                                "stage" to "device_login_init",
                                "error_type" to result.error::class.simpleName,
                            ),
                        level = ErrorHandler.ErrorLevel.ERROR,
                    )
                    return result
                }
            }

        val endpoint = openIdConfig.deviceAuthorizationEndpoint
        val scopes = (listOf("openid") + additionalScopes).distinct().joinToString(" ")
        return if (endpoint == null) {
            val configError =
                SrgLoginError.InvalidConfiguration(
                    "The IDP does not expose a device_authorization_endpoint in its " +
                        "OpenID Connect discovery document. Device flow is not supported by this IDP.",
                )
            ErrorHandlerRegistry.captureException(
                throwable = Exception(configError.toString()),
                context =
                    mapOf(
                        "operation" to "check_device_authorization_endpoint",
                        "stage" to "device_login_init",
                        "error_type" to "missing_endpoint",
                    ),
                level = ErrorHandler.ErrorLevel.ERROR,
            )
            SdkResult.Failure(configError)
        } else {
            requestDeviceAuthorization(openIdConfig, endpoint, scopes, additionalParameters)
        }
    }

    /**
     * POSTs to the device authorization endpoint (RFC 8628 §3.1) with the client ID, [scopes],
     * and [additionalParameters]. Wraps the response in a [DeviceFlowSetup].
     */
    private suspend fun requestDeviceAuthorization(
        openIdConfig: OpenIdConfig,
        endpoint: String,
        scopes: String,
        additionalParameters: Map<String, String>,
    ): SdkResult<DeviceFlowSetup> =
        when (
            val result =
                authApiService.requestDeviceAuthorization(
                    endpoint,
                    config.clientId,
                    scopes,
                    additionalParameters,
                )
        ) {
            is SdkResult.Success -> {
                SdkLogger.d(LogCategory.AUTHENTICATION) {
                    "Device flow started: userCode=${result.data.userCode}, " +
                        "verificationUri=${result.data.verificationUri}, " +
                        "expiresIn=${result.data.expiresIn}s, interval=${result.data.interval}s"
                }
                SdkResult.Success(DeviceFlowSetup(openIdConfig, result.data))
            }

            is SdkResult.Failure -> {
                result
            }
        }

    /**
     * RFC 8628 §3.3-3.5 polling loop: waits [pollIntervalSeconds] between token requests,
     * handles `authorization_pending` (continue), `slow_down` (+5s interval), transient network
     * errors (up to [MAX_TRANSIENT_RETRIES] retries), and client-side deadline enforcement.
     */
    private fun pollForToken(
        openIdConfig: OpenIdConfig,
        deviceAuth: DeviceAuthorizationResponse,
    ): Flow<LoginState> =
        flow {
            var pollIntervalSeconds = maxOf(deviceAuth.interval, MIN_POLL_INTERVAL_SECONDS)
            var keepPolling = true
            var transientRetryCount = 0
            val deadlineMillis =
                clock.now().toEpochMilliseconds() +
                    (deviceAuth.expiresIn + DEADLINE_MARGIN_SECONDS) * MILLIS_PER_SECOND

            while (keepPolling) {
                if (clock.now().toEpochMilliseconds() >= deadlineMillis) {
                    SdkLogger.d(LogCategory.AUTHENTICATION) {
                        "Device flow: client-side deadline reached, aborting poll"
                    }
                    emit(loginFailureEmitter.emit(SrgLoginError.TokenExpired))
                    break
                }

                delay(pollIntervalSeconds * MILLIS_PER_SECOND)

                val tokenResult =
                    authApiService.exchangeDeviceCodeForToken(
                        tokenEndpoint = openIdConfig.tokenEndpoint,
                        deviceCode = deviceAuth.deviceCode,
                        clientId = config.clientId,
                    )

                when (tokenResult) {
                    is SdkResult.Success -> {
                        val result =
                            tokenSuccessHandler.handle(
                                tokenResponse = tokenResult.data,
                                clientId = config.clientId,
                                issuer = openIdConfig.issuer,
                                jwksUri = openIdConfig.jwksUri,
                            )
                        emit(result)
                        keepPolling = false
                    }

                    is SdkResult.Failure -> {
                        val (newInterval, terminalFailure, newRetryCount) =
                            resolvePollingError(tokenResult.error, pollIntervalSeconds, transientRetryCount)
                        pollIntervalSeconds = newInterval
                        transientRetryCount = newRetryCount
                        keepPolling = terminalFailure == null
                        if (terminalFailure != null) emit(terminalFailure)
                    }
                }
            }
        }

    /**
     * Maps an RFC 8628 polling error to the next polling state:
     * - Network error → retry if under [MAX_TRANSIENT_RETRIES], else terminal.
     * - `authorization_pending` → continue at current interval.
     * - `slow_down` → continue at interval + 5s (RFC 8628 §3.5).
     * - Any other error → terminal failure.
     *
     * @return Triple of (newInterval, terminalFailure or null, newTransientRetryCount).
     */
    private fun resolvePollingError(
        error: SrgLoginError,
        currentInterval: Long,
        transientRetryCount: Int,
    ): Triple<Long, LoginState.Failure?, Int> =
        when {
            error is SrgLoginError.NetworkError -> {
                if (transientRetryCount < MAX_TRANSIENT_RETRIES) {
                    SdkLogger.d(LogCategory.AUTHENTICATION) {
                        "Device flow: transient network error, retry ${transientRetryCount + 1}/$MAX_TRANSIENT_RETRIES"
                    }
                    Triple(currentInterval, null, transientRetryCount + 1)
                } else {
                    SdkLogger.d(LogCategory.AUTHENTICATION) {
                        "Device flow: network error retries exhausted, aborting"
                    }
                    Triple(currentInterval, loginFailureEmitter.emit(error), transientRetryCount)
                }
            }

            error !is SrgLoginError.InvalidDataError -> {
                Triple(currentInterval, loginFailureEmitter.emit(error), 0)
            }

            else -> {
                when (error.reason) {
                    RFC_ERROR_AUTHORIZATION_PENDING -> {
                        SdkLogger.d(LogCategory.AUTHENTICATION) {
                            "Device flow: authorization_pending, polling in ${currentInterval}s"
                        }
                        Triple(currentInterval, null, 0)
                    }

                    RFC_ERROR_SLOW_DOWN -> {
                        val newInterval = currentInterval + SLOW_DOWN_INTERVAL_INCREMENT_SECONDS
                        SdkLogger.d(LogCategory.AUTHENTICATION) {
                            "Device flow: slow_down, new interval=${newInterval}s"
                        }
                        Triple(newInterval, null, 0)
                    }

                    else -> {
                        Triple(currentInterval, loginFailureEmitter.emit(error), 0)
                    }
                }
            }
        }
}
