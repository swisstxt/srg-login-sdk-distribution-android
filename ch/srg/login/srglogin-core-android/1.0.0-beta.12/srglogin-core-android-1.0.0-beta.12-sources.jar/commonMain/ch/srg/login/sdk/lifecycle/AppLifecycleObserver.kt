package ch.srg.login.sdk.lifecycle

import ch.srg.login.sdk.auth.PlatformAuthContext
import ch.srg.login.sdk.auth.TokenManager
import ch.srg.login.sdk.events.EventEmitter

/**
 * Application lifecycle observer for automatic SDK resource management.
 *
 * This observer automatically integrates with platform-specific lifecycle mechanisms
 * to clean up SDK resources when the application terminates or goes to background:
 *
 * - **Android**: ProcessLifecycleOwner (app lifecycle observation)
 * - **iOS**: NSNotificationCenter (app termination/background notifications) - Phase 2.8.3
 * - **JVM**: Runtime.addShutdownHook (JVM shutdown) - Phase 2.8.3
 * - **JS**: window.addEventListener ("beforeunload") - Phase 2.8.3
 *
 * **Automatic Actions**:
 * - **onStop/onBackground**: Stops token monitoring to save battery
 * - **onDestroy/onTerminate**: Disposes all SDK resources
 *
 * **Developer Experience**:
 * The lifecycle observer is automatically registered when the SDK is initialized.
 * Developers don't need to manually call `dispose()` in most cases.
 *
 * **Manual Cleanup**:
 * The `dispose()` method remains available in the public SDK API for:
 * - Platforms without automatic lifecycle integration (Phase 2.8.3 pending)
 * - Test environments where lifecycle observers may not be available
 * - Edge cases requiring explicit cleanup
 *
 * @property platformContext Platform-specific authentication context (contains platform components)
 * @property tokenManager TokenManager instance to observe and clean up
 * @property eventEmitter Event emitter for SDK lifecycle events (app lifecycle, token state)
 */
internal expect class AppLifecycleObserver(
    platformContext: PlatformAuthContext,
    tokenManager: TokenManager,
    eventEmitter: EventEmitter,
) {
    /**
     * Cleanup lifecycle observer.
     *
     * Unregisters the observer from platform-specific lifecycle mechanisms.
     * Safe to call multiple times (idempotent).
     *
     * **Note**: Usually called automatically via platform lifecycle events.
     * Manual call is rarely needed except in tests or special cleanup scenarios.
     */
    fun cleanup()
}
