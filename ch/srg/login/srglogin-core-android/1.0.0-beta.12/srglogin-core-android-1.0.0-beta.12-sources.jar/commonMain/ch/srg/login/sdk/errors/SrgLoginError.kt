package ch.srg.login.sdk.errors

/**
 * A sealed class representing all the possible, well-defined errors the SDK can produce.
 */
sealed class SrgLoginError {
    /**
     * A problem with the initial SDK configuration provided by the app.
     * @property reason A developer-friendly message explaining what is wrong.
     * @property details Additional context for debugging.
     */
    data class InvalidConfiguration(
        val reason: String,
        val details: String? = null,
    ) : SrgLoginError()

    /**
     * A network connectivity problem (e.g., no internet, DNS failure, host unreachable).
     * @property details Additional context about the network failure.
     * @property cause The underlying exception that caused this error.
     */
    data class NetworkError(
        val details: String? = null,
        val cause: Throwable? = null,
    ) : SrgLoginError()

    /**
     * An error reported by the server (e.g., 404 Not Found, 500 Internal Server Error).
     * @property code The HTTP status code.
     * @property message Optional server error message.
     * @property url The URL that was requested when the error occurred.
     */
    data class HttpError(
        val code: Int,
        val message: String? = null,
        val url: String? = null,
    ) : SrgLoginError()

    /**
     * The server's response was not in the expected JSON format and could not be parsed.
     * @property originalMessage The original exception message from the parser.
     * @property responseBody The response body that failed to parse (truncated for security).
     */
    data class SerializationError(
        val originalMessage: String?,
        val responseBody: String? = null,
    ) : SrgLoginError()

    /**
     * The server's response was valid JSON, but contained invalid or missing data.
     * @property reason A message explaining what was invalid about the data.
     */

    data class InvalidDataError(
        val reason: String,
    ) : SrgLoginError()

    /**
     * The operation failed because the refresh token is expired and the user must log in again.
     */
    data object TokenExpired : SrgLoginError()

    /**
     * The operation failed because the user is not authenticated — there is no
     * token at all in storage.
     *
     * This error is returned when:
     * - No tokens are stored in TokenStorage (user never logged in)
     * - Tokens were cleared by logout
     * - Tokens were cleared after a terminal refresh failure (e.g. `invalid_grant`)
     *
     * **Note**: An expired access token is **not** a `NotAuthenticated` condition —
     * `getAccessToken()` automatically refreshes expired tokens in both
     * `TokenRefreshMode.Automatic` and `TokenRefreshMode.Manual`. `NotAuthenticated`
     * is only returned when the SDK has nothing to refresh from.
     *
     * **Action Required**: Redirect user to login screen to authenticate.
     */
    data object NotAuthenticated : SrgLoginError()

    /**
     * OAuth 2.0 invalid_grant error - refresh token is invalid, expired, or revoked.
     *
     * This is a **terminal error** that requires re-authentication:
     * - All tokens must be cleared from storage
     * - User must be logged out
     * - User must log in again with username/password
     *
     * **Common causes**:
     * - Refresh token expired (exceeded maximum lifetime)
     * - Refresh token revoked by user or admin
     * - Token rotation detection (token already used)
     * - Refresh token not found on server
     *
     * **Action Required**: Logout user and require fresh authentication.
     *
     * @property errorDescription OAuth error_description from server
     * @property errorCode OAuth error code (typically "invalid_grant")
     */
    data class InvalidGrant(
        val errorDescription: String? = null,
        val errorCode: String = "invalid_grant",
    ) : SrgLoginError()

    /**
     * Failed to save tokens to storage after successful refresh.
     *
     * This is a critical error because the refresh succeeded server-side
     * but the app cannot persist the new tokens. The user may need to
     * re-authenticate to recover.
     *
     * @property message Description of the storage failure
     * @property cause The underlying exception that caused the failure
     */
    data class TokenStorageError(
        val message: String,
        val cause: Throwable? = null,
    ) : SrgLoginError()

    /**
     * User cancelled the authentication flow.
     */
    data class UserCancelled(
        val reason: String = "Authentication was cancelled by user",
    ) : SrgLoginError()

    /**
     * Authentication operation timed out waiting for user action.
     * @property message Description of the timeout
     */
    data class AuthenticationTimeout(
        val message: String,
    ) : SrgLoginError()

    /**
     * Platform does not support the requested authentication method.
     * @property message Description of the platform limitation.
     */
    data class UnsupportedPlatform(
        val message: String,
    ) : SrgLoginError()

    /**
     * Platform-specific error occurred during authentication.
     * @property message Description of the platform error.
     * @property cause The underlying platform exception.
     * @property platform The platform where the error occurred.
     */
    data class PlatformError(
        val message: String,
        val cause: Throwable? = null,
        val platform: String,
    ) : SrgLoginError()

    /**
     * JWT validation failed during logout token verification.
     * This indicates a potential security issue or malformed logout request.
     *
     * @property message Description of the validation failure
     * @property reason Specific reason for the validation failure
     */
    data class InvalidLogoutToken(
        val message: String,
        val reason: LogoutTokenError? = null,
    ) : SrgLoginError()

    /**
     * A catch-all for any other unexpected errors.
     * @property cause The original, underlying exception.
     * @property context Additional context about where the error occurred.
     */
    data class UnknownError(
        val cause: Throwable,
        val context: String? = null,
    ) : SrgLoginError()
}

/**
 * Specific reasons why a logout token validation failed.
 * Used for security monitoring and debugging.
 */
enum class LogoutTokenError {
    /** JWT signature verification failed - token may be forged */
    INVALID_SIGNATURE,

    /** Token issuer doesn't match expected authorization server */
    INVALID_ISSUER,

    /** Token audience doesn't match this client */
    INVALID_AUDIENCE,

    /** Token doesn't contain required back-channel logout event */
    INVALID_EVENT_TYPE,

    /** Token is too old based on 'iat' claim */
    TOKEN_EXPIRED,

    /** Token has already been used (replay attack) */
    REPLAY_ATTACK,

    /** Token doesn't match current user session */
    WRONG_SESSION,

    /** JWT format is invalid or malformed */
    MALFORMED_JWT,

    /** Required claims are missing */
    MISSING_REQUIRED_CLAIMS,

    /** Unable to retrieve public keys for validation */
    JWKS_UNAVAILABLE,
}
