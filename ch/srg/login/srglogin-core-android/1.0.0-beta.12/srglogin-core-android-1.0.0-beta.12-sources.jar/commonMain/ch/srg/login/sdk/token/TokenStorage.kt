package ch.srg.login.sdk.token

import ch.srg.login.sdk.model.RefreshTokenMetadata
import ch.srg.login.sdk.model.TokenResponseDto

/**
 * Defines the contract for a secure, platform-specific token storage mechanism.
 *
 * INTERNAL: This interface is not part of the public SDK API.
 */
internal interface TokenStorage {
    /**
     * Securely saves the token response.
     * This method should handle both initial saving and subsequent updates (e.g., after a token refresh).
     *
     * @param tokens The token response object to save.
     * @return A [Result] indicating success or failure.
     */
    suspend fun saveTokens(tokens: TokenResponseDto): Result<Unit>

    /**
     * Retrieves the saved token response.
     *
     * @return The saved [TokenResponseDto], or `null` if none is found.
     */
    suspend fun getTokens(): TokenResponseDto?

    /**
     * Deletes all saved tokens.
     *
     * @return A [Result] indicating success or failure.
     */
    suspend fun clearTokens(): Result<Unit>

    /**
     * Securely saves used JWT IDs with their timestamps for replay attack protection.
     * These IDs persist across app restarts to maintain security.
     *
     * @param usedIds Map of JWT ID to timestamp when it was first used
     * @return A [Result] indicating success or failure.
     */
    suspend fun saveJwtIds(usedIds: Map<String, Long>): Result<Unit>

    /**
     * Retrieves the map of used JWT IDs and their timestamps.
     *
     * @return Map of JWT ID to timestamp, or `null` if none saved.
     */
    suspend fun getJwtIds(): Map<String, Long>?

    /**
     * Clears all stored JWT IDs. Use with caution as this removes replay protection.
     *
     * @return A [Result] indicating success or failure.
     */
    suspend fun clearJwtIds(): Result<Unit>

    /**
     * Securely saves refresh token metadata for security monitoring.
     *
     * This metadata enables:
     * - Token rotation detection (via hash comparison)
     * - Usage anomaly detection (excessive refresh attempts)
     * - Token age tracking (maximum lifetime enforcement)
     * - Privacy-first security (no device tracking)
     *
     * **Privacy Note**:
     * Metadata contains only token-specific information (timestamps, use count, hash).
     * No personal data or device identifiers are stored.
     *
     * @param metadata The refresh token metadata to save
     * @return A [Result] indicating success or failure
     */
    suspend fun saveRefreshTokenMetadata(metadata: RefreshTokenMetadata): Result<Unit>

    /**
     * Retrieves the saved refresh token metadata.
     *
     * Returns null if:
     * - No metadata has been saved yet (first login)
     * - Metadata was cleared (logout)
     * - Storage was corrupted or reset
     *
     * @return The saved [RefreshTokenMetadata], or null if none is found
     */
    suspend fun getRefreshTokenMetadata(): RefreshTokenMetadata?

    /**
     * Clears all stored refresh token metadata.
     *
     * Should be called during:
     * - User logout (local or remote)
     * - Token revocation
     * - Security-related cleanup
     *
     * @return A [Result] indicating success or failure
     */
    suspend fun clearRefreshTokenMetadata(): Result<Unit>
}
