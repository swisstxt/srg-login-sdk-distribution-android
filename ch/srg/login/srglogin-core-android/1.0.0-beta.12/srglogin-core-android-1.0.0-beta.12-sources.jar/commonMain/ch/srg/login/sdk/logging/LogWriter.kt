package ch.srg.login.sdk.logging

/**
 * Interface for custom log writers that process LogEntry objects.
 *
 * Implement this interface to add custom logging behavior such as:
 * - File logging (save logs to disk)
 * - Debug UI (display logs in-app console)
 * - Metrics collection (count logs by category/severity)
 * - APM tracing (distributed tracing integration)
 *
 * ## Usage
 *
 * ```kotlin
 * class FileLogWriter : LogWriter {
 *     override fun write(entry: LogEntry) {
 *         val file = File(logDirectory, "sdk_${entry.timestamp}.log")
 *         file.appendText("[${entry.severity}] ${entry.message}\n")
 *     }
 * }
 *
 * // Register writer (development only)
 * if (BuildConfig.DEBUG) {
 *     SdkLogger.addCustomWriter(FileLogWriter())
 * }
 * ```
 *
 * ## Important Notes
 *
 * - **Thread Safety**: Your implementation should be thread-safe as `write()`
 *   can be called from any thread.
 *
 * - **Performance**: Keep `write()` fast to avoid blocking log calls. Consider
 *   buffering and async I/O for file/network operations.
 *
 * - **Error Handling**: Don't throw exceptions from `write()`. Catch and handle
 *   errors internally to avoid breaking the logging system.
 *
 * - **Not for Sentry**: Do NOT use this for error tracking services like Sentry
 *   or Crashlytics. Use ErrorHandler instead (dedicated API for errors only).
 *
 * ## When to Use
 *
 * Use LogWriter for:
 * - ✅ File logging (debug/development)
 * - ✅ Debug UI (in-app console)
 * - ✅ Metrics collection (count logs)
 * - ✅ APM tracing (performance monitoring)
 *
 * Do NOT use for:
 * - ❌ Sentry/Crashlytics (use ErrorHandler)
 * - ❌ Error tracking services (use ErrorHandler)
 *
 * ## Performance
 *
 * LogEntry is created lazily only when custom writers exist:
 * - No writers = Zero overhead ✅
 * - With writers = LogEntry created on every log
 *
 * @see LogEntry
 * @see SdkLogger.addCustomWriter
 * @see SdkLogger.removeCustomWriter
 */
internal interface LogWriter {
    /**
     * Processes a log entry.
     *
     * This method is called for every log event (if severity >= minSeverity)
     * when at least one custom writer is registered.
     *
     * **Implementation Requirements**:
     * - Must be thread-safe
     * - Should be fast (avoid blocking operations)
     * - Should not throw exceptions
     *
     * @param entry The log entry containing all log information
     */
    fun write(entry: LogEntry)
}
