package ch.srg.login.sdk.auth

/**
 * Static evaluation of the token storage at a given moment.
 *
 * This enum represents the four possible states of tokens in storage,
 * as determined by [TokenManagerImpl.evaluateTokenState]. It is intentionally
 * separate from [TokenState] (the public observable type) because:
 *
 * - `evaluateTokenState()` can only return these 4 states (storage-derived)
 * - [TokenState] additionally contains transition states (Refreshing, Refreshed,
 *   RefreshFailed) and the initial value (Uninitialized) that are not storage-derived
 *
 * Using this enum eliminates dead branches in `when` expressions that consume
 * `evaluateTokenState()` results.
 *
 * @see TokenState The public observable type (8 states)
 */
internal enum class EvaluatedTokenState {
    /** Token is present and not expired. */
    Valid,

    /** Token is present but approaching expiration threshold. */
    ExpiringSoon,

    /** Token is present but expired. */
    Expired,

    /** No tokens in storage. */
    NoTokens,
}

/**
 * Converts this storage evaluation result to the corresponding public [TokenState].
 */
internal fun EvaluatedTokenState.toTokenState(): TokenState =
    when (this) {
        EvaluatedTokenState.Valid -> TokenState.Valid
        EvaluatedTokenState.ExpiringSoon -> TokenState.ExpiringSoon
        EvaluatedTokenState.Expired -> TokenState.Expired
        EvaluatedTokenState.NoTokens -> TokenState.NoTokens
    }
