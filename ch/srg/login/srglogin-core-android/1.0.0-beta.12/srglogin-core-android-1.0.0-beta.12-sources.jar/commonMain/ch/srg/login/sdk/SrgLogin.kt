package ch.srg.login.sdk

import ch.srg.login.sdk.auth.AuthenticationManager
import ch.srg.login.sdk.auth.BackChannelLogoutListener
import ch.srg.login.sdk.auth.LoginMethod
import ch.srg.login.sdk.auth.LoginState
import ch.srg.login.sdk.auth.LogoutResult
import ch.srg.login.sdk.auth.LogoutType
import ch.srg.login.sdk.auth.PlatformAuthContext
import ch.srg.login.sdk.auth.TokenManager
import ch.srg.login.sdk.auth.TokenState
import ch.srg.login.sdk.lifecycle.AppLifecycleObserver
import ch.srg.login.sdk.logging.ErrorHandlerRegistry
import ch.srg.login.sdk.model.AccessToken
import ch.srg.login.sdk.model.TokenSet
import ch.srg.login.sdk.result.SdkResult
import kotlinx.coroutines.flow.Flow

/**
 * The main entry point for the SRG Login SDK.
 * It delegates authentication tasks to a configured [AuthenticationManager].
 *
 * @property config The configuration for the SDK.
 * @property authManager The authentication manager responsible for the login flow.
 * @property tokenManager The token manager for token lifecycle management and automatic refresh operations.
 * @property lifecycleObserver Platform-specific lifecycle observer for automatic resource cleanup.
 */
@Suppress("TooManyFunctions")
class SrgLogin internal constructor(
    private val config: SrgLoginConfig,
    private val authManager: AuthenticationManager,
    private val tokenManager: TokenManager,
    private val lifecycleObserver: AppLifecycleObserver,
) {
    /**
     * Initiates a login flow with the specified credentials and authentication context.
     *
     * @param loginMethod The login flow to use (e.g., Web, Device, UserPassword).
     * @param authContext The platform-specific authentication context.
     * @param additionalScopes Additional OAuth scopes to request (e.g., "offline_access", "profile", "email").
     *                         The "openid" scope is automatically included for OIDC compliance.
     *                         Default: empty list (only "openid" will be requested).
     *
     *                         **Common scopes**:
     *                         - `"offline_access"`: Request a refresh token for token renewal
     *                         - `"profile"`: Access user's profile information (name, picture, etc.)
     *                         - `"email"`: Access user's email address
     *
     *                         **Example**:
     *                         ```kotlin
     *                         // Login with refresh token support
     *                         srgLogin.login(
     *                             loginMethod = LoginMethod.Web,
     *                             authContext = authContext,
     *                             additionalScopes = listOf("offline_access", "profile", "email")
     *                         )
     *
     *                         // Minimal login (only authentication)
     *                         srgLogin.login(
     *                             loginMethod = LoginMethod.Web,
     *                             authContext = authContext
     *                         ) // Only "openid" scope will be requested
     *                         ```
     *
     * @param additionalParameters Additional OAuth/OIDC parameters to customize the authentication flow.
     *                             All values are automatically URL-encoded.
     *                             Default: empty map (no additional parameters).
     *
     *                             **Common OAuth 2.0/OIDC parameters**
     *                             (OIDC Core 1.0, Section 3.1.2.1 - https://openid.net/specs/openid-connect-core-1_0.html#AuthRequest):
     *                             - `"ui_locales"`: Preferred user interface language (e.g., "fr", "de", "en")
     *                             - `"prompt"`: Controls re-authentication and consent prompts
     *                               - `"none"`: No UI prompts (silent authentication)
     *                               - `"login"`: Force user to re-authenticate
     *                               - `"consent"`: Force consent screen even if already consented
     *                               - `"select_account"`: Prompt user to select account
     *                             - `"display"`: Display mode for authentication UI
     *                               - `"page"`: Full page (default)
     *                               - `"popup"`: Popup window
     *                               - `"touch"`: Touch-optimized interface
     *                               - `"wap"`: Feature phone display
     *                             - `"max_age"`: Maximum authentication age in seconds (forces re-auth if exceeded)
     *                             - `"login_hint"`: Pre-fills username/email in login form
     *                             - `"acr_values"`: Requested Authentication Context Class Reference
     *
     *                             **Examples**:
     *                             ```kotlin
     *                             // Force French UI
     *                             srgLogin.login(
     *                                 loginMethod = LoginMethod.Web,
     *                                 authContext = authContext,
     *                                 additionalParameters = mapOf("ui_locales" to "fr")
     *                             )
     *
     *                             // Force re-authentication
     *                             srgLogin.login(
     *                                 loginMethod = LoginMethod.Web,
     *                                 authContext = authContext,
     *                                 additionalParameters = mapOf("prompt" to "login")
     *                             )
     *
     *                             // Pre-fill username and force consent
     *                             srgLogin.login(
     *                                 loginMethod = LoginMethod.Web,
     *                                 authContext = authContext,
     *                                 additionalParameters = mapOf(
     *                                     "login_hint" to "user@example.com",
     *                                     "prompt" to "consent"
     *                                 )
     *                             )
     *
     *                             // Multi-language support with max authentication age
     *                             srgLogin.login(
     *                                 loginMethod = LoginMethod.Web,
     *                                 authContext = authContext,
     *                                 additionalScopes = listOf("offline_access", "profile"),
     *                                 additionalParameters = mapOf(
     *                                     "ui_locales" to "fr de en",  // Preferred languages in order
     *                                     "max_age" to "3600"          // Force re-auth if older than 1 hour
     *                                 )
     *                             )
     *                             ```
     *
     * @return A [Flow] that emits [LoginState] updates throughout the login process.
     */
    fun login(
        loginMethod: LoginMethod,
        authContext: PlatformAuthContext,
        additionalScopes: List<String> = emptyList(),
        additionalParameters: Map<String, String> = emptyMap(),
    ): Flow<LoginState> = authManager.login(loginMethod, authContext, additionalScopes, additionalParameters)

    /**
     * Logs the user out using the specified logout type.
     *
     * Defaults to [LogoutType.LocalOnly] which clears stored tokens and session data locally.
     *
     * For [LogoutType.FrontChannel]: The platform auth context is embedded in the type itself,
     * e.g. `logout(LogoutType.FrontChannel(authContext, postLogoutRedirectUri))`.
     *
     * For [LogoutType.BackChannel]: Validates the logout token JWT and clears the local session.
     *
     * @param logoutType The type of logout to perform (defaults to [LogoutType.LocalOnly])
     * @return [LogoutResult] with details about what was cleared/terminated
     */
    suspend fun logout(logoutType: LogoutType = LogoutType.LocalOnly): LogoutResult = authManager.logout(logoutType)

    /**
     * Registers a listener for back-channel logout notifications.
     *
     * Back-channel logout allows the authorization server to notify the SDK
     * when a user's session should be terminated (e.g., user logged out from
     * another device, admin revoked access, etc.).
     *
     * @param listener The listener to receive back-channel logout events
     * @return [SdkResult.Success] if registered, [SdkResult.Failure] if not supported on this platform
     */
    fun registerBackChannelLogoutListener(listener: BackChannelLogoutListener): SdkResult<Unit> =
        authManager.registerBackChannelLogoutListener(listener)

    /**
     * Unregisters a back-channel logout listener.
     *
     * @param listener The listener to remove
     * @return [SdkResult.Success] if unregistered, [SdkResult.Failure] if not supported on this platform
     */
    fun unregisterBackChannelLogoutListener(listener: BackChannelLogoutListener): SdkResult<Unit> =
        authManager.unregisterBackChannelLogoutListener(listener)

    /**
     * Opens another SSO client URL in platform-specific browser, leveraging the current
     * authenticated session cookies.
     *
     * Perfect for displaying profile pages, settings, admin panels, or any other SSO client
     * that shares the same authentication system.
     *
     * Uses fire-and-forget approach - returns success immediately after launching browser.
     *
     * @param ssoClientUrl URL of the SSO client to display
     * @param authContext The platform-specific authentication context
     * @return A [SdkResult] indicating success or failure of launching the SSO client
     */
    suspend fun openSsoClient(
        ssoClientUrl: String,
        authContext: PlatformAuthContext,
    ): SdkResult<Unit> = authManager.openSsoClient(ssoClientUrl, authContext)

    /**
     * Returns a valid access token, refreshing internally if needed.
     *
     * This is the **primary token access method**. It replaces the removed `refreshToken()`.
     *
     * - Token valid → returns immediately (no network)
     * - Token expired → refreshes automatically, returns new token
     * - `forceRefresh = true` → always refreshes (use after 401 from resource server)
     *
     * **Usage Example**:
     * ```kotlin
     * // Normal access:
     * val result = srgLogin.getAccessToken()
     *
     * // After a 401 (force refresh):
     * val freshResult = srgLogin.getAccessToken(forceRefresh = true)
     * ```
     *
     * @param forceRefresh Force a network refresh even if the current token is valid.
     * @return SdkResult.Success with AccessToken, or SdkResult.Failure with error
     */
    suspend fun getAccessToken(forceRefresh: Boolean = false): SdkResult<AccessToken> = tokenManager.getAccessToken(forceRefresh)

    /**
     * Checks if the user has a valid or refreshable authentication session.
     *
     * Returns true if EITHER condition is met:
     * - Valid (non-expired) access token exists in storage, OR
     * - Refresh token exists in storage (can obtain new access token)
     *
     * Returns false if BOTH conditions are false:
     * - No valid access token available, AND
     * - No refresh token available
     *
     * **Scenarios**:
     * - ✅ Valid access token + no refresh token → `true` (can make API calls immediately)
     * - ✅ Expired access token + refresh token → `true` (can refresh to get new token)
     * - ✅ Valid access token + refresh token → `true` (optimal case)
     * - ❌ Expired/missing access token + no refresh token → `false` (requires re-authentication)
     *
     * **Important**: This method checks LOCAL state only (no network call).
     * If tokens exist locally but are invalid server-side (revoked, corrupted),
     * this method will still return true until the next token operation detects the issue.
     * Invalid tokens are automatically detected and cleaned up when:
     * - `getAccessToken()` is called (including with `forceRefresh = true`)
     * - Server returns `invalid_grant` error
     *
     * **Usage Example**:
     * ```kotlin
     * if (srgLogin.isAuthenticated()) {
     *     // User has valid session locally, proceed to main screen
     *     navigateToMainScreen()
     * } else {
     *     // User needs to log in
     *     navigateToLoginScreen()
     * }
     * ```
     *
     * **Note**: This is a quick local check. Use `getAccessToken()` for
     * actual token retrieval with automatic refresh and server-side validation.
     *
     * @return true if user has valid access token OR refresh token, false otherwise
     */
    suspend fun isAuthenticated(): Boolean = tokenManager.isAuthenticated()

    /**
     * Checks if a refresh token is currently stored.
     *
     * A refresh token is required to silently renew the access token without
     * prompting the user to log in again. If no refresh token is available, the
     * next token operation after expiry will fail and the user must re-authenticate.
     *
     * **Note**: A stored refresh token may still be expired or revoked server-side.
     * The actual validity is only confirmed when [getAccessToken] is called and
     * the server responds — at that point the SDK clears the invalid token and
     * returns [ch.srg.login.sdk.result.SrgLoginError.InvalidGrant].
     *
     * **Usage Example**:
     * ```kotlin
     * if (srgLogin.hasRefreshToken()) {
     *     // Silent renewal is possible — show "session active" UI
     * } else {
     *     // No refresh token — user will need to log in again after token expiry
     * }
     * ```
     *
     * @return true if a refresh token exists in storage, false otherwise
     */
    suspend fun hasRefreshToken(): Boolean = tokenManager.hasRefreshToken()

    /**
     * Returns the raw refresh token string from secure storage, or `null` if none exists.
     *
     * **Development and testing use only.** This method exposes the raw refresh token
     * for debugging, diagnostics, and integration testing. Do **not** use it to build
     * a manual refresh flow — use [getAccessToken] with `forceRefresh = true` instead.
     *
     * **Security**: Never log, persist outside secure storage, or transmit the refresh
     * token off-device. It is the most sensitive credential in the OAuth 2.0 session.
     *
     * **Example**:
     * ```kotlin
     * // In a debug screen or integration test:
     * val refreshToken = srgLogin.getRefreshToken()
     * println("Refresh token present: ${refreshToken != null}")
     * // ⚠️ Do NOT log the actual value in production builds
     * ```
     *
     * @return The raw refresh token string, or `null` if no tokens are stored
     * @see hasRefreshToken For a safe boolean check without exposing the raw value
     * @see getAccessToken For obtaining a valid access token (the recommended API)
     */
    suspend fun getRefreshToken(): String? = tokenManager.getRefreshToken()

    /**
     * Observes the current token state as a reactive StateFlow.
     *
     * The StateFlow emits token state changes automatically on:
     * - Login (new tokens available)
     * - Logout (tokens cleared)
     * - Token refresh (tokens updated)
     *
     * **Initial Value**: [TokenState.Uninitialized]. The SDK replaces it with a real
     * state within milliseconds. Observers must handle `Uninitialized` explicitly —
     * typically by showing a splash screen and **not** navigating to login, otherwise
     * the app will briefly flash the login screen on every cold start even when the
     * user is already authenticated.
     *
     * **Usage Example**:
     * ```kotlin
     * // In ViewModel
     * val tokenState = srgLogin.observeTokenState()
     *     .stateIn(viewModelScope, SharingStarted.Eagerly, TokenState.Uninitialized)
     *
     * // In Composable
     * val state by tokenState.collectAsState()
     * when (state) {
     *     is TokenState.Uninitialized -> ShowSplashScreen()  // wait, do not navigate
     *     is TokenState.Valid -> ShowMainContent()
     *     is TokenState.ExpiringSoon -> ShowExpiryWarning()
     *     is TokenState.Expired -> ShowReauthenticateDialog()
     *     is TokenState.NoTokens -> ShowLoginScreen()
     *     // Handle other states (Refreshing, Refreshed, RefreshFailed)
     * }
     * ```
     *
     * @return StateFlow that emits current TokenState
     */
    fun observeTokenState(): Flow<TokenState> = tokenManager.observeTokenState()

    /**
     * Checks if error tracking is currently enabled.
     *
     * @return true if an error handler is configured, false otherwise
     *
     * @example
     * ```kotlin
     * if (srgLogin.isErrorTrackingEnabled()) {
     *     println("Errors are being reported to error tracking service")
     * } else {
     *     println("Error tracking is disabled")
     * }
     * ```
     */
    fun isErrorTrackingEnabled(): Boolean = ErrorHandlerRegistry.isEnabled()
}
