package ch.srg.login.sdk.logging

import ch.srg.login.sdk.internal.SecurityUtils
import co.touchlab.kermit.Logger
import co.touchlab.kermit.StaticConfig
import co.touchlab.kermit.platformLogWriter
import kotlinx.datetime.Clock
import kotlin.concurrent.Volatile

/**
 * Main logging API for the SRG Login SDK.
 *
 * SdkLogger is a wrapper around Kermit that provides:
 * - Automatic PII sanitization (via SecurityUtils)
 * - Global context enrichment (via TelemetryContext)
 * - Structured log entries (via LogEntry)
 * - Category-based taxonomy (via LogCategory)
 * - Lazy message evaluation for performance
 * - Multi-platform support (Android, iOS, JVM, JS)
 *
 * ## Architecture
 *
 * ```
 * Application Code
 *     ↓
 * SdkLogger.i(LogCategory.TOKEN) { "Token: eyJhbG..." }
 *     ↓
 * 1. Lazy evaluation → message() only if severity >= minSeverity
 * 2. PII sanitization → SecurityUtils.sanitizeErrorMessage()
 * 3. LogEntry creation → timestamp, severity, category, context, metadata
 * 4. Kermit logging → platformLogWriter() routes to native output
 *     ↓
 * Native Output:
 * - Android: Logcat (android.util.Log)
 * - iOS: OSLog (os_log / NSLog)
 * - JVM: stdout/stderr (println)
 * - JS: Browser DevTools Console (console.log/warn/error)
 * ```
 *
 * ## Usage Examples
 *
 * ### Basic Logging
 *
 * ```kotlin
 * // Info log
 * SdkLogger.i(LogCategory.TOKEN_MONITORING) { "Token refreshed successfully" }
 *
 * // Error log with exception
 * SdkLogger.e(LogCategory.NETWORK, throwable = exception) {
 *     "API call failed"
 * }
 *
 * // Warning with metadata
 * SdkLogger.w(
 *     category = LogCategory.TOKEN_MONITORING,
 *     metadata = mapOf("retryCount" to 3, "duration" to 234L)
 * ) {
 *     "Token refresh failed, will retry"
 * }
 * ```
 *
 * ### Lazy Evaluation (Performance)
 *
 * ```kotlin
 * // ✅ expensiveOperation() only called if VERBOSE logs enabled
 * SdkLogger.v(LogCategory.JWT_VALIDATION) {
 *     "JWT claims: ${expensiveOperation()}"
 * }
 *
 * // In production (minSeverity = INFO), this log is skipped entirely
 * ```
 *
 * ### Automatic PII Sanitization
 *
 * ```kotlin
 * // Code writes:
 * SdkLogger.i(LogCategory.AUTHENTICATION) {
 *     "User logged in: john.doe@example.com with token eyJhbGciOiJSUzI1NiIs..."
 * }
 *
 * // Output (automatically sanitized):
 * "[Authentication] User logged in: [EMAIL] with token [JWT_TOKEN]"
 * ```
 *
 * ### Global Context Enrichment
 *
 * ```kotlin
 * // Every log automatically includes:
 * // - sessionId (ephemeral)
 * // - businessUnit (SRF, RTS, RSI, RTR, SWI)
 * // - platform (Android, iOS, JVM, JS)
 * // - sdkVersion, appVersion, osVersion
 * // - environment (PROD, PREPROD, TEST)
 *
 * // Accessible via LogEntry for custom processing
 * ```
 *
 * ## Initialization
 *
 * SdkLogger must be initialized before use (typically in SDK initialization):
 *
 * ```kotlin
 * // SrgLoginSdk.kt (commonMain)
 * SdkLogger.initialize(
 *     context = telemetryContext,
 *     minSeverity = LogSeverity.getDefaultForBuild(isDebugBuild = BuildConfig.DEBUG)
 * )
 * ```
 *
 * ## Platform-Specific Output
 *
 * ### Android (Logcat)
 * ```
 * I/TokenMonitoring: Token refreshed successfully
 * E/Authentication: Login failed: [EMAIL] not found
 * W/Network: API call timeout after 30s
 * ```
 *
 * **View logs**:
 * ```bash
 * adb logcat | grep "TokenMonitoring"
 * adb logcat *:E  # Errors only
 * ```
 *
 * ### iOS (OSLog / NSLog)
 * ```
 * [TokenMonitoring] Token refreshed successfully
 * [Authentication] Login failed: [EMAIL] not found
 * [Network] API call timeout after 30s
 * ```
 *
 * **View logs**:
 * ```bash
 * # Xcode Console (automatic during debugging)
 * log stream --predicate 'subsystem == "ch.srg.login"'
 * log stream --level error  # Errors only
 * ```
 *
 * ### JVM (Console)
 * ```
 * [INFO] TokenMonitoring - Token refreshed successfully
 * [ERROR] Authentication - Login failed: [EMAIL] not found
 * [WARN] Network - API call timeout after 30s
 * ```
 *
 * ### JavaScript (Browser DevTools)
 * ```javascript
 * [TokenMonitoring] Token refreshed successfully
 * [Authentication] Login failed: [EMAIL] not found  // Red in console
 * [Network] API call timeout after 30s  // Yellow in console
 * ```
 *
 * ## API Methods
 *
 * SdkLogger follows the Android Log API naming convention:
 *
 * - **v()** - VERBOSE: Very detailed, development only
 * - **d()** - DEBUG: Development insights
 * - **i()** - INFO: General information (production default)
 * - **w()** - WARNING: Potential issues
 * - **e()** - ERROR: Errors requiring attention
 * - **wtf()** - ASSERT: Critical errors (SDK bugs)
 *
 * ## Thread Safety
 *
 * SdkLogger is **thread-safe** after initialization. All logging methods can be
 * called concurrently from multiple threads.
 *
 * **Important**: `initialize()` must be called **once** before any logging calls,
 * typically during SDK initialization on the main thread.
 *
 * ## Performance
 *
 * - **Lazy evaluation**: Message lambdas only executed if log level enabled
 * - **Severity filtering**: Early return if below minSeverity
 * - **Zero allocation** for filtered logs (modern Kotlin compiler optimization)
 * - **Kermit optimization**: Platform-specific writers optimized for each target
 *
 * ## Testing
 *
 * SdkLogger can be tested by injecting fake dependencies:
 *
 * ```kotlin
 * @Test
 * fun `logs are sanitized`() {
 *     val fakeSecurityUtils = FakeSecurityUtils()
 *     val fakeContext = TelemetryContext.create(...)
 *
 *     SdkLogger.initialize(fakeContext, LogSeverity.DEBUG)
 *     SdkLogger.i(LogCategory.TOKEN) { "Token: eyJhbGciOiJSUzI1NiIs..." }
 *
 *     assertTrue(fakeSecurityUtils.sanitizeCalled)
 * }
 * ```
 *
 * ## Future Extensibility (Phase 2+)
 *
 * LogEntry enables future custom log processing:
 *
 * ```kotlin
 * // Phase 2: Custom log writers
 * class SentryLogWriter : LogWriter {
 *     override fun write(entry: LogEntry) {
 *         if (entry.severity >= LogSeverity.ERROR) {
 *             Sentry.captureException(entry.throwable ?: Exception(entry.message))
 *         }
 *     }
 * }
 *
 * SdkLogger.addCustomWriter(SentryLogWriter())
 *
 * // Phase 3: Metrics collection
 * class MetricsCollector : LogWriter {
 *     override fun write(entry: LogEntry) {
 *         metrics.increment("sdk.logs.count", entry.context.toTags())
 *     }
 * }
 * ```
 *
 * @see LogSeverity
 * @see LogCategory
 * @see LogEntry
 * @see TelemetryContext
 * @see SecurityUtils
 */
internal object SdkLogger {
    /**
     * Global telemetry context for log enrichment.
     * Must be set via initialize() before logging.
     */
    private lateinit var context: TelemetryContext

    /**
     * Kermit logger instance configured for the target platform.
     * Must be set via initialize() before logging.
     */
    private lateinit var kermit: Logger

    /**
     * Minimum severity level to log.
     * Logs below this level are filtered out (early return).
     */
    private var minSeverity: LogSeverity = LogSeverity.INFO

    /**
     * Whether SdkLogger has been initialized.
     * Used to prevent logging before initialization.
     */
    private var isInitialized = false

    /**
     * Whether we've already warned about uninitialized state.
     * Used to prevent spamming the console with repeated warnings.
     */
    private var hasWarnedUninitialized = false

    /**
     * List of custom log writers for extensibility.
     * Writers are notified of all log events (if list is not empty).
     * Empty by default for zero overhead.
     *
     * Use cases:
     * - File logging (development/debug)
     * - Debug UI (in-app console)
     * - Metrics collection (Phase 2)
     * - APM tracing (Phase 2)
     *
     * NOT recommended for error tracking (use ErrorHandler instead).
     */
    @Volatile
    private var customWriters: List<LogWriter> = emptyList()

    /**
     * Adds a custom log writer for advanced logging scenarios.
     *
     * Writers receive LogEntry objects for all logs (if severity >= minSeverity).
     * Use for file logging, debug UI, metrics collection, etc.
     *
     * **Important**: Do NOT use this for error tracking services like Sentry.
     * Use ErrorHandler instead (dedicated API for errors only).
     *
     * @param writer The custom log writer to add
     *
     * @example
     * ```kotlin
     * // File logging (development only)
     * if (BuildConfig.DEBUG) {
     *     SdkLogger.addCustomWriter(FileLogWriter())
     * }
     *
     * // Debug UI (in-app console)
     * SdkLogger.addCustomWriter(DebugConsoleWriter())
     * ```
     */
    fun addCustomWriter(writer: LogWriter) {
        customWriters = customWriters + writer
    }

    /**
     * Removes a custom log writer.
     *
     * @param writer The custom log writer to remove
     */
    fun removeCustomWriter(writer: LogWriter) {
        customWriters = customWriters - writer
    }

    /**
     * Initializes SdkLogger with required dependencies.
     *
     * **Must be called once** before any logging operations, typically during
     * SDK initialization. Calling this method multiple times will reinitialize
     * the logger (useful for testing).
     *
     * @param context Global telemetry context for log enrichment
     * @param minSeverity Minimum severity level to log (default: INFO)
     *
     * @example
     * ```kotlin
     * // During SDK initialization
     * SdkLogger.initialize(
     *     context = telemetryContext,
     *     minSeverity = LogSeverity.getDefaultForBuild(isDebugBuild = BuildConfig.DEBUG)
     * )
     * ```
     */
    fun initialize(
        context: TelemetryContext,
        minSeverity: LogSeverity = LogSeverity.INFO,
    ) {
        this.context = context
        this.minSeverity = minSeverity
        this.kermit =
            Logger(
                config =
                    StaticConfig(
                        logWriterList =
                            listOf(
                                // Kermit selects native writer per platform
                                platformLogWriter(),
                            ),
                        minSeverity = minSeverity.toKermitSeverity(),
                    ),
            )
        this.customWriters = emptyList()
        this.isInitialized = true
        this.hasWarnedUninitialized = false // Reset warning flag on initialization
    }

    /**
     * Logs a VERBOSE message.
     *
     * Use for very detailed information, typically only enabled during development.
     * **Not logged in production** (filtered out by default minSeverity = INFO).
     *
     * @param category The category/module emitting this log
     * @param throwable Optional exception associated with this log
     * @param metadata Optional per-log custom metadata
     * @param message Lazy message supplier (only evaluated if log level enabled)
     *
     * @example
     * ```kotlin
     * SdkLogger.v(LogCategory.JWT_VALIDATION) {
     *     "JWT header: $header, payload: $payload"
     * }
     * ```
     */
    fun v(
        category: LogCategory,
        throwable: Throwable? = null,
        metadata: Map<String, Any> = emptyMap(),
        message: () -> String,
    ) {
        log(LogSeverity.VERBOSE, category, throwable, metadata, message)
    }

    /**
     * Logs a DEBUG message.
     *
     * Use for development insights and detailed information.
     * **Logged in debug builds**, filtered in production.
     *
     * @param category The category/module emitting this log
     * @param throwable Optional exception associated with this log
     * @param metadata Optional per-log custom metadata
     * @param message Lazy message supplier (only evaluated if log level enabled)
     *
     * @example
     * ```kotlin
     * SdkLogger.d(LogCategory.TOKEN_MONITORING) {
     *     "Token state changed: Valid -> ExpiringSoon"
     * }
     * ```
     */
    fun d(
        category: LogCategory,
        throwable: Throwable? = null,
        metadata: Map<String, Any> = emptyMap(),
        message: () -> String,
    ) {
        log(LogSeverity.DEBUG, category, throwable, metadata, message)
    }

    /**
     * Logs an INFO message.
     *
     * Use for general informational messages about normal SDK operation.
     * **Production default** - always logged.
     *
     * @param category The category/module emitting this log
     * @param throwable Optional exception associated with this log
     * @param metadata Optional per-log custom metadata
     * @param message Lazy message supplier (only evaluated if log level enabled)
     *
     * @example
     * ```kotlin
     * SdkLogger.i(LogCategory.SDK_CREATION) {
     *     "SDK initialized successfully for business unit: ${context.businessUnit}"
     * }
     * ```
     */
    fun i(
        category: LogCategory,
        throwable: Throwable? = null,
        metadata: Map<String, Any> = emptyMap(),
        message: () -> String,
    ) {
        log(LogSeverity.INFO, category, throwable, metadata, message)
    }

    /**
     * Logs a WARNING message.
     *
     * Use for potential issues that may require attention but are not errors.
     * Examples: retry attempts, degraded performance, recoverable errors.
     * **Always logged** in production and development.
     *
     * @param category The category/module emitting this log
     * @param throwable Optional exception associated with this log
     * @param metadata Optional per-log custom metadata
     * @param message Lazy message supplier (only evaluated if log level enabled)
     *
     * @example
     * ```kotlin
     * SdkLogger.w(
     *     category = LogCategory.TOKEN_MONITORING,
     *     metadata = mapOf("retryCount" to 3, "maxRetries" to 5)
     * ) {
     *     "Token refresh failed, will retry"
     * }
     * ```
     */
    fun w(
        category: LogCategory,
        throwable: Throwable? = null,
        metadata: Map<String, Any> = emptyMap(),
        message: () -> String,
    ) {
        log(LogSeverity.WARNING, category, throwable, metadata, message)
    }

    /**
     * Logs an ERROR message.
     *
     * Use for errors requiring attention, such as failed operations, unrecoverable
     * errors, or authentication failures.
     * **Always logged** in production and development.
     *
     * @param category The category/module emitting this log
     * @param throwable Optional exception associated with this log
     * @param metadata Optional per-log custom metadata
     * @param message Lazy message supplier (only evaluated if log level enabled)
     *
     * @example
     * ```kotlin
     * try {
     *     tokenRefresh()
     * } catch (e: IOException) {
     *     SdkLogger.e(LogCategory.NETWORK, throwable = e) {
     *         "Token refresh failed: network error"
     *     }
     * }
     * ```
     */
    fun e(
        category: LogCategory,
        throwable: Throwable? = null,
        metadata: Map<String, Any> = emptyMap(),
        message: () -> String,
    ) {
        log(LogSeverity.ERROR, category, throwable, metadata, message)
    }

    /**
     * Logs an ASSERT message (What a Terrible Failure).
     *
     * Use for critical errors that should **never happen** in production, such as
     * logic errors, invariant violations, or SDK bugs. This indicates a bug in
     * the SDK code itself.
     * **Always logged** - indicates severe SDK malfunction.
     *
     * @param category The category/module emitting this log
     * @param throwable Optional exception associated with this log
     * @param metadata Optional per-log custom metadata
     * @param message Lazy message supplier (only evaluated if log level enabled)
     *
     * @example
     * ```kotlin
     * val token = getToken()
     * if (token == null) {
     *     SdkLogger.wtf(LogCategory.TOKEN_MONITORING) {
     *         "CRITICAL: Token is null after successful validation - this should never happen"
     *     }
     * }
     * ```
     */
    fun wtf(
        category: LogCategory,
        throwable: Throwable? = null,
        metadata: Map<String, Any> = emptyMap(),
        message: () -> String,
    ) {
        log(LogSeverity.ASSERT, category, throwable, metadata, message)
    }

    /**
     * Internal logging method that handles the common logging flow.
     *
     * Flow:
     * 1. Check initialization
     * 2. Severity filtering (early return if below minSeverity)
     * 3. Lazy message evaluation
     * 4. PII sanitization
     * 5. LogEntry creation (for future extensibility)
     * 6. Kermit logging (routes to platform-specific output)
     *
     * @param severity The severity level of this log
     * @param category The category/module emitting this log
     * @param throwable Optional exception associated with this log
     * @param metadata Optional per-log custom metadata
     * @param message Lazy message supplier
     */
    private fun log(
        severity: LogSeverity,
        category: LogCategory,
        throwable: Throwable?,
        metadata: Map<String, Any>,
        message: () -> String,
    ) {
        // Check initialization
        if (!isInitialized) {
            // Fallback: print warning once if not initialized (useful for debugging)
            if (!hasWarnedUninitialized) {
                hasWarnedUninitialized = true
                println(
                    "[SdkLogger] WARNING: SdkLogger not initialized, call initialize() first. Subsequent logs will be silently dropped.",
                )
            }
            return
        }

        // Severity filtering (early return for performance)
        if (!severity.shouldLog(minSeverity)) {
            return
        }

        // Lazy evaluation: message() only called if we reach here
        val rawMessage = message()

        // PII sanitization (automatic and transparent)
        val sanitizedMessage = SecurityUtils.sanitizeErrorMessage(rawMessage)

        // Log to Kermit (routes to platform-specific output)
        val kermitSeverity = severity.toKermitSeverity()
        kermit.log(
            severity = kermitSeverity,
            tag = category.tag,
            throwable = throwable,
            message = sanitizedMessage,
        )

        // Lazy LogEntry creation: Only create if custom writers exist
        // This eliminates allocation overhead when no custom writers are registered
        // (which is 99% of the time in production)
        if (customWriters.isNotEmpty()) {
            val entry =
                LogEntry(
                    timestamp = Clock.System.now().toEpochMilliseconds(),
                    severity = severity,
                    category = category,
                    message = sanitizedMessage,
                    throwable = throwable,
                    context = context,
                    metadata = metadata,
                )
            customWriters.forEach { it.write(entry) }
        }
    }
}
