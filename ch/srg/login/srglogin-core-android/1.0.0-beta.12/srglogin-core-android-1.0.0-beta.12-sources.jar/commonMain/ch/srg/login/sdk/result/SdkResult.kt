package ch.srg.login.sdk.result

import ch.srg.login.sdk.errors.SrgLoginError

/**
 * A sealed class representing the result of an SDK operation.
 * It can be either a [Success] containing the desired data, or a [Failure]
 * containing a well-defined [SrgLoginError].
 */
sealed class SdkResult<out T> {
    data class Success<T>(
        val data: T,
    ) : SdkResult<T>()

    data class Failure(
        val error: SrgLoginError,
    ) : SdkResult<Nothing>()
}
