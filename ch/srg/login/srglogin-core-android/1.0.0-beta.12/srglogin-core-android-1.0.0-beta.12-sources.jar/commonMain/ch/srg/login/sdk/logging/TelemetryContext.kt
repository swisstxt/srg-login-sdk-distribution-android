package ch.srg.login.sdk.logging

import ch.srg.login.sdk.SdkBuildConfig

/**
 * Telemetry context for multi-tenant segmentation and log enrichment.
 *
 * This context is attached to all SDK logs and provides essential metadata
 * for filtering, debugging, and analytics across multiple SRG Business Units.
 *
 * ## Privacy & GDPR Compliance
 *
 * This data class is designed to be **GDPR-compliant** and does **not require
 * additional privacy declarations** in Google Play Store or Apple App Store:
 *
 * - **No Personal Data**: Does not contain user IDs, emails, or other PII
 * - **Diagnostic Data Only**: Contains only technical/diagnostic information
 * - **Ephemeral Session ID**: Session UUID is regenerated on each app launch (not persistent)
 * - **Device Info**: OS version and device model are acceptable diagnostic data
 *
 * ## Multi-Tenant Support
 *
 * The SDK is used by multiple SRG Business Units:
 * - **SRF** (Schweizer Radio und Fernsehen) - German-speaking Switzerland
 * - **RTS** (Radio Télévision Suisse) - French-speaking Switzerland
 * - **RSI** (Radiotelevisione svizzera) - Italian-speaking Switzerland
 * - **RTR** (Radiotelevisiun Svizra Rumantscha) - Romansh-speaking Switzerland
 * - **SWI** (Swissinfo) - International service
 *
 * @property appId Application package identifier (e.g., "ch.srf.news")
 * @property appName Human-readable application name (e.g., "SRF News")
 * @property appVersion Application version string (e.g., "2.5.3")
 * @property businessUnit Business unit identifier ("SRF", "RTS", "RSI", "RTR", "SWI")
 * @property businessUnitName Business unit full name (e.g., "Schweizer Radio und Fernsehen")
 * @property region Optional language region code (e.g., "de-ch", "fr-ch", "it-ch", "rm-ch")
 * @property sdkVersion SDK version string (e.g., "1.0.0")
 * @property platform Platform name ("Android", "iOS", "JVM", "JS")
 * @property osVersion Operating system version (diagnostic data)
 * @property deviceModel Device model name (diagnostic data)
 * @property sessionId Ephemeral session UUID (regenerated on each app launch, not persistent)
 * @property environment Environment identifier ("DEV", "INT", "PROD")
 * @property buildType Optional build type ("debug", "release")
 */
internal data class TelemetryContext(
    // Application Identity
    val appId: String,
    val appName: String,
    val appVersion: String,
    // Business Unit (Multi-Tenant)
    val businessUnit: String,
    val businessUnitName: String,
    val region: String? = null,
    // SDK Identity
    val sdkVersion: String,
    // Platform (Diagnostic data - GDPR compliant)
    val platform: String,
    val osVersion: String,
    val deviceModel: String,
    // Session (Ephemeral UUID - not persistent across app launches)
    val sessionId: String,
    // Environment
    val environment: String,
    val buildType: String? = null,
) {
    companion object {
        /**
         * SDK version from build configuration (gradle.properties).
         */
        val SDK_VERSION: String = SdkBuildConfig.VERSION

        /**
         * Creates a TelemetryContext with minimal required fields.
         *
         * This factory method provides a convenient way to create a context
         * with default values for optional fields.
         *
         * @param appId Application package identifier
         * @param appName Application name
         * @param appVersion Application version
         * @param businessUnit Business unit identifier
         * @param businessUnitName Business unit full name
         * @param platform Platform name
         * @param osVersion OS version
         * @param deviceModel Device model
         * @param sessionId Ephemeral session UUID
         * @param environment Environment identifier
         * @return A TelemetryContext instance
         */
        fun create(
            appId: String,
            appName: String,
            appVersion: String,
            businessUnit: String,
            businessUnitName: String,
            platform: String,
            osVersion: String,
            deviceModel: String,
            sessionId: String,
            environment: String,
        ): TelemetryContext =
            TelemetryContext(
                appId = appId,
                appName = appName,
                appVersion = appVersion,
                businessUnit = businessUnit,
                businessUnitName = businessUnitName,
                region = null,
                sdkVersion = SDK_VERSION,
                platform = platform,
                osVersion = osVersion,
                deviceModel = deviceModel,
                sessionId = sessionId,
                environment = environment,
                buildType = null,
            )
    }

    /**
     * Returns a formatted string representation for logging.
     *
     * Example output:
     * ```
     * [SRF News 2.5.3] [SRF/de-ch] [Android 14/Pixel 8] [session:abc-123] [PROD/release]
     * ```
     */
    fun toLogString(): String {
        val regionPart = region?.let { "/$it" } ?: ""
        val buildTypePart = buildType?.let { "/$it" } ?: ""
        return "[$appName $appVersion] [$businessUnitName$regionPart] " +
            "[$platform $osVersion/$deviceModel] [session:${sessionId.take(8)}] " +
            "[$environment$buildTypePart]"
    }
}
