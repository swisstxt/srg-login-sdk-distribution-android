package ch.srg.login.sdk.auth

import ch.srg.login.sdk.crypto.CryptoService
import ch.srg.login.sdk.data.api.SrgAuthApiService
import ch.srg.login.sdk.logging.ErrorHandler
import ch.srg.login.sdk.logging.ErrorHandlerRegistry
import ch.srg.login.sdk.logging.LogCategory
import ch.srg.login.sdk.logging.SdkLogger
import ch.srg.login.sdk.model.JsonWebKey
import ch.srg.login.sdk.model.JwkSet
import ch.srg.login.sdk.model.JwtClaims
import ch.srg.login.sdk.model.JwtHeader
import kotlinx.datetime.Clock
import kotlinx.serialization.json.Json
import kotlin.io.encoding.Base64
import kotlin.io.encoding.ExperimentalEncodingApi

/**
 * Service responsible for JWT parsing, JWKS retrieval, and signature verification.
 * This is a critical security component for validating all types of JWT tokens
 * including ID tokens, access tokens, and logout tokens.
 *
 * **Security Note**: This service implements cryptographic signature verification
 * according to RFC 7515 (JSON Web Signature) and RFC 7517 (JSON Web Key).
 * All JWT tokens MUST be signature-verified before claims are trusted.
 *
 * @property apiService Service for fetching JWKS from the authorization server
 * @property cryptoService Platform-specific cryptographic operations for signature verification
 * @property json JSON serializer for parsing JWT components
 */
internal class JwtValidationService(
    private val apiService: SrgAuthApiService,
    private val cryptoService: CryptoService,
    private val json: Json = Json { ignoreUnknownKeys = true },
) {
    init {
        SdkLogger.d(LogCategory.SDK_CREATION) { "JwtValidationService created (hashCode=${this.hashCode()})" }
    }

    // In-memory cache for JWKS to avoid repeated network calls
    private var cachedJwks: JwkSet? = null
    private var jwksCacheTime: Long = 0
    private val jwksCacheTtl = 3600L // 1 hour cache

    /**
     * Parses and validates a JWT token structure without signature verification.
     * This method extracts header and claims for further processing.
     */
    @OptIn(ExperimentalEncodingApi::class)
    suspend fun parseJwt(token: String): Result<ParsedJwt> {
        try {
            val parts = token.split(".")
            if (parts.size != 3) {
                return Result.failure(
                    Exception("JWT must have exactly 3 parts separated by dots"),
                )
            }

            val (headerPart, payloadPart, signaturePart) = parts

            val base64UrlDecoder = Base64.UrlSafe.withPadding(Base64.PaddingOption.ABSENT_OPTIONAL)

            // Decode header (JWT uses Base64URL encoding per RFC 7515 §2)
            val headerJson = base64UrlDecoder.decode(headerPart).decodeToString()
            val header = json.decodeFromString<JwtHeader>(headerJson)

            // Decode payload to extract claims (Base64URL, RFC 7519 §3)
            val payloadJson = base64UrlDecoder.decode(payloadPart).decodeToString()

            // Parse payload as a map of JsonElement to preserve the original JSON structure.
            // Non-standard claims flow into JwtClaims.rawClaims unchanged so consumers can
            // inspect arrays, nested objects, numeric precision, and booleans without lossy
            // conversion.
            val claimsMap = json.decodeFromString<Map<String, kotlinx.serialization.json.JsonElement>>(payloadJson)

            fun extractString(key: String): String? =
                claimsMap[key]?.let { element ->
                    if (element is kotlinx.serialization.json.JsonPrimitive && element.isString) {
                        element.content
                    } else {
                        null
                    }
                }

            fun extractLong(key: String): Long? =
                claimsMap[key]?.let { element ->
                    if (element is kotlinx.serialization.json.JsonPrimitive) {
                        element.content.toLongOrNull()
                    } else {
                        null
                    }
                }

            // Extracts a claim that may be a string OR an array of strings (RFC 7519 §4.1.3).
            // Normalizes both forms into List<String>. Filters out blank strings and non-string
            // elements. Returns empty list for missing/null/malformed claims — downstream
            // validation (validateRequiredClaims / validateIdTokenClaims) decides whether that's
            // acceptable.
            fun extractStringOrStringList(key: String): List<String> {
                val element = claimsMap[key] ?: return emptyList()
                return when (element) {
                    is kotlinx.serialization.json.JsonPrimitive -> {
                        if (element.isString && element.content.isNotBlank()) {
                            listOf(element.content)
                        } else {
                            emptyList()
                        }
                    }

                    is kotlinx.serialization.json.JsonArray -> {
                        element.mapNotNull { item ->
                            (item as? kotlinx.serialization.json.JsonPrimitive)
                                ?.takeIf { it.isString }
                                ?.content
                                ?.takeIf { it.isNotBlank() }
                        }
                    }

                    else -> {
                        emptyList()
                    }
                }
            }

            // Standard claim names per RFC 7519 §4.1 — anything else flows into rawClaims.
            val standardClaims = setOf("iss", "sub", "aud", "exp", "nbf", "iat", "jti")

            // Convert to JwtClaims
            val claims =
                JwtClaims(
                    iss = extractString("iss"),
                    sub = extractString("sub"),
                    aud = extractStringOrStringList("aud"),
                    exp = extractLong("exp"),
                    nbf = extractLong("nbf"),
                    iat = extractLong("iat"),
                    jti = extractString("jti"),
                    rawClaims = claimsMap.filterKeys { it !in standardClaims },
                )

            return Result.success(ParsedJwt(header, claims, signaturePart))
        } catch (e: Exception) {
            // Report to error tracking
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "parse_jwt",
                        "stage" to "jwt_structure_parsing",
                        "critical" to true,
                        "impact" to "jwt_validation_impossible",
                    ),
                level = ErrorHandler.ErrorLevel.FATAL,
            )

            return Result.failure(
                Exception("Failed to parse JWT: ${e.message}"),
            )
        }
    }

    /**
     * Retrieves and caches the JWKS (JSON Web Key Set) for signature verification.
     * Uses in-memory caching to improve performance.
     */
    suspend fun getJwks(jwksUri: String): Result<JwkSet> {
        val now = Clock.System.now().epochSeconds

        // Check if we have valid cached JWKS
        if (cachedJwks != null && (now - jwksCacheTime) < jwksCacheTtl) {
            return Result.success(cachedJwks!!)
        }

        return try {
            val jwks = apiService.getJwks(jwksUri)

            // Cache the result
            cachedJwks = jwks
            jwksCacheTime = now

            Result.success(jwks)
        } catch (e: Exception) {
            // Report to error tracking
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "get_jwks",
                        "jwks_uri" to jwksUri,
                        "critical" to true,
                        "impact" to "signature_verification_impossible",
                    ),
                level = ErrorHandler.ErrorLevel.FATAL,
            )

            Result.failure(
                Exception("Failed to retrieve JWKS from $jwksUri: ${e.message}"),
            )
        }
    }

    /**
     * Finds the appropriate public key for JWT signature verification.
     * Uses the 'kid' (Key ID) from JWT header to match against JWKS keys.
     */
    fun findVerificationKey(
        header: JwtHeader,
        jwks: JwkSet,
    ): JsonWebKey? =
        if (header.kid != null) {
            // Find key by Key ID if present
            jwks.keys.find { it.keyId == header.kid }
        } else {
            // Fallback: find first key that matches the algorithm
            jwks.keys.find { it.algorithm == header.alg }
        }

    /**
     * Validates basic JWT timing claims (iat, exp, nbf).
     * This checks token age and validity window.
     */
    fun validateTiming(
        claims: JwtClaims,
        maxAgeSeconds: Long = 300,
    ): Result<Unit> {
        val now = Clock.System.now().epochSeconds

        // Check issued at time (iat) - token shouldn't be too old
        claims.iat?.let { iat ->
            if (now - iat > maxAgeSeconds) {
                return Result.failure(
                    Exception("Token is too old (issued ${now - iat} seconds ago)"),
                )
            }
        }

        // Check not before (nbf) - token shouldn't be used before this time
        claims.nbf?.let { nbf ->
            if (now < nbf) {
                return Result.failure(
                    Exception("Token is not yet valid (not before: $nbf, now: $now)"),
                )
            }
        }

        // Check expiration (exp) - token shouldn't be expired
        claims.exp?.let { exp ->
            if (now >= exp) {
                return Result.failure(
                    Exception("Token has expired (exp: $exp, now: $now)"),
                )
            }
        }

        return Result.success(Unit)
    }

    /**
     * Validates that all required claims are present in the JWT.
     */
    fun validateRequiredClaims(claims: JwtClaims): Result<Unit> {
        // Check required claims
        if (claims.iss.isNullOrBlank()) {
            return Result.failure(
                Exception("Missing required 'iss' (issuer) claim"),
            )
        }

        if (claims.aud.isEmpty()) {
            return Result.failure(
                Exception("Missing required 'aud' (audience) claim"),
            )
        }

        if (claims.iat == null) {
            return Result.failure(
                Exception("Missing required 'iat' (issued at) claim"),
            )
        }

        if (claims.jti.isNullOrBlank()) {
            return Result.failure(
                Exception("Missing required 'jti' (JWT ID) claim"),
            )
        }

        return Result.success(Unit)
    }

    /**
     * Validates an ID token according to OIDC specification.
     *
     * @param idToken The ID token JWT string
     * @param clientId The expected client ID (audience)
     * @param issuer The expected issuer
     * @param jwksUri The JWKS URI for signature verification
     * @param nonce Optional nonce to validate
     * @param maxAgeSeconds Maximum age allowed for the token
     */
    suspend fun validateIdToken(
        idToken: String,
        clientId: String,
        issuer: String,
        jwksUri: String,
        nonce: String? = null,
        maxAgeSeconds: Long = 300,
    ): Result<JwtClaims> {
        try {
            // Parse the JWT
            val parseResult = parseJwt(idToken)
            if (parseResult.isFailure) {
                return Result.failure(parseResult.exceptionOrNull()!!)
            }

            val parsedJwt = parseResult.getOrThrow()
            val claims = parsedJwt.claims

            // Validate timing claims
            val timingResult = validateTiming(claims, maxAgeSeconds)
            if (timingResult.isFailure) {
                return Result.failure(timingResult.exceptionOrNull()!!)
            }

            // Validate ID token specific claims
            val idTokenClaimsResult = validateIdTokenClaims(claims, clientId, issuer, nonce)
            if (idTokenClaimsResult.isFailure) {
                return Result.failure(idTokenClaimsResult.exceptionOrNull()!!)
            }

            // Validate signature (get JWKS and verify)
            val jwksResult = getJwks(jwksUri)
            if (jwksResult.isFailure) {
                return Result.failure(jwksResult.exceptionOrNull()!!)
            }

            val jwks = jwksResult.getOrThrow()
            val verificationKey = findVerificationKey(parsedJwt.header, jwks)
            if (verificationKey == null) {
                return Result.failure(
                    Exception("No suitable verification key found for ID token"),
                )
            }

            // Verify JWT signature (CRITICAL SECURITY CHECK)
            val signatureValid = verifyJwtSignature(idToken, parsedJwt, verificationKey)
            if (!signatureValid) {
                return Result.failure(
                    Exception("ID token signature verification failed"),
                )
            }

            return Result.success(claims)
        } catch (e: Exception) {
            // Report to error tracking
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "validate_id_token",
                        "token_type" to "id_token",
                        "security_critical" to true,
                        "impact" to "user_identity_unverified",
                    ),
                level = ErrorHandler.ErrorLevel.FATAL,
            )

            return Result.failure(
                Exception("ID token validation failed: ${e.message}"),
            )
        }
    }

    /**
     * Validates access token claims according to OAuth 2.0 specification.
     *
     * @param accessToken The access token JWT string
     * @param clientId The expected client ID (audience)
     * @param issuer The expected issuer
     * @param jwksUri The JWKS URI for signature verification
     * @param maxAgeSeconds Maximum age allowed for the token
     */
    suspend fun validateAccessToken(
        accessToken: String,
        clientId: String,
        issuer: String,
        jwksUri: String,
        maxAgeSeconds: Long = 3600,
    ): Result<JwtClaims> {
        try {
            // Parse the JWT
            val parseResult = parseJwt(accessToken)
            if (parseResult.isFailure) {
                return Result.failure(parseResult.exceptionOrNull()!!)
            }

            val parsedJwt = parseResult.getOrThrow()
            val claims = parsedJwt.claims

            // Validate timing claims
            val timingResult = validateTiming(claims, maxAgeSeconds)
            if (timingResult.isFailure) {
                return Result.failure(timingResult.exceptionOrNull()!!)
            }

            // Validate access token specific claims
            val accessTokenClaimsResult = validateAccessTokenClaims(claims, clientId, issuer)
            if (accessTokenClaimsResult.isFailure) {
                return Result.failure(accessTokenClaimsResult.exceptionOrNull()!!)
            }

            // Validate signature (get JWKS and verify)
            val jwksResult = getJwks(jwksUri)
            if (jwksResult.isFailure) {
                return Result.failure(jwksResult.exceptionOrNull()!!)
            }

            val jwks = jwksResult.getOrThrow()
            val verificationKey = findVerificationKey(parsedJwt.header, jwks)
            if (verificationKey == null) {
                return Result.failure(
                    Exception("No suitable verification key found for access token"),
                )
            }

            // Verify JWT signature (CRITICAL SECURITY CHECK)
            val signatureValid = verifyJwtSignature(accessToken, parsedJwt, verificationKey)
            if (!signatureValid) {
                return Result.failure(
                    Exception("Access token signature verification failed"),
                )
            }

            return Result.success(claims)
        } catch (e: Exception) {
            // Report to error tracking
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "validate_access_token",
                        "token_type" to "access_token",
                        "security_critical" to true,
                        "impact" to "api_access_unauthorized",
                    ),
                level = ErrorHandler.ErrorLevel.FATAL,
            )

            return Result.failure(
                Exception("Access token validation failed: ${e.message}"),
            )
        }
    }

    /**
     * Validates ID token specific claims according to OIDC Core specification.
     */
    private fun validateIdTokenClaims(
        claims: JwtClaims,
        expectedClientId: String,
        expectedIssuer: String,
        expectedNonce: String?,
    ): Result<Unit> {
        // Validate issuer
        if (claims.iss != expectedIssuer) {
            return Result.failure(
                Exception("Invalid issuer: expected '$expectedIssuer', got '${claims.iss}'"),
            )
        }

        // Validate audience per OIDC Core §3.1.3.7 §3 — client_id MUST be in the aud list
        if (expectedClientId !in claims.aud) {
            return Result.failure(
                Exception(
                    "Invalid audience: expected '$expectedClientId' in audience list, got ${claims.aud}",
                ),
            )
        }

        // OIDC Core §3.1.3.7 §4-5 — if the ID token has multiple audiences, it MUST contain
        // an 'azp' (authorized party) claim AND that claim MUST equal the client_id.
        // Defense-in-depth against confused-deputy attacks where a different client
        // requested the token for a shared audience.
        if (claims.aud.size > 1) {
            val azp = claims.stringClaim("azp")
            if (azp.isNullOrBlank()) {
                return Result.failure(
                    Exception(
                        "ID token with multiple audiences must contain 'azp' (authorized party) claim " +
                            "per OIDC Core §3.1.3.7",
                    ),
                )
            }
            if (azp != expectedClientId) {
                return Result.failure(
                    Exception("Invalid 'azp': expected '$expectedClientId', got '$azp'"),
                )
            }
        }

        // Validate required claims for ID tokens
        if (claims.sub.isNullOrBlank()) {
            return Result.failure(
                Exception("Missing required 'sub' (subject) claim in ID token"),
            )
        }

        if (claims.iat == null) {
            return Result.failure(
                Exception("Missing required 'iat' (issued at) claim in ID token"),
            )
        }

        if (claims.exp == null) {
            return Result.failure(
                Exception("Missing required 'exp' (expiration) claim in ID token"),
            )
        }

        // Validate nonce if provided
        expectedNonce?.let { nonce ->
            val tokenNonce = claims.stringClaim("nonce")
            if (tokenNonce != nonce) {
                return Result.failure(
                    Exception("Nonce mismatch: expected '$nonce', got '$tokenNonce'"),
                )
            }
        }

        return Result.success(Unit)
    }

    /** Validates access token specific claims according to OAuth 2.0 specification. */
    @Suppress("ReturnCount")
    private fun validateAccessTokenClaims(
        claims: JwtClaims,
        expectedClientId: String,
        expectedIssuer: String,
    ): Result<Unit> {
        // Validate issuer
        if (claims.iss != expectedIssuer) {
            return Result.failure(
                Exception("Invalid issuer: expected '$expectedIssuer', got '${claims.iss}'"),
            )
        }

        // Validate audience (RFC 9068 / OAuth 2.0) — client_id (or resource server) MUST be in the aud list.
        // No azp rule here — that's OIDC-specific to id_tokens (§3.1.3.7).
        if (expectedClientId !in claims.aud) {
            return Result.failure(
                Exception(
                    "Invalid audience: expected '$expectedClientId' in audience list, got ${claims.aud}",
                ),
            )
        }

        // Validate required claims for access tokens
        if (claims.sub.isNullOrBlank()) {
            return Result.failure(
                Exception("Missing required 'sub' (subject) claim in access token"),
            )
        }

        if (claims.iat == null) {
            return Result.failure(
                Exception("Missing required 'iat' (issued at) claim in access token"),
            )
        }

        if (claims.exp == null) {
            return Result.failure(
                Exception("Missing required 'exp' (expiration) claim in access token"),
            )
        }

        // Note: Scope validation is NOT performed.
        // OAuth 2.0 spec (RFC 9068) states that scope claim SHOULD be present (not MUST),
        // and many authorization servers don't include it in access tokens.
        // Additionally, the spec allows servers to return fewer scopes than requested.
        // Therefore, strict scope validation would be non-compliant and too restrictive.

        return Result.success(Unit)
    }

    /**
     * Verifies the JWT signature using the appropriate cryptographic algorithm.
     *
     * This is the CRITICAL SECURITY METHOD that ensures token integrity.
     * According to RFC 7515 (JSON Web Signature), this method:
     * 1. Extracts the signing input (header.payload)
     * 2. Decodes the signature from Base64URL
     * 3. Verifies the signature using the public key from JWKS
     *
     * **Supported Algorithms** (RFC 7518):
     * - RS256, RS384, RS512: RSASSA-PKCS1-v1_5 with SHA-256/384/512
     * - ES256, ES384, ES512: ECDSA with P-256/384/521 curves and SHA-256/384/512
     *
     * @param token The complete JWT token string
     * @param parsedJwt The parsed JWT components
     * @param jwk The JSON Web Key for verification
     * @return true if signature is valid, false otherwise
     */
    @OptIn(ExperimentalEncodingApi::class)
    private fun verifyJwtSignature(
        token: String,
        parsedJwt: ParsedJwt,
        jwk: JsonWebKey,
    ): Boolean {
        try {
            // Extract the parts of the JWT
            val parts = token.split(".")
            if (parts.size != 3) {
                return false
            }

            val (headerPart, payloadPart, signaturePart) = parts

            // The signed data is "header.payload" (RFC 7515 Section 5.2)
            val signedData = "$headerPart.$payloadPart".encodeToByteArray()

            // Decode the signature from Base64URL (padding-tolerant)
            val base64UrlDecoder = Base64.UrlSafe.withPadding(Base64.PaddingOption.ABSENT_OPTIONAL)
            val signature = base64UrlDecoder.decode(signaturePart)

            // Get the algorithm from the JWT header
            val algorithm = parsedJwt.header.alg

            // Verify signature based on algorithm type
            return when {
                // RSA algorithms (RS256, RS384, RS512)
                algorithm.startsWith("RS") -> {
                    cryptoService.verifyRsaSignature(
                        data = signedData,
                        signature = signature,
                        jwk = jwk,
                        algorithm = algorithm,
                    )
                }

                // ECDSA algorithms (ES256, ES384, ES512)
                algorithm.startsWith("ES") -> {
                    cryptoService.verifyEcdsaSignature(
                        data = signedData,
                        signature = signature,
                        jwk = jwk,
                        algorithm = algorithm,
                    )
                }

                // Unsupported algorithm
                else -> {
                    false
                }
            }
        } catch (e: Exception) {
            // Any exception during signature verification means invalid signature
            // This is a security-critical failure

            // Report to error tracking
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "verify_jwt_signature",
                        "algorithm" to parsedJwt.header.alg,
                        "security_critical" to true,
                        "impact" to "potential_token_forgery",
                        "exception_type" to e::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.FATAL,
            )

            return false
        }
    }

    /**
     * Checks if an access token is expired.
     *
     * This is a lightweight check that only parses the JWT to extract the expiration claim
     * without performing full signature verification. Use this for refresh decisions.
     *
     * @param accessToken The access token JWT string
     * @return true if the token is expired or expiration cannot be determined, false otherwise
     */
    suspend fun isAccessTokenExpired(accessToken: String): Boolean {
        val parseResult = parseJwt(accessToken)
        if (parseResult.isFailure) {
            // If we can't parse the token, treat it as expired
            return true
        }

        val claims = parseResult.getOrThrow().claims
        val exp = claims.exp
        if (exp == null) {
            return true
        }

        val now = Clock.System.now().epochSeconds
        return now >= exp
    }

    /**
     * Checks if an access token is expiring soon (within the specified threshold).
     *
     * This method is used to determine if proactive token refresh should be triggered.
     *
     * @param accessToken The access token JWT string
     * @param thresholdSeconds Number of seconds before expiration to consider "expiring soon"
     * @return true if the token expires within the threshold, false otherwise
     */
    suspend fun isAccessTokenExpiringSoon(
        accessToken: String,
        thresholdSeconds: Long,
    ): Boolean {
        val parseResult = parseJwt(accessToken)
        if (parseResult.isFailure) {
            // If we can't parse the token, treat it as expiring soon
            return true
        }

        val claims = parseResult.getOrThrow().claims
        val exp = claims.exp ?: return true

        val now = Clock.System.now().epochSeconds
        val timeUntilExpiration = exp - now
        return timeUntilExpiration <= thresholdSeconds
    }

    /**
     * Clears the JWKS cache. Useful for testing or when keys are rotated.
     */
    fun clearJwksCache() {
        cachedJwks = null
        jwksCacheTime = 0
    }

    /**
     * Parses scopes from a claim value that can be in various formats.
     *
     * Supported formats:
     * - JSON array string: `"["openid","profile","email"]"`
     * - Space-separated string: `"openid profile email"`
     * - Comma-separated string: `"openid,profile,email"`
     * - Actual list: `["openid", "profile", "email"]`
     *
     * @param scopeClaim The scope claim value from JWT custom claims
     * @return Set of scope strings
     */
    internal fun parseScopesFromClaim(scopeClaim: Any): Set<String> =
        when (scopeClaim) {
            is String -> {
                val trimmed = scopeClaim.trim()
                // Check if it's a JSON array string like ["openid","profile","email"]
                if (trimmed.startsWith("[") && trimmed.endsWith("]")) {
                    trimmed
                        .removeSurrounding("[", "]")
                        .split(",")
                        .map { it.trim().removeSurrounding("\"") }
                        .filter { it.isNotBlank() }
                        .toSet()
                } else {
                    // Regular space or comma-separated string
                    trimmed
                        .split(Regex("[,\\s]+"))
                        .filter { it.isNotBlank() }
                        .toSet()
                }
            }

            is List<*> -> {
                scopeClaim.filterIsInstance<String>().toSet()
            }

            else -> {
                emptySet()
            }
        }
}

/**
 * Represents a parsed JWT with its components.
 */
internal data class ParsedJwt(
    val header: JwtHeader,
    val claims: JwtClaims,
    val signature: String,
)
