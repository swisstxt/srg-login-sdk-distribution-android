package ch.srg.login.sdk.logging

/**
 * Log categories for structured logging in the SRG Login SDK.
 *
 * Categorizes logs by SDK module or functionality to enable easier filtering,
 * analysis, and monitoring. Each category represents a distinct area of the SDK.
 *
 * ## Usage Examples
 *
 * ```kotlin
 * // Token monitoring logs
 * SdkLogger.i(LogCategory.TOKEN_MONITORING) { "Token refreshed successfully" }
 *
 * // Authentication flow logs
 * SdkLogger.i(LogCategory.AUTHENTICATION) { "Login flow started" }
 *
 * // Error logging with category
 * SdkLogger.e(LogCategory.NETWORK, throwable = exception) { "API call failed" }
 * ```
 *
 * ## Log Filtering
 *
 * Categories enable easy filtering in production:
 *
 * ```kotlin
 * // Android Logcat
 * adb logcat | grep "TokenMonitoring"
 *
 * // iOS Console
 * log show --predicate 'subsystem == "ch.srg.login" AND category == "Authentication"'
 * ```
 *
 * ## Migration from String Tags
 *
 * **Before**:
 * ```kotlin
 * companion object {
 *     private const val MONITORING_TAG = "SDK-TokenMonitoring"
 * }
 * println("$MONITORING_TAG: Token refreshed")
 * ```
 *
 * **After**:
 * ```kotlin
 * SdkLogger.i(LogCategory.TOKEN_MONITORING) { "Token refreshed" }
 * ```
 *
 * ## Category Distribution
 *
 * Distribution of logs across the SDK (from analysis of 91 println() calls):
 * - TOKEN_MONITORING: 39 logs (43%)
 * - AUTHENTICATION: 20 logs (22%)
 * - SDK_CREATION: 11 logs (12%)
 * - JWT_VALIDATION: 6 logs (7%)
 * - OPENID_CONFIG: 5 logs (5%)
 * - LIFECYCLE: 5 logs (5%)
 * - NETWORK: 4 logs (4%)
 * - SECURITY: 1 log (1%)
 * - STORAGE: 0 logs (future use)
 * - PERFORMANCE: 0 logs (future use)
 *
 * @property tag The human-readable category name for log output
 * @see SdkLogger
 * @see LogSeverity
 */
enum class LogCategory(
    val tag: String,
) {
    /**
     * Token lifecycle management and refresh operations.
     *
     * Use for:
     * - Token refresh operations (manual and automatic)
     * - Token state changes (Valid, ExpiringSoon, Expired, Refreshing)
     * - Background token monitoring lifecycle
     * - Token expiration detection and handling
     * - Refresh retry logic and exponential backoff
     * - Token metadata updates (session count, rotation)
     *
     * Examples:
     * - "Token refreshed successfully"
     * - "Token state changed: Valid -> ExpiringSoon"
     * - "Background monitoring started"
     * - "Token refresh failed, retrying (attempt 2/3)"
     * - "Adaptive threshold calculated: 150s for 300s token"
     *
     * Primary file: `TokenManagerImpl.kt` (39 logs)
     */
    TOKEN_MONITORING("TokenMonitoring"),

    /**
     * Authentication flows (login, logout, SSO).
     *
     * Use for:
     * - Login flow initiation and completion
     * - Logout operations (front-channel, back-channel)
     * - SSO client operations
     * - OAuth/OIDC authorization flows
     * - PKCE code challenge/verifier generation
     * - Redirect URL handling and validation
     * - Authentication state management
     *
     * Examples:
     * - "Login flow started with PKCE"
     * - "Authorization callback received"
     * - "Logout completed successfully"
     * - "SSO client opened in browser"
     * - "Back-channel logout processed for session XYZ"
     *
     * Primary file: `WebAuthenticationManager.kt` (20 logs)
     */
    AUTHENTICATION("Authentication"),

    /**
     * SDK initialization and configuration.
     *
     * Use for:
     * - SDK instance creation
     * - Configuration validation
     * - Dependency injection setup (Koin)
     * - Platform-specific initialization
     * - Feature flags and environment setup
     * - Initial health checks
     *
     * Examples:
     * - "SDK initialized successfully"
     * - "Configuration validated for environment: PROD"
     * - "DI container initialized with 12 modules"
     * - "Platform: Android 14 (API 34)"
     * - "Business unit: SRF (Swiss Radio and Television)"
     *
     * Primary file: `SrgLoginSdk.kt` (11 logs)
     */
    SDK_CREATION("Creation"),

    /**
     * OpenID Connect Discovery and configuration.
     *
     * Use for:
     * - OIDC discovery document fetching (.well-known/openid-configuration)
     * - Configuration parsing and validation
     * - Endpoint URL extraction (authorization, token, userinfo, etc.)
     * - JWKS (JSON Web Key Set) fetching
     * - Configuration caching and expiration
     * - Fallback handling for unavailable discovery
     *
     * Examples:
     * - "Fetching OpenID configuration from https://auth.example.com/.well-known/openid-configuration"
     * - "OpenID configuration cached for 3600s"
     * - "Authorization endpoint: https://auth.example.com/oauth/authorize"
     * - "JWKS fetched successfully with 3 keys"
     *
     * Primary file: `OpenIdConfigRepositoryImpl.kt` (5 logs)
     */
    OPENID_CONFIG("OpenIdConfig"),

    /**
     * JWT token parsing, validation, and signature verification.
     *
     * Use for:
     * - JWT header/payload/signature parsing
     * - Signature verification (RS256, ES256, etc.)
     * - Claims extraction and validation
     * - Token expiration checks (exp, nbf, iat)
     * - Issuer and audience validation
     * - JWKS key selection and matching
     * - Replay attack prevention (jti validation)
     *
     * Examples:
     * - "JWT signature verified successfully using key kid=abc123"
     * - "Token expires in 3600s"
     * - "Claims validation passed: iss, aud, exp"
     * - "JWT parsing failed: invalid Base64 encoding"
     * - "Token ID 'xyz789' already used (replay attack prevented)"
     *
     * Primary file: `JwtValidationService.kt` (6 logs)
     */
    JWT_VALIDATION("JwtValidation"),

    /**
     * Application and SDK lifecycle events.
     *
     * Use for:
     * - App foreground/background transitions
     * - SDK start/stop/pause/resume events
     * - Configuration changes (locale, theme)
     * - Memory warnings and resource cleanup
     * - Process lifecycle events
     * - Event emission and observation
     *
     * Examples:
     * - "App foregrounded, resuming token monitoring"
     * - "App backgrounded, pausing operations"
     * - "SDK lifecycle event emitted: AppForegrounded"
     * - "Configuration changed: locale=fr_CH"
     * - "Low memory warning received, cleaning up caches"
     *
     * Primary file: `SdkEventEmitter.kt` (5 logs)
     */
    LIFECYCLE("Lifecycle"),

    /**
     * Network operations and HTTP requests.
     *
     * Use for:
     * - HTTP request/response logging
     * - API endpoint calls
     * - Network error handling
     * - Retry logic for transient failures
     * - Request/response headers (sanitized)
     * - Connection timeouts and latency
     *
     * Examples:
     * - "POST /oauth/token - 200 OK (234ms)"
     * - "Network request failed: Connection timeout after 30s"
     * - "Retrying request (attempt 2/3) after 2s delay"
     * - "Response headers: content-type=application/json"
     *
     * Primary file: `SrgAuthApiServiceImpl.kt` (4 logs)
     */
    NETWORK("Network"),

    /**
     * Token storage operations (read, write, delete).
     *
     * Use for:
     * - Token persistence (save/load)
     * - Secure storage operations (Keystore, Keychain)
     * - Storage errors and fallbacks
     * - Token metadata persistence
     * - JWT ID replay prevention storage
     * - Storage cleanup and migrations
     *
     * Examples:
     * - "Tokens saved to secure storage successfully"
     * - "Tokens loaded from Keystore"
     * - "Storage error: Keychain access denied"
     * - "Cleared all tokens from storage"
     * - "Migrated token storage from v1 to v2 format"
     *
     * Primary file: Platform-specific `TokenStorage` implementations
     * Note: Currently using VERBOSE/DEBUG logs, will be migrated to SdkLogger
     */
    STORAGE("Storage"),

    /**
     * Security-related events and validations.
     *
     * Use for:
     * - Cryptographic operations (hashing, signing, verification)
     * - Security policy enforcement
     * - Certificate pinning
     * - Threat detection (tampering, man-in-the-middle)
     * - PII sanitization and GDPR compliance
     * - Security-critical errors
     *
     * Examples:
     * - "PKCE code verifier generated (64 chars, SHA-256)"
     * - "Certificate pinning validation passed"
     * - "Security warning: Insecure connection detected"
     * - "PII sanitized: email masked to us***@example.com"
     * - "Refresh token hash mismatch (possible tampering)"
     *
     * Primary file: `SecurityUtils.kt` (1 log)
     */
    SECURITY("Security"),

    /**
     * Performance metrics and timing information.
     *
     * Use for:
     * - Operation duration tracking
     * - Performance bottleneck identification
     * - Resource usage monitoring (memory, CPU)
     * - Slow operation warnings
     * - Optimization results
     * - Smart scheduling efficiency metrics
     *
     * Examples:
     * - "Token refresh completed in 234ms"
     * - "JWT validation took 12ms"
     * - "Background monitoring: 17 checks in 5h (94% reduction vs fixed interval)"
     * - "Warning: OpenID config fetch took 5.2s (expected < 1s)"
     * - "Memory usage: 2.4MB (tokens + metadata)"
     *
     * Note: Reserved for future performance logging and metrics integration
     */
    PERFORMANCE("Performance"),

    /**
     * Internal error tracking and reporting operations.
     *
     * Use for:
     * - SdkErrorReporter failures (Sentry event sending)
     * - ErrorHandler registration and configuration
     * - Error reporting service initialization
     * - Failed error uploads to external services
     * - Error tracking diagnostics and troubleshooting
     *
     * Examples:
     * - "Failed to send event to Sentry: Network timeout"
     * - "SdkErrorReporter initialized (environment=PROD)"
     * - "Error tracking disabled for DEV environment"
     * - "Sentry DSN validation failed: Invalid format"
     * - "Error event queued for retry (attempt 2/3)"
     *
     * Note: These logs help diagnose when the error tracking system itself fails.
     * Separate from general SDK errors to avoid confusion.
     *
     * Primary file: `SdkErrorReporter.kt`
     */
    ERROR_TRACKING("ErrorTracking"),
    ;

    /**
     * Returns the category tag for string representation.
     *
     * This allows using the enum directly in string contexts:
     * ```kotlin
     * val category = LogCategory.AUTHENTICATION
     * println("Category: $category")  // Prints: "Category: Authentication"
     * ```
     *
     * @return The category tag
     */
    override fun toString(): String = tag
}
