package ch.srg.login.sdk.model

/**
 * Returns a human-readable display name derived from [IdTokenClaims], using a
 * documented fallback chain.
 *
 * **Opt-in convenience** — this is an extension function (not a property on
 * [IdTokenClaims]) because the fallback chain encodes an opinionated choice that
 * not every consumer will agree with. Consumers that want a different policy can
 * ignore this extension and implement their own from the typed fields.
 *
 * Fallback chain (first non-blank value wins):
 *  1. [IdTokenClaims.name]
 *  2. [IdTokenClaims.givenName] joined with [IdTokenClaims.familyName] (if either is present)
 *  3. [IdTokenClaims.preferredUsername]
 *  4. [IdTokenClaims.email]
 *  5. [IdTokenClaims.subject] (always non-null — last-resort fallback)
 */
public fun IdTokenClaims.defaultDisplayName(): String =
    name
        ?: listOfNotNull(givenName, familyName).joinToString(" ").takeIf { it.isNotBlank() }
        ?: preferredUsername
        ?: email
        ?: subject
