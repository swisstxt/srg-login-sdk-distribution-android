package ch.srg.login.sdk.model

import kotlinx.datetime.Clock
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.longOrNull

/**
 * OIDC Address Claim (OIDC Core 1.0 §5.1.1).
 *
 * All fields are optional per the spec — only [formatted] is "RECOMMENDED" but not required.
 * Populated only when the IDP grants the `address` scope.
 *
 * The constructor is intentionally **public** — this is a plain data holder with no
 * validation semantics (unlike [IdTokenClaims], whose construction is SDK-internal to
 * enforce that an instance is proof of cryptographic validation).
 *
 * @property formatted Full mailing address, formatted for display or use on a mailing label.
 * @property streetAddress Full street address component (house number, street name, etc.).
 * @property locality City or locality component.
 * @property region State, province, or region component.
 * @property postalCode Zip code or postal code component.
 * @property country Country name component.
 */
public data class Address(
    val formatted: String? = null,
    val streetAddress: String? = null,
    val locality: String? = null,
    val region: String? = null,
    val postalCode: String? = null,
    val country: String? = null,
)

/**
 * Parsed claims from an OIDC ID Token (JWT payload).
 *
 * **Validation gate enforced at the type system level**: the primary constructor
 * is `internal`, and [@ConsistentCopyVisibility][kotlin.ConsistentCopyVisibility]
 * propagates that visibility to the generated `copy()` method. Consumers therefore
 * cannot construct or mutate an [IdTokenClaims] from outside the SDK — the only
 * way to obtain an instance is via [TokenSet.idTokenClaims], which the SDK
 * populates only after successful cryptographic validation (signature, issuer,
 * audience, expiration, nonce, azp). The existence of an instance is a
 * compile-time-checked proof of validation. (PR #77 review #8)
 *
 * Standard OIDC claims (OIDC Core 1.0 §2 and §5.1) are exposed as typed
 * properties. Non-standard or IDP-specific claims are available via [rawClaims]
 * with type-safe accessors:
 *
 *  - [getStringClaim], [getLongClaim], [getBooleanClaim]
 *  - [getStringListClaim], [getObjectClaim], [getArrayClaim]
 *  - [hasCustomClaim]
 *
 * The accessors apply **strict** JSON type checks: a JSON string `"42"` is NOT
 * coerced to a Long, and a JSON string `"true"` is NOT coerced to a Boolean.
 * This preserves the semantic distinction between "missing", "wrong type", and
 * "valid value" for downstream code.
 *
 * **Cross-platform note:** [rawClaims], [getObjectClaim], and [getArrayClaim] use
 * the SDK's own [ClaimValue] sealed class instead of `kotlinx.serialization.json.JsonElement`.
 * This keeps the public API platform-agnostic — Swift consumers (iOS, tvOS) get a
 * native `enum` via SKIE, TypeScript consumers via Kotlin/JS get a clean discriminated
 * union, and Java consumers get sealed-class pattern matching. (PR #77 review #4)
 *
 * @see [defaultDisplayName] for an opt-in convenience that derives a human-readable
 * display name from the claims, with a documented fallback chain.
 */
@ConsistentCopyVisibility
public data class IdTokenClaims internal constructor(
    /** Issuer Identifier — URL of the IDP that issued the token (`iss` claim). Always present. */
    val issuer: String,
    /** Stable, non-reassigned subject identifier of the authenticated user (`sub` claim). Always present. */
    val subject: String,
    /**
     * Audience(s) the token is intended for (`aud` claim, normalized to a list per RFC 7519 §4.1.3).
     * For multi-audience tokens, the SDK additionally enforces OIDC §3.1.3.7 azp validation.
     */
    val audience: List<String>,
    /** Expiration time (`exp` claim) as epoch seconds. Always present. */
    val expiresAt: Long,
    /** Issuance time (`iat` claim) as epoch seconds. Always present. */
    val issuedAt: Long,
    /**
     * Authorized Party (`azp` claim) — client_id of the party the token was issued to.
     * Required by OIDC §3.1.3.7 when [audience] contains more than one value.
     */
    val authorizedParty: String? = null,
    /**
     * String value used to associate a Client session with an ID Token (`nonce` claim).
     * Validated by the SDK against the nonce sent in the authorization request.
     */
    val nonce: String? = null,
    /**
     * Time when the End-User authenticated (`auth_time` claim) as epoch seconds.
     * Useful for re-authentication policies (e.g. step-up authentication).
     */
    val authTime: Long? = null,
    /**
     * Session identifier (`sid` claim) used for back-channel and front-channel logout.
     */
    val sessionId: String? = null,
    /**
     * Authentication Context Class Reference (`acr` claim) — assurance level
     * (e.g. `urn:mace:incommon:iap:silver`).
     */
    val acr: String? = null,
    /**
     * Authentication Methods References (`amr` claim) — methods used for authentication
     * (e.g. `["pwd", "mfa"]`). Values are IDP-specific (RFC 8176 is extensible).
     */
    val amr: List<String>? = null,
    /** End-User's full name (`name` claim) in displayable form. Granted by `profile` scope. */
    val name: String? = null,
    /** Given name(s) or first name(s) of the End-User (`given_name` claim). Granted by `profile` scope. */
    val givenName: String? = null,
    /** Surname(s) or last name(s) of the End-User (`family_name` claim). Granted by `profile` scope. */
    val familyName: String? = null,
    /**
     * Shorthand name by which the End-User wishes to be referred to (`preferred_username` claim).
     * Granted by `profile` scope. Not guaranteed to be unique by the IDP.
     */
    val preferredUsername: String? = null,
    /** URL of the End-User's profile picture (`picture` claim). Granted by `profile` scope. */
    val picture: String? = null,
    /**
     * End-User's locale (`locale` claim) as a BCP47 language tag (e.g. `fr-CH`).
     * Granted by `profile` scope.
     */
    val locale: String? = null,
    /**
     * Time when the End-User's profile information was last updated (`updated_at` claim) as epoch seconds.
     * Granted by `profile` scope.
     */
    val updatedAt: Long? = null,
    /** End-User's preferred email address (`email` claim). Granted by `email` scope. */
    val email: String? = null,
    /**
     * `true` if the IDP has verified the email belongs to the End-User (`email_verified` claim).
     * Granted by `email` scope.
     */
    val emailVerified: Boolean? = null,
    /**
     * End-User's preferred postal address (`address` claim) as a structured [Address] object.
     * Granted by `address` scope.
     */
    val address: Address? = null,
    /**
     * IDP-specific or non-standard claims preserved as [ClaimValue] (lossless, platform-agnostic).
     * Standard OIDC claims are pulled out into the typed properties above; only the residual
     * claims appear here. Use [getStringClaim], [getLongClaim], [getBooleanClaim],
     * [getStringListClaim], [getObjectClaim], [getArrayClaim], or [hasCustomClaim] for typed access.
     */
    val rawClaims: Map<String, ClaimValue> = emptyMap(),
) {
    // ===== Expiration =====

    /**
     * `true` if the ID token is expired according to the system clock (no clock skew tolerance).
     * For TV / set-top devices with potentially unsynchronized clocks, prefer [isExpiredWithSkew] with a tolerance.
     */
    val isExpired: Boolean
        get() = Clock.System.now().epochSeconds >= expiresAt

    /**
     * Returns `true` if the ID token is expired, applying [clockSkewSeconds] of tolerance.
     * Default tolerance is 30 seconds — recommended for devices that may have
     * clock drift (TV / set-top boxes).
     *
     * Named distinctly from the [isExpired] property to avoid the silent property-vs-function
     * call ambiguity (`claims.isExpired` strict vs `claims.isExpired()` 30s tolerance) that
     * arises when both share the same identifier.
     *
     * This extends the acceptance window **after** the nominal [expiresAt] — it accepts the ID
     * token as still valid for up to [clockSkewSeconds] seconds after it appears expired, to
     * tolerate a device clock that runs fast.
     *
     * For **proactive refresh** (refresh before tokens expire), use the access token instead:
     * `if (tokenSet.accessToken.expiresIn < 30) refresh()`. ID-token expiry is not the
     * appropriate trigger for refresh — the access token drives session lifetime.
     */
    public fun isExpiredWithSkew(clockSkewSeconds: Long = 30): Boolean {
        val now = Clock.System.now().epochSeconds
        return now >= expiresAt + clockSkewSeconds
    }

    // ===== Session =====

    /**
     * Duration in seconds since the user authenticated, derived from [authTime].
     * `null` if [authTime] is absent (the IDP did not include it).
     */
    val sessionAge: Long?
        get() = authTime?.let { Clock.System.now().epochSeconds - it }

    // ===== Audience =====

    /**
     * Returns `true` if [clientId] is one of the granted audiences.
     */
    public fun hasAudience(clientId: String): Boolean = clientId in audience

    // ===== Type-safe accessors for non-standard claims =====

    /**
     * Returns the string content of a JSON string claim, or `null` if the claim is absent
     * or not a JSON string. Numeric / boolean / array / object values return `null`.
     */
    public fun getStringClaim(name: String): String? = rawClaims[name]?.asText

    /**
     * Returns the Long value of a JSON integer claim, or `null` if the claim is absent
     * or is not an integer. Fractional ([ClaimValue.Decimal]) and JSON-string values
     * return `null` — strict type check (no implicit coercion).
     */
    public fun getLongClaim(name: String): Long? = rawClaims[name]?.asInteger

    /**
     * Returns the boolean value of a JSON boolean claim, or `null` if the claim is absent
     * or not a JSON boolean. JSON strings (even if they look like `"true"` / `"false"`)
     * return `null` — strict type check.
     */
    public fun getBooleanClaim(name: String): Boolean? = rawClaims[name]?.asBoolean

    /**
     * Returns the list of JSON-string elements from a JSON array claim, or `null` if the
     * claim is absent or not a JSON array.
     *
     * The [strict] parameter controls how mixed-type arrays are handled:
     * - `strict = false` (default, lenient): non-string elements are filtered out. An array
     *   `["admin", 2, "editor"]` returns `["admin", "editor"]`. Useful for tolerant consumption
     *   when an IDP occasionally returns mixed types and the BU app cares only about the
     *   string values.
     *
     *   **Note**: a non-empty array containing **only** non-string elements also returns an
     *   empty list, indistinguishable from a genuinely empty array `[]`. Use `strict = true`
     *   if you need to detect this case.
     * - `strict = true`: returns `null` if **any** element is a non-string (including
     *   [ClaimValue.Null]). The same `["admin", 2, "editor"]` returns `null`. Useful for
     *   security audits, monitoring IDP data quality, or any context where a malformed
     *   claim should be surfaced (e.g. log a warning, report to Sentry, fail closed).
     *
     * In both modes, an empty array claim returns an empty list (not `null`). Returns
     * `null` only if the claim is absent or not a JSON array. (PR #77 review #5)
     *
     * Example:
     * ```kotlin
     * // Permissive: take what you can use
     * val rolesForUi = claims.getStringListClaim("roles") ?: emptyList()
     *
     * // Strict: detect malformed claims
     * if (claims.getStringListClaim("roles", strict = true) == null &&
     *     claims.getArrayClaim("roles") != null
     * ) {
     *     log.warn("IDP returned a non-string element in 'roles' for user ${claims.subject}")
     * }
     * ```
     */
    public fun getStringListClaim(
        name: String,
        strict: Boolean = false,
    ): List<String>? {
        val array = rawClaims[name]?.asArray ?: return null
        val strings = array.mapNotNull { it.asText }
        return when {
            !strict -> strings
            strings.size == array.size -> strings
            else -> null
        }
    }

    /**
     * Returns the fields of a JSON object claim as `Map<String, ClaimValue>`, or `null`
     * if the claim is absent or not a JSON object.
     *
     * Replaces the previous `getJsonObjectClaim` (which returned `JsonObject` from
     * kotlinx-serialization) so that consumers on every platform — including Swift
     * (iOS/tvOS via SKIE) and TypeScript (via Kotlin/JS) — can navigate nested
     * structures without depending on `kotlinx-serialization-json`.
     */
    public fun getObjectClaim(name: String): Map<String, ClaimValue>? = rawClaims[name]?.asObject

    /**
     * Returns the items of a JSON array claim as `List<ClaimValue>`, or `null`
     * if the claim is absent or not a JSON array.
     *
     * Replaces the previous `getJsonArrayClaim` (which returned `JsonArray` from
     * kotlinx-serialization) — see [getObjectClaim] for the rationale.
     */
    public fun getArrayClaim(name: String): List<ClaimValue>? = rawClaims[name]?.asArray

    /**
     * Returns `true` if [name] is present in [rawClaims] (i.e. is a non-standard / IDP-specific
     * claim), regardless of its value type (including [ClaimValue.Null]).
     *
     * **Standard OIDC claims are NOT covered by this function** — they are exposed as typed
     * properties (`email`, `name`, `nonce`, `azp`, …) and removed from [rawClaims] to avoid
     * duplication. To check for a standard claim, use the property directly:
     *
     * ```kotlin
     * if (claims.email != null) { /* user has email */ }      // standard claim
     * if (claims.hasCustomClaim("tenant_id")) { /* ... */ }   // IDP-specific claim
     * ```
     *
     * Renamed from `hasClaim` in PR #77 (review #3) to remove the silent false-negative footgun:
     * `hasClaim("email")` previously returned `false` even when `claims.email != null`.
     */
    public fun hasCustomClaim(name: String): Boolean = name in rawClaims

    public companion object {
        // Standard OIDC claims that are pulled out of JwtClaims.rawClaims into typed
        // properties. Filtered out of the resulting IdTokenClaims.rawClaims to avoid
        // duplication: each claim lives in exactly one place.
        private val PULLED_OUT_CLAIMS =
            setOf(
                "azp",
                "nonce",
                "auth_time",
                "sid",
                "acr",
                "amr",
                "name",
                "given_name",
                "family_name",
                "preferred_username",
                "picture",
                "locale",
                "updated_at",
                "email",
                "email_verified",
                "address",
            )

        /**
         * Creates an [IdTokenClaims] instance from already-validated [JwtClaims].
         *
         * INTERNAL: only called by the SDK after successful OIDC validation
         * (`JwtValidationService.validateIdToken`). The required claims
         * (iss, sub, aud, exp, iat) are dereferenced unsafely (`!!`) — if any are
         * absent, upstream validation has a bug and a NullPointerException is
         * preferable to silent data corruption.
         *
         * Standard OIDC claims are pulled out of [JwtClaims.rawClaims] into typed
         * properties. The remaining claims (IDP-specific or non-standard) flow
         * unchanged into [IdTokenClaims.rawClaims] for consumer access via the
         * type-safe accessors. The conversion `JsonElement → ClaimValue` happens
         * here, at the public-API boundary, so kotlinx-serialization types never
         * leak out of the SDK.
         */
        internal fun fromJwtClaims(jwtClaims: JwtClaims): IdTokenClaims {
            val raw = jwtClaims.rawClaims
            return IdTokenClaims(
                // Required claims (validated upstream — non-null guaranteed)
                issuer = jwtClaims.iss!!,
                subject = jwtClaims.sub!!,
                audience = jwtClaims.aud,
                expiresAt = jwtClaims.exp!!,
                issuedAt = jwtClaims.iat!!,
                // Security claims
                authorizedParty = jwtClaims.stringClaim("azp"),
                nonce = jwtClaims.stringClaim("nonce"),
                authTime = (raw["auth_time"] as? JsonPrimitive)?.takeIf { !it.isString }?.longOrNull,
                sessionId = jwtClaims.stringClaim("sid"),
                acr = jwtClaims.stringClaim("acr"),
                amr = extractStringList(raw["amr"]),
                // Profile scope
                name = jwtClaims.stringClaim("name"),
                givenName = jwtClaims.stringClaim("given_name"),
                familyName = jwtClaims.stringClaim("family_name"),
                preferredUsername = jwtClaims.stringClaim("preferred_username"),
                picture = jwtClaims.stringClaim("picture"),
                locale = jwtClaims.stringClaim("locale"),
                updatedAt = (raw["updated_at"] as? JsonPrimitive)?.takeIf { !it.isString }?.longOrNull,
                // Email scope
                email = jwtClaims.stringClaim("email"),
                emailVerified = (raw["email_verified"] as? JsonPrimitive)?.takeIf { !it.isString }?.booleanOrNull,
                // Address scope
                address = jwtClaims.jsonObjectClaim("address")?.let(::parseAddress),
                // Drop pulled-out claims so consumers don't see duplicates, and convert remaining
                // JsonElement values to platform-agnostic ClaimValue at the boundary.
                rawClaims =
                    raw
                        .filterKeys { it !in PULLED_OUT_CLAIMS }
                        .mapValues { (_, value) -> value.toClaimValue() },
            )
        }

        private fun parseAddress(obj: JsonObject): Address =
            Address(
                formatted = (obj["formatted"] as? JsonPrimitive)?.takeIf { it.isString }?.content,
                streetAddress = (obj["street_address"] as? JsonPrimitive)?.takeIf { it.isString }?.content,
                locality = (obj["locality"] as? JsonPrimitive)?.takeIf { it.isString }?.content,
                region = (obj["region"] as? JsonPrimitive)?.takeIf { it.isString }?.content,
                postalCode = (obj["postal_code"] as? JsonPrimitive)?.takeIf { it.isString }?.content,
                country = (obj["country"] as? JsonPrimitive)?.takeIf { it.isString }?.content,
            )

        private fun extractStringList(element: JsonElement?): List<String>? =
            (element as? JsonArray)?.mapNotNull { item ->
                (item as? JsonPrimitive)?.takeIf { it.isString }?.content
            }
    }
}

/**
 * Converts a kotlinx-serialization [JsonElement] to the SDK's platform-agnostic [ClaimValue].
 *
 * Internal — the SDK applies this once at the [IdTokenClaims.fromJwtClaims] boundary so that
 * kotlinx-serialization types never appear in the public API.
 *
 * Type mapping:
 * - [JsonNull] → [ClaimValue.Null]
 * - JSON string primitive → [ClaimValue.Text]
 * - JSON boolean primitive (`true` / `false`) → [ClaimValue.Bool]
 * - JSON integer primitive (parses as Long) → [ClaimValue.Integer]
 * - JSON fractional / out-of-Long-range numeric → [ClaimValue.Decimal]
 * - [JsonArray] → [ClaimValue.Array] (recursively converted)
 * - [JsonObject] → [ClaimValue.Object] (recursively converted)
 *
 * The check order on [JsonPrimitive] matters: `isString` must be checked first to prevent
 * `kotlinx.serialization`'s lenient `booleanOrNull` / `longOrNull` from coercing JSON-string
 * `"true"` or `"42"` into the corresponding non-string ClaimValue branch.
 */
internal fun JsonElement.toClaimValue(): ClaimValue =
    when (this) {
        is JsonNull -> {
            ClaimValue.Null
        }

        is JsonPrimitive -> {
            when {
                this.isString -> ClaimValue.Text(this.content)
                this.content == "true" -> ClaimValue.Bool(true)
                this.content == "false" -> ClaimValue.Bool(false)
                this.longOrNull != null -> ClaimValue.Integer(this.longOrNull!!)
                this.doubleOrNull != null -> ClaimValue.Decimal(this.doubleOrNull!!)
                else -> ClaimValue.Text(this.content)
            }
        }

        is JsonArray -> {
            ClaimValue.Array(this.map { it.toClaimValue() })
        }

        is JsonObject -> {
            ClaimValue.Object(this.mapValues { (_, v) -> v.toClaimValue() })
        }
    }
