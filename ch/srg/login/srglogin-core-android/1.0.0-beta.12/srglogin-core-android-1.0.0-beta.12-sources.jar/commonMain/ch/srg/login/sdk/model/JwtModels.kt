package ch.srg.login.sdk.model

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive

/**
 * Represents the header of a JWT token.
 */
@Serializable
internal data class JwtHeader(
    // Algorithm (e.g., "RS256", "ES256")
    val alg: String,
    // Type (always "JWT")
    val typ: String = "JWT",
    // Key ID for signature verification
    val kid: String? = null,
)

/**
 * Represents the payload/claims of a JWT token.
 * This is a generic container for all JWT claims. Non-standard claims are stored
 * in [rawClaims] as [JsonElement] to preserve the original JSON structure
 * (arrays, nested objects, numeric precision, booleans) without lossy conversion.
 * Use [stringClaim] and [jsonObjectClaim] for typed access to common cases.
 */
internal data class JwtClaims(
    // Issuer
    val iss: String? = null,
    // Subject
    val sub: String? = null,
    // Audience — normalized to a list per RFC 7519 §4.1.3 (may be a string or array of strings in the raw JWT).
    // Empty list means the claim was absent, null, or malformed.
    val aud: List<String> = emptyList(),
    // Expiration time (Unix timestamp)
    val exp: Long? = null,
    // Not before (Unix timestamp)
    val nbf: Long? = null,
    // Issued at (Unix timestamp)
    val iat: Long? = null,
    // JWT ID (unique identifier)
    val jti: String? = null,
    // Non-standard claims preserved as JsonElement (RFC 7519 §4.2).
    // Use stringClaim() / jsonObjectClaim() helpers for typed access.
    val rawClaims: Map<String, JsonElement> = emptyMap(),
) {
    /**
     * Returns the value of a string claim from [rawClaims], or null if the claim is
     * absent or not a JSON string.
     */
    fun stringClaim(name: String): String? = (rawClaims[name] as? JsonPrimitive)?.takeIf { it.isString }?.content

    /**
     * Returns the value of a JSON object claim from [rawClaims], or null if the claim
     * is absent or not a JSON object.
     */
    fun jsonObjectClaim(name: String): JsonObject? = rawClaims[name] as? JsonObject
}

/**
 * Represents the validated claims of a logout token specifically.
 * Contains all the information needed for secure back-channel logout.
 */
internal data class LogoutTokenClaims(
    // Issuer - MUST match expected issuer
    val iss: String,
    // Audience - MUST contain client ID (normalized to list per RFC 7519 §4.1.3)
    val aud: List<String>,
    // Subject (user ID) - at least one of sub/sid required
    val sub: String? = null,
    // Session ID - at least one of sub/sid required
    val sid: String? = null,
    // MUST contain logout event — preserved as JsonObject to retain nested JSON structure
    val events: JsonObject,
    // Issued at - for age validation
    val iat: Long,
    // JWT ID - for replay protection
    val jti: String,
) {
    /**
     * Validates that this logout token contains the required back-channel logout event.
     */
    fun hasValidLogoutEvent(): Boolean = events.containsKey("http://schemas.openid.net/event/backchannel-logout")

    /**
     * Validates that at least one session identifier is present.
     */
    fun hasValidSessionIdentifier(): Boolean = !sub.isNullOrBlank() || !sid.isNullOrBlank()
}

/**
 * Represents current session information for matching against logout tokens.
 */
internal data class SessionInfo(
    // Current user ID (maps to 'sub' claim)
    val userId: String? = null,
    // Current session ID (maps to 'sid' claim)
    val sessionId: String? = null,
)
