package ch.srg.login.sdk.auth.logout

import ch.srg.login.sdk.SrgLoginConfig
import ch.srg.login.sdk.auth.LogoutResult
import ch.srg.login.sdk.auth.LogoutType
import ch.srg.login.sdk.auth.WebAuthCapable
import ch.srg.login.sdk.auth.WebAuthenticator
import ch.srg.login.sdk.data.OpenIdConfigRepository
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.logging.ErrorHandler
import ch.srg.login.sdk.logging.ErrorHandlerRegistry
import ch.srg.login.sdk.result.SdkResult
import ch.srg.login.sdk.token.TokenStorage

/**
 * Capability interface for front-channel (browser-based) logout support.
 *
 * Any [LogoutHandler] subclass that implements this interface gains FrontChannel logout
 * with a full default implementation. Individual methods can be overridden for
 * platform-specific behavior.
 *
 * FrontChannel logout builds a logout URL, clears the local session, and opens
 * the browser to terminate the server session.
 */
internal interface FrontChannelLogoutCapable {
    val config: SrgLoginConfig
    val tokenStorage: TokenStorage
    val openIdConfigRepository: OpenIdConfigRepository
    val webAuthenticator: WebAuthenticator

    /** Clears local session state. Provided by [LogoutHandler]. */
    suspend fun performLocalLogout(): LogoutResult

    /**
     * Builds logout URL, clears local session, and opens browser for server session termination.
     */
    @Suppress("LongMethod", "ReturnCount", "TooGenericExceptionCaught")
    suspend fun performFrontChannelLogout(type: LogoutType.FrontChannel): LogoutResult {
        val authContext = type.authContext
        if (authContext !is WebAuthCapable) {
            return LogoutResult.Failure(
                clearedLocalSession = false,
                serverLogoutAttempted = false,
                error =
                    SrgLoginError.InvalidConfiguration(
                        "Front-channel logout requires a WebAuthCapable authentication context.",
                    ),
            )
        }

        // Hoisted so the catch block can check if local logout was already performed,
        // preventing a double call that would emit duplicate TokensCleared events.
        var localLogoutResult: LogoutResult? = null

        try {
            // 1. Get OpenID Configuration for logout endpoint
            val openIdConfigResult = openIdConfigRepository.getConfiguration()
            val openIdConfig =
                when (openIdConfigResult) {
                    is SdkResult.Success -> {
                        openIdConfigResult.data
                    }

                    is SdkResult.Failure -> {
                        return LogoutResult.Failure(
                            clearedLocalSession = false,
                            serverLogoutAttempted = false,
                            error = openIdConfigResult.error,
                        )
                    }
                }

            // 2. Get postLogoutRedirectUri (call-site priority, then config)
            val postLogoutRedirectUri = type.postLogoutRedirectUri ?: config.postLogoutRedirectUri
            if (postLogoutRedirectUri == null) {
                return LogoutResult.Failure(
                    clearedLocalSession = false,
                    serverLogoutAttempted = false,
                    error =
                        SrgLoginError.InvalidConfiguration(
                            "Front-channel logout requires a postLogoutRedirectUri to be provided " +
                                "either in SrgLoginConfig or in the logout() call.",
                        ),
                )
            }

            // 3. Get stored ID token for id_token_hint
            val storedTokens = tokenStorage.getTokens()
            val idTokenHint = storedTokens?.idToken

            // 4. Build logout URL
            val logoutUrl =
                buildString {
                    append(openIdConfig.endSessionEndpoint ?: "${config.environment.baseUrl}/logout")
                    append("?client_id=${config.clientId}")
                    append("&post_logout_redirect_uri=${postLogoutRedirectUri.urlEncode()}")
                    idTokenHint?.let { idToken ->
                        append("&id_token_hint=${idToken.urlEncode()}")
                    }
                }

            // 5. Clear local session first
            localLogoutResult = performLocalLogout()
            val localCleared = localLogoutResult is LogoutResult.Success

            // 6. Open browser for server session termination
            val logoutResult = webAuthenticator.logout(logoutUrl, authContext)

            // 7. Return combined result
            return when (logoutResult) {
                is SdkResult.Success -> {
                    LogoutResult.Success(
                        clearedLocalSession = localCleared,
                        terminatedServerSession = true,
                    )
                }

                is SdkResult.Failure -> {
                    LogoutResult.Failure(
                        clearedLocalSession = localCleared,
                        serverLogoutAttempted = true,
                        error = logoutResult.error,
                    )
                }
            }
        } catch (e: Exception) {
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "front_channel_logout",
                        "stage" to "unhandled_exception",
                        "error_type" to e::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.ERROR,
            )
            // Only perform local logout in catch if it hasn't been done yet.
            // If webAuthenticator.logout() threw after performLocalLogout() succeeded,
            // calling it again would emit duplicate TokensCleared events.
            val localCleared =
                localLogoutResult?.let { it is LogoutResult.Success }
                    ?: (performLocalLogout() is LogoutResult.Success)

            return LogoutResult.Failure(
                clearedLocalSession = localCleared,
                serverLogoutAttempted = true,
                error = SrgLoginError.UnknownError(e),
            )
        }
    }

    /**
     * URL-encodes a string for safe use in OAuth 2.0 query parameters.
     */
    private fun String.urlEncode(): String =
        this
            .replace(":", "%3A")
            .replace("/", "%2F")
            .replace("?", "%3F")
            .replace("#", "%23")
            .replace("[", "%5B")
            .replace("]", "%5D")
            .replace("@", "%40")
            .replace("!", "%21")
            .replace("$", "%24")
            .replace("&", "%26")
            .replace("'", "%27")
            .replace("(", "%28")
            .replace(")", "%29")
            .replace("*", "%2A")
            .replace("+", "%2B")
            .replace(",", "%2C")
            .replace(";", "%3B")
            .replace("=", "%3D")
            .replace(" ", "%20")
}
