package ch.srg.login.sdk.auth.handler

import ch.srg.login.sdk.auth.JwtValidationService
import ch.srg.login.sdk.auth.LoginState
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.events.EventEmitter
import ch.srg.login.sdk.events.SdkLifecycleEvent
import ch.srg.login.sdk.events.StorageOperation
import ch.srg.login.sdk.logging.ErrorHandler
import ch.srg.login.sdk.logging.ErrorHandlerRegistry
import ch.srg.login.sdk.model.IdTokenClaims
import ch.srg.login.sdk.model.TokenResponseDto
import ch.srg.login.sdk.model.TokenSet
import ch.srg.login.sdk.token.TokenStorage
import kotlinx.datetime.Clock

/**
 * Handles the common token-success flow after a successful token exchange:
 * full JWT validation (issuer, audience, timing, signature), token persistence,
 * event emission on both the Flow and the event bus, and [LoginState.Success] creation.
 *
 * Extracted from duplicated logic in WebAuthenticationManager and DeviceAuthenticationManager.
 */
internal class TokenSuccessHandler(
    private val tokenStorage: TokenStorage,
    private val jwtValidationService: JwtValidationService,
    private val eventEmitter: EventEmitter,
    private val loginFailureEmitter: LoginFailureEmitter,
    private val clock: Clock = Clock.System,
) {
    /**
     * Validates tokens, persists them, and emits success events on both the Flow and the event bus.
     *
     * Performs full OIDC/OAuth 2.0 validation (issuer, audience, timing, signature) via
     * [JwtValidationService] — identical depth for Web, Device, and ROPC strategies.
     * On any failure, emits [SdkLifecycleEvent.LoginFailure] via [LoginFailureEmitter] so
     * monitoring observers see the failure alongside the direct Flow caller.
     *
     * @param tokenResponse The raw token response from the authorization server.
     * @param clientId The OAuth 2.0 client ID (used as expected audience).
     * @param issuer The expected token issuer (from OIDC discovery).
     * @param jwksUri The JWKS URI for signature verification (from OIDC discovery).
     * @param nonce Optional OIDC nonce for ID token validation (Web flow only).
     * @return [LoginState.Success] with parsed [TokenSet], or [LoginState.Failure] if
     *         validation or storage fails.
     */
    @Suppress("ReturnCount", "LongParameterList")
    suspend fun handle(
        tokenResponse: TokenResponseDto,
        clientId: String,
        issuer: String,
        jwksUri: String,
        nonce: String? = null,
    ): LoginState {
        // 1. Validate ID token if present (OIDC) and capture the validated claims.
        // The result was previously discarded — we now reuse it to populate idTokenClaims
        // in the resulting TokenSet, eliminating a downstream re-parse and exposing the
        // typed ID token claims to consumers.
        val validatedIdTokenClaims: IdTokenClaims? =
            tokenResponse.idToken?.let { idToken ->
                val idResult =
                    jwtValidationService.validateIdToken(
                        idToken = idToken,
                        clientId = clientId,
                        issuer = issuer,
                        jwksUri = jwksUri,
                        nonce = nonce,
                    )
                if (idResult.isFailure) {
                    return loginFailureEmitter.emit(
                        SrgLoginError.InvalidDataError(
                            "ID token validation failed: ${idResult.exceptionOrNull()?.message}",
                        ),
                    )
                }
                IdTokenClaims.fromJwtClaims(idResult.getOrThrow())
            }

        // 2. Validate access token and capture the validated claims (eliminates re-parse below).
        val accessResult =
            jwtValidationService.validateAccessToken(
                accessToken = tokenResponse.accessToken,
                clientId = clientId,
                issuer = issuer,
                jwksUri = jwksUri,
            )
        if (accessResult.isFailure) {
            return loginFailureEmitter.emit(
                SrgLoginError.InvalidDataError(
                    "Access token validation failed: ${accessResult.exceptionOrNull()?.message}",
                ),
            )
        }
        val validatedAccessTokenClaims = accessResult.getOrThrow()

        // 3. Persist tokens to storage
        val storageError = saveTokensOrCapture(tokenResponse)
        if (storageError != null) {
            return loginFailureEmitter.emit(storageError)
        }

        // 4. Convert to TokenSet with the already-validated claims (no re-parse).
        val tokenSet =
            TokenSet.fromDto(
                dto = tokenResponse,
                accessTokenClaims = validatedAccessTokenClaims,
                idTokenClaims = validatedIdTokenClaims,
            )

        // 5. Emit success events
        val loginSuccessTimestamp = clock.now().toEpochMilliseconds()
        eventEmitter.tryEmit(SdkLifecycleEvent.LoginSuccess(tokenSet, loginSuccessTimestamp))
        eventEmitter.tryEmit(
            SdkLifecycleEvent.TokensSaved(
                hasRefreshToken = tokenResponse.refreshToken != null,
                timestamp = clock.now().toEpochMilliseconds(),
            ),
        )

        return LoginState.Success(tokenSet)
    }

    /**
     * Persists [tokenResponse] to storage. On failure, emits [SdkLifecycleEvent.StorageError]
     * on the event bus and reports to Sentry at FATAL level.
     * Returns `null` on success, or the [SrgLoginError] on failure.
     */
    private suspend fun saveTokensOrCapture(tokenResponse: TokenResponseDto): SrgLoginError? {
        val saveResult = tokenStorage.saveTokens(tokenResponse)
        if (saveResult.isSuccess) return null

        val storageException = saveResult.exceptionOrNull() ?: Exception("Failed to save tokens")
        val storageError = SrgLoginError.UnknownError(storageException)
        eventEmitter.tryEmit(
            SdkLifecycleEvent.StorageError(
                operation = StorageOperation.SAVE,
                error = storageError,
                timestamp = clock.now().toEpochMilliseconds(),
            ),
        )
        ErrorHandlerRegistry.captureException(
            throwable = storageException,
            context =
                mapOf(
                    "operation" to "save_tokens_after_login",
                    "stage" to "login_storage",
                    "critical" to true,
                    "impact" to "user_authenticated_but_tokens_not_persisted",
                ),
            level = ErrorHandler.ErrorLevel.FATAL,
        )
        return storageError
    }
}
