package ch.srg.login.sdk.logging

/**
 * User context modes for error tracking with different privacy levels.
 *
 * Controls how user identifiers are handled when reporting errors to Sentry.
 * Each mode offers different trade-offs between privacy and debugging utility.
 *
 * ## Mode Comparison
 *
 * | Mode | Security | Cross-BU Correlation | GDPR | Use Case |
 * |------|---------|---------------------|------|----------|
 * | HASHED_SUB | ⭐⭐⭐⭐⭐ | ❌ Prevented | ✅ Yes | Production (recommended) |
 * | DIRECT_SUB | ⭐⭐⭐ | ✅ Possible | ✅ Yes | Debugging |
 * | SESSION_ID | ⭐⭐⭐⭐ | ❌ N/A | ✅ Yes | Testing |
 * | NONE | ⭐⭐⭐⭐⭐ | ❌ N/A | ✅ Yes | Maximum privacy |
 *
 * @see SdkErrorReporter
 */
enum class UserContextMode {
    /**
     * Hash user ID with salt (double anonymization: IDP's UUID + SDK's hash).
     *
     * **Security**: Defense in depth - even if Sentry is compromised, original sub cannot be recovered.
     * **Cross-BU**: Different salts per business unit prevent correlation.
     * **Grouping**: Same user = same hash (enables error aggregation).
     * **GDPR**: Compliant (hash is non-identifiable).
     *
     * **Recommended for production**.
     */
    HASHED_SUB,

    /**
     * Send JWT `sub` claim directly.
     *
     * **Use when**:
     * - Debugging environments
     * - IDP `sub` is already a UUID or anonymized
     *
     * **Not recommended for production** unless you have specific requirements.
     */
    DIRECT_SUB,

    /**
     * Use ephemeral session ID (regenerated on each app launch).
     *
     * **Characteristics**:
     * - Session-level grouping (errors within same session)
     * - No cross-session correlation
     * - Maximum privacy
     */
    SESSION_ID,

    /**
     * No user context sent to Sentry.
     *
     * **Use when**:
     * - Ultra privacy-sensitive applications
     * - User tracking not needed
     */
    NONE,
}
