package ch.srg.login.sdk.events

import ch.srg.login.sdk.auth.LogoutType
import ch.srg.login.sdk.auth.TokenState
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.model.TokenSet

/**
 * Represents all lifecycle events that occur within the SRG Login SDK.
 *
 * This sealed class hierarchy defines all possible events emitted by the SDK,
 * enabling event-driven architecture for:
 * - Internal component communication (decoupled architecture)
 * - Observability (analytics, logging, metrics)
 * - Future extensibility (easy to add new event types)
 *
 * **Event Categories**:
 * - Authentication: Login lifecycle events
 * - Logout: Logout lifecycle events
 * - Token Refresh: Token refresh lifecycle events
 * - App Lifecycle: Application startup/foreground/background/termination events
 * - Storage: Secure token storage operations (save/load/clear/errors)
 * - Token State: Token state change notifications
 *
 * **Usage in SDK**:
 * Events are emitted by [SdkEventEmitter] and consumed by:
 * - [TokenManager]: Listens to login/logout/app lifecycle/storage events
 * - [AppLifecycleObserver]: Emits app lifecycle events
 * - [WebAuthenticationManager]: Emits authentication/logout events
 * - [TokenStorage]: Emits storage events
 * - Future: Analytics, logging, metrics services
 *
 * **Timestamp**:
 * All events include a `timestamp` (milliseconds since epoch) for:
 * - Event ordering and correlation
 * - Performance tracking (duration calculations)
 * - Audit logs and debugging
 *
 * @since 1.0.0
 */
internal sealed class SdkLifecycleEvent {
    // ============================================
    // Authentication Events
    // ============================================

    /**
     * Emitted when a login flow is initiated.
     *
     * @property timestamp Time when login started (milliseconds since epoch)
     */
    data class LoginStarted(
        val timestamp: Long,
    ) : SdkLifecycleEvent()

    /**
     * Emitted when login completes successfully.
     *
     * @property tokenSet The complete token set with parsed AccessToken
     * @property timestamp Time when login succeeded (milliseconds since epoch)
     */
    data class LoginSuccess(
        val tokenSet: TokenSet,
        val timestamp: Long,
    ) : SdkLifecycleEvent()

    /**
     * Emitted when login fails.
     *
     * @property error The error that caused login to fail
     * @property timestamp Time when login failed (milliseconds since epoch)
     */
    data class LoginFailure(
        val error: SrgLoginError,
        val timestamp: Long,
    ) : SdkLifecycleEvent()

    // ============================================
    // Logout Events
    // ============================================

    /**
     * Emitted when a logout operation is initiated.
     *
     * @property logoutType Type of logout (LocalOnly, FrontChannel, BackChannel)
     * @property timestamp Time when logout started (milliseconds since epoch)
     */
    data class LogoutStarted(
        val logoutType: LogoutType,
        val timestamp: Long,
    ) : SdkLifecycleEvent()

    /**
     * Emitted when logout completes successfully.
     *
     * @property logoutType Type of logout that was performed
     * @property timestamp Time when logout succeeded (milliseconds since epoch)
     */
    data class LogoutSuccess(
        val logoutType: LogoutType,
        val timestamp: Long,
    ) : SdkLifecycleEvent()

    /**
     * Emitted when logout fails.
     *
     * Note: Even if logout fails remotely, local session is typically cleared.
     *
     * @property error The error that caused logout to fail
     * @property timestamp Time when logout failed (milliseconds since epoch)
     */
    data class LogoutFailure(
        val error: SrgLoginError,
        val timestamp: Long,
    ) : SdkLifecycleEvent()

    // ============================================
    // Token Refresh Events
    // ============================================

    /**
     * Emitted when a token refresh operation is initiated.
     *
     * @property timestamp Time when token refresh started (milliseconds since epoch)
     */
    data class TokenRefreshStarted(
        val timestamp: Long,
    ) : SdkLifecycleEvent()

    /**
     * Emitted when token refresh completes successfully.
     *
     * @property tokenSet The new token set with parsed AccessToken
     * @property timestamp Time when token refresh succeeded (milliseconds since epoch)
     */
    data class TokenRefreshSuccess(
        val tokenSet: TokenSet,
        val timestamp: Long,
    ) : SdkLifecycleEvent()

    /**
     * Emitted when token refresh fails.
     *
     * @property error The error that caused token refresh to fail
     * @property timestamp Time when token refresh failed (milliseconds since epoch)
     */
    data class TokenRefreshFailure(
        val error: SrgLoginError,
        val timestamp: Long,
    ) : SdkLifecycleEvent()

    // ============================================
    // Session Events
    // ============================================

    /**
     * Emitted when the session is forcibly terminated by the IDP (e.g. `invalid_grant`).
     *
     * Distinct from [LogoutSuccess], which represents a user-initiated logout.
     * Apps should treat this as a hard session end and redirect the user to the login screen.
     *
     * **Trigger**: The token endpoint returned `invalid_grant`, meaning the refresh token
     * has been revoked or expired server-side. All local tokens and metadata have already
     * been cleared from storage before this event is emitted.
     *
     * **SDK Actions** on receiving this event internally:
     * - Token monitoring is stopped
     * - [TokenState] transitions to [ch.srg.login.sdk.auth.TokenState.NoTokens]
     *
     * @property reason The underlying error that caused session invalidation
     * @property timestamp Time when session was invalidated (milliseconds since epoch)
     */
    data class SessionInvalidated(
        val reason: SrgLoginError,
        val timestamp: Long,
    ) : SdkLifecycleEvent()

    // ============================================
    // App Lifecycle Events
    // ============================================

    /**
     * Emitted when the application starts for the first time in this process.
     *
     * **Platform Behavior**:
     * - Android: Application.onCreate() or first ProcessLifecycleOwner.onCreate()
     * - iOS: applicationDidFinishLaunching (Phase 2.8.3)
     * - JVM: Main method entry (Phase 2.8.3)
     * - JS: window.addEventListener('load') (Phase 2.8.3)
     *
     * **SDK Actions**:
     * - TokenManager: Check if tokens exist and start monitoring if configured
     *
     * **Difference from AppForegrounded**:
     * - AppStarted: Emitted ONCE per app process (cold start)
     * - AppForegrounded: Emitted every time app comes to foreground (can happen multiple times)
     *
     * @property timestamp Time when app started (milliseconds since epoch)
     */
    data class AppStarted(
        val timestamp: Long,
    ) : SdkLifecycleEvent()

    /**
     * Emitted when the application comes to the foreground.
     *
     * **Platform Behavior**:
     * - Android: ProcessLifecycleOwner.onStart()
     * - iOS: UIApplicationDidBecomeActiveNotification (Phase 2.8.3)
     * - JVM: Not applicable (Phase 2.8.3)
     * - JS: window.addEventListener('focus') (Phase 2.8.3)
     *
     * **SDK Actions**:
     * - TokenManager: Restart token monitoring if tokens exist
     *
     * **Note**: Also emitted after AppStarted on first launch.
     *
     * @property timestamp Time when app foregrounded (milliseconds since epoch)
     */
    data class AppForegrounded(
        val timestamp: Long,
    ) : SdkLifecycleEvent()

    /**
     * Emitted when the application goes to the background.
     *
     * **Platform Behavior**:
     * - Android: ProcessLifecycleOwner.onStop()
     * - iOS: UIApplicationDidEnterBackgroundNotification (Phase 2.8.3)
     * - JVM: Not applicable (Phase 2.8.3)
     * - JS: window.addEventListener('blur') (Phase 2.8.3)
     *
     * **SDK Actions**:
     * - TokenManager: Stop token monitoring to save battery
     *
     * @property timestamp Time when app backgrounded (milliseconds since epoch)
     */
    data class AppBackgrounded(
        val timestamp: Long,
    ) : SdkLifecycleEvent()

    /**
     * Emitted when the application is about to terminate.
     *
     * **Platform Behavior**:
     * - Android: ProcessLifecycleOwner.onDestroy()
     * - iOS: UIApplicationWillTerminateNotification (Phase 2.8.3)
     * - JVM: Runtime.addShutdownHook() (Phase 2.8.3)
     * - JS: window.addEventListener('beforeunload') (Phase 2.8.3)
     *
     * **SDK Actions**:
     * - TokenManager: Dispose all resources (cancel coroutines, cleanup)
     *
     * @property timestamp Time when app termination started (milliseconds since epoch)
     */
    data class AppTerminated(
        val timestamp: Long,
    ) : SdkLifecycleEvent()

    // ============================================
    // Storage Events
    // ============================================

    /**
     * Emitted when tokens are successfully saved to secure storage.
     *
     * **Use Cases**:
     * - Audit trail: Track when tokens are persisted
     * - Analytics: Measure storage success rate
     * - Debugging: Verify save operations
     *
     * @property hasRefreshToken Whether a refresh token was included in the save
     * @property timestamp Time when tokens were saved (milliseconds since epoch)
     */
    data class TokensSaved(
        val hasRefreshToken: Boolean,
        val timestamp: Long,
    ) : SdkLifecycleEvent()

    /**
     * Emitted when tokens are successfully loaded from secure storage.
     *
     * **Use Cases**:
     * - Audit trail: Track when tokens are accessed
     * - Analytics: Measure session restoration success
     * - Performance: Track load latency
     *
     * @property hasRefreshToken Whether a refresh token was loaded
     * @property timestamp Time when tokens were loaded (milliseconds since epoch)
     */
    data class TokensLoaded(
        val hasRefreshToken: Boolean,
        val timestamp: Long,
    ) : SdkLifecycleEvent()

    /**
     * Emitted when tokens are cleared from secure storage.
     *
     * **Use Cases**:
     * - Security audit: Track token deletions
     * - Analytics: Understand logout patterns
     * - Debugging: Verify cleanup operations
     *
     * @property reason Reason for clearing (e.g., "logout", "invalid_grant", "expiration", "corruption")
     * @property timestamp Time when tokens were cleared (milliseconds since epoch)
     */
    data class TokensCleared(
        val reason: String,
        val timestamp: Long,
    ) : SdkLifecycleEvent()

    /**
     * Emitted when a storage operation fails.
     *
     * **Use Cases**:
     * - Error tracking: Monitor storage reliability
     * - Analytics: Identify device/platform issues (e.g., Keystore failures)
     * - Debugging: Diagnose storage problems
     *
     * **Common Errors**:
     * - SAVE: Keystore unavailable, encryption failed
     * - LOAD: Decryption failed, corrupted data
     * - DECRYPT: Key rotation issues, compromised storage
     *
     * @property operation The storage operation that failed
     * @property error The error that occurred
     * @property timestamp Time when storage error occurred (milliseconds since epoch)
     */
    data class StorageError(
        val operation: StorageOperation,
        val error: SrgLoginError,
        val timestamp: Long,
    ) : SdkLifecycleEvent()

    // ============================================
    // Token State Events
    // ============================================

    /**
     * Emitted when the token state changes.
     *
     * **Token States**:
     * - Valid: Token is valid and not expiring soon
     * - ExpiringSoon: Token approaching expiration (within threshold)
     * - Expired: Token has expired
     * - NoTokens: No tokens available in storage
     * - Refreshing: Token refresh in progress
     * - Refreshed: Token refresh completed successfully
     * - RefreshFailed: Token refresh failed
     *
     * **Use Cases**:
     * - UI updates: Show expiry warnings, session expired dialogs
     * - Proactive refresh: Trigger refresh when ExpiringSoon
     * - Analytics: Track token lifecycle patterns
     *
     * @property newState The new token state
     * @property timestamp Time when state changed (milliseconds since epoch)
     */
    data class TokenStateChanged(
        val newState: TokenState,
        val timestamp: Long,
    ) : SdkLifecycleEvent()
}

/**
 * Defines all possible secure storage operations that can fail.
 *
 * Used in [SdkLifecycleEvent.StorageError] to identify which operation failed.
 *
 * @since 1.0.0
 */
enum class StorageOperation {
    /**
     * Saving tokens to storage (includes encryption).
     */
    SAVE,

    /**
     * Loading tokens from storage (includes decryption).
     */
    LOAD,

    /**
     * Clearing/deleting tokens from storage.
     */
    CLEAR,

    /**
     * Encrypting token data before storage.
     */
    ENCRYPT,

    /**
     * Decrypting token data after loading from storage.
     */
    DECRYPT,
}
