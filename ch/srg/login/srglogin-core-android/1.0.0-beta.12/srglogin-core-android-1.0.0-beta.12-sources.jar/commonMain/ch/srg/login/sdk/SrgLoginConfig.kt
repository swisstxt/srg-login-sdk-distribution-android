package ch.srg.login.sdk

/**
 * Determines how the SDK manages token refresh.
 *
 * Two modes are available, matching the platform's execution model:
 *
 * - [Automatic]: SDK monitors token expiration in the background and refreshes proactively.
 *   `TokenState` is updated continuously (animated view). Recommended for Android, iOS, tvOS,
 *   Android TV, Web SPA — any platform with a foreground/background lifecycle.
 *
 * - [Manual]: App manages token refresh via `getAccessToken(forceRefresh = true)`.
 *   `TokenState` is updated on each `getAccessToken()` call (interactive view). Recommended
 *   for JVM servers, JS SSR, background workers — platforms without a lifecycle.
 *
 * In both modes, `getAccessToken()` returns a valid token (refreshing internally if expired).
 * The mode only affects whether the SDK proactively refreshes **before** expiration.
 *
 * **Industry alignment**: Firebase Auth, MSAL, Auth0 all converge on this pattern —
 * one method to get a valid token, optional force-refresh, no public `refreshToken()`.
 *
 * @see TokenRefreshConfig
 */
sealed class TokenRefreshMode {
    /**
     * SDK manages token refresh automatically via background monitoring.
     *
     * After login, the SDK automatically starts monitoring in the background — no
     * setup is required from the host app. The monitoring loop detects `ExpiringSoon`
     * tokens and refreshes them proactively, using adaptive thresholds and smart
     * scheduling for battery efficiency.
     *
     * `observeTokenState()` emits real-time state changes (animated view):
     * `Valid → ExpiringSoon → Refreshing → Refreshed → Valid`
     *
     * `getAccessToken(forceRefresh = true)` is available as a **fallback** for 401 retry
     * (monitoring cannot detect server-side token revocation of a structurally valid JWT).
     */
    data object Automatic : TokenRefreshMode()

    /**
     * App manages token refresh manually.
     *
     * No background monitoring runs. `TokenState` is updated on each `getAccessToken()` call.
     * The state stays static between calls (interactive view).
     *
     * `getAccessToken()` refreshes only when the token is `Expired`.
     * `getAccessToken(forceRefresh = true)` is the **primary refresh mechanism** — replaces
     * the removed `refreshToken()`. Use it before batch jobs, after a 401, or on the app's
     * own schedule.
     *
     * `observeTokenState()` emits state changes triggered by `getAccessToken()` calls:
     * `Valid → (no change until next call) → Refreshing → Refreshed → Valid`
     */
    data object Manual : TokenRefreshMode()
}

/**
 * Configuration for token refresh behavior.
 *
 * Controls how and when the SDK refreshes tokens. The [mode] determines the overall strategy
 * (automatic monitoring vs. manual), while the other properties control timing, retry, and
 * security thresholds.
 *
 * **Default Configuration** (Automatic mode):
 * ```kotlin
 * val config = SrgLoginConfig(
 *     clientId = "your-client-id",
 *     redirectUri = "app://callback",
 *     appIdentity = appIdentity,
 *     environment = Environment.PROD,
 *     tokenRefreshConfig = TokenRefreshConfig(
 *         mode = TokenRefreshMode.Automatic,
 *         refreshThresholdSeconds = 600,    // Refresh 10 min before expiry
 *         maxRetryAttempts = 5,             // Retry 5 times on failure
 *     )
 * )
 * ```
 *
 * **Example - Manual Mode** (JVM server):
 * ```kotlin
 * val config = SrgLoginConfig(
 *     clientId = "your-client-id",
 *     redirectUri = "app://callback",
 *     appIdentity = appIdentity,
 *     environment = Environment.PROD,
 *     tokenRefreshConfig = TokenRefreshConfig(
 *         mode = TokenRefreshMode.Manual,
 *     )
 * )
 *
 * // Get a valid token (refreshes internally if expired):
 * val token = srgLogin.getAccessToken()
 *
 * // Force refresh (e.g., after a 401 from resource server):
 * val freshToken = srgLogin.getAccessToken(forceRefresh = true)
 * ```
 *
 * @property mode The token refresh strategy. See [TokenRefreshMode] for details.
 *               Default: [TokenRefreshMode.Automatic].
 *
 * @property refreshThresholdSeconds Refresh token when this many seconds remain before expiry.
 *                                   Default: 300 seconds (5 minutes).
 *
 *                                   In [TokenRefreshMode.Automatic] mode with adaptive thresholds:
 *                                   - Tokens < 5 min lifetime: Use 50% of token lifetime (min 10s)
 *                                   - Tokens >= 5 min lifetime: Use this value (capped at 25% of lifetime)
 *
 *                                   In [TokenRefreshMode.Manual] mode: Used by `getAccessToken()` to
 *                                   determine whether the token is `ExpiringSoon` or `Expired`.
 *
 * @property maxRetryAttempts Maximum retry attempts for failed refresh due to network errors.
 *                            Default: 3 attempts.
 *                            Non-network errors (invalid_grant) are not retried.
 *
 * @property initialRetryDelayMs Initial retry delay in milliseconds for exponential backoff.
 *                               Default: 1000ms (1 second).
 *                               Each retry doubles the delay up to [maxRetryDelayMs].
 *
 * @property maxRetryDelayMs Maximum retry delay in milliseconds for exponential backoff.
 *                           Default: 30000ms (30 seconds).
 *
 * @property maxRefreshTokenUses Maximum number of refresh token uses before warning.
 *                               Default: 1000.
 *                               Used to detect potential token compromise (excessive usage).
 */
data class TokenRefreshConfig(
    val mode: TokenRefreshMode = TokenRefreshMode.Automatic,
    val refreshThresholdSeconds: Long = 300,
    val maxRetryAttempts: Int = 3,
    val initialRetryDelayMs: Long = 1000,
    val maxRetryDelayMs: Long = 30000,
    val maxRefreshTokenUses: Int = 1000,
) {
    init {
        require(refreshThresholdSeconds >= 0) {
            "refreshThresholdSeconds must be non-negative, got: $refreshThresholdSeconds"
        }
        require(maxRetryAttempts >= 0) {
            "maxRetryAttempts must be non-negative, got: $maxRetryAttempts"
        }
        require(initialRetryDelayMs >= 0) {
            "initialRetryDelayMs must be non-negative, got: $initialRetryDelayMs"
        }
        require(maxRetryDelayMs >= initialRetryDelayMs) {
            "maxRetryDelayMs ($maxRetryDelayMs) must be >= initialRetryDelayMs ($initialRetryDelayMs)"
        }
        require(maxRefreshTokenUses > 0) {
            "maxRefreshTokenUses must be positive, got: $maxRefreshTokenUses"
        }
    }
}

/**
 * Identity of the host application embedding the SRG Login SDK.
 *
 * This information is used for Sentry error attribution, allowing
 * filtering and grouping errors by host application and business unit
 * in a multi-tenant environment (SRF, RTS, RSI, RTR, SWI).
 *
 * **Example**:
 * ```kotlin
 * val identity = AppIdentity(
 *     appId = "ch.srf.news",
 *     appName = "SRF News",
 *     appVersion = "2.5.3",
 *     businessUnit = "SRF",
 *     businessUnitName = "Schweizer Radio und Fernsehen",
 * )
 * ```
 *
 * @property appId Application package identifier (e.g., "ch.srf.news")
 * @property appName Human-readable application name (e.g., "SRF News")
 * @property appVersion Application version string (e.g., "2.5.3")
 * @property businessUnit Business unit identifier (e.g., "SRF", "RTS", "RSI", "RTR", "SWI")
 * @property businessUnitName Business unit full name (e.g., "Schweizer Radio und Fernsehen")
 */
data class AppIdentity(
    val appId: String,
    val appName: String,
    val appVersion: String,
    val businessUnit: String,
    val businessUnitName: String,
) {
    init {
        require(appId.isNotBlank()) { "appId cannot be blank" }
        require(appName.isNotBlank()) { "appName cannot be blank" }
        require(appVersion.isNotBlank()) { "appVersion cannot be blank" }
        require(businessUnit.isNotBlank()) { "businessUnit cannot be blank" }
        require(businessUnitName.isNotBlank()) { "businessUnitName cannot be blank" }
    }
}

/**
 * Represents the configuration for the SRG Login SDK.
 *
 * @property clientId The client ID for your application.
 * @property redirectUri The redirect URI for your application.
 * @property appIdentity The identity of the host application for Sentry error attribution.
 * @property postLogoutRedirectUri The redirect URI after logout (optional).
 * @property environment The target environment for authentication.
 * @property enableLogging A flag to enable or disable logging within the SDK.
 * @property tokenRefreshConfig Configuration for automatic token refresh behavior.
 * @property enableErrorTracking A flag to enable or disable internal error tracking with Sentry.
 *   Default is `true` (enabled). Set to `false` to disable error tracking entirely.
 *   When disabled, SDK errors will not be reported to Sentry.
 *
 *   **When to disable**:
 *   - Debug/development builds (errors logged to console only)
 *   - Privacy-sensitive applications
 *   - During testing/QA
 *   - If your organization has compliance requirements
 *
 *   **Example**:
 *   ```kotlin
 *   val config = SrgLoginConfig(
 *       clientId = "client-id",
 *       redirectUri = "app://callback",
 *       appIdentity = AppIdentity(
 *           appId = "ch.srf.news",
 *           appName = "SRF News",
 *           appVersion = "2.5.3",
 *           businessUnit = "SRF",
 *           businessUnitName = "Schweizer Radio und Fernsehen",
 *       ),
 *       environment = Environment.PROD,
 *       enableErrorTracking = false  // Disable error tracking
 *   )
 *   ```
 */
data class SrgLoginConfig(
    val clientId: String,
    val redirectUri: String,
    val appIdentity: AppIdentity,
    val environment: Environment,
    val postLogoutRedirectUri: String? = null,
    val enableLogging: Boolean = false,
    val tokenRefreshConfig: TokenRefreshConfig = TokenRefreshConfig(),
    val enableErrorTracking: Boolean = true,
    /**
     * Enables the Resource Owner Password Credentials (ROPC) grant type.
     *
     * **SECURITY WARNING**: ROPC is deprecated by RFC 9700 Section 2.4 because it exposes
     * the user's plaintext password to the client application. Only enable as a last-resort
     * fallback (e.g., tvOS where no browser is available for authorization code flow).
     *
     * When enabled, [ch.srg.login.sdk.auth.LoginMethod.UserPassword] can be used with
     * [ch.srg.login.sdk.SrgLogin.login] to authenticate directly with username and password.
     *
     * Default: `false` (disabled)
     */
    val enableRopcFlow: Boolean = false,
    /**
     * The client secret for the ROPC grant type.
     *
     * Required when the OAuth client is registered as a confidential client on the IDP.
     * Only used when [enableRopcFlow] is `true`.
     *
     * **SECURITY WARNING**: Embedding a client secret in a native app is generally discouraged
     * (it can be extracted from the binary). Only use when required by the IDP configuration.
     *
     * Default: `null` (public client, no secret sent)
     */
    val clientSecret: String? = null,
) {
    init {
        // Validation for clientId
        require(clientId.isNotBlank()) {
            "clientId cannot be blank"
        }

        // Validation for redirectUri
        require(redirectUri.isNotBlank()) {
            "redirectUri cannot be blank"
        }
        require(redirectUri.contains("://")) {
            "redirectUri must be a valid URI with scheme (e.g., 'myapp://callback')"
        }

        // Validation for postLogoutRedirectUri (only if provided)
        postLogoutRedirectUri?.let { uri ->
            require(uri.isNotBlank()) {
                "postLogoutRedirectUri cannot be blank if provided"
            }
            require(uri.contains("://")) {
                "postLogoutRedirectUri must be a valid URI with scheme (e.g., 'myapp://logout')"
            }
        }
    }

    /**
     * The URL to fetch the OpenID configuration from.
     */
    val openIdConfigurationUrl: String by lazy {
        "${environment.baseUrl}/.well-known/openid-configuration"
    }

    internal companion object {
        /**
         * Creates a configuration for the development environment.
         */
        fun dev(
            appIdentity: AppIdentity,
            clientId: String = "dev-client-id",
            redirectUri: String = "ch.swisstxt.sdktestapplication://oauth/callback",
            postLogoutRedirectUri: String? = null,
            enableLogging: Boolean = true,
        ): SrgLoginConfig =
            SrgLoginConfig(
                clientId = clientId,
                redirectUri = redirectUri,
                appIdentity = appIdentity,
                postLogoutRedirectUri = postLogoutRedirectUri,
                environment = Environment.DEV,
                enableLogging = enableLogging,
            )

        /**
         * Creates a configuration for the integration environment.
         */
        fun int(
            appIdentity: AppIdentity,
            clientId: String = "int-client-id",
            redirectUri: String = "ch.swisstxt.sdktestapplication://oauth/callback",
            postLogoutRedirectUri: String? = null,
        ): SrgLoginConfig =
            SrgLoginConfig(
                clientId = clientId,
                redirectUri = redirectUri,
                appIdentity = appIdentity,
                postLogoutRedirectUri = postLogoutRedirectUri,
                environment = Environment.INT,
            )

        /**
         * Creates a configuration for the production environment.
         */
        fun prod(
            appIdentity: AppIdentity,
            clientId: String = "prod-client-id",
            redirectUri: String = "ch.swisstxt.sdktestapplication://oauth/callback",
            postLogoutRedirectUri: String? = null,
        ): SrgLoginConfig =
            SrgLoginConfig(
                clientId = clientId,
                redirectUri = redirectUri,
                appIdentity = appIdentity,
                postLogoutRedirectUri = postLogoutRedirectUri,
                environment = Environment.PROD,
            )
    }
}

// Extension functions for improved developer experience with SrgLoginConfig.

/**
 * Creates a copy of this configuration with the specified logout redirect URI.
 *
 * @param uri The post-logout redirect URI to set
 * @return A new SrgLoginConfig instance with the updated logout redirect URI
 */
fun SrgLoginConfig.withLogoutRedirect(uri: String): SrgLoginConfig = copy(postLogoutRedirectUri = uri)

/**
 * Creates a copy of this configuration with the specified logout redirect URI if the condition is true.
 *
 * @param condition The condition to check
 * @param uri The post-logout redirect URI to set if condition is true
 * @return A new SrgLoginConfig instance, potentially with updated logout redirect URI
 */
fun SrgLoginConfig.withLogoutRedirectIf(
    condition: Boolean,
    uri: String,
): SrgLoginConfig = if (condition) copy(postLogoutRedirectUri = uri) else this

/**
 * Creates a copy of this configuration with logging enabled.
 *
 * @return A new SrgLoginConfig instance with logging enabled
 */
fun SrgLoginConfig.withLogging(): SrgLoginConfig = copy(enableLogging = true)

/**
 * Creates a copy of this configuration with the specified token refresh configuration.
 *
 * **Example - Replace entire configuration**:
 * ```kotlin
 * val config = SrgLoginConfig.dev()
 *     .withTokenRefreshConfig(
 *         TokenRefreshConfig(
 *             mode = TokenRefreshMode.Automatic,
 *             refreshThresholdSeconds = 600,
 *             maxRetryAttempts = 5,
 *         )
 *     )
 * ```
 *
 * @param config The token refresh configuration to set
 * @return A new SrgLoginConfig instance with the updated token refresh configuration
 */
fun SrgLoginConfig.withTokenRefreshConfig(config: TokenRefreshConfig): SrgLoginConfig = copy(tokenRefreshConfig = config)

/**
 * Creates a copy of this configuration with modified token refresh configuration.
 *
 * This extension function allows inline configuration using a builder-style lambda,
 * which is convenient for modifying specific properties without recreating the entire config.
 *
 * **Example - Switch to Manual mode**:
 * ```kotlin
 * val config = SrgLoginConfig.dev()
 *     .configureTokenRefresh {
 *         copy(mode = TokenRefreshMode.Manual)
 *     }
 * ```
 *
 * **Example - Automatic with custom threshold**:
 * ```kotlin
 * val config = SrgLoginConfig.prod()
 *     .configureTokenRefresh {
 *         copy(
 *             mode = TokenRefreshMode.Automatic,
 *             refreshThresholdSeconds = 600,
 *         )
 *     }
 * ```
 *
 * @param configure A lambda that receives the current TokenRefreshConfig and returns a modified copy
 * @return A new SrgLoginConfig instance with the updated token refresh configuration
 */
fun SrgLoginConfig.configureTokenRefresh(configure: TokenRefreshConfig.() -> TokenRefreshConfig): SrgLoginConfig =
    copy(tokenRefreshConfig = tokenRefreshConfig.configure())

/**
 * Enables or disables automatic token state monitoring.
 *
 * Convenience alternative to [withTokenRefreshConfig] / [configureTokenRefresh] for the common
 * case of enabling monitoring while keeping all other [TokenRefreshConfig] defaults. Especially
 * useful on Apple platforms where [TokenRefreshConfig]'s primary constructor is unavailable from
 * Swift due to Kotlin/Native ObjC interop constraints (constructors with `init {}` validation
 * blocks are marked `NS_UNAVAILABLE`).
 *
 * **Example (Swift)**:
 * ```swift
 * let config = SrgLoginConfig(...)
 *     .withRopcFlow(clientSecret: "secret")
 *     .withAutomaticTokenMonitoring(enabled: true)
 * ```
 *
 * @param enabled Whether automatic token monitoring should be active.
 *   `true` sets [TokenRefreshMode.Automatic]; `false` sets [TokenRefreshMode.Manual].
 *   Defaults to `true`.
 * @return A new [SrgLoginConfig] with [TokenRefreshConfig.mode] updated.
 */
fun SrgLoginConfig.withAutomaticTokenMonitoring(enabled: Boolean = true): SrgLoginConfig =
    copy(
        tokenRefreshConfig =
            tokenRefreshConfig.copy(
                mode = if (enabled) TokenRefreshMode.Automatic else TokenRefreshMode.Manual,
            ),
    )

/**
 * Creates a copy of this configuration with the ROPC flow enabled.
 *
 * **SECURITY WARNING**: ROPC is deprecated by RFC 9700 Section 2.4. Only enable as a
 * last-resort fallback (e.g., tvOS where no browser is available for authorization code flow).
 *
 * **Confidential clients**: If the OAuth client is registered as a confidential client on the IDP,
 * provide the [clientSecret]. For public clients, omit it (defaults to `null`).
 *
 * **Example**:
 * ```kotlin
 * val config = SrgLoginConfig(
 *     clientId = "your-client-id",
 *     redirectUri = "app://callback",
 *     appIdentity = appIdentity,
 *     environment = Environment.INT,
 * ).withRopcFlow(clientSecret = "your-client-secret")
 * ```
 *
 * @param clientSecret The client secret for confidential clients, or `null` for public clients.
 * @return A new SrgLoginConfig instance with ROPC enabled and the client secret set.
 */
fun SrgLoginConfig.withRopcFlow(clientSecret: String? = null): SrgLoginConfig = copy(enableRopcFlow = true, clientSecret = clientSecret)

/**
 * Represents the available authentication environments.
 *
 * @property baseUrl The base URL of the environment.
 */
enum class Environment(
    val baseUrl: String,
) {
    /**
     * Development environment.
     */
    DEV("https://account-dev.srgssr.ch"),

    /**
     * Integration environment.
     */
    INT("https://account-int.srgssr.ch"),

    /**
     * Production environment.
     */
    PROD("https://account.srgssr.ch"),
}
