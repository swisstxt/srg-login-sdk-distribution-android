package ch.srg.login.sdk.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Represents a JSON Web Key Set (JWKS) used for JWT signature validation.
 * https://datatracker.ietf.org/doc/html/rfc7517
 */
@Serializable
internal data class JwkSet(
    @SerialName("keys")
    val keys: List<JsonWebKey>,
)

/**
 * Represents a single JSON Web Key (JWK) used for cryptographic operations.
 */
@Serializable
internal data class JsonWebKey(
    // "RSA" or "EC"
    @SerialName("kty")
    val keyType: String,
    // "sig" for signature
    @SerialName("use")
    val publicKeyUse: String? = null,
    @SerialName("key_ops")
    val keyOperations: List<String>? = null,
    // "RS256", "ES256", etc.
    @SerialName("alg")
    val algorithm: String? = null,
    // Key identifier
    @SerialName("kid")
    val keyId: String? = null,
    @SerialName("x5c")
    val x509CertificateChain: List<String>? = null,
    @SerialName("x5t")
    val x509CertificateThumbprint: String? = null,
    @SerialName("x5t#S256")
    val x509CertificateThumbprintSha256: String? = null,
    // RSA specific parameters
    @SerialName("n")
    val rsaModulus: String? = null,
    @SerialName("e")
    val rsaExponent: String? = null,
    // EC specific parameters
    // "P-256", "P-384", "P-521"
    @SerialName("crv")
    val ellipticCurve: String? = null,
    @SerialName("x")
    val ecXCoordinate: String? = null,
    @SerialName("y")
    val ecYCoordinate: String? = null,
)
