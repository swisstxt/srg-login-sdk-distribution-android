package ch.srg.login.sdk.token

/**
 * Base sealed class for all token storage related exceptions.
 */
sealed class TokenStorageException(
    message: String,
    cause: Throwable? = null,
) : Exception(message, cause) {
    /**
     * Thrown when encryption/decryption operations fail.
     */
    class EncryptionException(
        message: String = "Failed to encrypt/decrypt token data",
        cause: Throwable? = null,
    ) : TokenStorageException(message, cause)

    /**
     * Thrown when file I/O operations fail.
     */
    class FileAccessException(
        message: String = "Failed to access token storage file",
        cause: Throwable? = null,
    ) : TokenStorageException(message, cause)

    /**
     * Thrown when keystore operations fail.
     */
    class KeystoreException(
        message: String = "Failed to access Android Keystore",
        cause: Throwable? = null,
    ) : TokenStorageException(message, cause)

    /**
     * Thrown when token data is corrupted or invalid.
     */
    class CorruptedDataException(
        message: String = "Token data is corrupted or invalid",
        cause: Throwable? = null,
    ) : TokenStorageException(message, cause)

    /**
     * Thrown when storage initialization fails.
     */
    class InitializationException(
        message: String = "Failed to initialize token storage",
        cause: Throwable? = null,
    ) : TokenStorageException(message, cause)
}
