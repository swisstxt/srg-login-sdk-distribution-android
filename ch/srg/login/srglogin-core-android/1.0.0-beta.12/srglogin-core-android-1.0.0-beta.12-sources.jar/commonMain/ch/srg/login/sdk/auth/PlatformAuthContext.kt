package ch.srg.login.sdk.auth

/**
 * Platform-specific authentication context interface.
 * Each platform provides its own implementation with the necessary
 * context information for authentication operations.
 */
expect interface PlatformAuthContext {
    /**
     * The type of platform this context represents.
     */
    val platformType: PlatformType
}

/**
 * Enumeration of supported platform types for authentication.
 */
enum class PlatformType {
    /** Android mobile/tablet devices */
    ANDROID_MOBILE,

    /** Android TV and Google TV devices */
    ANDROID_TV,

    /** iOS mobile devices */
    IOS,

    /** tvOS (Apple TV) devices */
    TVOS,

    /** JVM desktop applications */
    JVM,

    /** Web/JavaScript applications (browsers) */
    WEB,
}

/**
 * Marker interface for contexts that support web-based authentication flows.
 * Platforms implementing this interface can use Chrome Custom Tabs, Safari, or similar browsers.
 */
interface WebAuthCapable

/**
 * Marker interface for contexts that support device code authentication flows.
 * Platforms implementing this interface can display device codes and verification URLs to users.
 */
interface DeviceCodeCapable

/**
 * Marker interface for TV and limited-input device contexts.
 * These platforms typically require device code flow due to input limitations.
 */
interface TvPlatform : DeviceCodeCapable
