package ch.srg.login.sdk.auth.flows

import ch.srg.login.sdk.SrgLoginConfig
import ch.srg.login.sdk.auth.LoginMethod
import ch.srg.login.sdk.auth.LoginState
import ch.srg.login.sdk.auth.PlatformAuthContext
import ch.srg.login.sdk.auth.WebAuthCapable
import ch.srg.login.sdk.auth.WebAuthenticator
import ch.srg.login.sdk.auth.handler.LoginFailureEmitter
import ch.srg.login.sdk.auth.handler.TokenSuccessHandler
import ch.srg.login.sdk.data.OpenIdConfigRepository
import ch.srg.login.sdk.data.api.SrgAuthApiService
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.events.EventEmitter
import ch.srg.login.sdk.events.SdkLifecycleEvent
import ch.srg.login.sdk.internal.SecurityUtils
import ch.srg.login.sdk.logging.ErrorHandler
import ch.srg.login.sdk.logging.ErrorHandlerRegistry
import ch.srg.login.sdk.logging.LogCategory
import ch.srg.login.sdk.logging.SdkLogger
import ch.srg.login.sdk.result.SdkResult
import io.ktor.http.decodeURLQueryComponent
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow

/**
 * Login flow for web-based OIDC authorization code flow with PKCE.
 *
 * Validates [LoginMethod.Web] + [WebAuthCapable] context, generates PKCE parameters,
 * builds authorization URL, launches browser, validates state (CSRF), exchanges code
 * for tokens, validates tokens, and delegates success/failure handling.
 */
@Suppress("LongParameterList")
internal class AuthorizationCodeFlow(
    private val config: SrgLoginConfig,
    private val openIdConfigRepository: OpenIdConfigRepository,
    private val authApiService: SrgAuthApiService,
    private val webAuthenticator: WebAuthenticator,
    private val securityUtils: SecurityUtils,
    private val tokenSuccessHandler: TokenSuccessHandler,
    private val loginFailureEmitter: LoginFailureEmitter,
    private val eventEmitter: EventEmitter,
) : LoginFlow {
    companion object {
        private const val FLOW_ID_LENGTH = 6
    }

    /**
     * Executes the PKCE Authorization Code Flow: generates state (CSRF) + nonce (OIDC replay
     * defense) + PKCE parameters, builds the authorization URL, launches the browser,
     * validates state on callback, and exchanges the code for tokens.
     *
     * @param loginMethod Must be [LoginMethod.Web]; any other type returns [LoginState.Failure].
     * @param authContext Must be [WebAuthCapable]; TV contexts are rejected.
     */
    @Suppress("LongMethod", "CyclomaticComplexMethod")
    override fun login(
        loginMethod: LoginMethod,
        authContext: PlatformAuthContext,
        additionalScopes: List<String>,
        additionalParameters: Map<String, String>,
    ): Flow<LoginState> =
        flow {
            val flowId =
                kotlinx.datetime.Clock.System
                    .now()
                    .toEpochMilliseconds()
                    .toString()
                    .takeLast(FLOW_ID_LENGTH)
            SdkLogger.d(LogCategory.AUTHENTICATION) {
                "Login flow started (Flow-$flowId) with scopes: $additionalScopes, " +
                    "additionalParams: ${additionalParameters.keys}"
            }

            // Emit LoginStarted before validation — consistent with DeviceAuthorizationFlow and RopcFlow.
            // Ensures all 3 flows emit LoginStarted as the first action, so event observers (analytics,
            // monitoring) always see a LoginStarted regardless of whether subsequent validation passes.
            val loginStartedTimestamp =
                kotlinx.datetime.Clock.System
                    .now()
                    .toEpochMilliseconds()
            eventEmitter.tryEmit(SdkLifecycleEvent.LoginStarted(loginStartedTimestamp))

            // Validate login method type
            if (loginMethod !is LoginMethod.Web) {
                SdkLogger.d(LogCategory.AUTHENTICATION) { "Invalid login method type (Flow-$flowId)" }
                emit(
                    loginFailureEmitter.emit(
                        SrgLoginError.InvalidConfiguration("AuthorizationCodeFlow only supports the Web login method."),
                    ),
                )
                return@flow
            }

            // Validate platform context capabilities
            if (authContext !is WebAuthCapable) {
                SdkLogger.d(LogCategory.AUTHENTICATION) { "Invalid auth context - not WebAuthCapable (Flow-$flowId)" }
                emit(
                    loginFailureEmitter.emit(
                        SrgLoginError.InvalidConfiguration(
                            "Web authentication requires a WebAuthCapable context. " +
                                "TV platforms should use LoginMethod.Device instead of LoginMethod.Web.",
                        ),
                    ),
                )
                return@flow
            }

            SdkLogger.d(LogCategory.AUTHENTICATION) { "LoginMethod and context validated (Flow-$flowId)" }

            // 1. Get OpenID Configuration
            val openIdConfigResult = openIdConfigRepository.getConfiguration()
            val openIdConfig =
                when (openIdConfigResult) {
                    is SdkResult.Success -> {
                        openIdConfigResult.data
                    }

                    is SdkResult.Failure -> {
                        ErrorHandlerRegistry.captureException(
                            throwable =
                                when (val error = openIdConfigResult.error) {
                                    is SrgLoginError.NetworkError -> {
                                        error.cause ?: Exception(error.details ?: "Network error")
                                    }

                                    is SrgLoginError.HttpError -> {
                                        Exception("HTTP ${error.code}: ${error.message}")
                                    }

                                    else -> {
                                        Exception(error.toString())
                                    }
                                },
                            context =
                                mapOf(
                                    "operation" to "fetch_openid_config",
                                    "stage" to "login_init",
                                    "error_type" to openIdConfigResult.error::class.simpleName,
                                ),
                            level = ErrorHandler.ErrorLevel.ERROR,
                        )
                        emit(loginFailureEmitter.emit(openIdConfigResult.error))
                        return@flow
                    }
                }

            // 2. Generate PKCE, state, and nonce
            val currentPkce = securityUtils.generatePkce()
            val currentState = securityUtils.generateState()
            val currentNonce = securityUtils.generateState()

            SdkLogger.d(LogCategory.AUTHENTICATION) {
                "Generated security params (Flow-$flowId): " +
                    "state=[REDACTED], " +
                    "nonce=[REDACTED], " +
                    "code_verifier=[REDACTED], " +
                    "code_challenge=[REDACTED]"
            }

            // 3. Build Authorization URL
            val allScopes = (listOf("openid") + additionalScopes).distinct()
            val authUrl =
                buildString {
                    append(openIdConfig.authorizationEndpoint)
                    append("?client_id=${config.clientId}")
                    append("&redirect_uri=${config.redirectUri}")
                    append("&response_type=code")
                    append("&scope=${allScopes.joinToString(" ")}")
                    append("&state=$currentState")
                    append("&nonce=$currentNonce")
                    append("&code_challenge=${currentPkce.codeChallenge}")
                    append("&code_challenge_method=S256")

                    val reservedParams =
                        setOf(
                            "client_id",
                            "redirect_uri",
                            "response_type",
                            "state",
                            "nonce",
                            "code_challenge",
                            "code_challenge_method",
                            "scope",
                        )
                    val filteredParams =
                        additionalParameters.filterKeys { key ->
                            val isReserved = key.lowercase() in reservedParams
                            if (isReserved) {
                                SdkLogger.d(LogCategory.AUTHENTICATION) {
                                    "Ignoring reserved OAuth parameter '$key' in additionalParameters (Flow-$flowId)"
                                }
                            }
                            !isReserved
                        }
                    filteredParams.forEach { (key, value) ->
                        if (value.isEmpty()) {
                            SdkLogger.d(LogCategory.AUTHENTICATION) {
                                "Ignoring parameter '$key' with empty value (Flow-$flowId)"
                            }
                        } else {
                            append("&${key.urlEncode()}=${value.urlEncode()}")
                        }
                    }
                }

            val sanitizedUrl = SecurityUtils.sanitizeUrl(authUrl)
            SdkLogger.d(LogCategory.AUTHENTICATION) { "Authorization URL: $sanitizedUrl (Flow-$flowId)" }
            SdkLogger.d(LogCategory.AUTHENTICATION) { "Opening browser for authentication (Flow-$flowId)" }

            // 4. Launch browser
            val authResult = webAuthenticator.authenticate(authUrl, authContext)

            // 5. Handle browser result
            when (authResult) {
                is SdkResult.Failure -> {
                    ErrorHandlerRegistry.captureException(
                        throwable =
                            when (val error = authResult.error) {
                                is SrgLoginError.UserCancelled -> {
                                    Exception("User cancelled authentication")
                                }

                                is SrgLoginError.NetworkError -> {
                                    error.cause ?: Exception(error.details ?: "Network error")
                                }

                                else -> {
                                    Exception(error.toString())
                                }
                            },
                        context =
                            mapOf(
                                "operation" to "browser_authentication",
                                "stage" to "login_browser",
                                "error_type" to authResult.error::class.simpleName,
                            ),
                        level =
                            if (authResult.error is SrgLoginError.UserCancelled) {
                                ErrorHandler.ErrorLevel.INFO
                            } else {
                                ErrorHandler.ErrorLevel.ERROR
                            },
                    )
                    emit(loginFailureEmitter.emit(authResult.error))
                }

                is SdkResult.Success -> {
                    val callbackUrl = authResult.data
                    val code = getQueryParameter(callbackUrl, "code")
                    val receivedState = getQueryParameter(callbackUrl, "state")
                    val oauthError = getQueryParameter(callbackUrl, "error")

                    SdkLogger.d(LogCategory.AUTHENTICATION) {
                        "Callback received (Flow-$flowId): " +
                            "URL=${SecurityUtils.sanitizeUrl(callbackUrl)}, code=[REDACTED], " +
                            "stateMatch=${receivedState == currentState}, " +
                            "receivedStateIsNull=${receivedState == null}" +
                            if (oauthError != null) ", oauthError=$oauthError" else ""
                    }

                    // 5a. Check for OAuth error response from IDP (RFC 6749 §4.1.2.1).
                    // Must be checked before state validation: some IDPs omit `state` in error
                    // responses, which would otherwise trigger a misleading CSRF alarm.
                    if (oauthError != null) {
                        val errorDescription = getQueryParameter(callbackUrl, "error_description")
                        SdkLogger.d(LogCategory.AUTHENTICATION) {
                            "IDP returned error response: $oauthError (Flow-$flowId)"
                        }
                        emit(
                            loginFailureEmitter.emit(
                                SrgLoginError.InvalidDataError(
                                    errorDescription ?: "Authorization failed: $oauthError",
                                ),
                            ),
                        )
                        return@flow
                    }

                    // 5b. Verify state (CSRF)
                    if (receivedState == null || receivedState != currentState) {
                        SdkLogger.d(LogCategory.AUTHENTICATION) {
                            "State validation FAILED - possible CSRF attack (Flow-$flowId)"
                        }
                        emit(
                            loginFailureEmitter.emit(
                                SrgLoginError.InvalidDataError(
                                    "Invalid state received from callback. Possible CSRF attack.",
                                ),
                            ),
                        )
                        return@flow
                    }

                    SdkLogger.d(LogCategory.AUTHENTICATION) { "State validation SUCCESS (Flow-$flowId)" }

                    if (code == null) {
                        emit(
                            loginFailureEmitter.emit(
                                SrgLoginError.InvalidDataError("Authorization code not found in callback URL."),
                            ),
                        )
                        return@flow
                    }

                    // 5c. Exchange code for token
                    val tokenResponse =
                        authApiService.exchangeCodeForToken(
                            tokenEndpoint = openIdConfig.tokenEndpoint,
                            code = code,
                            redirectUri = config.redirectUri,
                            clientId = config.clientId,
                            codeVerifier = currentPkce.codeVerifier,
                        )

                    // 5d. Validate tokens, persist, and emit success via shared handler
                    val result =
                        tokenSuccessHandler.handle(
                            tokenResponse = tokenResponse,
                            clientId = config.clientId,
                            issuer = openIdConfig.issuer,
                            jwksUri = openIdConfig.jwksUri,
                            nonce = currentNonce,
                        )
                    emit(result)
                }
            }
        }.catch { e ->
            if (e is CancellationException) throw e
            val exception = e as? Exception ?: throw e
            val error = openIdConfigRepository.mapExceptionToError(exception)
            ErrorHandlerRegistry.captureException(
                throwable = exception,
                context =
                    mapOf(
                        "operation" to "login_flow",
                        "stage" to "unhandled_exception",
                        "error_type" to exception::class.simpleName,
                        "error_mapped_to" to error::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.ERROR,
            )
            emit(loginFailureEmitter.emit(error))
        }

    /**
     * Extracts the named query parameter from [url] and URL-decodes its value.
     * Returns `null` if the parameter is absent or the URL has no query string.
     */
    private fun getQueryParameter(
        url: String,
        name: String,
    ): String? {
        val query = url.substringAfter('?', "")
        return query
            .split('&')
            .mapNotNull { pair ->
                val parts = pair.split('=', limit = 2)
                if (parts.size == 2 && parts[0] == name) {
                    parts[1].decodeURLQueryComponent()
                } else {
                    null
                }
            }.firstOrNull()
    }

    /**
     * Percent-encodes this string for use as an OAuth 2.0 query parameter value.
     * Pure KMP implementation — no platform dependency.
     */
    private fun String.urlEncode(): String =
        this
            .replace(":", "%3A")
            .replace("/", "%2F")
            .replace("?", "%3F")
            .replace("#", "%23")
            .replace("[", "%5B")
            .replace("]", "%5D")
            .replace("@", "%40")
            .replace("!", "%21")
            .replace("$", "%24")
            .replace("&", "%26")
            .replace("'", "%27")
            .replace("(", "%28")
            .replace(")", "%29")
            .replace("*", "%2A")
            .replace("+", "%2B")
            .replace(",", "%2C")
            .replace(";", "%3B")
            .replace("=", "%3D")
            .replace(" ", "%20")
}
