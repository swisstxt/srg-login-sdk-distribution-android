package ch.srg.login.sdk.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Response from the device authorization endpoint (RFC 8628 §3.2).
 *
 * The client displays [userCode] and [verificationUri] to the user, who then
 * authenticates on a secondary device. The SDK polls the token endpoint using
 * [deviceCode] until the user completes authentication or the code expires.
 */
@Serializable
internal data class DeviceAuthorizationResponse(
    @SerialName("device_code") val deviceCode: String,
    @SerialName("user_code") val userCode: String,
    @SerialName("verification_uri") val verificationUri: String,
    @SerialName("verification_uri_complete") val verificationUriComplete: String? = null,
    @SerialName("expires_in") val expiresIn: Long,
    @SerialName("interval") val interval: Long = 5,
)
