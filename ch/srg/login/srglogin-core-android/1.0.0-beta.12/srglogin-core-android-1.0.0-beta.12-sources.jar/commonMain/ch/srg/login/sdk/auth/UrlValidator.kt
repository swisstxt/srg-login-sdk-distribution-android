package ch.srg.login.sdk.auth

import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.result.SdkResult

/**
 * Validates SSO client URL according to OAuth 2.0 Native Apps RFC 8252.
 *
 * Security requirements:
 * - URL must not be empty or blank
 * - URL must start with https:// or http://
 * - HTTPS is required for all URLs except localhost (RFC 8252 Section 8.3)
 * - URL must contain a valid domain after the protocol
 *
 * @param url The SSO client URL to validate
 * @return [SdkResult.Success] if valid, [SdkResult.Failure] with specific error otherwise
 *
 * @see <a href="https://tools.ietf.org/html/rfc8252#section-8.3">RFC 8252 Section 8.3</a>
 */
internal fun validateSsoClientUrl(url: String): SdkResult<Unit> {
    // Validation 1: URL cannot be empty or blank
    if (url.isBlank()) {
        return SdkResult.Failure(
            SrgLoginError.InvalidConfiguration(
                reason = "SSO client URL cannot be empty",
            ),
        )
    }

    // Validation 2: URL must start with https:// or http://
    val lowercaseUrl = url.lowercase()
    if (!lowercaseUrl.startsWith("https://") && !lowercaseUrl.startsWith("http://")) {
        return SdkResult.Failure(
            SrgLoginError.InvalidConfiguration(
                reason = "SSO client URL must start with https:// or http:// (invalid protocol in URL: $url)",
            ),
        )
    }

    // Validation 3: HTTPS required EXCEPT for localhost (RFC 8252 Section 8.3)
    // HTTP is only allowed for local development
    if (lowercaseUrl.startsWith("http://")) {
        val isLocalhost =
            lowercaseUrl.contains("://localhost") ||
                lowercaseUrl.contains("://127.0.0.1") ||
                lowercaseUrl.contains("://[::1]")

        if (!isLocalhost) {
            return SdkResult.Failure(
                SrgLoginError.InvalidConfiguration(
                    reason =
                        "SSO client URL must use HTTPS for security. " +
                            "HTTP is only allowed for localhost (RFC 8252 Section 8.3). " +
                            "Invalid URL: $url",
                ),
            )
        }
    }

    // Validation 4: URL must have content after protocol
    val afterProtocol = url.substringAfter("://")
    if (afterProtocol.isBlank() || afterProtocol == url) {
        return SdkResult.Failure(
            SrgLoginError.InvalidConfiguration(
                reason = "Invalid SSO client URL format: missing domain after protocol (URL: $url)",
            ),
        )
    }

    // Validation 5: Domain must not be empty (not just a slash)
    val domain = afterProtocol.substringBefore("/")
    if (domain.isBlank()) {
        return SdkResult.Failure(
            SrgLoginError.InvalidConfiguration(
                reason = "Invalid SSO client URL format: missing domain (URL: $url)",
            ),
        )
    }

    return SdkResult.Success(Unit)
}
