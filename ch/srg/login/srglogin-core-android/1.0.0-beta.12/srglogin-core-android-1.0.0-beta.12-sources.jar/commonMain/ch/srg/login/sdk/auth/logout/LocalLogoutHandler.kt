package ch.srg.login.sdk.auth.logout

import ch.srg.login.sdk.events.EventEmitter
import ch.srg.login.sdk.token.TokenStorage
import kotlinx.datetime.Clock

/**
 * Simplest logout handler — supports only local logout (token clearing).
 * No back-channel or front-channel capabilities.
 */
internal class LocalLogoutHandler(
    tokenStorage: TokenStorage,
    eventEmitter: EventEmitter,
    clock: Clock = Clock.System,
) : LogoutHandler(tokenStorage, eventEmitter, clock)
