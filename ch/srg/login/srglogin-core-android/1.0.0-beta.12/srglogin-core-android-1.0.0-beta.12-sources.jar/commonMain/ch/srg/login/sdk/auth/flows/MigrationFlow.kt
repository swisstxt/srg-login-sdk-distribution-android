package ch.srg.login.sdk.auth.flows

import ch.srg.login.sdk.SrgLoginConfig
import ch.srg.login.sdk.auth.LoginMethod
import ch.srg.login.sdk.auth.LoginState
import ch.srg.login.sdk.auth.OAuthErrorMapper
import ch.srg.login.sdk.auth.PlatformAuthContext
import ch.srg.login.sdk.auth.handler.LoginFailureEmitter
import ch.srg.login.sdk.auth.handler.TokenSuccessHandler
import ch.srg.login.sdk.data.OpenIdConfigRepository
import ch.srg.login.sdk.data.api.SrgAuthApiService
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.events.EventEmitter
import ch.srg.login.sdk.events.SdkLifecycleEvent
import ch.srg.login.sdk.logging.ErrorHandler
import ch.srg.login.sdk.logging.ErrorHandlerRegistry
import ch.srg.login.sdk.logging.LogCategory
import ch.srg.login.sdk.logging.SdkLogger
import ch.srg.login.sdk.result.SdkResult
import ch.srg.login.sdk.token.TokenStorage
import io.ktor.client.plugins.ClientRequestException
import io.ktor.client.plugins.ServerResponseException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.datetime.Clock

/**
 * Login flow for session migration from another SDK or plain OAuth API integration.
 *
 * Calls the refresh endpoint with the provided refresh token to obtain a fresh, fully validated
 * token set (including JWKS signature verification), then seeds the SDK's secure storage.
 * No access token is accepted — the refresh endpoint always returns a current token set with
 * a known expiry, making direct token import unnecessary.
 *
 * **Note:** `additionalScopes` and `additionalParameters` are part of the [LoginFlow] interface
 * contract but are not applicable to migration and are intentionally ignored.
 */
@Suppress("LongParameterList")
internal class MigrationFlow(
    private val config: SrgLoginConfig,
    private val openIdConfigRepository: OpenIdConfigRepository,
    private val authApiService: SrgAuthApiService,
    private val tokenSuccessHandler: TokenSuccessHandler,
    private val tokenStorage: TokenStorage,
    private val loginFailureEmitter: LoginFailureEmitter,
    private val eventEmitter: EventEmitter,
    private val clock: Clock = Clock.System,
) : LoginFlow {
    @Suppress("TooGenericExceptionCaught", "LongMethod", "CyclomaticComplexMethod")
    override fun login(
        loginMethod: LoginMethod,
        authContext: PlatformAuthContext,
        additionalScopes: List<String>,
        additionalParameters: Map<String, String>,
    ): Flow<LoginState> =
        flow {
            val loginStartedTimestamp = clock.now().toEpochMilliseconds()
            eventEmitter.tryEmit(SdkLifecycleEvent.LoginStarted(loginStartedTimestamp))

            if (loginMethod !is LoginMethod.Migration) {
                SdkLogger.d(LogCategory.AUTHENTICATION) { "MigrationFlow only supports Migration login method" }
                emit(
                    loginFailureEmitter.emit(
                        SrgLoginError.InvalidConfiguration(
                            "MigrationFlow only supports the Migration login method.",
                        ),
                    ),
                )
                return@flow
            }

            SdkLogger.d(LogCategory.AUTHENTICATION) { "Migration flow started" }

            if (loginMethod.refreshToken.isBlank()) {
                emit(
                    loginFailureEmitter.emit(
                        SrgLoginError.InvalidConfiguration(
                            "Migration: refreshToken must not be blank.",
                        ),
                    ),
                )
                return@flow
            }

            if (tokenStorage.getTokens() != null) {
                emit(
                    loginFailureEmitter.emit(
                        SrgLoginError.InvalidConfiguration(
                            "Migration: tokens are already present in SDK storage. " +
                                "Call localLogout() to clear the SDK's storage before migrating.",
                        ),
                    ),
                )
                return@flow
            }

            val openIdConfig =
                when (val result = openIdConfigRepository.getConfiguration()) {
                    is SdkResult.Success -> {
                        result.data
                    }

                    is SdkResult.Failure -> {
                        val throwable =
                            when (val error = result.error) {
                                is SrgLoginError.NetworkError -> {
                                    error.cause ?: Exception(error.details ?: "Network error")
                                }

                                is SrgLoginError.HttpError -> {
                                    Exception("HTTP ${error.code}: ${error.message}")
                                }

                                else -> {
                                    Exception(error.toString())
                                }
                            }
                        ErrorHandlerRegistry.captureException(
                            throwable = throwable,
                            context =
                                mapOf(
                                    "operation" to "fetch_openid_config",
                                    "stage" to "migration_flow",
                                ),
                            level = ErrorHandler.ErrorLevel.ERROR,
                        )
                        emit(loginFailureEmitter.emit(result.error))
                        return@flow
                    }
                }

            SdkLogger.d(LogCategory.AUTHENTICATION) { "Migration: calling refresh endpoint" }
            val tokenResponse =
                authApiService.refreshAccessToken(
                    tokenEndpoint = openIdConfig.tokenEndpoint,
                    refreshToken = loginMethod.refreshToken,
                    clientId = config.clientId,
                )

            emit(
                tokenSuccessHandler.handle(
                    tokenResponse = tokenResponse,
                    clientId = config.clientId,
                    issuer = openIdConfig.issuer,
                    jwksUri = openIdConfig.jwksUri,
                ),
            )
        }.catch { e ->
            if (e is CancellationException) throw e
            val exception = e as? Exception ?: throw e
            val error =
                when (exception) {
                    is ClientRequestException -> OAuthErrorMapper.mapClientRequestException(exception)
                    is ServerResponseException -> OAuthErrorMapper.mapServerResponseException(exception)
                    else -> openIdConfigRepository.mapExceptionToError(exception)
                }
            ErrorHandlerRegistry.captureException(
                throwable = exception,
                context =
                    mapOf(
                        "operation" to "migration_flow",
                        "stage" to "unhandled_exception",
                        "error_type" to e::class.simpleName,
                        "error_mapped_to" to error::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.ERROR,
            )
            emit(loginFailureEmitter.emit(error))
        }
}
