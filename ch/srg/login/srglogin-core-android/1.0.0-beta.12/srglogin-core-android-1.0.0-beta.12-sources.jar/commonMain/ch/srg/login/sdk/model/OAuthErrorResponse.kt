package ch.srg.login.sdk.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * OAuth 2.0 error response as defined in RFC 6749 Section 5.2.
 *
 * When the authorization server returns an error, it includes an error response with:
 * - `error`: A single ASCII error code (required)
 * - `error_description`: Human-readable ASCII text description (optional)
 * - `error_uri`: URI identifying a human-readable web page with error information (optional)
 *
 * **Common OAuth Error Codes**:
 * - `invalid_request`: The request is missing a required parameter, includes an unsupported parameter value
 * - `invalid_client`: Client authentication failed
 * - `invalid_grant`: The provided authorization grant or refresh token is invalid, expired, or revoked
 * - `unauthorized_client`: The client is not authorized to request an authorization code using this method
 * - `unsupported_grant_type`: The authorization grant type is not supported by the authorization server
 * - `invalid_scope`: The requested scope is invalid, unknown, or malformed
 *
 * @property error The error code (e.g., "invalid_grant")
 * @property errorDescription Human-readable error description
 * @property errorUri URI with more information about the error
 *
 * @see <a href="https://datatracker.ietf.org/doc/html/rfc6749#section-5.2">RFC 6749 Section 5.2 - Error Response</a>
 */
@Serializable
internal data class OAuthErrorResponse(
    @SerialName("error")
    val error: String,
    @SerialName("error_description")
    val errorDescription: String? = null,
    @SerialName("error_uri")
    val errorUri: String? = null,
)
