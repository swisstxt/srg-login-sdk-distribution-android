package ch.srg.login.sdk.internal

import ch.srg.login.sdk.logging.SdkLogger
import ch.srg.login.sdk.logging.TelemetryContext

/**
 * Platform-specific system information for logging and telemetry.
 *
 * Provides essential platform details for structured logging, debugging, and
 * observability. Each platform provides its own implementation with accurate
 * system information.
 *
 * ## Architecture Role
 *
 * PlatformInfo serves the **Core/Logging Layer** and is completely independent
 * from authentication concerns. It is used primarily by:
 * - SdkLogger initialization (TelemetryContext enrichment)
 * - Observability and monitoring
 * - Platform-specific debugging
 *
 * ## Usage
 *
 * ```kotlin
 * // Retrieve platform information (internal SDK use only)
 * val platformName = PlatformInfo.getPlatformName()    // "Android", "iOS", etc.
 * val osVersion = PlatformInfo.getOsVersion()          // "Android 14", "iOS 17.2"
 * val deviceModel = PlatformInfo.getDeviceModel()      // "Pixel 8", "iPhone 15"
 * ```
 *
 * ## Platform Implementations
 *
 * ### Android
 * - Platform: "Android"
 * - OS Version: "Android {Build.VERSION.RELEASE}" → "Android 14"
 * - Device Model: "{Build.MANUFACTURER} {Build.MODEL}" → "Google Pixel 8"
 *
 * ### iOS
 * - Platform: "iOS"
 * - OS Version: "iOS {UIDevice.systemVersion}" → "iOS 17.2"
 * - Device Model: "{UIDevice.model}" → "iPhone 15"
 *
 * ### JVM
 * - Platform: "JVM"
 * - OS Version: "{os.name} {os.version}" → "macOS 14.2"
 * - Device Model: "{os.arch}" → "aarch64"
 *
 * ### JavaScript
 * - Platform: "JavaScript"
 * - OS Version: Parsed from navigator.userAgent
 * - Device Model: "Browser"
 *
 * ## Thread Safety
 *
 * All methods are **thread-safe** and can be called from any thread.
 * Results are typically computed once and cached internally by the platform.
 *
 * ## Privacy & GDPR
 *
 * Platform information collected here is considered **diagnostic data** and
 * does not contain Personally Identifiable Information (PII):
 * - OS version: Acceptable diagnostic data
 * - Device model: Acceptable diagnostic data (not unique to user)
 * - Platform name: Technical information
 *
 * This data does **not** require additional privacy declarations in app stores.
 *
 * @see TelemetryContext
 * @see SdkLogger
 */
internal expect object PlatformInfo {
    /**
     * Returns the platform name.
     *
     * Identifies the runtime platform for the SDK. Used for filtering logs
     * by platform and understanding platform-specific behavior.
     *
     * @return Platform name: "Android", "iOS", "JVM", or "JavaScript"
     *
     * @example
     * ```kotlin
     * val platform = PlatformInfo.getPlatformName()
     * // Android: "Android"
     * // iOS: "iOS"
     * // JVM: "JVM"
     * // JS: "JavaScript"
     * ```
     */
    fun getPlatformName(): String

    /**
     * Returns the operating system version.
     *
     * Provides the OS version for debugging platform-specific issues and
     * understanding the runtime environment. Format varies by platform.
     *
     * @return OS version string with platform-specific format
     *
     * @example
     * ```kotlin
     * val osVersion = PlatformInfo.getOsVersion()
     * // Android: "Android 14"
     * // iOS: "iOS 17.2"
     * // JVM: "macOS 14.2" or "Windows 11"
     * // JS: "Chrome 120.0.0.0"
     * ```
     */
    fun getOsVersion(): String

    /**
     * Returns the device model or architecture.
     *
     * Identifies the device hardware for debugging device-specific issues.
     * The format and level of detail varies by platform.
     *
     * @return Device model string (manufacturer + model on mobile, architecture on desktop)
     *
     * @example
     * ```kotlin
     * val deviceModel = PlatformInfo.getDeviceModel()
     * // Android: "Google Pixel 8" or "Samsung SM-S918B"
     * // iOS: "iPhone 15" or "iPad Pro"
     * // JVM: "aarch64" or "x86_64"
     * // JS: "Browser"
     * ```
     */
    fun getDeviceModel(): String
}
