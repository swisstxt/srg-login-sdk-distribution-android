package ch.srg.login.sdk.auth

import ch.srg.login.sdk.result.SdkResult

/**
 * Base implementation of [WebAuthenticator] that provides automatic URL validation
 * for SSO client operations.
 *
 * This abstract class implements the Template Method pattern:
 * - Public methods ([authenticate], [logout], [openSsoClient]) handle common validation
 * - Protected abstract methods (*Platform) delegate to platform-specific implementations
 *
 * All platform implementations (Android, iOS, JVM, JS) should extend this class
 * to ensure consistent URL validation across all platforms.
 *
 * ## Architecture
 *
 * ```
 * User Code
 *    ↓
 * openSsoClient(url, context)  ← Public API (validates URL automatically)
 *    ↓
 * validateSsoClientUrl(url)    ← Automatic validation (RFC 8252)
 *    ↓
 * openSsoClientPlatform(...)   ← Platform-specific implementation
 * ```
 *
 * ## Example
 *
 * ```kotlin
 * // Android implementation
 * internal class WebAuthenticatorImpl : BaseWebAuthenticator() {
 *     override suspend fun openSsoClientPlatform(...): SdkResult<Unit> {
 *         // URL already validated by BaseWebAuthenticator
 *         // Implement Android-specific logic here
 *     }
 * }
 * ```
 *
 * @see WebAuthenticator
 * @see validateSsoClientUrl
 */
internal abstract class BaseWebAuthenticator : WebAuthenticator {
    /**
     * Authenticates user via OAuth 2.0/OIDC flow.
     *
     * Delegates to platform-specific implementation without validation.
     * URL validation happens at authorization URL generation time.
     *
     * @param authUrl The OAuth authorization URL
     * @param authContext Platform-specific authentication context
     * @return Success with callback URL or Failure with error
     */
    final override suspend fun authenticate(
        authUrl: String,
        authContext: PlatformAuthContext,
    ): SdkResult<String> = authenticatePlatform(authUrl, authContext)

    /**
     * Logs out user via front-channel logout flow.
     *
     * Delegates to platform-specific implementation without validation.
     * URL validation happens at logout URL generation time.
     *
     * @param logoutUrl The logout endpoint URL
     * @param authContext Platform-specific authentication context
     * @return Success or Failure with error
     */
    final override suspend fun logout(
        logoutUrl: String,
        authContext: PlatformAuthContext,
    ): SdkResult<Unit> = logoutPlatform(logoutUrl, authContext)

    /**
     * Opens SSO client page in browser with automatic URL validation.
     *
     * **Validation performed automatically:**
     * - URL cannot be empty
     * - Must start with https:// (or http:// for localhost only)
     * - Must contain valid domain
     *
     * If validation fails, returns [SdkResult.Failure] immediately without
     * calling platform implementation.
     *
     * @param ssoClientUrl The SSO client page URL to open
     * @param authContext Platform-specific authentication context
     * @return Success or Failure with validation/platform error
     */
    final override suspend fun openSsoClient(
        ssoClientUrl: String,
        authContext: PlatformAuthContext,
    ): SdkResult<Unit> {
        // Automatic URL validation (RFC 8252 compliance)
        val validationResult = validateSsoClientUrl(ssoClientUrl)
        if (validationResult is SdkResult.Failure) {
            return validationResult
        }

        // Delegate to platform-specific implementation
        return openSsoClientPlatform(ssoClientUrl, authContext)
    }

    // ========== Protected Abstract Methods - Platform Implementations ==========

    /**
     * Platform-specific implementation of authentication flow.
     *
     * Implement this method to handle OAuth 2.0/OIDC authentication using
     * platform-specific browser APIs (e.g., Chrome Custom Tabs, ASWebAuthenticationSession).
     *
     * @param authUrl The OAuth authorization URL (already validated)
     * @param authContext Platform-specific authentication context
     * @return Success with callback URL or Failure with error
     */
    protected abstract suspend fun authenticatePlatform(
        authUrl: String,
        authContext: PlatformAuthContext,
    ): SdkResult<String>

    /**
     * Platform-specific implementation of logout flow.
     *
     * Implement this method to handle front-channel logout using
     * platform-specific browser APIs.
     *
     * @param logoutUrl The logout endpoint URL (already validated)
     * @param authContext Platform-specific authentication context
     * @return Success or Failure with error
     */
    protected abstract suspend fun logoutPlatform(
        logoutUrl: String,
        authContext: PlatformAuthContext,
    ): SdkResult<Unit>

    /**
     * Platform-specific implementation of SSO client opening.
     *
     * Implement this method to open SSO client pages (profile, settings, admin)
     * using platform-specific browser APIs.
     *
     * **Important:** URL validation is already performed by [openSsoClient].
     * You can safely assume the URL is valid and complies with RFC 8252.
     *
     * @param ssoClientUrl The SSO client page URL (already validated)
     * @param authContext Platform-specific authentication context
     * @return Success or Failure with platform error
     */
    protected abstract suspend fun openSsoClientPlatform(
        ssoClientUrl: String,
        authContext: PlatformAuthContext,
    ): SdkResult<Unit>
}
