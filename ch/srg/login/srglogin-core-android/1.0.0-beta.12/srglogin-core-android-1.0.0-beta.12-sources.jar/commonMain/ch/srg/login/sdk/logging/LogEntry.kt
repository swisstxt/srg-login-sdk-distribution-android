package ch.srg.login.sdk.logging

/**
 * Structured log entry containing all metadata for a single log event.
 *
 * LogEntry represents a complete, immutable snapshot of a log event with all associated
 * metadata, context, and optional data. It serves as the foundation for extensible
 * logging, enabling custom log writers, metrics collection, and distributed tracing.
 *
 * ## Architecture Role
 *
 * LogEntry is the data structure that flows through the logging pipeline:
 *
 * ```
 * SdkLogger.log() → Creates LogEntry → Distributes to:
 *   ├─ Kermit (console/logcat)
 *   ├─ Custom Writers (Sentry, files, analytics)
 *   └─ Future: Metrics/Tracing collectors
 * ```
 *
 * ## Usage Examples
 *
 * ### Basic Log Entry (created internally by SdkLogger)
 *
 * ```kotlin
 * // Application code calls:
 * SdkLogger.i(LogCategory.TOKEN_MONITORING) { "Token refreshed" }
 *
 * // SdkLogger internally creates:
 * val entry = LogEntry(
 *     timestamp = Clock.System.now().toEpochMilliseconds(),
 *     severity = LogSeverity.INFO,
 *     category = LogCategory.TOKEN_MONITORING,
 *     message = "Token refreshed",
 *     throwable = null,
 *     context = currentTelemetryContext,
 *     metadata = emptyMap()
 * )
 * ```
 *
 * ### Log Entry with Exception
 *
 * ```kotlin
 * // Application code:
 * SdkLogger.e(LogCategory.NETWORK, throwable = exception) {
 *     "API call failed"
 * }
 *
 * // LogEntry created:
 * LogEntry(
 *     timestamp = 1638360000000L,
 *     severity = LogSeverity.ERROR,
 *     category = LogCategory.NETWORK,
 *     message = "API call failed",
 *     throwable = IOException("Connection timeout"),
 *     context = telemetryContext,
 *     metadata = emptyMap()
 * )
 * ```
 *
 * ### Log Entry with Custom Metadata
 *
 * ```kotlin
 * // Application code:
 * SdkLogger.w(
 *     category = LogCategory.TOKEN_MONITORING,
 *     metadata = mapOf(
 *         "retryCount" to 3,
 *         "duration" to 234L,
 *         "errorCode" to "invalid_grant"
 *     )
 * ) {
 *     "Token refresh failed after retries"
 * }
 *
 * // LogEntry created:
 * LogEntry(
 *     timestamp = 1638360000000L,
 *     severity = LogSeverity.WARNING,
 *     category = LogCategory.TOKEN_MONITORING,
 *     message = "Token refresh failed after retries",
 *     throwable = null,
 *     context = telemetryContext,
 *     metadata = mapOf(
 *         "retryCount" to 3,
 *         "duration" to 234L,
 *         "errorCode" to "invalid_grant"
 *     )
 * )
 * ```
 *
 * ## Custom Log Writers (Future - Phase 2)
 *
 * LogEntry enables custom log processing without modifying SdkLogger:
 *
 * ```kotlin
 * // Send errors to Sentry
 * class SentryLogWriter : LogWriter {
 *     override fun write(entry: LogEntry) {
 *         if (entry.severity >= LogSeverity.ERROR) {
 *             Sentry.captureException(
 *                 entry.throwable ?: Exception(entry.message),
 *                 mapOf(
 *                     "category" to entry.category.tag,
 *                     "sessionId" to entry.context.sessionId,
 *                     "businessUnit" to entry.context.businessUnit,
 *                     "platform" to entry.context.platform
 *                 ) + entry.metadata
 *             )
 *         }
 *     }
 * }
 *
 * // Write logs to file
 * class FileLogWriter : LogWriter {
 *     override fun write(entry: LogEntry) {
 *         val json = Json.encodeToString(
 *             mapOf(
 *                 "timestamp" to entry.timestamp,
 *                 "severity" to entry.severity.name,
 *                 "category" to entry.category.tag,
 *                 "message" to entry.message,
 *                 "sessionId" to entry.context.sessionId,
 *                 "metadata" to entry.metadata
 *             )
 *         )
 *         fileWriter.appendLine(json)
 *     }
 * }
 *
 * // Register custom writers
 * SdkLogger.initialize(
 *     context = telemetryContext,
 *     additionalWriters = listOf(
 *         SentryLogWriter(),
 *         FileLogWriter()
 *     )
 * )
 * ```
 *
 * ## Metrics Collection (Future - Phase 2)
 *
 * LogEntry can be analyzed for metrics:
 *
 * ```kotlin
 * object LogMetricsCollector : LogWriter {
 *     override fun write(entry: LogEntry) {
 *         // Count logs by category and severity
 *         metrics.increment(
 *             "sdk.logs.count",
 *             tags = mapOf(
 *                 "category" to entry.category.tag,
 *                 "severity" to entry.severity.name,
 *                 "businessUnit" to entry.context.businessUnit
 *             )
 *         )
 *
 *         // Track error rate
 *         if (entry.severity >= LogSeverity.ERROR) {
 *             metrics.increment("sdk.errors.count", entry.context.toTags())
 *         }
 *     }
 * }
 * ```
 *
 * ## Distributed Tracing (Future - Phase 3)
 *
 * LogEntry can enrich distributed traces:
 *
 * ```kotlin
 * object TracingIntegration : LogWriter {
 *     override fun write(entry: LogEntry) {
 *         currentSpan?.addEvent(
 *             name = entry.message,
 *             timestamp = entry.timestamp,
 *             attributes = mapOf(
 *                 "log.severity" to entry.severity.name,
 *                 "log.category" to entry.category.tag,
 *                 "session.id" to entry.context.sessionId
 *             ) + entry.metadata
 *         )
 *     }
 * }
 * ```
 *
 * ## Thread Safety
 *
 * LogEntry is **immutable** (data class with val properties), making it inherently thread-safe.
 * Multiple threads can safely read the same LogEntry without synchronization.
 *
 * ## Performance
 *
 * - **Memory**: ~200-500 bytes per entry (depending on message/metadata size)
 * - **Creation**: ~0.1ms (negligible overhead)
 * - **GC Impact**: Minimal (short-lived objects, quickly collected)
 *
 * @property timestamp Unix epoch timestamp in milliseconds when the log was created
 * @property severity The severity level of this log event
 * @property category The category/module that emitted this log
 * @property message The human-readable log message
 * @property throwable Optional exception/error associated with this log
 * @property context Global telemetry context (session, platform, business unit, etc.)
 * @property metadata Per-log custom metadata as key-value pairs
 *
 * @see SdkLogger
 * @see LogSeverity
 * @see LogCategory
 * @see TelemetryContext
 * @see LogWriter
 */
internal data class LogEntry(
    /**
     * Unix epoch timestamp in milliseconds when this log was created.
     *
     * This timestamp represents the exact moment the log event occurred, allowing
     * for precise correlation with other events, metrics, and traces.
     *
     * Example:
     * ```kotlin
     * val entry = LogEntry(
     *     timestamp = Clock.System.now().toEpochMilliseconds(),  // e.g., 1638360000000L
     *     // ...
     * )
     *
     * // Convert to human-readable format
     * val instant = Instant.fromEpochMilliseconds(entry.timestamp)
     * println(instant)  // 2021-12-01T12:00:00Z
     * ```
     */
    val timestamp: Long,
    /**
     * The severity level of this log event.
     *
     * Indicates the importance/criticality of this log:
     * - VERBOSE: Very detailed, development only
     * - DEBUG: Development insights
     * - INFO: General information (production default)
     * - WARNING: Potential issues
     * - ERROR: Errors requiring attention
     * - ASSERT: Critical errors (SDK bugs)
     *
     * Used for filtering and prioritization in log processing.
     */
    val severity: LogSeverity,
    /**
     * The category/module that emitted this log.
     *
     * Categorizes the log by SDK functionality:
     * - TOKEN_MONITORING: Token lifecycle
     * - AUTHENTICATION: Login/logout flows
     * - SDK_CREATION: SDK initialization
     * - NETWORK: HTTP requests
     * - etc.
     *
     * Enables filtering logs by module and analyzing SDK behavior by category.
     */
    val category: LogCategory,
    /**
     * The human-readable log message.
     *
     * This is the primary content of the log, describing what happened.
     * The message should be:
     * - Clear and concise
     * - Actionable (explain what happened, not just "error")
     * - PII-sanitized (no tokens, emails, passwords)
     *
     * Examples:
     * - "Token refreshed successfully"
     * - "Login flow started with PKCE"
     * - "API call failed: Connection timeout after 30s"
     */
    val message: String,
    /**
     * Optional exception/error associated with this log.
     *
     * When a log is created due to an exception (typically ERROR or ASSERT logs),
     * this field contains the throwable for stack trace analysis and error tracking.
     *
     * Example:
     * ```kotlin
     * try {
     *     tokenRefresh()
     * } catch (e: IOException) {
     *     SdkLogger.e(LogCategory.NETWORK, throwable = e) {
     *         "Token refresh failed"
     *     }
     *     // LogEntry.throwable = IOException
     * }
     * ```
     *
     * Custom log writers can send this to error tracking services (Sentry, etc.).
     */
    val throwable: Throwable? = null,
    /**
     * Global telemetry context attached to this log.
     *
     * Contains rich metadata about the SDK session, platform, business unit, etc.
     * This context is shared across all logs in the same SDK instance and provides
     * essential information for multi-tenant support, debugging, and analytics.
     *
     * Context fields include:
     * - sessionId: Ephemeral session identifier
     * - businessUnit: SRF, RTS, RSI, RTR, SWI
     * - platform: Android, iOS, JVM, JS
     * - appVersion, sdkVersion, osVersion, etc.
     *
     * See [TelemetryContext] for complete details.
     */
    val context: TelemetryContext,
    /**
     * Per-log custom metadata as key-value pairs.
     *
     * Allows attaching additional structured data to individual logs without
     * modifying the global context. Useful for operation-specific details.
     *
     * Common use cases:
     * - Performance: `mapOf("duration" to 234L)` (ms)
     * - Retry logic: `mapOf("retryCount" to 3, "maxRetries" to 5)`
     * - Error details: `mapOf("errorCode" to "invalid_grant", "httpStatus" to 401)`
     * - Operation context: `mapOf("tokenType" to "access", "flowType" to "pkce")`
     *
     * Example:
     * ```kotlin
     * SdkLogger.w(
     *     category = LogCategory.TOKEN_MONITORING,
     *     metadata = mapOf(
     *         "retryCount" to 3,
     *         "duration" to 234L,
     *         "errorCode" to "invalid_grant",
     *         "nextRetryIn" to 2000L
     *     )
     * ) {
     *     "Token refresh failed, will retry"
     * }
     * ```
     *
     * **Note**: Metadata is sanitized for PII before logging. Avoid including
     * sensitive data (tokens, passwords, emails) - use sanitized versions only.
     */
    val metadata: Map<String, Any> = emptyMap(),
)
