package ch.srg.login.sdk.token

/**
 * Configuration class for token storage implementations.
 *
 * @param keystoreAlias The alias to use for key generation in Android Keystore.
 * @param fileName The name of the file where tokens will be stored.
 * @param enableBackup Whether to allow backup of the storage file (Android only).
 */
data class TokenStorageConfig(
    val keystoreAlias: String = "srg_login_sdk_token_key",
    val fileName: String = "srg_login_tokens",
    val enableBackup: Boolean = false,
)
