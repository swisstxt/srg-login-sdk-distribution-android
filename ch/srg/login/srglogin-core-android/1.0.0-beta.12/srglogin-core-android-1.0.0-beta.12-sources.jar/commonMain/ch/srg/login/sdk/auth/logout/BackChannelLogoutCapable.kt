package ch.srg.login.sdk.auth.logout

import ch.srg.login.sdk.SrgLoginConfig
import ch.srg.login.sdk.auth.BackChannelLogoutListener
import ch.srg.login.sdk.auth.JwtValidationService
import ch.srg.login.sdk.auth.LogoutResult
import ch.srg.login.sdk.auth.LogoutTokenValidationService
import ch.srg.login.sdk.auth.LogoutType
import ch.srg.login.sdk.auth.PersistentReplayCache
import ch.srg.login.sdk.data.OpenIdConfigRepository
import ch.srg.login.sdk.data.api.SrgAuthApiService
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.logging.ErrorHandler
import ch.srg.login.sdk.logging.ErrorHandlerRegistry
import ch.srg.login.sdk.result.SdkResult
import ch.srg.login.sdk.token.TokenStorage

/**
 * Capability interface for back-channel logout support.
 *
 * Any [LogoutHandler] subclass that implements this interface gains BackChannel logout
 * and listener management with a full default implementation. Individual methods can be
 * overridden for platform-specific behavior.
 *
 * BackChannel logout validates the logout token JWT (signature, issuer, replay cache),
 * clears local session, and notifies all registered [BackChannelLogoutListener]s.
 */
internal interface BackChannelLogoutCapable {
    val config: SrgLoginConfig
    val tokenStorage: TokenStorage
    val openIdConfigRepository: OpenIdConfigRepository
    val jwtValidationService: JwtValidationService
    val authApiService: SrgAuthApiService

    /**
     * Read-only snapshot of currently registered back-channel logout listeners.
     * Implementations must provide thread-safe storage (copy-on-write recommended).
     */
    val backChannelListeners: List<BackChannelLogoutListener>

    val replayCache: PersistentReplayCache

    /** Clears local session state. Provided by [LogoutHandler]. */
    suspend fun performLocalLogout(): LogoutResult

    /**
     * Validates the logout token JWT and performs local logout.
     */
    @Suppress("LongMethod", "NestedBlockDepth", "ReturnCount", "TooGenericExceptionCaught")
    suspend fun performBackChannelLogout(type: LogoutType.BackChannel): LogoutResult {
        try {
            // 1. Get OpenID Configuration for JWKS URI and issuer
            val openIdConfigResult = openIdConfigRepository.getConfiguration()
            val openIdConfig =
                when (openIdConfigResult) {
                    is SdkResult.Success -> {
                        openIdConfigResult.data
                    }

                    is SdkResult.Failure -> {
                        return LogoutResult.Failure(
                            clearedLocalSession = false,
                            serverLogoutAttempted = false,
                            error = openIdConfigResult.error,
                        )
                    }
                }

            // 2. Create JWT validation components
            val logoutValidator =
                LogoutTokenValidationService(
                    jwtValidationService = jwtValidationService,
                    replayCache = replayCache,
                    expectedIssuer = openIdConfig.issuer,
                    clientId = config.clientId,
                    jwksUri = openIdConfig.jwksUri,
                )

            // 3. Validate the logout token (globally — session matching deferred)
            val validationResult = logoutValidator.validateLogoutTokenGlobal(type.logoutToken)
            when {
                validationResult.isSuccess -> {
                    validationResult.getOrThrow()
                }

                else -> {
                    val error =
                        validationResult.exceptionOrNull() as? SrgLoginError
                            ?: SrgLoginError.InvalidLogoutToken("Logout token validation failed")
                    return LogoutResult.Failure(
                        clearedLocalSession = false,
                        serverLogoutAttempted = false,
                        error = error,
                    )
                }
            }

            // 4. Validation successful — clear local session
            val localLogoutResult = performLocalLogout()
            if (localLogoutResult !is LogoutResult.Success) {
                return localLogoutResult
            }

            // 5. Notify all registered listeners
            // Snapshot the list before iterating to avoid ConcurrentModificationException
            // if register/unregister is called from another thread during iteration.
            val listeners = backChannelListeners.toList()
            var hasListenerError = false
            var lastError: SrgLoginError? = null

            for (listener in listeners) {
                try {
                    val listenerResult = listener.onBackChannelLogout(type.logoutToken)
                    if (listenerResult is SdkResult.Failure) {
                        hasListenerError = true
                        lastError = listenerResult.error
                        ErrorHandlerRegistry.captureException(
                            throwable = Exception(listenerResult.error.toString()),
                            context =
                                mapOf(
                                    "operation" to "back_channel_logout_listener",
                                    "listener" to listener::class.simpleName,
                                    "error_type" to listenerResult.error::class.simpleName,
                                ),
                            level = ErrorHandler.ErrorLevel.WARNING,
                        )
                    }
                } catch (e: Exception) {
                    hasListenerError = true
                    lastError = SrgLoginError.UnknownError(e)
                    ErrorHandlerRegistry.captureException(
                        throwable = e,
                        context =
                            mapOf(
                                "operation" to "back_channel_logout_listener",
                                "listener" to listener::class.simpleName,
                                "error_type" to "exception",
                            ),
                        level = ErrorHandler.ErrorLevel.ERROR,
                    )
                }
            }

            return if (hasListenerError && lastError != null) {
                LogoutResult.Failure(
                    clearedLocalSession = true,
                    serverLogoutAttempted = false,
                    error = lastError,
                )
            } else {
                LogoutResult.Success(
                    clearedLocalSession = true,
                    // Back-channel: server initiated the logout, SDK cleared local state.
                    terminatedServerSession = false,
                )
            }
        } catch (e: Exception) {
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "back_channel_logout_validation",
                        "stage" to "logout_validation",
                        "security_concern" to true,
                        "error_type" to e::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.FATAL,
            )
            return LogoutResult.Failure(
                clearedLocalSession = false,
                serverLogoutAttempted = false,
                error = SrgLoginError.UnknownError(e, "Back-channel logout validation failed"),
            )
        }
    }

    /**
     * Registers a [listener] to receive back-channel logout notifications.
     *
     * No-op if [listener] is already registered.
     * Implementations must ensure thread-safe mutation (copy-on-write recommended).
     */
    fun registerBackChannelLogoutListener(listener: BackChannelLogoutListener)

    /**
     * Unregisters a previously registered [listener].
     *
     * No-op if [listener] was not registered.
     * Implementations must ensure thread-safe mutation (copy-on-write recommended).
     */
    fun unregisterBackChannelLogoutListener(listener: BackChannelLogoutListener)
}
