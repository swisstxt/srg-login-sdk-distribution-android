package ch.srg.login.sdk.events

import ch.srg.login.sdk.logging.LogCategory
import ch.srg.login.sdk.logging.SdkLogger
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * Event emitter for SDK lifecycle events.
 *
 * This class provides the infrastructure for event-driven communication between
 * SDK components (TokenManager, WebAuthenticationManager, AppLifecycleObserver, TokenStorage).
 *
 * **Architecture**: Hybrid Event-Driven Architecture
 * - Event Bus pattern for extensibility and observability
 * - Instance-scoped (not global singleton) for multi-instance SDK support
 * - Each SrgLogin instance has its own isolated SdkEventEmitter
 *
 * **Multi-Instance Support**:
 * - Created as Koin `factory` (not `single`)
 * - Each SrgLogin instance gets its own event emitter
 * - Events are scoped per SDK instance (no cross-instance interference)
 *
 * **Backpressure Handling**:
 * - `replay = 0`: No event replay for late subscribers
 * - `extraBufferCapacity = 64`: Buffer up to 64 events if consumers are slow
 * - `onBufferOverflow = DROP_OLDEST`: Drop oldest events if buffer is full
 *
 * **Usage**:
 * ```kotlin
 * // Emit events (from WebAuthenticationManager, TokenManager, TokenStorage, etc.)
 * eventEmitter.emit(SdkLifecycleEvent.LoginSuccess(tokenResponse, System.currentTimeMillis()))
 * eventEmitter.emit(SdkLifecycleEvent.TokensSaved(hasRefreshToken = true, System.currentTimeMillis()))
 *
 * // Listen to events (from TokenManager, future analytics services)
 * eventEmitter.events.collect { event ->
 *     when (event) {
 *         is SdkLifecycleEvent.LoginSuccess -> startTokenMonitoring()
 *         is SdkLifecycleEvent.LogoutSuccess -> stopTokenMonitoring()
 *         is SdkLifecycleEvent.TokensSaved -> println("Tokens persisted to storage")
 *         is SdkLifecycleEvent.StorageError -> handleStorageFailure(event.error)
 *         // ... handle other events
 *     }
 * }
 * ```
 *
 * **Event Categories**:
 * - **Authentication**: Login lifecycle (LoginStarted, LoginSuccess, LoginFailure)
 * - **Logout**: Logout lifecycle (LogoutStarted, LogoutSuccess, LogoutFailure)
 * - **Token Refresh**: Token refresh lifecycle (TokenRefreshStarted, TokenRefreshSuccess, TokenRefreshFailure)
 * - **App Lifecycle**: App state changes (AppStarted, AppForegrounded, AppBackgrounded, AppTerminated)
 * - **Storage**: Secure token storage operations (TokensSaved, TokensLoaded, TokensCleared, StorageError)
 * - **Token State**: Token state changes (TokenStateChanged)
 *
 * **Future Extensibility**:
 * This event emitter will support:
 * - Analytics services (track login/logout patterns, storage operations)
 * - Logging services (structured event logging)
 * - Metrics collection (performance tracking)
 * - Observability tools (APM integration)
 *
 * **Testability**: Implements [EventEmitter] interface for easy testing with fake implementations.
 *
 * @since 1.0.0
 */
internal class SdkEventEmitter : EventEmitter {
    init {
        SdkLogger.d(LogCategory.SDK_CREATION) { "SdkEventEmitter created (hashCode=${this.hashCode()})" }
    }

    /**
     * Internal mutable event flow.
     *
     * Configuration:
     * - `replay = 0`: Late subscribers don't receive past events
     * - `extraBufferCapacity = 64`: Buffer up to 64 events for slow consumers
     * - `onBufferOverflow = DROP_OLDEST`: Drop oldest events if buffer overflows
     */
    private val _events =
        MutableSharedFlow<SdkLifecycleEvent>(
            replay = 0,
            extraBufferCapacity = 64,
            onBufferOverflow = BufferOverflow.DROP_OLDEST,
        )

    /**
     * Public read-only event flow.
     *
     * Consumers can collect this flow to receive SDK lifecycle events.
     *
     * **Example**:
     * ```kotlin
     * eventEmitter.events.collect { event ->
     *     when (event) {
     *         is SdkLifecycleEvent.LoginSuccess -> println("User logged in")
     *         is SdkLifecycleEvent.TokenRefreshStarted -> println("Refreshing token...")
     *         is SdkLifecycleEvent.TokensSaved -> println("Tokens saved to storage")
     *         // ... handle other events
     *     }
     * }
     * ```
     */
    override val events: SharedFlow<SdkLifecycleEvent> = _events.asSharedFlow()

    /**
     * Emits an SDK lifecycle event (suspending).
     *
     * Use this method when emitting events from suspend functions or coroutines.
     * If called from a non-suspending context, use [tryEmit] instead.
     *
     * **Note**: This method suspends if the buffer is full and waits for space.
     * In practice, with `extraBufferCapacity = 64` and `BufferOverflow.DROP_OLDEST`,
     * this should rarely suspend.
     *
     * @param event The lifecycle event to emit
     */
    override suspend fun emit(event: SdkLifecycleEvent) {
        _events.emit(event)
    }

    /**
     * Attempts to emit an SDK lifecycle event (non-suspending).
     *
     * Use this method when emitting events from non-suspending contexts
     * (e.g., init blocks, callbacks, platform-specific event handlers).
     *
     * **Behavior**:
     * - Returns `true` if event was emitted successfully
     * - Returns `false` if buffer is full and event was dropped (should be rare)
     *
     * **Note**: With `BufferOverflow.DROP_OLDEST`, this always returns `true`
     * because the oldest event is dropped to make space for the new event.
     *
     * @param event The lifecycle event to emit
     * @return `true` if event was emitted, `false` if dropped (rare with DROP_OLDEST)
     */
    override fun tryEmit(event: SdkLifecycleEvent): Boolean = _events.tryEmit(event)
}
