package ch.srg.login.sdk.auth

import ch.srg.login.sdk.model.AccessToken
import ch.srg.login.sdk.result.SdkResult
import kotlinx.coroutines.flow.StateFlow

/**
 * Manages OAuth 2.0 token lifecycle including refresh, access, and state monitoring.
 *
 * This interface defines the contract for complete token management,
 * including refresh operations, token access with automatic refresh,
 * state monitoring, and authentication checks.
 *
 * **Responsibilities**:
 * - Provide access to valid tokens (with automatic refresh if enabled)
 * - Coordinate token refresh workflow (check state, call API, update storage)
 * - Monitor token state and provide reactive updates
 * - Update refresh token metadata (use count, timestamps, rotation detection)
 * - Integrate with JwtValidationService for expiration checks
 * - Integrate with TokenStorage for persistence
 *
 * **Usage Example**:
 * ```kotlin
 * val tokenManager: TokenManager = // ... from DI
 *
 * // Get access token (automatically refreshes if expired)
 * val accessTokenResult = tokenManager.getAccessToken()
 * when (accessTokenResult) {
 *     is SdkResult.Success -> useToken(accessTokenResult.data)
 *     is SdkResult.Failure -> handleError(accessTokenResult.error)
 * }
 *
 * // Force refresh (e.g., after 401 from resource server)
 * val freshResult = tokenManager.getAccessToken(forceRefresh = true)
 *
 * // Check authentication status
 * if (tokenManager.isAuthenticated()) {
 *     // User is authenticated
 * }
 * ```
 *
 * **Thread Safety**: Implementations should be thread-safe and handle
 * concurrent refresh attempts appropriately (e.g., deduplicate requests).
 */
interface TokenManager {
    /**
     * Gets the current state of tokens for refresh decision-making.
     *
     * This method evaluates the current token response and returns the appropriate
     * state based on expiration and configuration:
     * - `TokenState.NoTokens`: No tokens available (user not logged in)
     * - `TokenState.Valid`: Token is valid and not expiring soon
     * - `TokenState.ExpiringSoon`: Token is valid but within refresh threshold
     * - `TokenState.Expired`: Token has expired
     *
     * The state determination considers:
     * - Access token expiration time (from JWT exp claim)
     * - Refresh threshold from TokenRefreshConfig
     * - Proactive refresh enabled/disabled setting
     *
     * **Use Case**: Call this before making API requests to decide if refresh is needed.
     *
     * @return Current TokenState
     */
    suspend fun getCurrentTokenState(): TokenState

    /**
     * Checks if a refresh token is available.
     *
     * A refresh token is required to refresh access tokens. If no refresh token
     * is available, the user needs to re-authenticate via the login flow.
     *
     * **Note**: Even if a refresh token exists, it may be expired or revoked.
     * Actual refresh attempts may still fail with invalid_grant errors.
     *
     * @return true if a refresh token exists in storage, false otherwise
     */
    suspend fun hasRefreshToken(): Boolean

    /**
     * Returns the raw refresh token string from secure storage, or `null` if none exists.
     *
     * **Development and testing use only.** This method exposes the raw refresh token
     * for debugging, diagnostics, and integration testing scenarios. Do **not** use it to
     * build a manual refresh flow — the SDK handles token refresh internally via
     * [getAccessToken] with `forceRefresh = true`.
     *
     * The returned value is the opaque string as received from the IDP token endpoint.
     * It may be a JWT or an opaque reference depending on the IDP configuration.
     *
     * **Security**: The refresh token is the most sensitive credential in the OAuth 2.0
     * session. Never log, persist outside secure storage, or transmit it off-device.
     *
     * @return The raw refresh token string, or `null` if no tokens are stored
     * @see hasRefreshToken For a safe boolean check without exposing the raw value
     * @see getAccessToken For obtaining a valid access token (the recommended API)
     */
    suspend fun getRefreshToken(): String?

    /**
     * Returns a valid access token, refreshing internally if needed.
     *
     * This is the **primary token access method** for all platforms and modes.
     *
     * **Behavior**:
     * - Token is `Valid` or `ExpiringSoon` → returns immediately (no network call)
     * - Token is `Expired` → refreshes automatically, then returns the new token
     * - `forceRefresh = true` → always refreshes, regardless of current state.
     *   Use after receiving a 401 from a resource server (the JWT may be structurally
     *   valid but revoked server-side, which the SDK cannot detect from the token alone).
     *
     * In [TokenRefreshMode.Automatic] mode, `forceRefresh` is a **fallback** —
     * background monitoring handles proactive refresh; `forceRefresh` covers 401 retry.
     *
     * In [TokenRefreshMode.Manual] mode, `forceRefresh` is the **primary refresh
     * mechanism** — it replaces the removed `refreshToken()` method.
     *
     * **Usage Example**:
     * ```kotlin
     * // Normal access (returns cached or refreshes if expired):
     * val result = tokenManager.getAccessToken()
     *
     * // After a 401 from resource server (force a fresh token):
     * val freshResult = tokenManager.getAccessToken(forceRefresh = true)
     * ```
     *
     * @param forceRefresh Force a network refresh even if the current token is valid.
     *   Default: `false`. Use `true` only after a 401 response or when you know the
     *   token is revoked server-side.
     * @return SdkResult.Success with AccessToken containing parsed JWT claims, or SdkResult.Failure if:
     *   - No tokens stored (requires login) — returns NotAuthenticated error
     *   - Refresh failed (network error, invalid refresh token)
     */
    suspend fun getAccessToken(forceRefresh: Boolean = false): SdkResult<AccessToken>

    /**
     * Checks if the user has a valid or refreshable authentication session.
     *
     * Returns true if EITHER condition is met:
     * - Valid (non-expired) access token exists in storage, OR
     * - Refresh token exists in storage (can obtain new access token)
     *
     * Returns false if BOTH conditions are false:
     * - No valid access token available, AND
     * - No refresh token available
     *
     * **Scenarios**:
     * - ✅ Valid access token + no refresh token → `true` (can make API calls immediately)
     * - ✅ Expired access token + refresh token → `true` (can refresh to get new token)
     * - ✅ Valid access token + refresh token → `true` (optimal case)
     * - ❌ Expired/missing access token + no refresh token → `false` (requires re-authentication)
     *
     * **Important**: This method checks LOCAL state only (no network call).
     * If tokens exist locally but are invalid server-side (revoked, corrupted),
     * this method will still return true until the next token operation detects the issue.
     * Invalid tokens are automatically detected and cleaned up when:
     * - `getAccessToken()` is called (including with `forceRefresh = true`)
     * - Server returns `invalid_grant` error
     *
     * **Usage Example**:
     * ```kotlin
     * if (tokenManager.isAuthenticated()) {
     *     // User has valid session locally, proceed to main screen
     *     navigateToMainScreen()
     * } else {
     *     // User needs to log in
     *     navigateToLoginScreen()
     * }
     * ```
     *
     * **Note**: This is a quick local check. Use `getAccessToken()` to get
     * the actual token with automatic refresh and server-side validation.
     *
     * @return true if user has valid access token OR refresh token, false otherwise
     */
    suspend fun isAuthenticated(): Boolean

    /**
     * Observes the current token state as a reactive StateFlow.
     *
     * The StateFlow emits token state changes automatically on:
     * - Login (new tokens available)
     * - Logout (tokens cleared)
     * - Token refresh (tokens updated)
     * - Periodic monitoring (when using TokenRefreshMode.Automatic)
     *
     * **Initial Value**: [TokenState.Uninitialized]. The SDK replaces it with a real
     * state (Valid/ExpiringSoon/Expired/NoTokens) within milliseconds of construction,
     * once the initial storage evaluation completes. Observers must handle this state
     * explicitly — typically by waiting (showing a splash screen) and **not** treating
     * it as "no session". Treating `Uninitialized` as `NoTokens` would briefly flash
     * a login screen on every cold start even when the user is already authenticated.
     *
     * **Use Cases**:
     * - UI state management (show session expiry warnings)
     * - Analytics (track session lifecycle events)
     * - Background sync coordination (pause when no valid token)
     * - Debug panels (display current token status)
     *
     * **Usage Example**:
     * ```kotlin
     * // In ViewModel
     * val tokenState = tokenManager.observeTokenState()
     *     .stateIn(viewModelScope, SharingStarted.Eagerly, TokenState.Uninitialized)
     *
     * val showSessionExpiring = tokenState.map { state ->
     *     state is TokenState.ExpiringSoon
     * }
     *
     * // In Composable
     * val state by tokenState.collectAsState()
     * when (state) {
     *     is TokenState.Uninitialized -> ShowSplashScreen()  // wait, do not navigate
     *     is TokenState.Valid -> ShowMainContent()
     *     is TokenState.ExpiringSoon -> ShowExpiryWarning()
     *     is TokenState.Expired -> ShowReauthenticateDialog()
     *     is TokenState.NoTokens -> ShowLoginScreen()
     *     // Handle other states (Refreshing, Refreshed, RefreshFailed)
     * }
     * ```
     *
     * @return StateFlow that emits current TokenState
     */
    fun observeTokenState(): StateFlow<TokenState>

    /**
     * Starts automatic background token state monitoring.
     *
     * Only active when [TokenRefreshConfig.mode] is [TokenRefreshMode.Automatic].
     * In [TokenRefreshMode.Manual] this method logs a warning and does nothing.
     *
     * **When to call**:
     * - After successful login (the SDK already wires this up via the `LoginSuccess` event)
     * - After app returns to foreground (on Android, called automatically by PlatformLifecycleObserver)
     *
     * **What it does**:
     * - Launches background coroutine to periodically check token state
     * - Uses adaptive threshold based on token lifetime
     * - Uses smart scheduling for battery efficiency (1s to 15 min intervals depending on state)
     * - Triggers automatic refresh when ExpiringSoon/Expired
     * - Updates StateFlow for UI observation via `observeTokenState()`
     *
     * **Idempotent**: Safe to call multiple times — restarts the monitoring loop so the
     * next cycle is immediately scheduled against the latest token's expiry.
     *
     * @see stopTokenMonitoring
     */
    suspend fun startTokenMonitoring()

    /**
     * Stops automatic background token state monitoring.
     *
     * **When to call**:
     * - On explicit logout
     * - When app goes to background (on Android, called automatically by PlatformLifecycleObserver)
     * - Before app termination (to save battery)
     *
     * **What it does**:
     * - Cancels background monitoring coroutine
     * - Stops all periodic token state checks
     * - Frees associated resources
     *
     * **Idempotent**: Safe to call multiple times (no effect if not running)
     *
     * **Note**: Not a suspend function because it only cancels coroutines (no blocking I/O).
     * Can be called from lifecycle callbacks directly.
     *
     * @see startTokenMonitoring
     */
    fun stopTokenMonitoring()

    /**
     * Disposes all SDK resources and stops background operations.
     *
     * **Lifecycle Integration**:
     * - Called automatically by PlatformLifecycleObserver on app termination/background
     * - Can also be called manually for explicit cleanup
     * - Safe to call multiple times (idempotent)
     *
     * **Cleanup Actions**:
     * 1. Stop token monitoring (cancel background coroutine)
     * 2. Cancel monitoring scope (cleanup all background jobs)
     *
     * **Platform-Specific Triggers**:
     * - Android: ProcessLifecycleOwner.onDestroy
     * - iOS: NSNotificationCenter UIApplicationWillTerminateNotification (Phase 2.8.3)
     * - JVM: Runtime.addShutdownHook (Phase 2.8.3)
     * - JS: window.addEventListener("beforeunload") (Phase 2.8.3)
     *
     * **Note**: Not a suspend function because it only cancels coroutines (no blocking I/O).
     * Can be called from lifecycle callbacks directly. After calling dispose(), the
     * TokenManager instance should not be used. Create a new instance if needed.
     */
    fun dispose()
}
