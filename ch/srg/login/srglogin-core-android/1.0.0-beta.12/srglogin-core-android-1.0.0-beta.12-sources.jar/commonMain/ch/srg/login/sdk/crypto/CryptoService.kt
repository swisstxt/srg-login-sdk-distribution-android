package ch.srg.login.sdk.crypto

import ch.srg.login.sdk.model.JsonWebKey

/**
 * Platform-specific cryptographic operations service.
 *
 * This interface defines cryptographic operations required for JWT validation
 * and OAuth 2.0/OIDC security. Each platform provides its own implementation
 * using native crypto libraries (e.g., Java Security on Android, CommonCrypto on iOS).
 *
 * The service is designed to be injectable via dependency injection (Koin),
 * making it testable and following Modern Android Development (MAD) principles.
 */
internal interface CryptoService {
    /**
     * Computes the SHA-256 hash of the input bytes.
     *
     * This is used for PKCE (Proof Key for Code Exchange) code challenge generation
     * in the OAuth 2.0 authorization code flow with PKCE (RFC 7636).
     *
     * @param input The input bytes to hash
     * @return The SHA-256 hash as a byte array
     *
     * @throws Exception if the SHA-256 algorithm is not available
     */
    fun sha256(input: ByteArray): ByteArray

    /**
     * Verifies an RSA signature using the specified algorithm.
     *
     * Supports RS256, RS384, and RS512 algorithms as defined in RFC 7518.
     * The signature verification ensures the JWT token was signed by the holder
     * of the private key corresponding to the public key in the JWK.
     *
     * **Algorithm Mapping**:
     * - RS256: RSASSA-PKCS1-v1_5 using SHA-256
     * - RS384: RSASSA-PKCS1-v1_5 using SHA-384
     * - RS512: RSASSA-PKCS1-v1_5 using SHA-512
     *
     * @param data The signed data (JWT header + "." + payload as UTF-8 bytes)
     * @param signature The signature bytes to verify (decoded from Base64URL)
     * @param jwk The JSON Web Key containing the RSA public key parameters (n and e)
     * @param algorithm The signature algorithm identifier ("RS256", "RS384", or "RS512")
     * @return `true` if the signature is valid, `false` otherwise
     *
     * **Returns false if**:
     * - The JWK is not an RSA key (kty != "RSA")
     * - Required RSA parameters (n, e) are missing
     * - The algorithm is not supported
     * - Signature verification fails
     * - Any cryptographic error occurs
     *
     * @see <a href="https://datatracker.ietf.org/doc/html/rfc7518#section-3.3">RFC 7518 Section 3.3</a>
     */
    fun verifyRsaSignature(
        data: ByteArray,
        signature: ByteArray,
        jwk: JsonWebKey,
        algorithm: String,
    ): Boolean

    /**
     * Verifies an ECDSA signature using the specified algorithm.
     *
     * Supports ES256, ES384, and ES512 algorithms as defined in RFC 7518.
     * ECDSA signatures use elliptic curve cryptography and are more efficient
     * than RSA while providing equivalent security.
     *
     * **Algorithm Mapping**:
     * - ES256: ECDSA using P-256 curve and SHA-256
     * - ES384: ECDSA using P-384 curve and SHA-384
     * - ES512: ECDSA using P-521 curve and SHA-512
     *
     * **Note**: JWT ECDSA signatures use the IEEE P1363 format (r || s),
     * not the DER format used by some crypto libraries. The implementation
     * must handle format conversion if necessary.
     *
     * @param data The signed data (JWT header + "." + payload as UTF-8 bytes)
     * @param signature The signature bytes to verify (decoded from Base64URL)
     * @param jwk The JSON Web Key containing the EC public key parameters (x, y, crv)
     * @param algorithm The signature algorithm identifier ("ES256", "ES384", or "ES512")
     * @return `true` if the signature is valid, `false` otherwise
     *
     * **Returns false if**:
     * - The JWK is not an EC key (kty != "EC")
     * - Required EC parameters (x, y, crv) are missing
     * - The curve is not supported
     * - The algorithm is not supported
     * - Signature verification fails
     * - Any cryptographic error occurs
     *
     * @see <a href="https://datatracker.ietf.org/doc/html/rfc7518#section-3.4">RFC 7518 Section 3.4</a>
     */
    fun verifyEcdsaSignature(
        data: ByteArray,
        signature: ByteArray,
        jwk: JsonWebKey,
        algorithm: String,
    ): Boolean
}
