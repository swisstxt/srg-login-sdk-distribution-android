package ch.srg.login.sdk.auth.handler

import ch.srg.login.sdk.auth.LoginState
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.events.EventEmitter
import ch.srg.login.sdk.events.SdkLifecycleEvent
import kotlinx.datetime.Clock

/**
 * Emits a [SdkLifecycleEvent.LoginFailure] event and returns a [LoginState.Failure].
 *
 * Extracted from duplicated `emitLoginFailureEvent()` / `failure()` helpers in
 * WebAuthenticationManager and DeviceAuthenticationManager.
 */
internal class LoginFailureEmitter(
    private val eventEmitter: EventEmitter,
    private val clock: Clock = Clock.System,
) {
    /**
     * Emits a [SdkLifecycleEvent.LoginFailure] event and returns the corresponding [LoginState.Failure].
     *
     * @param error The error that caused login to fail.
     * @return [LoginState.Failure] wrapping the given error.
     */
    fun emit(error: SrgLoginError): LoginState.Failure {
        val timestamp = clock.now().toEpochMilliseconds()
        eventEmitter.tryEmit(SdkLifecycleEvent.LoginFailure(error, timestamp))
        return LoginState.Failure(error)
    }
}
