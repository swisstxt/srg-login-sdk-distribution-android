package ch.srg.login.sdk.auth

import ch.srg.login.sdk.token.TokenStorage
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.datetime.Clock

/**
 * Interface for protecting against JWT replay attacks by tracking used JWT IDs.
 * Essential security component for back-channel logout validation.
 */
interface ReplayAttackCache {
    /**
     * Marks a JWT ID (jti) as used and checks if it was already used.
     *
     * @param jti The JWT ID to mark as used
     * @return true if this is the first time this JTI is seen, false if it was already used
     */
    suspend fun markAsUsed(jti: String): Boolean

    /**
     * Cleans up old entries that are no longer needed.
     * Should be called periodically to prevent memory leaks.
     */
    suspend fun cleanup()

    /**
     * Checks if a JWT ID has been used without marking it as used.
     * Useful for testing or read-only checks.
     */
    suspend fun isAlreadyUsed(jti: String): Boolean

    /**
     * Clears all cached entries. Use with caution - mainly for testing.
     */
    suspend fun clear()
}

/**
 * Persistent implementation of ReplayAttackCache using TokenStorage.
 * JWT IDs are stored securely and persist across app restarts, providing
 * robust protection against replay attacks.
 *
 * INTERNAL: This implementation is not part of the public SDK API.
 */
internal class PersistentReplayCache(
    private val tokenStorage: TokenStorage,
    // 1 hour default
    private val maxAgeSeconds: Long = 3600L,
) : ReplayAttackCache {
    private val mutex = Mutex()

    // In-memory cache for performance optimization
    private var memoryCache: MutableMap<String, Long>? = null
    private var lastCleanup = 0L

    override suspend fun markAsUsed(jti: String): Boolean =
        mutex.withLock {
            val usedTokens = loadUsedTokens().toMutableMap()
            val now = Clock.System.now().epochSeconds

            val wasAlreadyUsed = usedTokens.containsKey(jti)

            if (!wasAlreadyUsed) {
                // Add new JTI with current timestamp
                usedTokens[jti] = now

                // Clean up old entries periodically
                if (shouldCleanup(now)) {
                    cleanupExpiredTokens(usedTokens, now)
                }

                // Save back to persistent storage
                saveUsedTokens(usedTokens)
            }

            !wasAlreadyUsed // Return true if this is first time seeing this JTI
        }

    override suspend fun isAlreadyUsed(jti: String): Boolean =
        mutex.withLock {
            loadUsedTokens().containsKey(jti)
        }

    override suspend fun cleanup(): Unit =
        mutex.withLock {
            val usedTokens = loadUsedTokens().toMutableMap()
            val now = Clock.System.now().epochSeconds

            val beforeSize = usedTokens.size
            cleanupExpiredTokens(usedTokens, now)
            val afterSize = usedTokens.size

            if (beforeSize != afterSize) {
                saveUsedTokens(usedTokens)
            }

            lastCleanup = now
        }

    override suspend fun clear(): Unit =
        mutex.withLock {
            tokenStorage.clearJwtIds()
            memoryCache = null
        }

    private suspend fun loadUsedTokens(): Map<String, Long> {
        // Try memory cache first for performance
        if (memoryCache != null) {
            return memoryCache!!
        }

        // Load from persistent storage
        val stored = tokenStorage.getJwtIds() ?: emptyMap()

        // Cache in memory for subsequent calls
        memoryCache = stored.toMutableMap()

        return stored
    }

    private suspend fun saveUsedTokens(tokens: Map<String, Long>) {
        val result = tokenStorage.saveJwtIds(tokens)

        if (result.isSuccess) {
            // Update memory cache
            memoryCache = tokens.toMutableMap()
        } else {
            // Clear memory cache on save failure to force reload
            memoryCache = null
        }
    }

    private fun cleanupExpiredTokens(
        tokens: MutableMap<String, Long>,
        now: Long,
    ) {
        val cutoff = now - maxAgeSeconds

        val iterator = tokens.iterator()
        while (iterator.hasNext()) {
            val entry = iterator.next()
            if (entry.value < cutoff) {
                iterator.remove()
            }
        }
    }

    private fun shouldCleanup(now: Long): Boolean {
        // Cleanup every hour or when we have too many entries
        return now - lastCleanup > 3600 || memoryCache?.size ?: 0 > 1000
    }

    /**
     * Gets the current size of the cache for monitoring purposes.
     */
    suspend fun getCacheSize(): Int =
        mutex.withLock {
            loadUsedTokens().size
        }
}

/**
 * In-memory implementation of ReplayAttackCache for testing or scenarios
 * where persistence is not required.
 *
 * WARNING: This implementation loses protection across app restarts!
 * Use PersistentReplayCache for production.
 */
class InMemoryReplayCache(
    // 1 hour default
    private val maxAgeSeconds: Long = 3600L,
) : ReplayAttackCache {
    // Thread-safe storage for used JTI with their timestamps
    private val usedTokens = mutableMapOf<String, Long>()
    private var lastCleanup = Clock.System.now().epochSeconds

    // Simple mutex for thread safety with suspend functions
    private val mutex = Mutex()

    override suspend fun markAsUsed(jti: String): Boolean =
        mutex.withLock {
            cleanupIfNeeded()

            val now = Clock.System.now().epochSeconds
            val wasAlreadyUsed = usedTokens.containsKey(jti)

            // Store with current timestamp
            usedTokens[jti] = now

            !wasAlreadyUsed // Return true if this is first time seeing this JTI
        }

    override suspend fun isAlreadyUsed(jti: String): Boolean =
        mutex.withLock {
            cleanupIfNeeded()
            usedTokens.containsKey(jti)
        }

    override suspend fun cleanup(): Unit =
        mutex.withLock {
            val now = Clock.System.now().epochSeconds
            val cutoff = now - maxAgeSeconds

            // Remove entries older than maxAgeSeconds
            val iterator = usedTokens.iterator()
            while (iterator.hasNext()) {
                val entry = iterator.next()
                if (entry.value < cutoff) {
                    iterator.remove()
                }
            }

            lastCleanup = now
        }

    override suspend fun clear(): Unit =
        mutex.withLock {
            usedTokens.clear()
            lastCleanup = Clock.System.now().epochSeconds
        }

    private fun cleanupIfNeeded() {
        val now = Clock.System.now().epochSeconds
        // Cleanup every hour or when cache gets large
        if (now - lastCleanup > 3600 || usedTokens.size > 10000) {
            runCatching {
                // Basic cleanup without suspend context
                val cutoff = now - maxAgeSeconds
                usedTokens.entries.removeAll { it.value < cutoff }
                lastCleanup = now
            }
        }
    }

    /**
     * Gets the current size of the cache for monitoring purposes.
     */
    suspend fun getCacheSize(): Int =
        mutex.withLock {
            usedTokens.size
        }
}
