package ch.srg.login.sdk.data

import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.model.OpenIdConfig
import ch.srg.login.sdk.result.SdkResult

/**
 * Defines the contract for a repository that handles fetching the OpenID Connect configuration.
 */
internal interface OpenIdConfigRepository {
    /**
     * Fetches the OpenID configuration.
     *
     * @return An [SdkResult] containing the [OpenIdConfig] on success, or an [SrgLoginError] on failure.
     */
    suspend fun getConfiguration(): SdkResult<OpenIdConfig>

    /**
     * Maps a generic [Exception] to a well-defined [SrgLoginError].
     * This is useful for handling network and parsing errors consistently.
     */
    fun mapExceptionToError(e: Exception): SrgLoginError
}
