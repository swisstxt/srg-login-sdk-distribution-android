package ch.srg.login.sdk.logging

import ch.srg.login.sdk.crypto.CryptoService
import ch.srg.login.sdk.internal.SecurityUtils
import io.ktor.client.HttpClient
import io.ktor.client.request.header
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.http.ContentType
import io.ktor.http.contentType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.datetime.Clock
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import kotlin.uuid.ExperimentalUuidApi
import kotlin.uuid.Uuid

/**
 * Custom HTTP-based Sentry error reporter.
 *
 * This implementation sends error reports directly to Sentry's REST API without
 * using the Sentry KMP SDK, allowing complete isolation from any Sentry instance
 * used by the application.
 *
 * ## Architecture
 *
 * - **Direct HTTP**: Uses Ktor HttpClient to send events to Sentry REST API
 * - **No Singleton**: Completely independent from Sentry KMP SDK singleton
 * - **Fail-Safe**: All errors are caught silently to prevent SDK crashes
 * - **Lightweight**: Only implements necessary Sentry protocol features
 *
 * ## Sentry Protocol
 *
 * Implements Sentry Store API v7:
 * - Endpoint: `POST https://o{ORG_ID}.ingest.{REGION}.sentry.io/api/{PROJECT_ID}/store/`
 * - Auth: `X-Sentry-Auth` header with public key
 * - Body: JSON event with exception, context, user data
 *
 * @param dsn Sentry DSN (https://PUBLIC_KEY@o{ORG_ID}.ingest.{REGION}.sentry.io/{PROJECT_ID})
 * @param httpClient Ktor HTTP client for sending requests
 * @param telemetryContext SDK telemetry context for enrichment
 * @param cryptoService Crypto service for user ID hashing
 * @param userContextMode User privacy mode (HASHED_SUB, DIRECT_SUB, SESSION_ID, NONE)
 * @param salt Salt for user ID hashing (required for HASHED_SUB mode)
 *
 * @see ErrorHandler
 * @see ErrorHandlerRegistry
 */
internal class SdkErrorReporter(
    private val dsn: String,
    private val httpClient: HttpClient,
    private val telemetryContext: TelemetryContext,
    private val cryptoService: CryptoService,
    private val userContextMode: UserContextMode,
    private val salt: String? = null,
) : ErrorHandler {
    private val parsedDsn: SentryDsn
    private val endpoint: String
    private val authHeader: String

    private var currentUserId: String? = null
    private val tags = mutableMapOf<String, String>()

    // Coroutine scope for async event sending
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val json =
        Json {
            ignoreUnknownKeys = true
            encodeDefaults = true
        }

    init {
        require(dsn.isNotBlank()) { "DSN cannot be blank" }

        // Validate salt for HASHED_SUB mode
        if (userContextMode == UserContextMode.HASHED_SUB) {
            require(!salt.isNullOrBlank()) {
                "Salt is required for HASHED_SUB mode"
            }
        }

        parsedDsn = SentryDsn.parse(dsn)
        endpoint = "https://o${parsedDsn.organizationId}.ingest.${parsedDsn.region}.sentry.io/api/${parsedDsn.projectId}/store/"
        authHeader = buildAuthHeader()
    }

    override fun captureException(
        throwable: Throwable,
        context: Map<String, Any?>,
        level: ErrorHandler.ErrorLevel,
    ) {
        try {
            // Sanitize exception message to prevent token/PII leaks
            val rawMessage = throwable.message ?: throwable::class.simpleName ?: "Unknown error"
            val sanitizedMessage = SecurityUtils.sanitizeErrorMessage(rawMessage)

            val event =
                buildSentryEvent(
                    message = sanitizedMessage,
                    level = level,
                    exception = throwable,
                    context = context,
                )
            // Launch coroutine for async event sending
            scope.launch {
                sendEvent(event)
            }
        } catch (e: Exception) {
            // Fail-safe: Never throw from error handler
            // Log error to help diagnose ErrorReporter failures
            SdkLogger.e(LogCategory.ERROR_TRACKING, throwable = e) {
                "Failed to capture exception in SdkErrorReporter"
            }
            // Errors are non-blocking (fail-safe guarantee maintained)
        }
    }

    override fun captureMessage(
        message: String,
        context: Map<String, Any?>,
        level: ErrorHandler.ErrorLevel,
    ) {
        try {
            // Sanitize message to prevent token/PII leaks
            val sanitizedMessage = SecurityUtils.sanitizeErrorMessage(message)

            val event =
                buildSentryEvent(
                    message = sanitizedMessage,
                    level = level,
                    exception = null,
                    context = context,
                )
            // Launch coroutine for async event sending
            scope.launch {
                sendEvent(event)
            }
        } catch (e: Exception) {
            // Fail-safe: Never throw from error handler
            // Log error to help diagnose ErrorReporter failures
            SdkLogger.e(LogCategory.ERROR_TRACKING, throwable = e) {
                "Failed to capture message in SdkErrorReporter"
            }
            // Errors are non-blocking (fail-safe guarantee maintained)
        }
    }

    override fun setUser(userId: String?) {
        currentUserId = userId
    }

    override fun setTag(
        key: String,
        value: String,
    ) {
        tags[key] = value
    }

    /**
     * Build Sentry event JSON structure.
     */
    private fun buildSentryEvent(
        message: String,
        level: ErrorHandler.ErrorLevel,
        exception: Throwable?,
        context: Map<String, Any?>,
    ): SentryEvent {
        val timestamp = Clock.System.now()

        return SentryEvent(
            eventId = generateEventId(),
            timestamp = timestamp.toString(),
            platform = "kotlin",
            level = level.toSentryLevel(),
            logger = "srg-login-sdk",
            message = message,
            exception = exception?.let { buildSentryException(it) },
            contexts = buildContexts(),
            user = buildUser(),
            tags = buildTags(context),
            extra = context.filterValues { it != null }.mapValues { it.value.toString() },
        )
    }

    /**
     * Build Sentry exception structure from Throwable.
     */
    private fun buildSentryException(throwable: Throwable): SentryExceptionData {
        val values = mutableListOf<SentryException>()

        var current: Throwable? = throwable
        while (current != null) {
            values.add(
                SentryException(
                    type = current::class.simpleName ?: "UnknownException",
                    value = current.message ?: "",
                    stacktrace = buildStacktrace(current),
                ),
            )
            current = current.cause
        }

        return SentryExceptionData(values = values)
    }

    /**
     * Build stacktrace from exception.
     */
    private fun buildStacktrace(throwable: Throwable): SentryStacktrace? {
        val stackTrace = throwable.stackTraceToString()
        if (stackTrace.isEmpty()) return null

        // Parse stack trace into frames
        val frames =
            stackTrace
                .lines()
                .filter { it.trim().isNotEmpty() }
                .map { line ->
                    SentryStackFrame(
                        filename = extractFilename(line),
                        function = extractFunction(line),
                        lineno = extractLineNumber(line),
                        inApp = line.contains("ch.srg.login.sdk"),
                    )
                }

        return SentryStacktrace(frames = frames)
    }

    /**
     * Build contexts with telemetry data.
     */
    private fun buildContexts(): SentryContexts =
        SentryContexts(
            app =
                SentryAppContext(
                    appName = telemetryContext.appName,
                    appVersion = telemetryContext.appVersion,
                    appIdentifier = telemetryContext.appId,
                ),
            device =
                SentryDeviceContext(
                    model = telemetryContext.deviceModel,
                    type = telemetryContext.platform,
                ),
            os =
                SentryOsContext(
                    name = telemetryContext.platform,
                    version = telemetryContext.osVersion,
                ),
        )

    /**
     * Build user context based on UserContextMode.
     */
    private fun buildUser(): SentryUser? {
        val userId = currentUserId ?: return null

        val sentryUserId =
            when (userContextMode) {
                UserContextMode.HASHED_SUB -> {
                    // Hash user ID with salt
                    hashUserId(
                        userId = userId,
                        salt = salt!!,
                        businessUnit = telemetryContext.businessUnit,
                        cryptoService = cryptoService,
                    )
                }

                UserContextMode.DIRECT_SUB -> {
                    userId
                }

                UserContextMode.SESSION_ID -> {
                    telemetryContext.sessionId
                }

                UserContextMode.NONE -> {
                    return null
                }
            }

        return SentryUser(id = sentryUserId)
    }

    /**
     * Build tags from context and stored tags.
     *
     * Tags include:
     * - SDK identity: `sdk.name`, `sdk.version`
     * - Host app identity: `app.id`, `app.name`, `app.version`
     * - Multi-tenant: `business_unit`, `environment`
     * - Dynamic: stored tags + context tags
     */
    private fun buildTags(context: Map<String, Any?>): Map<String, String> {
        val allTags = mutableMapOf<String, String>()

        // SDK identity tags
        allTags["sdk.name"] = "srg-login-sdk"
        allTags["sdk.version"] = TelemetryContext.SDK_VERSION

        // Host app identity tags (for multi-tenant Sentry filtering)
        allTags["app.id"] = telemetryContext.appId
        allTags["app.name"] = telemetryContext.appName
        allTags["app.version"] = telemetryContext.appVersion

        // Multi-tenant tags
        allTags["environment"] = telemetryContext.environment
        allTags["business_unit"] = telemetryContext.businessUnit

        // Add stored tags
        allTags.putAll(tags)

        // Add context tags (convert to strings)
        context.forEach { (key, value) ->
            if (value != null) {
                allTags[key] = value.toString()
            }
        }

        return allTags
    }

    /**
     * Send event to Sentry via HTTP POST.
     */
    private suspend fun sendEvent(event: SentryEvent) {
        try {
            val eventJson = json.encodeToString(event)

            httpClient.post(endpoint) {
                header("X-Sentry-Auth", authHeader)
                contentType(ContentType.Application.Json)
                setBody(eventJson)
            }
        } catch (e: Exception) {
            // Fail-safe: Never throw from error handler
            // Log error to help diagnose ErrorReporter failures
            SdkLogger.e(LogCategory.ERROR_TRACKING, throwable = e) {
                "Failed to send event to Sentry"
            }
            // Network errors, timeouts, etc. are logged but non-blocking
        }
    }

    /**
     * Build X-Sentry-Auth header.
     */
    private fun buildAuthHeader(): String {
        val timestamp = Clock.System.now().epochSeconds
        return "Sentry sentry_version=7, " +
            "sentry_key=${parsedDsn.publicKey}, " +
            "sentry_client=srg-login-sdk/1.0.0, " +
            "sentry_timestamp=$timestamp"
    }

    /**
     * Generate unique event ID (UUID v4 format).
     *
     * Uses cryptographically secure random number generator via kotlin.uuid.Uuid.random()
     * to ensure globally unique and unpredictable event IDs.
     */
    @OptIn(ExperimentalUuidApi::class)
    private fun generateEventId(): String = Uuid.random().toString()

    // Helper functions for stack trace parsing
    private fun extractFilename(line: String): String? {
        val pattern = Regex("""at .+\((.+?):\d+\)""")
        return pattern.find(line)?.groupValues?.get(1)
    }

    private fun extractFunction(line: String): String? {
        val pattern = Regex("""at (.+?)\(""")
        return pattern.find(line)?.groupValues?.get(1)
    }

    private fun extractLineNumber(line: String): Int? {
        val pattern = Regex(""":(\d+)\)""")
        return pattern
            .find(line)
            ?.groupValues
            ?.get(1)
            ?.toIntOrNull()
    }

    private fun ErrorHandler.ErrorLevel.toSentryLevel(): String =
        when (this) {
            ErrorHandler.ErrorLevel.DEBUG -> "debug"
            ErrorHandler.ErrorLevel.INFO -> "info"
            ErrorHandler.ErrorLevel.WARNING -> "warning"
            ErrorHandler.ErrorLevel.ERROR -> "error"
            ErrorHandler.ErrorLevel.FATAL -> "fatal"
        }

    /**
     * Hash user ID with salt and business unit for anonymization.
     *
     * Format: SHA-256(userId + salt + businessUnit) → first 16 hex chars
     *
     * @param userId The user ID to hash
     * @param salt The salt for hashing
     * @param businessUnit The business unit (prevents cross-BU correlation)
     * @param cryptoService Crypto service for SHA-256 hashing
     * @return 16-character hex hash
     */
    private fun hashUserId(
        userId: String,
        salt: String,
        businessUnit: String,
        cryptoService: CryptoService,
    ): String {
        val input = (userId + salt + businessUnit).encodeToByteArray()
        val hashBytes = cryptoService.sha256(input)
        // Convert ByteArray to hex string (KMP-compatible)
        val hexString =
            hashBytes.joinToString("") { byte ->
                val value = byte.toInt() and 0xFF
                if (value < 16) "0${value.toString(16)}" else value.toString(16)
            }
        return hexString.take(16)
    }
}

/**
 * Parsed Sentry DSN components.
 */
internal data class SentryDsn(
    val publicKey: String,
    val organizationId: String,
    val projectId: String,
    val region: String,
) {
    companion object {
        /**
         * Parse Sentry DSN string.
         *
         * Format: https://PUBLIC_KEY@o{ORG_ID}.ingest.{REGION}.sentry.io/{PROJECT_ID}
         * Example: https://abc123@o166386.ingest.us.sentry.io/4510742725066752
         */
        fun parse(dsn: String): SentryDsn {
            require(dsn.startsWith("https://")) { "DSN must start with https://" }

            val withoutProtocol = dsn.removePrefix("https://")
            val parts = withoutProtocol.split("@")
            require(parts.size == 2) { "Invalid DSN format: missing @" }

            val publicKey = parts[0]
            val remaining = parts[1]

            val hostAndPath = remaining.split("/")
            require(hostAndPath.size >= 2) { "Invalid DSN format: missing project ID" }

            val host = hostAndPath[0]
            val projectId = hostAndPath[1]

            // Parse organization ID and region from host
            // Format: o{ORG_ID}.ingest.{REGION}.sentry.io
            val hostParts = host.split(".")
            require(hostParts.size >= 4) { "Invalid DSN format: invalid host" }

            val orgId = hostParts[0].removePrefix("o")
            val region = hostParts[2] // e.g., "us", "eu", etc.

            return SentryDsn(
                publicKey = publicKey,
                organizationId = orgId,
                projectId = projectId,
                region = region,
            )
        }
    }
}

// Sentry JSON data structures

@Serializable
internal data class SentryEvent(
    @SerialName("event_id")
    val eventId: String,
    val timestamp: String,
    val platform: String,
    val level: String,
    val logger: String,
    val message: String,
    val exception: SentryExceptionData? = null,
    val contexts: SentryContexts,
    val user: SentryUser? = null,
    val tags: Map<String, String>,
    val extra: Map<String, String> = emptyMap(),
)

@Serializable
internal data class SentryExceptionData(
    val values: List<SentryException>,
)

@Serializable
internal data class SentryException(
    val type: String,
    val value: String,
    val stacktrace: SentryStacktrace? = null,
)

@Serializable
internal data class SentryStacktrace(
    val frames: List<SentryStackFrame>,
)

@Serializable
internal data class SentryStackFrame(
    val filename: String? = null,
    val function: String? = null,
    val lineno: Int? = null,
    @SerialName("in_app")
    val inApp: Boolean = false,
)

@Serializable
internal data class SentryContexts(
    val app: SentryAppContext,
    val device: SentryDeviceContext,
    val os: SentryOsContext,
)

@Serializable
internal data class SentryAppContext(
    @SerialName("app_name")
    val appName: String,
    @SerialName("app_version")
    val appVersion: String,
    @SerialName("app_identifier")
    val appIdentifier: String,
)

@Serializable
internal data class SentryDeviceContext(
    val model: String,
    val type: String,
)

@Serializable
internal data class SentryOsContext(
    val name: String,
    val version: String,
)

@Serializable
internal data class SentryUser(
    val id: String,
)
