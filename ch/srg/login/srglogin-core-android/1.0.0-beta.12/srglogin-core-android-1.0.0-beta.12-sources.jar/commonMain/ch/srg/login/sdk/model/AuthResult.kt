package ch.srg.login.sdk.model

/**
 * INTERNAL: Not part of public SDK API.
 */
internal sealed class AuthResult {
    data class Success(
        val tokens: TokenResponseDto,
    ) : AuthResult()

    data class Error(
        val error: AuthError,
    ) : AuthResult()

    object Cancelled : AuthResult()
}

sealed class AuthError(
    val message: String,
    val cause: Throwable? = null,
) {
    data class NetworkError(
        val errorMessage: String,
        val throwable: Throwable? = null,
    ) : AuthError(errorMessage, throwable)

    data class InvalidConfiguration(
        val errorMessage: String,
    ) : AuthError(errorMessage)

    data class InvalidResponse(
        val errorMessage: String,
    ) : AuthError(errorMessage)

    data class TokenExpired(
        val errorMessage: String = "Token has expired",
    ) : AuthError(errorMessage)

    data class UnknownError(
        val errorMessage: String,
        val throwable: Throwable? = null,
    ) : AuthError(errorMessage, throwable)
}
