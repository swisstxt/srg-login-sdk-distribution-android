package ch.srg.login.sdk.auth

import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.model.TokenSet

/**
 * Represents the current state of the SDK's tokens.
 *
 * ### Observer guidance
 *
 * - [Uninitialized]: SDK has not yet evaluated the token storage.
 *   **Take no action** — wait for the SDK to emit a real state.
 *   Optionally show a splash screen or loading indicator.
 *
 * - [NoTokens]: SDK confirms no usable tokens exist.
 *   Navigate to the login screen.
 *
 * - [Valid]: Token is present and non-expired. Navigate to the main content.
 *
 * - [ExpiringSoon]: Token is close to expiration. In [ch.srg.login.sdk.TokenRefreshMode.Automatic]
 *   the SDK will refresh proactively; in [ch.srg.login.sdk.TokenRefreshMode.Manual] the app should
 *   consider calling `getAccessToken(forceRefresh = true)` soon.
 *
 * - [Expired]: Token has expired. The next `getAccessToken()` call will refresh it.
 *
 * - [Refreshing], [Refreshed], [RefreshFailed]: Transition states emitted by
 *   the internal `refreshTokens()`. Useful for UI feedback (spinners, banners) but typically
 *   not load-bearing for navigation decisions.
 *
 * ### `Uninitialized` vs `NoTokens`
 *
 * `Uninitialized` is the value held by the StateFlow before the SDK has had any
 * chance to evaluate local storage. It is **not** equivalent to `NoTokens` —
 * the latter is a confirmation that no tokens exist, the former means "not yet known".
 * Observers **must not** trigger a logout navigation on `Uninitialized`, only on `NoTokens`.
 *
 * `Uninitialized` is emitted **exactly once**, as the initial StateFlow value.
 * It is replaced by a real state during SDK initialization, typically within
 * a few milliseconds of SrgLogin construction.
 *
 * **Usage Example**:
 * ```kotlin
 * srgLogin.observeTokenState().collect { state ->
 *     when (state) {
 *         TokenState.Uninitialized -> { /* wait, show splash */ }
 *         TokenState.NoTokens -> navigateToLogin()
 *         TokenState.Valid -> navigateToHome()
 *         TokenState.ExpiringSoon -> navigateToHome()
 *         TokenState.Expired -> { /* getAccessToken() will refresh */ }
 *         TokenState.Refreshing -> showSpinner()
 *         TokenState.Refreshed -> hideSpinner()
 *         is TokenState.RefreshFailed -> showError(state.error)
 *     }
 * }
 * ```
 */
sealed class TokenState {
    /**
     * Initial state before the SDK has evaluated the token storage.
     *
     * Observers should not take action on this state — it means "not yet known",
     * not "no tokens". This state is replaced by a real state ([Valid], [NoTokens],
     * [ExpiringSoon], [Expired]) as soon as the SDK finishes initialization and
     * evaluates local storage (typically within a few milliseconds).
     *
     * This distinction prevents observers from mistakenly navigating to a login
     * screen during the brief window between SDK construction and the first
     * storage evaluation.
     */
    data object Uninitialized : TokenState()

    /**
     * Tokens are valid and not expiring soon.
     * App can make API calls safely.
     */
    data object Valid : TokenState()

    /**
     * Token is expiring soon (within threshold), refresh recommended.
     * App should proactively refresh but can still use current token.
     */
    data object ExpiringSoon : TokenState()

    /**
     * Currently refreshing token in background.
     * App should queue API calls or use current token if still valid.
     */
    data object Refreshing : TokenState()

    /**
     * Token refresh succeeded — fresh tokens are now available in storage.
     *
     * This is a **signal**, not a data carrier. To obtain the new access token,
     * call `getAccessToken()` — the single canonical path for token access in
     * both `Automatic` and `Manual` modes. This is consistent with [Valid],
     * [ExpiringSoon], and all other states that carry no token payload.
     *
     * The raw refresh token is never exposed through the observable StateFlow
     * to prevent accidental leakage via logging, analytics, or crash reports.
     * (PR #71 review #7, team decision 2026-04-16)
     */
    data object Refreshed : TokenState()

    /**
     * Token expired and needs immediate refresh.
     * App should trigger refresh before making API calls.
     */
    data object Expired : TokenState()

    /**
     * Refresh failed, user re-authentication required.
     * This typically happens when refresh token is revoked or expired.
     *
     * @property error The error that caused the refresh failure
     */
    data class RefreshFailed(
        val error: SrgLoginError,
    ) : TokenState()

    /**
     * No tokens available — confirmed absence of any usable token.
     * User needs to log in.
     */
    data object NoTokens : TokenState()
}
