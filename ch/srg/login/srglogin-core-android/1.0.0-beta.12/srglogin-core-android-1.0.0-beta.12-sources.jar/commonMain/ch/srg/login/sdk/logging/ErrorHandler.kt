package ch.srg.login.sdk.logging

/**
 * Interface for error tracking services (Sentry, Crashlytics, Firebase, etc.).
 *
 * This interface provides a contract for reporting errors to external monitoring services.
 * It is separate from [ch.srg.login.sdk.logging.SdkLogger] which handles general logging.
 *
 * ## Architecture: Dual API
 *
 * - **SdkLogger**: For all log levels (VERBOSE, DEBUG, INFO, WARNING, ERROR, ASSERT)
 *   - Use for debugging, monitoring, and general application flow
 *   - High volume (95% of all events)
 *   - Outputs to console, files, debug UI
 *
 * - **ErrorHandler**: For errors only (WARNING, ERROR, FATAL)
 *   - Use for tracking errors that need investigation
 *   - Low volume (5% of all events)
 *   - Sends to cloud services (Sentry, Crashlytics)
 *
 * ## Usage
 *
 * Error tracking is automatically initialized by the SDK based on environment:
 * - **DEV**: No tracking
 * - **INT/PROD**: Automatic tracking with SdkErrorReporter
 *
 * ```kotlin
 * // Report errors in SDK code (happens automatically at error sites)
 * try {
 *     tokenManager.refreshTokens()
 * } catch (e: Exception) {
 *     // Log to console
 *     SdkLogger.e(LogCategory.TOKEN_MONITORING, throwable = e) {
 *         "Token refresh failed"
 *     }
 *
 *     // Report to Sentry
 *     ErrorHandlerRegistry.captureException(
 *         throwable = e,
 *         context = mapOf("operation" to "token_refresh")
 *     )
 *
 *     throw e
 * }
 * ```
 *
 * ## Implementation Guidelines
 *
 * - **Thread Safety**: Implementations must be thread-safe
 * - **Non-Blocking**: Error reporting should not block SDK operations
 * - **No PII**: Never include personally identifiable information
 * - **Fail Silently**: If error tracking fails, SDK should continue working
 * - **GDPR Compliant**: Only collect diagnostic data, not user data
 *
 * ## When to Use
 *
 * Use ErrorHandler for:
 * - ✅ Exceptions that need investigation
 * - ✅ Critical errors affecting functionality
 * - ✅ Network failures, API errors
 * - ✅ JWT validation failures
 * - ✅ Token refresh failures
 *
 * Do NOT use for:
 * - ❌ Debug logs (use SdkLogger.d())
 * - ❌ Info logs (use SdkLogger.i())
 * - ❌ Expected validation errors
 * - ❌ User input validation
 *
 * @see ch.srg.login.sdk.logging.SdkLogger
 * @see ErrorHandlerRegistry
 */
internal interface ErrorHandler {
    /**
     * Captures an exception with optional context.
     *
     * Use this to report exceptions that occur during SDK operations.
     * The exception will be sent to the configured error tracking service
     * with additional context for debugging.
     *
     * **Thread Safety**: This method must be thread-safe.
     *
     * **Performance**: Implementations should be non-blocking. Consider
     * using background queues for network operations.
     *
     * **Privacy**: Do NOT include PII in context. Use anonymized IDs only.
     *
     * @param throwable The exception to report
     * @param context Additional context for debugging (operation name, user action, etc.)
     *               Keys should be descriptive (e.g., "operation", "retry_count")
     *               Values must not contain PII
     * @param level Error severity level (defaults to ERROR)
     *
     * @example
     * ```kotlin
     * try {
     *     apiService.refreshToken()
     * } catch (e: NetworkException) {
     *     captureException(
     *         throwable = e,
     *         context = mapOf(
     *             "operation" to "token_refresh",
     *             "retry_count" to 3,
     *             "endpoint" to "/oauth/token"
     *         ),
     *         level = ErrorLevel.ERROR
     *     )
     * }
     * ```
     */
    fun captureException(
        throwable: Throwable,
        context: Map<String, Any?> = emptyMap(),
        level: ErrorLevel = ErrorLevel.ERROR,
    )

    /**
     * Captures a message (non-exception error).
     *
     * Use this to report error conditions that don't have an associated exception.
     * For example, validation failures, configuration errors, or unexpected states.
     *
     * **When to Use**:
     * - Configuration validation failed
     * - Unexpected null values
     * - State machine errors
     * - API contract violations
     *
     * **Privacy**: Message must not contain PII.
     *
     * @param message The error message to report (must not contain PII)
     * @param context Additional context for debugging
     * @param level Error severity level (defaults to ERROR)
     *
     * @example
     * ```kotlin
     * if (config.clientId.isBlank()) {
     *     captureMessage(
     *         message = "SDK configuration invalid: clientId is blank",
     *         context = mapOf("config_source" to "initialization"),
     *         level = ErrorLevel.ERROR
     *     )
     * }
     * ```
     */
    fun captureMessage(
        message: String,
        context: Map<String, Any?> = emptyMap(),
        level: ErrorLevel = ErrorLevel.ERROR,
    )

    /**
     * Sets user context for error tracking.
     *
     * **CRITICAL SECURITY & PRIVACY REQUIREMENTS**:
     *
     * This method receives an **already anonymized** user identifier.
     * The SDK implementation is responsible for anonymization BEFORE calling this method.
     *
     * ## Security: Double Anonymization (Recommended)
     *
     * For maximum security, the SDK uses **double anonymization**:
     * 1. IDP provides anonymized `sub` claim (e.g., UUID, hash)
     * 2. SDK further hashes the `sub` with salt: `SHA-256(sub + salt + business_unit)`
     *
     * This approach ensures:
     * - ✅ Even if error tracking service is compromised, original `sub` cannot be recovered
     * - ✅ Cross-business-unit correlation is prevented (different salts)
     * - ✅ Grouping errors by user remains possible (same input = same hash)
     * - ✅ Defense in depth security
     *
     * ## What This Method Receives
     *
     * This method receives a **hashed user ID** like:
     * - `"a1b2c3d4e5f6g7h8"` (16-char hash of JWT sub)
     * - NOT the original JWT `sub` claim
     * - NOT any PII (email, name, etc.)
     *
     * ## GDPR Compliance
     *
     * The anonymized ID is NOT personal data under GDPR Article 4(1) because:
     * - It cannot be linked back to an individual without the original `sub` and salt
     * - It is technical, non-identifiable information
     * - No additional user consent required
     *
     * ## Implementation Note
     *
     * Implementations (e.g., SdkErrorReporter) receive this already-anonymized ID.
     * They should NOT perform additional hashing or transformation.
     *
     * @param userId Anonymized user identifier (already hashed by SDK, null to clear)
     *
     * @example
     * ```kotlin
     * // ✅ CORRECT: Receives hashed ID from SDK
     * setUser(userId = "a1b2c3d4e5f6g7h8")  // 16-char hash
     *
     * // ❌ NEVER CALL WITH PII (SDK prevents this)
     * // setUser(userId = "john.doe@example.com")  // This should never happen
     * ```
     *
     * @see [GDPR Article 4(1)](https://gdpr-info.eu/art-4-gdpr/)
     */
    fun setUser(userId: String?)

    /**
     * Adds a custom tag for filtering in error tracking UI.
     *
     * Tags are key-value pairs used to filter and group errors in the
     * error tracking dashboard (e.g., Sentry, Crashlytics).
     *
     * **Common Tags**:
     * - `operation`: "token_refresh", "authentication", "logout"
     * - `feature`: "authentication", "token_management"
     * - `retry_count`: "1", "2", "3"
     *
     * **Privacy**: Tags must not contain PII.
     *
     * **Note**: Global tags (business_unit, platform, environment, etc.)
     * are automatically set by the implementation using TelemetryContext.
     * This method is for dynamic, operation-specific tags.
     *
     * @param key Tag key (e.g., "operation", "feature")
     * @param value Tag value (e.g., "token_refresh", "authentication")
     *
     * @example
     * ```kotlin
     * setTag("operation", "token_refresh")
     * setTag("retry_count", "3")
     * setTag("endpoint", "/oauth/token")
     * ```
     */
    fun setTag(
        key: String,
        value: String,
    )

    /**
     * Error severity levels.
     *
     * Maps to common error tracking service levels (Sentry, Crashlytics, etc.).
     *
     * ## Level Guidelines
     *
     * - **DEBUG**: Diagnostic information (rarely used in error tracking)
     * - **INFO**: Informational messages (rarely used in error tracking)
     * - **WARNING**: Warning conditions that should be investigated
     *   - Example: Deprecated API usage, slow operations
     * - **ERROR**: Error conditions that affect functionality
     *   - Example: Network failures, token refresh failures
     * - **FATAL**: Critical errors that prevent SDK from functioning
     *   - Example: Configuration errors, security violations
     */
    enum class ErrorLevel {
        DEBUG,
        INFO,
        WARNING,
        ERROR,
        FATAL,
    }
}
