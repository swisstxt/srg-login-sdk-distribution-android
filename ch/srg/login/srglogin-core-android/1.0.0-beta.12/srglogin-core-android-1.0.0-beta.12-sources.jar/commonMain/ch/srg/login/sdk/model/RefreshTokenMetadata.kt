package ch.srg.login.sdk.model

import kotlinx.serialization.Serializable

/**
 * Session-scoped metadata about refresh token usage for debugging and analytics.
 *
 * This data tracks refresh token usage patterns within the current authentication
 * session for troubleshooting, debugging, and understanding user behavior. It does
 * NOT implement client-side security enforcement - OAuth 2.0 security is handled
 * by the authorization server via token family revocation (RFC 6819, RFC 9700).
 *
 * **Session Scope**:
 * - Metadata is reset on each new login (new session starts)
 * - Metadata is cleared on logout (session ends)
 * - Metadata persists across app restarts within the same session
 * - `sessionRefreshCount` tracks refreshes within the current session only
 *
 * **Purpose: Debugging & Analytics**:
 * - Troubleshoot authentication issues ("user had 15 refreshes before error")
 * - Detect client-side bugs (refresh loops, excessive refreshes)
 * - Understand session length and user behavior
 * - Debug token rotation issues with `previousTokenHash`
 *
 * **Privacy-First Design**:
 * - No device tracking (no Android ID, IMEI, etc.)
 * - No installation tracking
 * - GDPR/CCPA compliant by default
 * - Only tracks token-specific metadata
 *
 * **Example Usage**:
 * ```kotlin
 * // On new login - create fresh session metadata
 * val currentTimeMillis = Clock.System.now().toEpochMilliseconds()
 * val currentTimeSeconds = currentTimeMillis / 1000
 *
 * val metadata = RefreshTokenMetadata(
 *     sessionCreatedAt = currentTimeMillis,
 *     issuedAt = currentTimeSeconds,
 *     lastUsedAt = currentTimeSeconds,
 *     lastRefreshAt = null,
 *     sessionRefreshCount = 0,
 *     lastRefreshError = null,
 *     previousTokenHash = null
 * )
 *
 * // On successful token refresh - update metadata
 * val updated = metadata.withSuccessfulRefresh(
 *     newLastUsedAt = Clock.System.now().epochSeconds,
 *     newLastRefreshAt = Clock.System.now().toEpochMilliseconds(),
 *     newPreviousTokenHash = sha256Hash(oldRefreshToken)
 * )
 *
 * // On failed token refresh - record error
 * val withError = metadata.withFailedRefresh("invalid_grant: Refresh token expired")
 * ```
 */
@Serializable
internal data class RefreshTokenMetadata(
    /**
     * Timestamp when the current session was created (epoch milliseconds).
     *
     * **Session lifecycle**:
     * - Set once when user logs in (session starts)
     * - Never changes during the session (even after token rotation)
     * - Reset to new timestamp on next login (new session)
     *
     * **Debugging uses**:
     * - Calculate session duration: `currentTime - sessionCreatedAt`
     * - Analyze session lifetime patterns
     * - Correlate issues with session age ("errors after 8-hour sessions")
     * - Monitor long-lived sessions for security/UX analysis
     */
    val sessionCreatedAt: Long,
    /**
     * Timestamp when this refresh token was first issued (epoch seconds).
     *
     * Used to calculate token age and enforce maximum lifetime policies.
     * Does not change during token rotation.
     */
    val issuedAt: Long,
    /**
     * Timestamp when this refresh token was last used for a refresh (epoch seconds).
     *
     * Updated on every successful refresh operation.
     * Used to detect suspicious time gaps or rapid refresh patterns.
     */
    val lastUsedAt: Long,
    /**
     * Timestamp of the last successful token refresh (epoch milliseconds).
     *
     * **Purpose**:
     * - Track exact timing of refresh operations
     * - Verify refresh intervals are as expected (e.g., every hour)
     * - Debug timing-related issues
     * - Distinguish between "never refreshed" (null) vs "refreshed at X"
     *
     * **Lifecycle**:
     * - Starts as null for new sessions (no refresh yet)
     * - Updated to current timestamp on each successful refresh
     * - Reset to null on new login
     *
     * Null means no refresh has occurred in this session yet.
     */
    val lastRefreshAt: Long? = null,
    /**
     * Number of times tokens have been refreshed within the current session.
     *
     * **Session-scoped counter**:
     * - Starts at 0 when a new session begins (new login)
     * - Incremented on each successful refresh within the session
     * - Reset to 0 on next login (new session)
     * - Cleared on logout
     *
     * **Debugging uses**:
     * - Troubleshoot auth issues: "User had 15 refreshes before error occurred"
     * - Detect refresh loops: Rapid growth may indicate client bug
     * - Understand session length: Higher count = longer session
     * - Performance monitoring: Excessive refreshes impact battery/network
     *
     * Default: 0 (newly issued token or new session)
     */
    val sessionRefreshCount: Int = 0,
    /**
     * Error message from the last failed refresh attempt.
     *
     * **Purpose**:
     * - Immediate troubleshooting: See why last refresh failed
     * - Root cause analysis: "invalid_grant" vs network errors
     * - User support: Provide context when investigating auth issues
     * - Error pattern detection: Track common failure modes
     *
     * **Lifecycle**:
     * - Starts as null for new sessions (no errors yet)
     * - Set to error message when refresh fails
     * - Cleared (set to null) on next successful refresh
     * - Reset to null on new login
     *
     * **Example values**:
     * - "invalid_grant: Refresh token expired"
     * - "Network error: Connection timeout"
     * - "Server error: 503 Service Unavailable"
     *
     * Null means last refresh succeeded or no refresh attempted yet.
     */
    val lastRefreshError: String? = null,
    /**
     * SHA-256 hash of the previous refresh token value.
     *
     * Used to detect refresh token rotation and prevent reuse attacks.
     * When a refresh token is used, it may be rotated (replaced with a new one).
     * This hash allows detection if:
     * - The token was refreshed by another client (theft indicator)
     * - The token is being reused after rotation (replay attack)
     *
     * Set to null for newly issued tokens (no previous token exists).
     *
     * **Security Note**: We store the hash, not the actual token value,
     * to prevent exposure if storage is compromised.
     */
    val previousTokenHash: String? = null,
) {
    /**
     * Calculates the age of this refresh token in seconds.
     *
     * @param currentTime Current timestamp in epoch seconds
     * @return Age of the token in seconds
     */
    fun getTokenAgeSeconds(currentTime: Long): Long = currentTime - issuedAt

    /**
     * Calculates time since last refresh in seconds.
     *
     * @param currentTime Current timestamp in epoch seconds
     * @return Seconds since last refresh
     */
    fun getTimeSinceLastRefreshSeconds(currentTime: Long): Long = currentTime - lastUsedAt

    /**
     * Calculates the session duration in milliseconds.
     *
     * @param currentTime Current timestamp in epoch milliseconds
     * @return Session age in milliseconds
     */
    fun getSessionDurationMillis(currentTime: Long): Long = currentTime - sessionCreatedAt

    /**
     * Creates a copy of this metadata after a successful token refresh.
     *
     * This method updates all relevant fields when a refresh succeeds:
     * - Increments the session refresh counter
     * - Updates the last refresh timestamp
     * - Clears any previous error (successful refresh)
     * - Updates token hash for rotation detection
     *
     * @param newLastUsedAt New timestamp for last token usage (epoch seconds)
     * @param newLastRefreshAt New timestamp for successful refresh (epoch milliseconds)
     * @param newPreviousTokenHash SHA-256 hash of the refresh token that was just used
     * @return Updated metadata reflecting the successful refresh
     */
    fun withSuccessfulRefresh(
        newLastUsedAt: Long,
        newLastRefreshAt: Long,
        newPreviousTokenHash: String?,
    ): RefreshTokenMetadata =
        copy(
            lastUsedAt = newLastUsedAt,
            lastRefreshAt = newLastRefreshAt,
            sessionRefreshCount = sessionRefreshCount + 1,
            // Clear error on success
            lastRefreshError = null,
            previousTokenHash = newPreviousTokenHash,
        )

    /**
     * Creates a copy of this metadata after a failed token refresh.
     *
     * This method updates error tracking when a refresh fails:
     * - Records the error message for debugging
     * - Does NOT increment refresh count (refresh didn't succeed)
     * - Preserves other metadata fields
     *
     * @param errorMessage Description of the refresh failure
     * @return Updated metadata with error information
     */
    fun withFailedRefresh(errorMessage: String): RefreshTokenMetadata =
        copy(
            lastRefreshError = errorMessage,
        )
}
