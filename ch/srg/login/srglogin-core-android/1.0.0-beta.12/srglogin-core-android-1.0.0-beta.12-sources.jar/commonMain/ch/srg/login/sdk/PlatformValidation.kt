package ch.srg.login.sdk

/**
 * Platform-specific validation for SDK initialization.
 * Each platform can define its own requirements for the platformContext parameter.
 */
internal expect fun validatePlatformRequirements(platformContext: Any?)
