package ch.srg.login.sdk.events

import kotlinx.coroutines.flow.SharedFlow

/**
 * Interface for emitting SDK lifecycle events.
 *
 * This interface defines the contract for event emission in the SDK's
 * event-driven architecture. It enables:
 * - Loose coupling between SDK components
 * - Easy testing with fake implementations
 * - Clean dependency injection
 * - Future extensibility (custom event emitters)
 *
 * **Design Principle**: Dependency Inversion Principle (SOLID)
 * - High-level modules (TokenManager, WebAuthenticationManager) depend on this abstraction
 * - Low-level module (SdkEventEmitter) implements this abstraction
 *
 * **Testing**: Easily mockable/fakeable for unit tests
 * ```kotlin
 * class FakeSdkEventEmitter : EventEmitter {
 *     val emittedEvents = mutableListOf<SdkLifecycleEvent>()
 *     override suspend fun emit(event: SdkLifecycleEvent) {
 *         emittedEvents.add(event)
 *     }
 * }
 * ```
 *
 * **Production Implementation**: [SdkEventEmitter]
 *
 * @since 1.0.0
 */
internal interface EventEmitter {
    /**
     * Shared flow of SDK lifecycle events.
     *
     * Consumers can collect this flow to observe all SDK events:
     * ```kotlin
     * eventEmitter.events.collect { event ->
     *     when (event) {
     *         is SdkLifecycleEvent.LoginSuccess -> handleLogin()
     *         is SdkLifecycleEvent.TokenRefreshSuccess -> handleRefresh()
     *         // ... other events
     *     }
     * }
     * ```
     */
    val events: SharedFlow<SdkLifecycleEvent>

    /**
     * Emits an event (suspend function).
     *
     * Use this method when emitting from suspending contexts (coroutines).
     * The emission will suspend if all subscribers are slow and the buffer is full.
     *
     * @param event The event to emit
     */
    suspend fun emit(event: SdkLifecycleEvent)

    /**
     * Tries to emit an event without suspending (non-blocking).
     *
     * Use this method when emitting from non-suspending contexts or when
     * you don't want to suspend on buffer overflow.
     *
     * @param event The event to emit
     * @return `true` if emission succeeded, `false` if buffer is full
     */
    fun tryEmit(event: SdkLifecycleEvent): Boolean
}
