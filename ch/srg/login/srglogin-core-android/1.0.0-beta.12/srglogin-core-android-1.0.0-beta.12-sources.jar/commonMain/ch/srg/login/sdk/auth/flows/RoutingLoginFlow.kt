package ch.srg.login.sdk.auth.flows

import ch.srg.login.sdk.auth.LoginMethod
import ch.srg.login.sdk.auth.LoginState
import ch.srg.login.sdk.auth.PlatformAuthContext
import ch.srg.login.sdk.errors.SrgLoginError
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf
import kotlin.reflect.KClass

/**
 * Routes login calls to the correct [LoginFlow] based on [LoginMethod] type.
 *
 * Used on platforms that support multiple login flows (e.g., tvOS: Device + ROPC).
 * Single-flow platforms can use a concrete flow directly.
 */
internal class RoutingLoginFlow(
    private val strategies: Map<KClass<out LoginMethod>, LoginFlow>,
) : LoginFlow {
    override fun login(
        loginMethod: LoginMethod,
        authContext: PlatformAuthContext,
        additionalScopes: List<String>,
        additionalParameters: Map<String, String>,
    ): Flow<LoginState> {
        val strategy =
            strategies[loginMethod::class]
                ?: return flowOf(
                    LoginState.Failure(
                        SrgLoginError.InvalidConfiguration(
                            "No login flow registered for ${loginMethod::class.simpleName}.",
                        ),
                    ),
                )
        return strategy.login(loginMethod, authContext, additionalScopes, additionalParameters)
    }
}
