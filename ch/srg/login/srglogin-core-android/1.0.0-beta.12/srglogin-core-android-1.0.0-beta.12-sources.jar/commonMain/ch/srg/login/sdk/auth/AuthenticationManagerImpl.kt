package ch.srg.login.sdk.auth

import ch.srg.login.sdk.auth.flows.LoginFlow
import ch.srg.login.sdk.auth.logout.BackChannelLogoutCapable
import ch.srg.login.sdk.auth.logout.LogoutHandler
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.logging.LogCategory
import ch.srg.login.sdk.logging.SdkLogger
import ch.srg.login.sdk.result.SdkResult
import kotlinx.coroutines.flow.Flow

/**
 * Unified authentication manager that delegates login to a [LoginFlow]
 * and logout to a [LogoutHandler].
 *
 * This replaces the per-flow `WebAuthenticationManager` / `DeviceAuthenticationManager`
 * classes with a single composable implementation.
 * [LoginMethod.Migration] is routed to a dedicated `migrationFlow`; all other login methods
 * are dispatched to `loginStrategy`.
 */
internal class AuthenticationManagerImpl(
    private val loginStrategy: LoginFlow,
    private val logoutHandler: LogoutHandler,
    private val webAuthenticator: WebAuthenticator?,
    private val migrationFlow: LoginFlow,
) : AuthenticationManager {
    override fun login(
        loginMethod: LoginMethod,
        authContext: PlatformAuthContext,
        additionalScopes: List<String>,
        additionalParameters: Map<String, String>,
    ): Flow<LoginState> {
        if (loginMethod is LoginMethod.Migration) {
            return migrationFlow.login(loginMethod, authContext, additionalScopes, additionalParameters)
        }
        return loginStrategy.login(loginMethod, authContext, additionalScopes, additionalParameters)
    }

    /** Delegates to [LogoutHandler.logout]. */
    override suspend fun logout(logoutType: LogoutType): LogoutResult = logoutHandler.logout(logoutType)

    /**
     * Routes to the underlying [BackChannelLogoutCapable] logout handler.
     * Returns [SdkResult.Failure] with [SrgLoginError.InvalidConfiguration] if the platform
     * does not support back-channel logout (e.g., TV platforms without a browser).
     */
    override fun registerBackChannelLogoutListener(listener: BackChannelLogoutListener): SdkResult<Unit> {
        val capable = logoutHandler as? BackChannelLogoutCapable
        if (capable == null) {
            val message = "Back-channel logout is not supported on this platform."
            SdkLogger.w(LogCategory.AUTHENTICATION) { message }
            return SdkResult.Failure(SrgLoginError.InvalidConfiguration(message))
        }
        capable.registerBackChannelLogoutListener(listener)
        return SdkResult.Success(Unit)
    }

    /**
     * Routes to the underlying [BackChannelLogoutCapable] logout handler.
     * Returns [SdkResult.Failure] if the platform does not support back-channel logout.
     */
    override fun unregisterBackChannelLogoutListener(listener: BackChannelLogoutListener): SdkResult<Unit> {
        val capable = logoutHandler as? BackChannelLogoutCapable
        if (capable == null) {
            val message = "Back-channel logout is not supported on this platform."
            SdkLogger.w(LogCategory.AUTHENTICATION) { message }
            return SdkResult.Failure(SrgLoginError.InvalidConfiguration(message))
        }
        capable.unregisterBackChannelLogoutListener(listener)
        return SdkResult.Success(Unit)
    }

    /**
     * Opens an SSO client URL in the platform browser.
     *
     * Returns [SdkResult.Failure] with [SrgLoginError.InvalidConfiguration] if the platform
     * does not support web authentication (i.e., no [WebAuthenticator] is provided), or if
     * URL validation fails (see [validateSsoClientUrl]).
     */
    override suspend fun openSsoClient(
        ssoClientUrl: String,
        authContext: PlatformAuthContext,
    ): SdkResult<Unit> =
        when (webAuthenticator) {
            null -> {
                val message = "openSsoClient is not supported on this platform."
                SdkLogger.w(LogCategory.AUTHENTICATION) { message }
                SdkResult.Failure(SrgLoginError.InvalidConfiguration(message))
            }

            else -> {
                validateSsoClientUrl(ssoClientUrl).takeIf { it is SdkResult.Failure }
                    ?: webAuthenticator.openSsoClient(ssoClientUrl, authContext)
            }
        }
}
