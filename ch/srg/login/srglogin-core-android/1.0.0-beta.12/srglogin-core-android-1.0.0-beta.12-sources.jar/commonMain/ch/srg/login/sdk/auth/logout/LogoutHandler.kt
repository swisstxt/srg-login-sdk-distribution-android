package ch.srg.login.sdk.auth.logout

import ch.srg.login.sdk.auth.LogoutResult
import ch.srg.login.sdk.auth.LogoutType
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.events.EventEmitter
import ch.srg.login.sdk.events.SdkLifecycleEvent
import ch.srg.login.sdk.events.StorageOperation
import ch.srg.login.sdk.token.TokenStorage
import kotlinx.datetime.Clock

/**
 * Abstract base class for logout handling using the Template Method pattern.
 *
 * Routes [LogoutType] to the appropriate handler, checking for capability support.
 * Subclasses gain additional logout methods by implementing capability interfaces
 * ([BackChannelLogoutCapable], [FrontChannelLogoutCapable]).
 *
 * The [performLocalLogout] method is shared by all handlers and capability interfaces.
 */
internal abstract class LogoutHandler(
    protected open val tokenStorage: TokenStorage,
    protected val eventEmitter: EventEmitter,
    protected val clock: Clock = Clock.System,
) {
    /**
     * Template method — routes by [LogoutType], checks capability, emits events.
     * Not open — subclasses customize behavior via capability interfaces.
     */
    suspend fun logout(logoutType: LogoutType): LogoutResult {
        emitLogoutStarted(logoutType)

        val result =
            when (logoutType) {
                is LogoutType.LocalOnly -> {
                    performLocalLogout()
                }

                is LogoutType.FrontChannel -> {
                    (this as? FrontChannelLogoutCapable)?.performFrontChannelLogout(logoutType)
                        ?: notSupported("FrontChannel")
                }

                is LogoutType.BackChannel -> {
                    (this as? BackChannelLogoutCapable)?.performBackChannelLogout(logoutType)
                        ?: notSupported("BackChannel")
                }
            }

        emitLogoutResult(logoutType, result)
        return result
    }

    /**
     * Clears local session state: removes stored tokens and emits [SdkLifecycleEvent.TokensCleared].
     * Declared in [BackChannelLogoutCapable] and [FrontChannelLogoutCapable] so capability interfaces
     * can call it directly without an unsafe cast.
     */
    suspend fun performLocalLogout(): LogoutResult {
        val clearResult = tokenStorage.clearTokens()
        return if (clearResult.isSuccess) {
            val timestamp = clock.now().toEpochMilliseconds()
            eventEmitter.tryEmit(
                SdkLifecycleEvent.TokensCleared(
                    reason = "logout",
                    timestamp = timestamp,
                ),
            )
            LogoutResult.Success(
                clearedLocalSession = true,
                terminatedServerSession = false,
            )
        } else {
            val storageException = clearResult.exceptionOrNull() ?: Exception("Failed to clear local tokens")
            val storageError = SrgLoginError.UnknownError(storageException)
            eventEmitter.tryEmit(
                SdkLifecycleEvent.StorageError(
                    operation = StorageOperation.CLEAR,
                    error = storageError,
                    timestamp = clock.now().toEpochMilliseconds(),
                ),
            )
            LogoutResult.Failure(
                clearedLocalSession = false,
                serverLogoutAttempted = false,
                error = storageError,
            )
        }
    }

    /** Emits [SdkLifecycleEvent.LogoutStarted] with the current timestamp. */
    private fun emitLogoutStarted(logoutType: LogoutType) {
        val timestamp = clock.now().toEpochMilliseconds()
        eventEmitter.tryEmit(SdkLifecycleEvent.LogoutStarted(logoutType, timestamp))
    }

    /** Emits [SdkLifecycleEvent.LogoutSuccess] or [SdkLifecycleEvent.LogoutFailure] based on [result]. */
    private fun emitLogoutResult(
        logoutType: LogoutType,
        result: LogoutResult,
    ) {
        val timestamp = clock.now().toEpochMilliseconds()
        when (result) {
            is LogoutResult.Success -> {
                eventEmitter.tryEmit(SdkLifecycleEvent.LogoutSuccess(logoutType, timestamp))
            }

            is LogoutResult.Failure -> {
                eventEmitter.tryEmit(SdkLifecycleEvent.LogoutFailure(result.error, timestamp))
            }
        }
    }

    /** Returns [LogoutResult.Failure] with [SrgLoginError.InvalidConfiguration] for unsupported logout types. */
    private fun notSupported(type: String): LogoutResult =
        LogoutResult.Failure(
            clearedLocalSession = false,
            serverLogoutAttempted = false,
            error =
                SrgLoginError.InvalidConfiguration(
                    "$type logout is not supported on this platform.",
                ),
        )
}
