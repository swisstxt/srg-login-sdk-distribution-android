package ch.srg.login.sdk.model

/**
 * Public token result from authentication.
 *
 * Represents the consumer-facing OAuth 2.0/OIDC token response, with the access
 * token parsed into a type-safe [AccessToken] and (when an OIDC `openid` scope
 * was granted) the ID token claims exposed via [idTokenClaims].
 *
 * Returned via [ch.srg.login.sdk.auth.LoginState.Success] after a successful login.
 * **Not** exposed via [ch.srg.login.sdk.auth.TokenState] (the observable StateFlow) —
 * `TokenState.Refreshed` is a `data object` signal with no payload, keeping the
 * refresh token out of the observable stream.
 *
 * @property accessToken Access token with parsed JWT claims.
 * @property refreshToken Refresh token for obtaining new access tokens (null if not
 *   provided by the IDP, e.g. when `offline_access` scope was not requested).
 *   **Security**: Never log, persist outside secure storage, or transmit off-device.
 * @property idToken Raw OIDC ID token JWT string (null if not provided or not using OIDC).
 *   Useful for debugging or transmitting to a backend that re-validates. For consumer
 *   logic, prefer the typed [idTokenClaims] which is only populated after the SDK has
 *   cryptographically validated the JWT (signature, iss, aud, exp, nonce, azp).
 * @property idTokenClaims Parsed and validated ID token claims. The presence of this object is
 *   a proof that the SDK has fully validated the ID token — consumers can trust the values
 *   without re-parsing the JWT.
 *
 *   **May be `null`** in any of these cases:
 *   - The `openid` scope was not granted at login (no ID token returned).
 *   - Login completed without an ID token (e.g. ROPC against an IdP that does not return one).
 *   - **After a token refresh**, when the IDP did not return a fresh ID token, or when
 *     re-validation of the refreshed ID token failed (e.g. JWKS key rotation between login
 *     and refresh — the access token is still usable, only the typed claims drop). The SDK
 *     emits a warning log in this case but no dedicated event, by design (cf. ADR-012 §12).
 *
 *   For a **stable user identifier** that survives refreshes, prefer [AccessToken.subject]
 *   (always populated when the token's `sub` claim is present, which is universal in OIDC)
 *   over `idTokenClaims.subject`. Reserve `idTokenClaims` for richer profile data
 *   (`email`, `name`, etc.) and accept that those may need to be cached at login if the BU
 *   app wants them available across refreshes. (PR #77 review #9)
 * @property tokenType Token type, typically "Bearer".
 * @property scopes OAuth scopes granted by the IDP. Use [hasScope] to check whether a
 *   specific scope was granted. Empty list means the IDP did not return a scope claim.
 *
 * Usage:
 * ```kotlin
 * srgLogin.login(LoginMethod.Web, authContext).collect { state ->
 *     when (state) {
 *         is LoginState.Success -> {
 *             val tokenSet = state.tokenSet
 *             val accessToken = tokenSet.accessToken
 *             println("Token expires: ${accessToken.formatExpiresIn()}")
 *
 *             // Check granted scopes
 *             if (tokenSet.hasScope("offline_access")) {
 *                 println("Refresh token will be available")
 *             }
 *
 *             // Access typed ID token claims (when openid scope granted)
 *             tokenSet.idTokenClaims?.let { claims ->
 *                 println("Authenticated as: ${claims.subject}")
 *             }
 *         }
 *         is LoginState.Failure -> { /* handle error */ }
 *         else -> { /* intermediate states */ }
 *     }
 * }
 * ```
 */
public data class TokenSet(
    val accessToken: AccessToken,
    val refreshToken: String? = null,
    val idToken: String? = null,
    val idTokenClaims: IdTokenClaims? = null,
    val tokenType: String = "Bearer",
    val scopes: List<String> = emptyList(),
) {
    /**
     * Returns `true` if [scope] is in [scopes] (i.e. was granted by the IDP).
     */
    public fun hasScope(scope: String): Boolean = scope in scopes

    public companion object {
        /**
         * Create TokenSet from TokenResponseDto (internal conversion).
         *
         * INTERNAL: callers MUST provide already-validated claims. The presence of
         * [idTokenClaims] is a proof that the SDK has fully validated the ID token
         * (signature, iss, aud, exp, nonce, azp). Pass `null` when no ID token was
         * issued (no `openid` scope) or when validation is intentionally skipped
         * (freshness check rebuild from encrypted storage).
         *
         * @param dto Internal DTO from OAuth 2.0 token endpoint.
         * @param accessTokenClaims Validated (or trusted-from-storage) claims of the access token.
         * @param idTokenClaims Validated ID token claims, or `null` if no ID token was returned.
         */
        internal fun fromDto(
            dto: TokenResponseDto,
            accessTokenClaims: JwtClaims,
            idTokenClaims: IdTokenClaims? = null,
        ): TokenSet {
            val accessToken = AccessToken.fromJwt(dto.accessToken, accessTokenClaims)
            return TokenSet(
                accessToken = accessToken,
                refreshToken = dto.refreshToken,
                idToken = dto.idToken,
                idTokenClaims = idTokenClaims,
                tokenType = dto.tokenType,
                scopes = parseScopes(dto.scope),
            )
        }

        /**
         * Parses the OAuth wire-format space-separated scope string into a list.
         * Trims whitespace and filters empty tokens. Null or blank input → empty list.
         */
        private fun parseScopes(scope: String?): List<String> {
            if (scope.isNullOrBlank()) return emptyList()
            return scope.trim().split(" ").filter { it.isNotBlank() }
        }
    }
}
