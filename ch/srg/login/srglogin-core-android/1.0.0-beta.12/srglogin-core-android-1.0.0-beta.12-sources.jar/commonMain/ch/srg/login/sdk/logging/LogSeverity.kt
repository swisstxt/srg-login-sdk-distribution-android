package ch.srg.login.sdk.logging

import co.touchlab.kermit.Severity

/**
 * Log severity levels for the SRG Login SDK.
 *
 * Defines a hierarchy of log levels from most verbose (VERBOSE) to most critical (ASSERT).
 * Each level maps to a corresponding Kermit severity for platform-specific logging.
 *
 * ## Severity Hierarchy
 *
 * 1. **VERBOSE** (Priority 1) - Very detailed logging for development/debugging
 * 2. **DEBUG** (Priority 2) - Development insights and detailed information
 * 3. **INFO** (Priority 3) - General informational messages (production default)
 * 4. **WARNING** (Priority 4) - Potential issues that should be reviewed
 * 5. **ERROR** (Priority 5) - Errors that require attention
 * 6. **ASSERT** (Priority 6) - Critical errors that should never happen
 *
 * ## Usage Examples
 *
 * ```kotlin
 * // Development build - enable debug logs
 * val devSeverity = LogSeverity.getDefaultForBuild(isDebugBuild = true)
 * // Returns: LogSeverity.DEBUG
 *
 * // Production build - only info and above
 * val prodSeverity = LogSeverity.getDefaultForBuild(isDebugBuild = false)
 * // Returns: LogSeverity.INFO
 *
 * // Filtering logs by severity
 * val shouldLog = LogSeverity.DEBUG.shouldLog(minSeverity = LogSeverity.INFO)
 * // Returns: false (DEBUG < INFO)
 *
 * val shouldLog2 = LogSeverity.ERROR.shouldLog(minSeverity = LogSeverity.INFO)
 * // Returns: true (ERROR >= INFO)
 * ```
 *
 * ## When to Use Each Level
 *
 * ### VERBOSE
 * - Very detailed state information
 * - Variable values, intermediate calculations
 * - Low-level SDK internals
 * - Example: "JWT claim 'iat' = 1638360000"
 *
 * ### DEBUG
 * - Development insights
 * - Method entry/exit
 * - State transitions
 * - Example: "Token state changed: Valid -> ExpiringSoon"
 *
 * ### INFO
 * - General informational messages
 * - Successful operations
 * - Configuration changes
 * - Example: "SDK initialized successfully"
 * - **Production default**
 *
 * ### WARNING
 * - Potential issues that may require attention
 * - Degraded performance
 * - Recoverable errors
 * - Example: "Token refresh failed, retrying (attempt 2/3)"
 *
 * ### ERROR
 * - Errors requiring attention
 * - Failed operations
 * - Unrecoverable errors
 * - Example: "Token refresh failed: invalid_grant"
 *
 * ### ASSERT
 * - Critical errors that should never happen
 * - Logic errors, invariant violations
 * - Bugs in SDK code
 * - Example: "CRITICAL: Null pointer despite validation"
 *
 * ## Production vs Development
 *
 * **Development (Debug Build)**:
 * - Minimum severity: DEBUG
 * - Enables detailed logging for development
 * - Performance impact acceptable
 *
 * **Production (Release Build)**:
 * - Minimum severity: INFO
 * - Reduces noise and performance overhead
 * - Only important messages logged
 *
 * @property priority Numeric priority for comparison (1 = lowest, 6 = highest)
 * @see SdkLogger
 * @see LogCategory
 */
enum class LogSeverity(
    val priority: Int,
) {
    /**
     * Very detailed logging for development and debugging.
     *
     * Use for:
     * - Variable values
     * - Detailed state information
     * - Low-level SDK internals
     *
     * **Not logged in production** (filtered out by default).
     */
    VERBOSE(1),

    /**
     * Development insights and detailed information.
     *
     * Use for:
     * - Method entry/exit
     * - State transitions
     * - Configuration details
     *
     * **Logged in debug builds**, filtered in production.
     */
    DEBUG(2),

    /**
     * General informational messages.
     *
     * Use for:
     * - Successful operations
     * - Configuration changes
     * - Normal SDK operation
     *
     * **Production default** - Always logged.
     */
    INFO(3),

    /**
     * Potential issues that may require attention.
     *
     * Use for:
     * - Degraded performance
     * - Recoverable errors
     * - Retry attempts
     *
     * **Always logged** in production and development.
     */
    WARNING(4),

    /**
     * Errors requiring attention.
     *
     * Use for:
     * - Failed operations
     * - Unrecoverable errors
     * - Authentication failures
     *
     * **Always logged** in production and development.
     */
    ERROR(5),

    /**
     * Critical errors that should never happen.
     *
     * Use for:
     * - Logic errors
     * - Invariant violations
     * - SDK bugs
     *
     * **Always logged** - indicates a bug in SDK code.
     */
    ASSERT(6),
    ;

    /**
     * Determines if this severity level should be logged given a minimum severity threshold.
     *
     * A log should be emitted if its severity is **greater than or equal to** the minimum severity.
     *
     * @param minSeverity The minimum severity level to log
     * @return `true` if this severity should be logged, `false` otherwise
     *
     * @example
     * ```kotlin
     * // Minimum severity: INFO
     * LogSeverity.VERBOSE.shouldLog(LogSeverity.INFO)  // false (1 < 3)
     * LogSeverity.DEBUG.shouldLog(LogSeverity.INFO)    // false (2 < 3)
     * LogSeverity.INFO.shouldLog(LogSeverity.INFO)     // true  (3 == 3)
     * LogSeverity.WARNING.shouldLog(LogSeverity.INFO)  // true  (4 > 3)
     * LogSeverity.ERROR.shouldLog(LogSeverity.INFO)    // true  (5 > 3)
     * LogSeverity.ASSERT.shouldLog(LogSeverity.INFO)   // true  (6 > 3)
     * ```
     */
    fun shouldLog(minSeverity: LogSeverity): Boolean = this.priority >= minSeverity.priority

    /**
     * Maps this SDK severity to the corresponding Kermit severity.
     *
     * Kermit uses a slightly different severity hierarchy:
     * - Verbose → Verbose
     * - Debug → Debug
     * - Info → Info
     * - Warn → Warn
     * - Error → Error
     * - Assert → Assert
     *
     * @return The corresponding Kermit Severity
     */
    fun toKermitSeverity(): Severity =
        when (this) {
            VERBOSE -> Severity.Verbose
            DEBUG -> Severity.Debug
            INFO -> Severity.Info
            WARNING -> Severity.Warn
            ERROR -> Severity.Error
            ASSERT -> Severity.Assert
        }

    companion object {
        /**
         * Returns the recommended default log severity for a given build type.
         *
         * **Debug builds**: Returns [DEBUG] to enable detailed logging during development.
         *
         * **Release builds**: Returns [INFO] to reduce noise and performance overhead in production.
         *
         * @param isDebugBuild `true` for debug builds, `false` for release builds
         * @return [DEBUG] for debug builds, [INFO] for release builds
         *
         * @example
         * ```kotlin
         * // Development/debug build
         * val severity = LogSeverity.getDefaultForBuild(isDebugBuild = true)
         * // Returns: LogSeverity.DEBUG
         *
         * // Production/release build
         * val severity = LogSeverity.getDefaultForBuild(isDebugBuild = false)
         * // Returns: LogSeverity.INFO
         * ```
         */
        fun getDefaultForBuild(isDebugBuild: Boolean): LogSeverity = if (isDebugBuild) DEBUG else INFO
    }
}
