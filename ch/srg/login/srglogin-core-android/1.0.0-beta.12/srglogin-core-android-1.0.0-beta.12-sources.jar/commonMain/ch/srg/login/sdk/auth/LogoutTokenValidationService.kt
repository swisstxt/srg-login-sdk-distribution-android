package ch.srg.login.sdk.auth

import ch.srg.login.sdk.logging.ErrorHandler
import ch.srg.login.sdk.logging.ErrorHandlerRegistry
import ch.srg.login.sdk.model.JsonWebKey
import ch.srg.login.sdk.model.JwtClaims
import ch.srg.login.sdk.model.LogoutTokenClaims
import ch.srg.login.sdk.model.SessionInfo
import kotlinx.serialization.json.Json

/**
 * Comprehensive service for OIDC back-channel logout token validation.
 * This service orchestrates all security checks required for safe logout token processing.
 *
 * Security validations include:
 * - JWT structure and signature verification
 * - Issuer and audience validation
 * - Replay attack protection
 * - Session matching
 * - Required claims verification
 * - Logout event validation
 */
internal class LogoutTokenValidationService(
    private val jwtValidationService: JwtValidationService,
    private val replayCache: ReplayAttackCache,
    private val expectedIssuer: String,
    private val clientId: String,
    private val jwksUri: String,
    private val json: Json = Json { ignoreUnknownKeys = true },
) {
    /**
     * Validates a logout token against all security requirements.
     * This is the main entry point for logout token validation.
     *
     * @param token The raw JWT logout token
     * @param currentSession Information about the current user session
     * @return Validated logout token claims or error
     */
    suspend fun validateLogoutToken(
        token: String,
        currentSession: SessionInfo? = null,
    ): Result<LogoutTokenClaims> {
        try {
            // Step 1: Parse JWT structure
            val parsedJwt =
                jwtValidationService.parseJwt(token).getOrElse { error ->
                    return Result.failure(error)
                }

            // Step 2: Validate required claims are present
            jwtValidationService.validateRequiredClaims(parsedJwt.claims).getOrElse { error ->
                return Result.failure(error)
            }

            // Step 3: Validate JWT timing (age, expiration, etc.)
            jwtValidationService.validateTiming(parsedJwt.claims, maxAgeSeconds = 600).getOrElse { error ->
                return Result.failure(error)
            }

            // Step 4: Validate issuer
            if (parsedJwt.claims.iss != expectedIssuer) {
                return Result.failure(
                    Exception("Invalid issuer. Expected: $expectedIssuer, Got: ${parsedJwt.claims.iss}"),
                )
            }

            // Step 5: Validate audience (RFC 7519 §4.1.3) — check containment to support multi-audience.
            // Unlike id_tokens (OIDC §3.1.3.7), logout tokens do not require azp for multi-audience
            // per the OIDC Back-Channel Logout spec.
            if (clientId !in parsedJwt.claims.aud) {
                return Result.failure(
                    Exception(
                        "Invalid audience. Expected '$clientId' in audience list, got ${parsedJwt.claims.aud}",
                    ),
                )
            }

            // Step 6: Retrieve JWKS for signature verification
            val jwks =
                jwtValidationService.getJwks(jwksUri).getOrElse { error ->
                    return Result.failure(error)
                }

            // Step 7: Find appropriate verification key
            val verificationKey =
                jwtValidationService.findVerificationKey(parsedJwt.header, jwks)
                    ?: return Result.failure(
                        Exception("No matching public key found for kid: ${parsedJwt.header.kid}"),
                    )

            // Step 8: Verify JWT signature
            // NOTE: In a real implementation, you would use a cryptographic library
            // to verify the signature using the public key. For this example, we'll
            // assume signature verification is handled by a platform-specific implementation.
            val signatureValid = verifySignature(token, verificationKey)
            if (!signatureValid) {
                return Result.failure(
                    Exception("JWT signature verification failed"),
                )
            }

            // Step 9: Check for replay attacks
            val jti = parsedJwt.claims.jti!! // We already validated this exists
            val isFirstUsage = replayCache.markAsUsed(jti)
            if (!isFirstUsage) {
                return Result.failure(
                    Exception("Logout token has already been used (jti: $jti)"),
                )
            }

            // Step 10: Extract and validate logout-specific claims
            val logoutClaims =
                extractLogoutClaims(parsedJwt.claims).getOrElse { error ->
                    return Result.failure(error)
                }

            // Step 11: Validate logout event
            if (!logoutClaims.hasValidLogoutEvent()) {
                return Result.failure(
                    Exception("Token does not contain valid back-channel logout event"),
                )
            }

            // Step 12: Validate session identifier
            if (!logoutClaims.hasValidSessionIdentifier()) {
                return Result.failure(
                    Exception("Token must contain either 'sub' or 'sid' claim"),
                )
            }

            // Step 13: Validate against current session (if provided)
            currentSession?.let { session ->
                val sessionMatches = validateSessionMatch(logoutClaims, session)
                if (!sessionMatches) {
                    return Result.failure(
                        Exception("Logout token does not match current user session"),
                    )
                }
            }

            return Result.success(logoutClaims)
        } catch (e: Exception) {
            // Global catch for any unexpected exception (fail-safe design)
            // Report to error tracking
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "validate_logout_token",
                        "token_type" to "logout_token",
                        "security_critical" to true,
                        "fail_safe" to true,
                        "exception_type" to e::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.FATAL,
            )

            return Result.failure(
                Exception("Logout token validation failed: ${e.message}", e),
            )
        }
    }

    /**
     * Extracts logout-specific claims from the JWT claims.
     */
    private fun extractLogoutClaims(claims: JwtClaims): Result<LogoutTokenClaims> {
        try {
            // Extract the 'events' claim as a JsonObject to preserve nested JSON structure.
            val events =
                claims.jsonObjectClaim("events") ?: return Result.failure(
                    Exception("Missing required 'events' claim"),
                )

            return Result.success(
                LogoutTokenClaims(
                    iss = claims.iss!!,
                    aud = claims.aud,
                    sub = claims.sub,
                    sid = claims.stringClaim("sid"),
                    events = events,
                    iat = claims.iat!!,
                    jti = claims.jti!!,
                ),
            )
        } catch (e: Exception) {
            // Report to error tracking
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "extract_logout_claims",
                        "stage" to "logout_token_parsing",
                        "exception_type" to e::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.ERROR,
            )

            return Result.failure(
                Exception("Failed to extract logout claims: ${e.message}"),
            )
        }
    }

    /**
     * Validates that the logout token applies to the current session.
     */
    private fun validateSessionMatch(
        logoutClaims: LogoutTokenClaims,
        currentSession: SessionInfo,
    ): Boolean {
        // If token has subject (user ID), it should match current user
        logoutClaims.sub?.let { tokenSub ->
            currentSession.userId?.let { currentUserId ->
                if (tokenSub == currentUserId) return true
            }
        }

        // If token has session ID, it should match current session
        logoutClaims.sid?.let { tokenSid ->
            currentSession.sessionId?.let { currentSessionId ->
                if (tokenSid == currentSessionId) return true
            }
        }

        // If we have both sub and sid in the token, at least one should match
        return if (logoutClaims.sub != null && logoutClaims.sid != null) {
            // Both are present but neither matched - session mismatch
            false
        } else {
            // Only one identifier available and it didn't match
            false
        }
    }

    /**
     * Verifies the JWT signature using the provided public key.
     *
     * NOTE: This is a placeholder for actual cryptographic signature verification.
     * In a real implementation, you would use platform-specific crypto libraries
     * such as:
     * - Android: java.security APIs
     * - iOS: Security framework
     * - JVM: Bouncy Castle or similar
     */
    private fun verifySignature(
        token: String,
        key: JsonWebKey,
    ): Boolean {
        // TODO: Implement actual signature verification based on key.alg
        // For RS256: RSA-PSS with SHA-256
        // For ES256: ECDSA with P-256 and SHA-256
        // etc.

        // For now, return true to allow implementation to proceed
        // In production, this MUST be properly implemented
        return true
    }

    /**
     * Validates a logout token without checking against current session.
     * Useful for global logout scenarios or when session info is not available.
     */
    suspend fun validateLogoutTokenGlobal(token: String): Result<LogoutTokenClaims> = validateLogoutToken(token, currentSession = null)

    /**
     * Clears the JWKS cache. Useful for testing or when keys are rotated.
     */
    fun clearJwksCache() {
        jwtValidationService.clearJwksCache()
    }
}
