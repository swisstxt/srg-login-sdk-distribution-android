package ch.srg.login.sdk.auth.flows

import ch.srg.login.sdk.auth.LoginMethod
import ch.srg.login.sdk.auth.LoginState
import ch.srg.login.sdk.auth.PlatformAuthContext
import kotlinx.coroutines.flow.Flow

/**
 * Defines the contract for a login flow.
 *
 * Each implementation handles a specific login method (Web, Device, ROPC).
 * Flows are composed into the [ch.srg.login.sdk.auth.AuthenticationManager]
 * via [RoutingLoginFlow] or used directly for single-flow platforms.
 */
internal fun interface LoginFlow {
    /**
     * Executes the login flow for the given [loginMethod].
     *
     * @param loginMethod The login method to use (Web, Device, or UserPassword/ROPC).
     * @param authContext Platform-specific context required to present the authentication UI.
     * @param additionalScopes Extra OAuth scopes to request beyond the SDK defaults.
     * @param additionalParameters Extra parameters forwarded to the authorization or token endpoint.
     * @return A [Flow] that emits [LoginState] updates until the flow completes or fails.
     */
    fun login(
        loginMethod: LoginMethod,
        authContext: PlatformAuthContext,
        additionalScopes: List<String>,
        additionalParameters: Map<String, String>,
    ): Flow<LoginState>
}
