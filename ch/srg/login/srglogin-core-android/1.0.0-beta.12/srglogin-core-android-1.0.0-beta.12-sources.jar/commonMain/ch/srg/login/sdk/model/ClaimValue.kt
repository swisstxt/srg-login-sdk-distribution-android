package ch.srg.login.sdk.model

/**
 * Type-safe, platform-agnostic representation of a JSON claim value.
 *
 * Used by [IdTokenClaims.rawClaims], [IdTokenClaims.getObjectClaim], and
 * [IdTokenClaims.getArrayClaim] in place of `kotlinx.serialization.json.JsonElement`.
 * Keeps the SDK's public API free of any external library type, so consumers on
 * every target platform can use these accessors without adding `kotlinx-serialization-json`
 * to their own dependencies and without depending on its binary stability.
 *
 * **Cross-platform support:**
 * - **Kotlin (Android, JVM, JS)**: idiomatic exhaustive `when` matching.
 * - **Swift (iOS, tvOS) via SKIE**: this sealed class is rewritten as a Swift `enum`
 *   with associated values, native to Swift `switch` statements.
 * - **TypeScript (via Kotlin/JS)**: emitted as a discriminated-union-friendly hierarchy.
 * - **Java (Spring/Quarkus)**: usable via `instanceof` patterns; Java 17+ pattern matching.
 *
 * **Numeric representation:** JSON does not distinguish integers from fractionals at the
 * wire level — the SDK splits them based on parseability:
 * - Whole-number values that fit in a [Long] become [Integer].
 * - Fractional or out-of-Long-range values become [Decimal] (Double-precision).
 * - Consumers that need either flavour as a Double can use [asDecimal] which promotes
 *   [Integer] values to Double automatically.
 *
 * **Example (Kotlin):**
 * ```kotlin
 * when (val role = claims.rawClaims["role"]) {
 *     is ClaimValue.Text  -> println("role string: ${role.value}")
 *     is ClaimValue.Array -> role.value.forEach { println(it.asText) }
 *     ClaimValue.Null, null -> println("no role")
 *     else -> println("unexpected type")
 * }
 * ```
 *
 * **Example (Swift via SKIE):**
 * ```swift
 * switch claims.rawClaims["role"] {
 * case .text(let s):    print("role string: \(s)")
 * case .array(let arr): arr.forEach { print($0.asText ?? "") }
 * case .null_, .none:   print("no role")
 * default:              print("unexpected type")
 * }
 * ```
 */
public sealed class ClaimValue {
    /** JSON `null` literal. Distinct from "claim absent". */
    public data object Null : ClaimValue()

    /** JSON string primitive — e.g. `"alice@example.com"`. */
    public data class Text(
        val value: String,
    ) : ClaimValue()

    /**
     * JSON integer that fits in a [Long] — e.g. `1234567890` (epoch seconds, IDs, counts).
     * Fractional or out-of-Long-range values fall under [Decimal] instead.
     */
    public data class Integer(
        val value: Long,
    ) : ClaimValue()

    /**
     * JSON fractional or out-of-Long-range numeric — e.g. `0.87`, `1.5e20`.
     *
     * Despite the name, this is **not** `BigDecimal`: the value is a Double and is
     * subject to IEEE-754 precision limits. The name aligns with RFC 7159's implicit
     * "integer / decimal" distinction; for arbitrary-precision needs, consumers should
     * read the original token string and parse it themselves.
     */
    public data class Decimal(
        val value: Double,
    ) : ClaimValue()

    /** JSON boolean — `true` or `false`. */
    public data class Bool(
        val value: Boolean,
    ) : ClaimValue()

    /**
     * JSON array — preserves ordering and per-element types.
     * Empty arrays are represented as [Array] with empty [value], not [Null].
     */
    public data class Array(
        val value: List<ClaimValue>,
    ) : ClaimValue()

    /**
     * JSON object — string-keyed nested structure.
     * Empty objects are represented as [Object] with empty [value], not [Null].
     */
    public data class Object(
        val value: Map<String, ClaimValue>,
    ) : ClaimValue()

    // ===== Convenience accessors =====
    //
    // Provided so that consumers don't need an exhaustive `when` for simple lookups.
    // Each `as*` property returns the underlying value if the runtime type matches,
    // else `null`. These helpers compose well with safe-call chaining:
    //
    //     claims.rawClaims["tenant_id"]?.asText
    //     claims.rawClaims["roles"]?.asArray?.mapNotNull { it.asText }
    //     claims.rawClaims["metadata"]?.asObject?.get("region")?.asText

    /** The string value if this is [Text], else `null`. */
    public val asText: String? get() = (this as? Text)?.value

    /** The Long value if this is [Integer], else `null`. Does NOT promote [Decimal] (use [asDecimal]). */
    public val asInteger: Long? get() = (this as? Integer)?.value

    /**
     * The Double value if this is [Decimal] OR [Integer] (promoted), else `null`.
     * Promotion is intentional: a consumer asking for "the numeric value as a Double"
     * accepts both integer and fractional inputs.
     */
    public val asDecimal: Double?
        get() =
            when (this) {
                is Decimal -> value
                is Integer -> value.toDouble()
                else -> null
            }

    /** The Boolean value if this is [Bool], else `null`. */
    public val asBoolean: Boolean? get() = (this as? Bool)?.value

    /** The list of items if this is [Array], else `null`. */
    public val asArray: List<ClaimValue>? get() = (this as? Array)?.value

    /** The map of fields if this is [Object], else `null`. */
    public val asObject: Map<String, ClaimValue>? get() = (this as? Object)?.value

    /** `true` if this is the [Null] singleton. */
    public val isNull: Boolean get() = this is Null
}
