package ch.srg.login.sdk.auth

import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.util.DisplayMetrics

/**
 * Android implementation of PlatformAuthContext.
 */
actual interface PlatformAuthContext {
    actual val platformType: PlatformType
}

/**
 * Android mobile/tablet authentication context.
 * Provides necessary Android components for Chrome Custom Tabs authentication.
 *
 * @property context The Android context (required)
 * @property activity The Activity context (optional, but recommended for best UX)
 */
data class AndroidAuthContext(
    val context: Context,
    val activity: Activity? = null,
    override val platformType: PlatformType = PlatformType.ANDROID_MOBILE,
) : PlatformAuthContext,
    WebAuthCapable,
    DeviceCodeCapable {
    init {
        println("SDK-Creation: 🏗️ CONSTRUCTOR - AndroidAuthContext created (hashCode=${this.hashCode()})")
    }

    /**
     * Gets the best available context for launching Custom Tabs.
     * Prefers Activity context when available for optimal user experience.
     */
    fun getBestContext(): Context = activity ?: context

    /**
     * Checks if Activity context is available.
     * Activity context provides better Custom Tabs integration.
     */
    fun hasActivity(): Boolean = activity != null

    /**
     * Validates that the context is suitable for authentication operations.
     */
    fun isValid(): Boolean = context != null
}

/**
 * Android TV/Google TV authentication context.
 * Optimized for TV platforms with limited input capabilities.
 *
 * @property context The Android context (required)
 * @property activity The Activity context (optional)
 * @property isLeanback Whether this is explicitly a leanback/TV environment
 */
data class AndroidTvAuthContext(
    val context: Context,
    val activity: Activity? = null,
    private val isLeanback: Boolean = true,
    override val platformType: PlatformType = PlatformType.ANDROID_TV,
) : PlatformAuthContext,
    TvPlatform {
    /**
     * Gets display metrics for TV-optimized UI calculations.
     */
    fun getDisplayMetrics(): DisplayMetrics = context.resources.displayMetrics

    /**
     * Checks if voice input is available on this TV device.
     */
    fun hasVoiceInput(): Boolean = context.packageManager.hasSystemFeature(PackageManager.FEATURE_MICROPHONE)

    /**
     * Checks if the device supports high-resolution displays (4K, etc.).
     */
    fun isHighResolutionDisplay(): Boolean {
        val metrics = getDisplayMetrics()
        return metrics.widthPixels >= 3840 || metrics.heightPixels >= 2160
    }

    /**
     * Gets the best available context, preferring Activity when available.
     */
    fun getBestContext(): Context = activity ?: context
}
