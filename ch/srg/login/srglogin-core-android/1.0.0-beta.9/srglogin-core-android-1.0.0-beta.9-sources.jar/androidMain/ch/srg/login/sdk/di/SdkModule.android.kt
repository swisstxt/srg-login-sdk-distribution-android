package ch.srg.login.sdk.di

import android.content.Context
import ch.srg.login.sdk.auth.AndroidAuthContext
import ch.srg.login.sdk.auth.PlatformAuthContext
import ch.srg.login.sdk.auth.TokenManager
import ch.srg.login.sdk.auth.WebAuthenticator
import ch.srg.login.sdk.auth.WebAuthenticatorImpl
import ch.srg.login.sdk.crypto.AndroidCryptoService
import ch.srg.login.sdk.crypto.CryptoService
import ch.srg.login.sdk.events.EventEmitter
import ch.srg.login.sdk.internal.SecurityUtils
import ch.srg.login.sdk.lifecycle.AppLifecycleObserver
import ch.srg.login.sdk.token.AndroidEncryptedTokenStorage
import ch.srg.login.sdk.token.TokenStorage
import ch.srg.login.sdk.token.TokenStorageConfig
import io.ktor.client.HttpClient
import io.ktor.client.engine.cio.CIO
import io.ktor.client.plugins.HttpTimeout
import io.ktor.client.plugins.contentnegotiation.ContentNegotiation
import io.ktor.client.plugins.logging.LogLevel
import io.ktor.client.plugins.logging.Logger
import io.ktor.client.plugins.logging.Logging
import io.ktor.serialization.kotlinx.json.json
import kotlinx.serialization.json.Json
import org.koin.dsl.module

/**
 * Android-specific Koin module.
 * Provides `actual` implementations for platform-dependent classes.
 */
internal actual val platformModule =
    module {
        // Cryptographic operations service
        single<CryptoService> { AndroidCryptoService() }

        // Web authentication via Chrome Custom Tabs
        factory<WebAuthenticator> { WebAuthenticatorImpl(get()) }

        // TokenStorage implementation for Android with hardware-backed encryption
        single<TokenStorage> {
            AndroidEncryptedTokenStorage(
                context = get<Context>(),
                config = getOrNull<TokenStorageConfig>() ?: TokenStorageConfig(),
            )
        }

        // Platform authentication context (created from Android Context)
        // Factory scope: new instance per SrgLogin instance
        factory<PlatformAuthContext> {
            AndroidAuthContext(
                context = get<Context>(),
                // Activity is passed during login/logout calls, not during SDK init
                activity = null,
            )
        }

        // Platform lifecycle observer for automatic resource cleanup
        // Factory scope: new instance per SrgLogin instance
        // IMPORTANT: Receives tokenManager and eventEmitter as parameters to avoid duplicate instantiation
        factory { (tokenManager: TokenManager, eventEmitter: EventEmitter) ->
            AppLifecycleObserver(
                platformContext = get<PlatformAuthContext>(),
                // Use the passed instance instead of resolving from Koin
                tokenManager = tokenManager,
                // Use the passed instance instead of resolving from Koin
                eventEmitter = eventEmitter,
            )
        }
    }

/**
 * Android-specific implementation of HTTP client creation.
 * Uses CIO engine which is suitable for Android applications.
 *
 * @param enableLogging Whether to enable HTTP request/response logging
 * @param securityUtilsProvider Lazy provider for SecurityUtils (evaluated only when logging)
 */
internal actual fun createHttpClient(
    enableLogging: Boolean,
    securityUtilsProvider: () -> SecurityUtils,
): HttpClient =
    HttpClient(CIO) {
        // Enable automatic exception throwing for non-2xx responses
        // This ensures ClientRequestException (4xx) and ServerResponseException (5xx)
        // are thrown and properly mapped by OAuthErrorMapper in TokenManagerImpl
        expectSuccess = true

        install(ContentNegotiation) {
            json(
                Json {
                    ignoreUnknownKeys = true
                    coerceInputValues = true
                },
            )
        }
        install(HttpTimeout) {
            requestTimeoutMillis = 30000L
            connectTimeoutMillis = 15000L
            socketTimeoutMillis = 30000L
        }
        if (enableLogging) {
            install(Logging) {
                logger =
                    object : Logger {
                        override fun log(message: String) {
                            // Lazy evaluation - SecurityUtils is only accessed when actually logging
                            val securityUtils = securityUtilsProvider()
                            val sanitizedMessage = securityUtils.sanitizeErrorMessage(message)
                            println("SrgLogin-HTTP: $sanitizedMessage")
                            android.util.Log.d("SrgLogin-HTTP", sanitizedMessage)
                        }
                    }
                level = LogLevel.INFO
            }
        }
    }
