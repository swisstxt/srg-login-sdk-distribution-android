package ch.srg.login.sdk.auth

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.browser.customtabs.CustomTabsIntent
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.internal.SecurityUtils
import ch.srg.login.sdk.logging.LogCategory
import ch.srg.login.sdk.logging.SdkLogger
import ch.srg.login.sdk.result.SdkResult
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Android implementation of [WebAuthenticator] using Chrome Custom Tabs.
 *
 * @property securityUtils Security utilities for state generation.
 */
internal class WebAuthenticatorImpl(
    private val securityUtils: SecurityUtils,
) : BaseWebAuthenticator() {
    companion object {
        private const val CREATION_TAG = "SDK-Creation"
        private const val TAG_SSO = "WebAuth-SSO"
        private const val CHROME_PACKAGE = "com.android.chrome"

        /**
         * Checks if Chrome browser is installed on the device.
         *
         * Uses multiple detection methods with diagnostic logging to understand
         * device-specific behavior (especially on Samsung devices).
         *
         * @param context Android context for package manager access
         * @return `true` if Chrome is installed, `false` otherwise
         */
        private fun isChromeInstalled(context: Context): Boolean {
            SdkLogger.d(LogCategory.AUTHENTICATION) {
                "🔍 [DIAGNOSTIC] Starting Chrome detection on device: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}"
            }

            // Method 1: Check package existence via PackageManager.getPackageInfo()
            val method1Success =
                try {
                    context.packageManager.getPackageInfo(CHROME_PACKAGE, 0)
                    SdkLogger.d(LogCategory.AUTHENTICATION) {
                        "✅ [DIAGNOSTIC] Method 1 (getPackageInfo): Chrome package found via PackageManager"
                    }
                    true
                } catch (e: PackageManager.NameNotFoundException) {
                    SdkLogger.w(LogCategory.AUTHENTICATION) {
                        "❌ [DIAGNOSTIC] Method 1 (getPackageInfo): Chrome package NOT found - NameNotFoundException"
                    }
                    false
                } catch (e: Exception) {
                    SdkLogger.e(LogCategory.AUTHENTICATION) {
                        "❌ [DIAGNOSTIC] Method 1 (getPackageInfo): Unexpected exception - ${e::class.simpleName}: ${e.message}"
                    }
                    false
                }

            // Method 2: Check if Chrome can resolve a test intent
            val method2Success =
                try {
                    val testIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.example.com"))
                    testIntent.`package` = CHROME_PACKAGE
                    val resolveInfo =
                        context.packageManager.resolveActivity(
                            testIntent,
                            PackageManager.MATCH_DEFAULT_ONLY,
                        )
                    if (resolveInfo != null) {
                        SdkLogger.d(LogCategory.AUTHENTICATION) {
                            "✅ [DIAGNOSTIC] Method 2 (resolveActivity): Chrome can resolve intents - " +
                                "activityInfo=${resolveInfo.activityInfo?.name}"
                        }
                        true
                    } else {
                        SdkLogger.w(LogCategory.AUTHENTICATION) {
                            "❌ [DIAGNOSTIC] Method 2 (resolveActivity): Chrome cannot resolve intents - resolveInfo is null"
                        }
                        false
                    }
                } catch (e: Exception) {
                    SdkLogger.e(LogCategory.AUTHENTICATION) {
                        "❌ [DIAGNOSTIC] Method 2 (resolveActivity): Exception - ${e::class.simpleName}: ${e.message}"
                    }
                    false
                }

            // Method 3: Check if Chrome package is enabled
            val method3Success =
                try {
                    val packageInfo = context.packageManager.getApplicationInfo(CHROME_PACKAGE, 0)
                    val isEnabled = packageInfo.enabled
                    if (isEnabled) {
                        SdkLogger.d(LogCategory.AUTHENTICATION) {
                            "✅ [DIAGNOSTIC] Method 3 (getApplicationInfo): Chrome is installed and ENABLED"
                        }
                        true
                    } else {
                        SdkLogger.w(LogCategory.AUTHENTICATION) {
                            "⚠️ [DIAGNOSTIC] Method 3 (getApplicationInfo): Chrome is installed but DISABLED"
                        }
                        false
                    }
                } catch (e: PackageManager.NameNotFoundException) {
                    SdkLogger.w(LogCategory.AUTHENTICATION) {
                        "❌ [DIAGNOSTIC] Method 3 (getApplicationInfo): Chrome application NOT found"
                    }
                    false
                } catch (e: Exception) {
                    SdkLogger.e(LogCategory.AUTHENTICATION) {
                        "❌ [DIAGNOSTIC] Method 3 (getApplicationInfo): Exception - ${e::class.simpleName}: ${e.message}"
                    }
                    false
                }

            // Final result: Chrome is available if ANY method succeeds
            val chromeAvailable = method1Success || method2Success || method3Success

            SdkLogger.i(LogCategory.AUTHENTICATION) {
                "📊 [DIAGNOSTIC] Chrome detection summary: " +
                    "Method1(getPackageInfo)=$method1Success | " +
                    "Method2(resolveActivity)=$method2Success | " +
                    "Method3(getApplicationInfo)=$method3Success | " +
                    "FINAL_RESULT=$chromeAvailable"
            }

            return chromeAvailable
        }

        /**
         * Logs Chrome browser availability for Custom Tabs flow.
         *
         * This helper centralizes Chrome detection logging across all Custom Tabs usages:
         * - Authentication (OAuth login)
         * - Logout (session termination)
         * - SSO Client (profile access, settings, etc.)
         *
         * @param context Android context for Chrome detection
         * @param flowType Type of flow (e.g., "authentication", "logout", "SSO client")
         */
        private fun logChromeAvailability(
            context: Context,
            flowType: String,
        ) {
            val chromeAvailable = isChromeInstalled(context)

            if (!chromeAvailable) {
                SdkLogger.w(LogCategory.AUTHENTICATION) {
                    "Chrome browser not detected via PackageManager for $flowType. " +
                        "This may occur on devices without <queries> manifest declaration (Android 11+) " +
                        "or devices where Chrome is truly not installed. " +
                        "Attempting to launch Chrome directly - if successful, SSO will work correctly. " +
                        "If Chrome is unavailable, will fallback to default browser (SSO may not work)."
                }
            } else {
                SdkLogger.d(LogCategory.AUTHENTICATION) {
                    "Chrome browser detected for $flowType. Launching Custom Tab with SSO session sharing enabled."
                }
            }
        }
    }

    init {
        println("$CREATION_TAG: 🏗️ CONSTRUCTOR - WebAuthenticatorImpl created (hashCode=${this.hashCode()})")
    }

    override suspend fun authenticatePlatform(
        authUrl: String,
        authContext: PlatformAuthContext,
    ): SdkResult<String> =
        when (authContext) {
            is AndroidAuthContext -> {
                authenticateWithCustomTabs(authUrl, authContext)
            }

            is AndroidTvAuthContext -> {
                // TV platforms should use Device Code Flow, not web authentication
                SdkResult.Failure(
                    SrgLoginError.UnsupportedPlatform(
                        "Android TV requires Device Code Flow authentication. " +
                            "Use Credentials.Device instead of Credentials.Web for TV platforms.",
                    ),
                )
            }

            else -> {
                SdkResult.Failure(
                    SrgLoginError.InvalidConfiguration(
                        "Android WebAuthenticator requires AndroidAuthContext, " +
                            "received: ${authContext::class.simpleName}",
                    ),
                )
            }
        }

    override suspend fun logoutPlatform(
        logoutUrl: String,
        authContext: PlatformAuthContext,
    ): SdkResult<Unit> =
        when (authContext) {
            is AndroidAuthContext -> {
                logoutWithCustomTabs(logoutUrl, authContext)
            }

            is AndroidTvAuthContext -> {
                // TV platforms should handle logout differently
                SdkResult.Failure(
                    SrgLoginError.UnsupportedPlatform(
                        "Android TV logout should use LogoutType.LocalOnly instead of front-channel logout.",
                    ),
                )
            }

            else -> {
                SdkResult.Failure(
                    SrgLoginError.InvalidConfiguration(
                        "Android WebAuthenticator requires AndroidAuthContext, " +
                            "received: ${authContext::class.simpleName}",
                    ),
                )
            }
        }

    private suspend fun authenticateWithCustomTabs(
        authUrl: String,
        authContext: AndroidAuthContext,
    ): SdkResult<String> {
        return try {
            suspendCancellableCoroutine { continuation ->

                if (!authContext.isValid()) {
                    continuation.resume(
                        SdkResult.Failure(
                            SrgLoginError.InvalidConfiguration("Invalid Android context provided"),
                        ),
                    )
                    return@suspendCancellableCoroutine
                }

                // Extract OIDC state parameter from auth URL
                val state = extractStateFromUrl(authUrl)
                if (state == null) {
                    continuation.resume(
                        SdkResult.Failure(
                            SrgLoginError.InvalidConfiguration("Missing state parameter in authorization URL"),
                        ),
                    )
                    return@suspendCancellableCoroutine
                }

                // Register continuation with OIDC state
                StateContinuationRegistry.registerLoginContinuation(state, continuation)

                val customTabsIntent = createCustomTabsIntent()

                val success = launchCustomTabs(customTabsIntent, authUrl, authContext)

                if (!success) {
                    val fallbackSuccess = launchFallbackBrowser(authUrl, authContext)

                    if (!fallbackSuccess) {
                        StateContinuationRegistry.cancelLogin(state, "No suitable browser found for authentication")
                        return@suspendCancellableCoroutine
                    }
                }

                // Set up cancellation handling
                continuation.invokeOnCancellation {
                    StateContinuationRegistry.cancelLogin(state, "Authentication was cancelled")
                }
            }
        } catch (e: Exception) {
            SdkResult.Failure(
                SrgLoginError.PlatformError(
                    message = "Failed to launch browser for authentication: ${e.message}",
                    cause = e,
                    platform = "Android",
                ),
            )
        }
    }

    private fun createCustomTabsIntent(): CustomTabsIntent =
        CustomTabsIntent
            .Builder()
            .setShowTitle(true)
            .setUrlBarHidingEnabled(true)
            .build()

    private fun launchCustomTabs(
        customTabsIntent: CustomTabsIntent,
        authUrl: String,
        authContext: AndroidAuthContext,
    ): Boolean =
        try {
            val launchContext = authContext.getBestContext() as Context

            // Log Chrome availability for authentication flow
            logChromeAvailability(launchContext, "authentication")

            SdkLogger.d(LogCategory.AUTHENTICATION) {
                "🚀 [DIAGNOSTIC] Attempting to launch Custom Tabs for authentication WITH package=com.android.chrome (Chrome FORCED)"
            }

            val intent =
                customTabsIntent.intent.apply {
                    data = Uri.parse(authUrl)

                    // Force Chrome for authentication to ensure SSO session sharing.
                    // Chrome Custom Tabs share cookies across all flows (auth + SSO),
                    // enabling seamless SSO without re-authentication.
                    // Falls back to default browser if Chrome is not available.
                    `package` = CHROME_PACKAGE

                    if (!authContext.hasActivity()) {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                }

            launchContext.startActivity(intent)

            SdkLogger.i(LogCategory.AUTHENTICATION) {
                "✅ [DIAGNOSTIC] Chrome Custom Tab launched successfully for authentication (Chrome opened with package=com.android.chrome)"
            }

            true
        } catch (e: Exception) {
            SdkLogger.e(LogCategory.AUTHENTICATION) {
                "❌ [DIAGNOSTIC] Custom Tabs launch FAILED for authentication - ${e::class.simpleName}: ${e.message}"
            }
            false
        }

    private fun launchFallbackBrowser(
        authUrl: String,
        authContext: AndroidAuthContext,
    ): Boolean =
        try {
            val launchContext = authContext.getBestContext() as Context
            val intent =
                Intent(Intent.ACTION_VIEW, Uri.parse(authUrl)).apply {
                    if (!authContext.hasActivity()) {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                }

            launchContext.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }

    private suspend fun logoutWithCustomTabs(
        logoutUrl: String,
        authContext: AndroidAuthContext,
    ): SdkResult<Unit> {
        return try {
            suspendCancellableCoroutine { continuation ->

                if (!authContext.isValid()) {
                    continuation.resume(
                        SdkResult.Failure(
                            SrgLoginError.InvalidConfiguration("Invalid Android context provided"),
                        ),
                    )
                    return@suspendCancellableCoroutine
                }

                // Extract or generate state parameter for logout URL
                val state = extractStateFromUrl(logoutUrl) ?: generateStateForLogout()

                // Build final logout URL with state if not present
                val finalLogoutUrl =
                    if (!logoutUrl.contains("state=")) {
                        "$logoutUrl${if (logoutUrl.contains("?")) "&" else "?"}state=$state"
                    } else {
                        logoutUrl
                    }

                // Register logout continuation with OIDC state
                StateContinuationRegistry.registerLogoutContinuation(state, continuation)

                val customTabsIntent = createLogoutCustomTabsIntent()

                val success = launchCustomTabsForLogout(customTabsIntent, finalLogoutUrl, authContext)

                if (!success) {
                    val fallbackSuccess = launchFallbackBrowserForLogout(finalLogoutUrl, authContext)

                    if (!fallbackSuccess) {
                        StateContinuationRegistry.cancelLogout(state, "No suitable browser found for logout")
                        return@suspendCancellableCoroutine
                    }
                }

                // Set up cancellation handling
                continuation.invokeOnCancellation {
                    StateContinuationRegistry.cancelLogout(state, "Logout was cancelled")
                }
            }
        } catch (e: Exception) {
            SdkResult.Failure(
                SrgLoginError.PlatformError(
                    message = "Failed to launch browser for logout: ${e.message}",
                    cause = e,
                    platform = "Android",
                ),
            )
        }
    }

    private fun createLogoutCustomTabsIntent(): CustomTabsIntent =
        CustomTabsIntent
            .Builder()
            .setShowTitle(true)
            .setUrlBarHidingEnabled(false) // Show URL bar for logout transparency
            .build()

    private fun launchCustomTabsForLogout(
        customTabsIntent: CustomTabsIntent,
        logoutUrl: String,
        authContext: AndroidAuthContext,
    ): Boolean =
        try {
            val launchContext = authContext.getBestContext() as Context

            // Log Chrome availability for logout flow
            logChromeAvailability(launchContext, "logout")

            val intent =
                customTabsIntent.intent.apply {
                    data = Uri.parse(logoutUrl)
                    if (!authContext.hasActivity()) {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    // Add flags to clear browser state if needed
                    addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
                    addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
                }

            launchContext.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }

    private fun launchFallbackBrowserForLogout(
        logoutUrl: String,
        authContext: AndroidAuthContext,
    ): Boolean =
        try {
            val launchContext = authContext.getBestContext() as Context
            val intent =
                Intent(Intent.ACTION_VIEW, Uri.parse(logoutUrl)).apply {
                    if (!authContext.hasActivity()) {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    addFlags(Intent.FLAG_ACTIVITY_NO_HISTORY)
                    addFlags(Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS)
                }

            launchContext.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }

    /**
     * Extracts the OIDC state parameter from a URL.
     *
     * @param url The URL containing the state parameter
     * @return The state value or null if not found
     */
    private fun extractStateFromUrl(url: String): String? =
        try {
            val uri = Uri.parse(url)
            uri.getQueryParameter("state")
        } catch (e: Exception) {
            null
        }

    override suspend fun openSsoClientPlatform(
        ssoClientUrl: String,
        authContext: PlatformAuthContext,
    ): SdkResult<Unit> {
        // Vérification WebAuthCapable pour éviter Android TV
        if (authContext !is WebAuthCapable) {
            return SdkResult.Failure(
                SrgLoginError.InvalidConfiguration(
                    "SSO client opening requires a WebAuthCapable context. " +
                        "TV platforms should use different approaches for web content display.",
                ),
            )
        }

        return when (authContext) {
            is AndroidAuthContext -> {
                openSsoClientWithCustomTabs(ssoClientUrl, authContext)
            }

            else -> {
                SdkResult.Failure(
                    SrgLoginError.InvalidConfiguration(
                        "Android WebAuthenticator requires AndroidAuthContext, " +
                            "received: ${authContext::class.simpleName}",
                    ),
                )
            }
        }
    }

    /**
     * Opens SSO client URL in Custom Tabs with Chrome enforcement and fallback handling.
     *
     * This is the main entry point for SSO client access (e.g., opening profile settings after login).
     * It implements a two-tier launch strategy:
     *
     * ## Launch Strategy
     *
     * 1. **Primary**: Chrome Custom Tabs (SSO-enabled)
     *    - Forces Chrome browser for session sharing
     *    - Enables seamless SSO without re-authentication
     *    - See [launchCustomTabsForSsoClient] for detailed rationale
     *
     * 2. **Fallback**: Default browser (degraded experience)
     *    - Used when Chrome is not installed
     *    - SSO will NOT work - user must re-authenticate
     *    - Still provides access to SSO services
     *
     * ## Fire-and-Forget Pattern
     *
     * This method returns immediately after launching the browser (no callback expected).
     * The browser session is independent from the app - user can:
     * - Close the browser tab
     * - Switch back to the app
     * - Navigate freely in the browser
     *
     * ## Usage Example
     *
     * ```kotlin
     * // After successful authentication
     * val result = srgLogin.openSsoClient(
     *     url = "https://settings.srgssr.ch/profile",
     *     context = this
     * )
     * when (result) {
     *     is SdkResult.Success -> {
     *         // Browser launched - user can access profile
     *         // SSO works automatically (no re-auth if using Chrome)
     *     }
     *     is SdkResult.Failure -> {
     *         // No browser available or context invalid
     *     }
     * }
     * ```
     *
     * ## Related Documentation
     *
     * - **SSO Architecture**: `docs/architecture/custom-tabs/CUSTOM_TABS_SESSION_MANAGEMENT_EN.md`
     * - **Chrome Enforcement**: [launchCustomTabsForSsoClient] - Detailed KDoc on why Chrome is forced
     *
     * @param ssoClientUrl The SSO service URL to open (e.g., profile settings, account management)
     * @param authContext Android authentication context (activity or application context)
     * @return [SdkResult.Success] if browser launched, [SdkResult.Failure] if no browser available
     *
     * @see launchCustomTabsForSsoClient Primary launch method with Chrome enforcement
     * @see launchFallbackBrowserForSsoClient Fallback when Chrome unavailable
     */
    private suspend fun openSsoClientWithCustomTabs(
        ssoClientUrl: String,
        authContext: AndroidAuthContext,
    ): SdkResult<Unit> {
        return try {
            SdkLogger.d(LogCategory.AUTHENTICATION) {
                "Starting SSO client launch for URL: ${ssoClientUrl.take(50)}..."
            }

            // Validate Android context
            if (!authContext.isValid()) {
                SdkLogger.e(LogCategory.AUTHENTICATION) {
                    "SSO client launch failed: Invalid Android context provided"
                }
                return SdkResult.Failure(
                    SrgLoginError.InvalidConfiguration("Invalid Android context provided"),
                )
            }

            // Create Custom Tabs intent
            val customTabsIntent = createSsoClientCustomTabsIntent()

            // Attempt to launch Custom Tabs (Chrome)
            val success = launchCustomTabsForSsoClient(customTabsIntent, ssoClientUrl, authContext)

            if (!success) {
                // Fallback to default browser if Chrome not available
                val fallbackSuccess = launchFallbackBrowserForSsoClient(ssoClientUrl, authContext)

                if (!fallbackSuccess) {
                    SdkLogger.e(LogCategory.AUTHENTICATION) {
                        "SSO client launch failed: No browser available on device. " +
                            "Both Chrome and fallback browser launch attempts failed."
                    }
                    return SdkResult.Failure(
                        SrgLoginError.PlatformError(
                            message = "No suitable browser found for SSO client",
                            platform = "Android",
                        ),
                    )
                }
            }

            SdkLogger.i(LogCategory.AUTHENTICATION) {
                "SSO client launched successfully. Browser opened for user interaction."
            }

            // Fire-and-forget: Return success immediately after launching browser
            SdkResult.Success(Unit)
        } catch (e: Exception) {
            SdkLogger.e(LogCategory.AUTHENTICATION) {
                "SSO client launch exception: ${e.message}. Exception: ${e::class.simpleName}"
            }
            SdkResult.Failure(
                SrgLoginError.PlatformError(
                    message = "Failed to launch browser for SSO client: ${e.message}",
                    cause = e,
                    platform = "Android",
                ),
            )
        }
    }

    private fun createSsoClientCustomTabsIntent(): CustomTabsIntent =
        CustomTabsIntent
            .Builder()
            .setShowTitle(true)
            .setUrlBarHidingEnabled(false) // Show URL bar for transparency
            .build()

    /**
     * Launches Custom Tabs for SSO client with Chrome browser enforcement.
     *
     * ## Why Chrome is Enforced
     *
     * This method explicitly forces Chrome Custom Tabs (`package = "com.android.chrome"`) for critical reasons:
     *
     * 1. **SSO Session Sharing**: Custom Tabs share Chrome's cookie store, enabling seamless SSO.
     *    After initial authentication, session cookies persist in Chrome's profile, allowing
     *    subsequent SSO client access without re-authentication.
     *
     * 2. **Samsung Browser CSP Issues**: Samsung Internet Browser has known Content Security Policy
     *    issues that break OAuth redirect flows. Forcing Chrome avoids these compatibility problems.
     *
     * 3. **Consistent User Experience**: Standardizing on Chrome ensures predictable SSO behavior
     *    across all supported Android devices.
     *
     * ## Session Persistence Architecture
     *
     * ```
     * App Login → Chrome Custom Tab → Authentication → Cookies in Chrome Profile
     *                                                   (JSESSIONID, sso_session, etc.)
     *                                                   ↓
     * App SSO Client → Chrome Custom Tab → Reuses cookies → Direct access (no auth prompt)
     * ```
     *
     * ## Fallback Behavior
     *
     * If Chrome is not installed (e.g., Amazon Fire devices, China market):
     * - Catches [android.content.ActivityNotFoundException]
     * - Returns `false` to trigger fallback to default browser
     * - **⚠️ SSO will NOT work** - user must re-authenticate for each SSO client access
     *
     * ## Affected Devices
     *
     * **Devices without Chrome** (~5% of Android devices):
     * - Amazon Fire tablets/phones
     * - Devices in China (Google Play unavailable)
     * - Users who uninstalled Chrome
     *
     * → These devices get degraded experience (no SSO) but authentication still works via fallback
     *
     * ## Technical References
     *
     * - **Architecture Docs**: `docs/architecture/custom-tabs/CUSTOM_TABS_SESSION_MANAGEMENT_EN.md`
     * - **Session Mechanism**: Section 3 & 4 - Cookie persistence and SSO flow
     * - **Security Model**: Section 6 - Browser isolation and session boundaries
     *
     * @param customTabsIntent The Custom Tabs intent configured for SSO client
     * @param ssoClientUrl The SSO service URL to open (e.g., profile settings)
     * @param authContext Android authentication context for activity/application context
     * @return `true` if Chrome Custom Tab launched successfully, `false` if Chrome not available
     *
     * @throws android.content.ActivityNotFoundException if Chrome is not installed (caught internally)
     *
     * @see launchFallbackBrowserForSsoClient Fallback when Chrome is unavailable
     * @see openSsoClientWithCustomTabs Parent method orchestrating the SSO flow
     */
    private fun launchCustomTabsForSsoClient(
        customTabsIntent: CustomTabsIntent,
        ssoClientUrl: String,
        authContext: AndroidAuthContext,
    ): Boolean =
        try {
            val launchContext = authContext.getBestContext() as Context

            // Log Chrome availability for SSO client flow
            logChromeAvailability(launchContext, "SSO client")

            SdkLogger.d(LogCategory.AUTHENTICATION) {
                "🚀 [DIAGNOSTIC] Attempting to launch Custom Tabs for SSO client WITH package=$CHROME_PACKAGE (Chrome FORCED)"
            }

            val intent =
                customTabsIntent.intent.apply {
                    data = Uri.parse(ssoClientUrl)

                    // Force Chrome Custom Tabs for SSO session sharing + Samsung CSP workaround
                    // See KDoc above for detailed rationale
                    `package` = CHROME_PACKAGE

                    if (!authContext.hasActivity()) {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                }

            launchContext.startActivity(intent)

            SdkLogger.i(LogCategory.AUTHENTICATION) {
                "✅ [DIAGNOSTIC] Chrome Custom Tab launched successfully " +
                    "for SSO client (Chrome opened with package=$CHROME_PACKAGE): " +
                    "${ssoClientUrl.take(50)}..."
            }

            true
        } catch (e: android.content.ActivityNotFoundException) {
            // Chrome not installed - fallback will be attempted (SSO won't work)
            SdkLogger.w(LogCategory.AUTHENTICATION) {
                "Chrome Custom Tab launch failed: ActivityNotFoundException. " +
                    "Chrome browser is not installed or disabled. " +
                    "Attempting fallback to default browser (SSO will not work)."
            }
            false
        } catch (e: Exception) {
            SdkLogger.e(LogCategory.AUTHENTICATION) {
                "Unexpected error launching Chrome Custom Tab: ${e.message}. " +
                    "Attempting fallback to default browser. Exception: ${e::class.simpleName}"
            }
            false
        }

    private fun launchFallbackBrowserForSsoClient(
        ssoClientUrl: String,
        authContext: AndroidAuthContext,
    ): Boolean =
        try {
            SdkLogger.w(LogCategory.AUTHENTICATION) {
                "Using fallback browser for SSO client (Chrome unavailable). " +
                    "⚠️ SSO will NOT work - user will be prompted to authenticate. " +
                    "This is expected on devices without Chrome (Amazon Fire, China market)."
            }

            val launchContext = authContext.getBestContext() as Context
            val intent =
                Intent(Intent.ACTION_VIEW, Uri.parse(ssoClientUrl)).apply {
                    if (!authContext.hasActivity()) {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                }

            launchContext.startActivity(intent)

            SdkLogger.i(LogCategory.AUTHENTICATION) {
                "Fallback browser launched successfully. User may need to authenticate."
            }

            true
        } catch (e: Exception) {
            SdkLogger.e(LogCategory.AUTHENTICATION) {
                "Fallback browser launch failed: ${e.message}. " +
                    "No browser available on device. Exception: ${e::class.simpleName}"
            }
            false
        }

    /**
     * Generates a cryptographically secure state parameter for logout flows.
     * Uses the same security standards as login flows.
     *
     * @return A secure random state string
     */
    private fun generateStateForLogout(): String = securityUtils.generateState()
}
