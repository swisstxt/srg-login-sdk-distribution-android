package ch.srg.login.sdk.data.api

import ch.srg.login.sdk.internal.SecurityUtils
import ch.srg.login.sdk.logging.ErrorHandler
import ch.srg.login.sdk.logging.ErrorHandlerRegistry
import ch.srg.login.sdk.logging.LogCategory
import ch.srg.login.sdk.logging.SdkLogger
import ch.srg.login.sdk.model.JwkSet
import ch.srg.login.sdk.model.OpenIdConfig
import ch.srg.login.sdk.model.TokenResponseDto
import io.ktor.client.HttpClient
import io.ktor.client.call.body
import io.ktor.client.request.forms.FormDataContent
import io.ktor.client.request.get
import io.ktor.client.request.headers
import io.ktor.client.request.post
import io.ktor.client.request.setBody
import io.ktor.http.Parameters

/**
 * Implementation of [SrgAuthApiService].
 *
 * @property httpClient The pre-configured Ktor HttpClient.
 * @property securityUtils Security utilities for error message sanitization.
 */
internal class SrgAuthApiServiceImpl(
    private val httpClient: HttpClient,
    private val securityUtils: SecurityUtils,
) : SrgAuthApiService {
    override suspend fun getOpenIdConfiguration(baseUrl: String): OpenIdConfig {
        try {
            validateUrl(baseUrl)
            val url = "$baseUrl/.well-known/openid-configuration"
            return httpClient.get(url).body()
        } catch (e: Exception) {
            // Report to error tracking
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "get_openid_configuration",
                        "endpoint" to "well_known_openid_configuration",
                        "base_url" to baseUrl,
                        "critical" to true,
                        "impact" to "sdk_initialization_failure",
                        "exception_type" to e::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.FATAL,
            )

            throw e
        }
    }

    override suspend fun exchangeCodeForToken(
        tokenEndpoint: String,
        code: String,
        redirectUri: String,
        clientId: String,
        codeVerifier: String,
    ): TokenResponseDto {
        try {
            val response =
                httpClient.post(tokenEndpoint) {
                    headers {
                        append("Content-Type", "application/x-www-form-urlencoded")
                        append("Accept", "application/json")
                    }
                    setBody(
                        FormDataContent(
                            Parameters.build {
                                append("grant_type", "authorization_code")
                                append("code", code)
                                append("redirect_uri", redirectUri)
                                append("client_id", clientId)
                                append("code_verifier", codeVerifier)
                            },
                        ),
                    )
                }
            return response.body()
        } catch (e: Exception) {
            val sanitizedMessage = securityUtils.sanitizeErrorMessage(e.message ?: "Unknown error")
            SdkLogger.e(LogCategory.NETWORK, throwable = e) { "Failed to exchange code for token: $sanitizedMessage" }

            // Report to error tracking
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "exchange_code_for_token",
                        "endpoint" to "token_endpoint",
                        "grant_type" to "authorization_code",
                        "stage" to "post_authentication",
                        "exception_type" to e::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.ERROR,
            )

            throw e
        }
    }

    override suspend fun getJwks(jwksUri: String): JwkSet {
        validateJwksUri(jwksUri)
        return httpClient.get(jwksUri).body()
    }

    override suspend fun refreshAccessToken(
        tokenEndpoint: String,
        refreshToken: String,
        clientId: String,
    ): TokenResponseDto {
        try {
            val response =
                httpClient.post(tokenEndpoint) {
                    headers {
                        append("Content-Type", "application/x-www-form-urlencoded")
                        append("Accept", "application/json")
                    }
                    setBody(
                        FormDataContent(
                            Parameters.build {
                                append("grant_type", "refresh_token")
                                append("refresh_token", refreshToken)
                                append("client_id", clientId)
                            },
                        ),
                    )
                }
            return response.body()
        } catch (e: Exception) {
            val sanitizedMessage = securityUtils.sanitizeErrorMessage(e.message ?: "Unknown error")
            SdkLogger.e(LogCategory.NETWORK, throwable = e) { "Failed to refresh access token: $sanitizedMessage" }

            // Report to error tracking
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "refresh_access_token",
                        "endpoint" to "token_endpoint",
                        "grant_type" to "refresh_token",
                        "critical" to true,
                        "exception_type" to e::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.ERROR,
            )

            throw e
        }
    }

    private fun validateUrl(baseUrl: String) {
        SdkLogger.d(LogCategory.NETWORK) { "Validating baseUrl='$baseUrl'" }
        require(baseUrl.isNotBlank()) { "Base URL cannot be blank" }
        require(baseUrl.startsWith("https://")) { "Base URL must use HTTPS" }
        require(!baseUrl.endsWith("/")) { "Base URL should not end with /" }
        SdkLogger.d(LogCategory.NETWORK) { "URL validation passed for baseUrl='$baseUrl'" }
    }

    private fun validateJwksUri(jwksUri: String) {
        require(jwksUri.isNotBlank()) { "JWKS URI cannot be blank" }
        require(jwksUri.startsWith("https://")) { "JWKS URI must use HTTPS for security" }
    }
}
