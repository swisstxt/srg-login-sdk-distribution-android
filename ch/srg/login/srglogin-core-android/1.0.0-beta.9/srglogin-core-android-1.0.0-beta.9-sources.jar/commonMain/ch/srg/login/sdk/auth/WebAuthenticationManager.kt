package ch.srg.login.sdk.auth

import ch.srg.login.sdk.SrgLoginConfig
import ch.srg.login.sdk.data.OpenIdConfigRepository
import ch.srg.login.sdk.data.api.SrgAuthApiService
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.events.EventEmitter
import ch.srg.login.sdk.events.SdkLifecycleEvent
import ch.srg.login.sdk.events.StorageOperation
import ch.srg.login.sdk.internal.SecurityUtils
import ch.srg.login.sdk.logging.ErrorHandler
import ch.srg.login.sdk.logging.ErrorHandlerRegistry
import ch.srg.login.sdk.logging.LogCategory
import ch.srg.login.sdk.logging.SdkLogger
import ch.srg.login.sdk.model.TokenSet
import ch.srg.login.sdk.result.SdkResult
import ch.srg.login.sdk.token.TokenStorage
import io.ktor.http.decodeURLQueryComponent
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow

/**
 * The concrete implementation of [AuthenticationManager] for the web-based OIDC flow.
 *
 * @property config The SDK configuration.
 * @property openIdConfigRepository The repository to fetch the OIDC discovery document.
 * @property authApiService The service to perform the final token exchange.
 * @property webAuthenticator The platform-specific browser handler.
 * @property tokenStorage The token storage implementation for persistence.
 * @property securityUtils Security utilities for PKCE generation and state generation.
 * @property jwtValidationService Service for JWT parsing and signature verification.
 * @property eventEmitter Event emitter for SDK lifecycle events (event-driven communication).
 */
internal class WebAuthenticationManager(
    private val config: SrgLoginConfig,
    private val openIdConfigRepository: OpenIdConfigRepository,
    private val authApiService: SrgAuthApiService,
    private val webAuthenticator: WebAuthenticator,
    private val tokenStorage: TokenStorage,
    private val securityUtils: SecurityUtils,
    private val jwtValidationService: JwtValidationService,
    private val eventEmitter: EventEmitter,
) : AuthenticationManager {
    companion object {
        private const val CREATION_TAG = "SDK-Creation"
    }

    init {
        SdkLogger.i(LogCategory.AUTHENTICATION) {
            "WebAuthenticationManager created " +
                "(hashCode=${this.hashCode()}, " +
                "OpenIdConfigRepository=${openIdConfigRepository.hashCode()}, " +
                "EventEmitter=${eventEmitter.hashCode()})"
        }
    }

    private val backChannelLogoutListeners = mutableListOf<BackChannelLogoutListener>()

    /**
     * Helper to emit LoginFailure event and then LoginState.Failure.
     *
     * @param error The error that caused login to fail
     * @return LoginState.Failure to emit in the flow
     */
    private fun emitLoginFailureEvent(error: SrgLoginError): LoginState.Failure {
        val timestamp =
            kotlinx.datetime.Clock.System
                .now()
                .toEpochMilliseconds()
        eventEmitter.tryEmit(SdkLifecycleEvent.LoginFailure(error, timestamp))
        return LoginState.Failure(error)
    }

    override fun login(
        credentials: Credentials,
        authContext: PlatformAuthContext,
        additionalScopes: List<String>,
        additionalParameters: Map<String, String>,
    ): Flow<LoginState> =
        flow {
            // Track flow start with unique ID
            val flowId =
                kotlinx.datetime.Clock.System
                    .now()
                    .toEpochMilliseconds()
                    .toString()
                    .takeLast(6)
            SdkLogger.d(LogCategory.AUTHENTICATION) {
                "Login flow started (Flow-$flowId) with scopes: $additionalScopes, additionalParams: ${additionalParameters.keys}"
            }

            // Validate credentials type
            if (credentials !is Credentials.Web) {
                SdkLogger.d(LogCategory.AUTHENTICATION) { "Invalid credentials type (Flow-$flowId)" }
                emit(emitLoginFailureEvent(SrgLoginError.InvalidConfiguration("WebAuthenticationManager only supports Web credentials.")))
                return@flow
            }

            // Validate platform context capabilities
            if (authContext !is WebAuthCapable) {
                SdkLogger.d(LogCategory.AUTHENTICATION) { "Invalid auth context - not WebAuthCapable (Flow-$flowId)" }
                emit(
                    emitLoginFailureEvent(
                        SrgLoginError.InvalidConfiguration(
                            "Web authentication requires a WebAuthCapable context. " +
                                "TV platforms should use Credentials.Device instead of Credentials.Web.",
                        ),
                    ),
                )
                return@flow
            }

            SdkLogger.d(LogCategory.AUTHENTICATION) { "Credentials and context validated (Flow-$flowId)" }

            // Emit LoginStarted event
            val loginStartedTimestamp =
                kotlinx.datetime.Clock.System
                    .now()
                    .toEpochMilliseconds()
            eventEmitter.tryEmit(SdkLifecycleEvent.LoginStarted(loginStartedTimestamp))

            // 1. Get OpenID Configuration
            val openIdConfigResult = openIdConfigRepository.getConfiguration()
            val openIdConfig =
                when (openIdConfigResult) {
                    is SdkResult.Success -> {
                        openIdConfigResult.data
                    }

                    is SdkResult.Failure -> {
                        // Report to error tracking
                        ErrorHandlerRegistry.captureException(
                            throwable =
                                when (val error = openIdConfigResult.error) {
                                    is SrgLoginError.NetworkError -> error.cause ?: Exception(error.details ?: "Network error")
                                    is SrgLoginError.HttpError -> Exception("HTTP ${error.code}: ${error.message}")
                                    else -> Exception(error.toString())
                                },
                            context =
                                mapOf(
                                    "operation" to "fetch_openid_config",
                                    "stage" to "login_init",
                                    "error_type" to openIdConfigResult.error::class.simpleName,
                                ),
                            level = ErrorHandler.ErrorLevel.ERROR,
                        )

                        emit(emitLoginFailureEvent(openIdConfigResult.error))
                        return@flow
                    }
                }

            // 1b. Create token validation service for validating received tokens
            val tokenValidationService =
                TokenValidationService(
                    jwtValidationService = jwtValidationService,
                    logoutTokenValidationService =
                        LogoutTokenValidationService(
                            jwtValidationService = jwtValidationService,
                            replayCache = PersistentReplayCache(tokenStorage, maxAgeSeconds = 3600L),
                            expectedIssuer = openIdConfig.issuer,
                            clientId = config.clientId,
                            jwksUri = openIdConfig.jwksUri,
                        ),
                    apiService = authApiService,
                )

            // 2. Generate and store security parameters
            val currentPkce = securityUtils.generatePkce()
            val currentState = securityUtils.generateState()

            // Log generated security parameters
            SdkLogger.d(LogCategory.AUTHENTICATION) {
                "Generated security params (Flow-$flowId): " +
                    "state=$currentState, " +
                    "code_verifier=${currentPkce.codeVerifier}, " +
                    "code_challenge=${currentPkce.codeChallenge}"
            }

            // 3. Build Authorization URL with scopes
            // Ensure "openid" is always included for OIDC compliance
            val allScopes = (listOf("openid") + additionalScopes).distinct()

            val authUrl =
                buildString {
                    append(openIdConfig.authorizationEndpoint)
                    append("?client_id=${config.clientId}")
                    append("&redirect_uri=${config.redirectUri}")
                    append("&response_type=code")
                    append("&scope=${allScopes.joinToString(" ")}")
                    append("&state=$currentState")
                    append("&code_challenge=${currentPkce.codeChallenge}")
                    append("&code_challenge_method=S256")

                    // Add additional OAuth/OIDC parameters (e.g., ui_locales, prompt, display)
                    // Filter out reserved OAuth parameters to prevent security issues
                    val reservedParams =
                        setOf(
                            "client_id",
                            "redirect_uri",
                            "response_type",
                            "state",
                            "code_challenge",
                            "code_challenge_method",
                            "scope",
                        )

                    val filteredParams =
                        additionalParameters.filterKeys { key ->
                            val isReserved = key.lowercase() in reservedParams
                            if (isReserved) {
                                SdkLogger.d(LogCategory.AUTHENTICATION) {
                                    "Ignoring reserved OAuth parameter '$key' in additionalParameters (Flow-$flowId)"
                                }
                            }
                            !isReserved
                        }

                    filteredParams.forEach { (key, value) ->
                        if (value.isEmpty()) {
                            SdkLogger.d(LogCategory.AUTHENTICATION) {
                                "Ignoring parameter '$key' with empty value (Flow-$flowId)"
                            }
                        } else {
                            append("&${key.urlEncode()}=${value.urlEncode()}")
                        }
                    }
                }

            // DEBUG: Log authorization URL
            SdkLogger.d(LogCategory.AUTHENTICATION) { "Authorization URL: $authUrl (Flow-$flowId)" }
            SdkLogger.d(LogCategory.AUTHENTICATION) { "Opening browser for authentication (Flow-$flowId)" }

            // 4. Trigger platform-specific browser
            val authResult = webAuthenticator.authenticate(authUrl, authContext)

            // 5. Handle browser result
            when (authResult) {
                is SdkResult.Failure -> {
                    // Report to error tracking
                    ErrorHandlerRegistry.captureException(
                        throwable =
                            when (val error = authResult.error) {
                                is SrgLoginError.UserCancelled -> Exception("User cancelled authentication")
                                is SrgLoginError.NetworkError -> error.cause ?: Exception(error.details ?: "Network error")
                                else -> Exception(error.toString())
                            },
                        context =
                            mapOf(
                                "operation" to "browser_authentication",
                                "stage" to "login_browser",
                                "error_type" to authResult.error::class.simpleName,
                            ),
                        level =
                            if (authResult.error is SrgLoginError.UserCancelled) {
                                ErrorHandler.ErrorLevel.INFO
                            } else {
                                ErrorHandler.ErrorLevel.ERROR
                            },
                    )

                    emit(emitLoginFailureEvent(authResult.error))
                }

                is SdkResult.Success -> {
                    val callbackUrl = authResult.data
                    val code = getQueryParameter(callbackUrl, "code")
                    val receivedState = getQueryParameter(callbackUrl, "state")

                    // DEBUG: Log callback details
                    SdkLogger.d(LogCategory.AUTHENTICATION) {
                        "Callback received (Flow-$flowId): " +
                            "URL=$callbackUrl, code=$code, " +
                            "expectedState=$currentState, receivedState=$receivedState, " +
                            "stateMatch=${receivedState == currentState}, " +
                            "receivedStateIsNull=${receivedState == null}"
                    }

                    // 5a. Verify state to prevent CSRF
                    if (receivedState == null || receivedState != currentState) {
                        SdkLogger.d(LogCategory.AUTHENTICATION) { "State validation FAILED - possible CSRF attack (Flow-$flowId)" }
                        emit(
                            emitLoginFailureEvent(
                                SrgLoginError.InvalidDataError("Invalid state received from callback. Possible CSRF attack."),
                            ),
                        )
                        return@flow
                    }

                    SdkLogger.d(LogCategory.AUTHENTICATION) { "State validation SUCCESS (Flow-$flowId)" }

                    if (code == null) {
                        emit(emitLoginFailureEvent(SrgLoginError.InvalidDataError("Authorization code not found in callback URL.")))
                        return@flow
                    }

                    // 5b. Exchange code for token
                    val tokenResponse =
                        authApiService.exchangeCodeForToken(
                            tokenEndpoint = openIdConfig.tokenEndpoint,
                            code = code,
                            redirectUri = config.redirectUri,
                            clientId = config.clientId,
                            codeVerifier = currentPkce.codeVerifier,
                        )

                    // 5c. Validate received tokens for security compliance
                    val validationResult =
                        tokenValidationService.validateTokenResponse(
                            tokenResponse = tokenResponse,
                            config = config,
                            openIdConfig = openIdConfig,
                            // TODO: Add nonce support if needed
                            nonce = null,
                        )

                    if (validationResult.isFailure) {
                        val validationException = validationResult.exceptionOrNull()
                        val error =
                            SrgLoginError.InvalidDataError(
                                "Token validation failed: ${validationException?.message}",
                            )

                        // Report to error tracking
                        ErrorHandlerRegistry.captureException(
                            throwable = validationException ?: Exception("Token validation failed"),
                            context =
                                mapOf(
                                    "operation" to "validate_token_response",
                                    "stage" to "login_token_validation",
                                    "critical" to true,
                                    "error_details" to error.toString(),
                                ),
                            level = ErrorHandler.ErrorLevel.FATAL,
                        )

                        emit(emitLoginFailureEvent(error))
                        return@flow
                    }

                    // 5d. Save validated tokens to persistent storage
                    val saveResult = tokenStorage.saveTokens(tokenResponse)
                    if (saveResult.isFailure) {
                        // Emit StorageError event
                        val storageErrorTimestamp =
                            kotlinx.datetime.Clock.System
                                .now()
                                .toEpochMilliseconds()
                        val storageException = saveResult.exceptionOrNull() ?: Exception("Failed to save tokens")
                        val storageError = SrgLoginError.UnknownError(storageException)
                        eventEmitter.tryEmit(
                            SdkLifecycleEvent.StorageError(
                                operation = StorageOperation.SAVE,
                                error = storageError,
                                timestamp = storageErrorTimestamp,
                            ),
                        )

                        // Report to error tracking
                        ErrorHandlerRegistry.captureException(
                            throwable = storageException,
                            context =
                                mapOf(
                                    "operation" to "save_tokens_after_login",
                                    "stage" to "login_storage",
                                    "critical" to true,
                                    "impact" to "user_authenticated_but_tokens_not_persisted",
                                ),
                            level = ErrorHandler.ErrorLevel.FATAL,
                        )

                        emit(emitLoginFailureEvent(storageError))
                        return@flow
                    }

                    // Convert TokenResponseDto to TokenSet with parsed AccessToken
                    val tokenSet =
                        TokenSet.fromDto(tokenResponse) { token ->
                            jwtValidationService.parseJwt(token).map { it.claims }
                        }

                    // Emit LoginSuccess event first (login succeeded with valid tokens)
                    val loginSuccessTimestamp =
                        kotlinx.datetime.Clock.System
                            .now()
                            .toEpochMilliseconds()
                    eventEmitter.tryEmit(SdkLifecycleEvent.LoginSuccess(tokenSet, loginSuccessTimestamp))

                    // Emit TokensSaved event after (tokens persisted to storage)
                    val tokensSavedTimestamp =
                        kotlinx.datetime.Clock.System
                            .now()
                            .toEpochMilliseconds()
                    eventEmitter.tryEmit(
                        SdkLifecycleEvent.TokensSaved(
                            hasRefreshToken = tokenResponse.refreshToken != null,
                            timestamp = tokensSavedTimestamp,
                        ),
                    )

                    emit(LoginState.Success(tokenSet))
                }
            }
        }.catch { e ->
            // Handle any unhandled exceptions with proper Flow.catch
            val error = openIdConfigRepository.mapExceptionToError(e as Exception)

            // Report to error tracking
            ErrorHandlerRegistry.captureException(
                throwable = e as Exception,
                context =
                    mapOf(
                        "operation" to "login_flow",
                        "stage" to "unhandled_exception",
                        "error_type" to e::class.simpleName,
                        "error_mapped_to" to error::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.ERROR,
            )

            emit(emitLoginFailureEvent(error))
        }

    override suspend fun logout(): SdkResult<Unit> {
        val logoutResult = logout(LogoutType.LocalOnly)
        return when (logoutResult) {
            is LogoutResult.Success -> SdkResult.Success(Unit)
            is LogoutResult.Failure -> SdkResult.Failure(logoutResult.error)
        }
    }

    override suspend fun logout(logoutType: LogoutType): LogoutResult {
        // Emit LogoutStarted event
        val timestamp =
            kotlinx.datetime.Clock.System
                .now()
                .toEpochMilliseconds()
        eventEmitter.tryEmit(SdkLifecycleEvent.LogoutStarted(logoutType, timestamp))

        val result =
            when (logoutType) {
                is LogoutType.LocalOnly -> {
                    performLocalLogout()
                }

                is LogoutType.BackChannel -> {
                    performBackChannelLogout(logoutType.logoutToken)
                }

                is LogoutType.FrontChannel -> {
                    LogoutResult.Failure(
                        clearedLocalSession = false,
                        serverLogoutAttempted = false,
                        error =
                            SrgLoginError.InvalidConfiguration(
                                "FrontChannel logout requires an authentication context. Use logout(logoutType, authContext) instead.",
                            ),
                    )
                }
            }

        // Emit LogoutSuccess or LogoutFailure event
        emitLogoutResultEvent(logoutType, result)

        return result
    }

    override suspend fun logout(
        logoutType: LogoutType,
        authContext: PlatformAuthContext,
    ): LogoutResult {
        // Emit LogoutStarted event
        val timestamp =
            kotlinx.datetime.Clock.System
                .now()
                .toEpochMilliseconds()
        eventEmitter.tryEmit(SdkLifecycleEvent.LogoutStarted(logoutType, timestamp))

        val result =
            when (logoutType) {
                is LogoutType.LocalOnly -> performLocalLogout()
                is LogoutType.BackChannel -> performBackChannelLogout(logoutType.logoutToken)
                is LogoutType.FrontChannel -> performFrontChannelLogout(logoutType, authContext)
            }

        // Emit LogoutSuccess or LogoutFailure event
        emitLogoutResultEvent(logoutType, result)

        return result
    }

    /**
     * Helper to emit LogoutSuccess or LogoutFailure event based on LogoutResult.
     *
     * @param logoutType The type of logout that was performed
     * @param result The logout result
     */
    private fun emitLogoutResultEvent(
        logoutType: LogoutType,
        result: LogoutResult,
    ) {
        val timestamp =
            kotlinx.datetime.Clock.System
                .now()
                .toEpochMilliseconds()
        when (result) {
            is LogoutResult.Success -> {
                eventEmitter.tryEmit(SdkLifecycleEvent.LogoutSuccess(logoutType, timestamp))
            }

            is LogoutResult.Failure -> {
                eventEmitter.tryEmit(SdkLifecycleEvent.LogoutFailure(result.error, timestamp))
            }
        }
    }

    override fun registerBackChannelLogoutListener(listener: BackChannelLogoutListener) {
        if (!backChannelLogoutListeners.contains(listener)) {
            backChannelLogoutListeners.add(listener)
        }
    }

    override fun unregisterBackChannelLogoutListener(listener: BackChannelLogoutListener) {
        backChannelLogoutListeners.remove(listener)
    }

    override suspend fun openSsoClient(
        ssoClientUrl: String,
        authContext: PlatformAuthContext,
        onReturnCallback: ((String) -> Unit)?,
    ): SdkResult<Unit> {
        // Note: onReturnCallback is now ignored as we use suspendCancellableCoroutine pattern
        return webAuthenticator.openSsoClient(ssoClientUrl, authContext)
    }

    private suspend fun performLocalLogout(): LogoutResult {
        val clearResult = tokenStorage.clearTokens()
        return if (clearResult.isSuccess) {
            // Emit TokensCleared event
            val tokensClearedTimestamp =
                kotlinx.datetime.Clock.System
                    .now()
                    .toEpochMilliseconds()
            eventEmitter.tryEmit(
                SdkLifecycleEvent.TokensCleared(
                    reason = "logout",
                    timestamp = tokensClearedTimestamp,
                ),
            )

            LogoutResult.Success(
                clearedLocalSession = true,
                terminatedServerSession = false,
            )
        } else {
            // Emit StorageError event
            val storageErrorTimestamp =
                kotlinx.datetime.Clock.System
                    .now()
                    .toEpochMilliseconds()
            val storageException = clearResult.exceptionOrNull() ?: Exception("Failed to clear local tokens")
            val storageError = SrgLoginError.UnknownError(storageException)
            eventEmitter.tryEmit(
                SdkLifecycleEvent.StorageError(
                    operation = StorageOperation.CLEAR,
                    error = storageError,
                    timestamp = storageErrorTimestamp,
                ),
            )

            LogoutResult.Failure(
                clearedLocalSession = false,
                serverLogoutAttempted = false,
                error = storageError,
            )
        }
    }

    private suspend fun performBackChannelLogout(logoutToken: String): LogoutResult {
        // Validate the logout token JWT - CRITICAL SECURITY CHECK
        try {
            // 1. Get OpenID Configuration for JWKS URI and issuer
            val openIdConfigResult = openIdConfigRepository.getConfiguration()
            val openIdConfig =
                when (openIdConfigResult) {
                    is SdkResult.Success -> {
                        openIdConfigResult.data
                    }

                    is SdkResult.Failure -> {
                        return LogoutResult.Failure(
                            clearedLocalSession = false,
                            serverLogoutAttempted = false,
                            error = openIdConfigResult.error,
                        )
                    }
                }

            // 2. Create JWT validation components
            val replayCache = PersistentReplayCache(tokenStorage, maxAgeSeconds = 3600L)
            val logoutValidator =
                LogoutTokenValidationService(
                    jwtValidationService = jwtValidationService,
                    replayCache = replayCache,
                    expectedIssuer = openIdConfig.issuer,
                    clientId = config.clientId,
                    jwksUri = openIdConfig.jwksUri,
                )
            val tokenValidationService =
                TokenValidationService(
                    jwtValidationService = jwtValidationService,
                    logoutTokenValidationService = logoutValidator,
                    apiService = authApiService,
                )

            // 3. Get current session info for validation
            val currentTokens = tokenStorage.getTokens()
            val currentSession =
                currentTokens?.let { tokens ->
                    // Extract session info from stored tokens if available
                    // This would require parsing the ID token to get sub/sid claims
                    // For now, we'll validate globally without session matching
                    null
                }

            // 4. Validate the logout token
            val validationResult =
                if (currentSession != null) {
                    logoutValidator.validateLogoutToken(logoutToken, currentSession)
                } else {
                    logoutValidator.validateLogoutTokenGlobal(logoutToken)
                }

            val validatedClaims =
                when {
                    validationResult.isSuccess -> {
                        validationResult.getOrThrow()
                    }

                    else -> {
                        // Validation failed - this is a security issue
                        val error =
                            validationResult.exceptionOrNull() as? SrgLoginError
                                ?: SrgLoginError.InvalidLogoutToken("Logout token validation failed")

                        return LogoutResult.Failure(
                            clearedLocalSession = false,
                            serverLogoutAttempted = false,
                            error = error,
                        )
                    }
                }

            // 5. Validation successful - proceed with logout
            // Clear local session
            val localLogoutResult = performLocalLogout()
            if (localLogoutResult !is LogoutResult.Success) {
                return localLogoutResult
            }

            // 6. Notify all registered listeners with validated token
            var hasListenerError = false
            var lastError: SrgLoginError? = null

            for (listener in backChannelLogoutListeners) {
                try {
                    val listenerResult = listener.onBackChannelLogout(logoutToken)
                    if (listenerResult is SdkResult.Failure) {
                        hasListenerError = true
                        lastError = listenerResult.error

                        // Report listener failure to error tracking
                        ErrorHandlerRegistry.captureException(
                            throwable = Exception(listenerResult.error.toString()),
                            context =
                                mapOf(
                                    "operation" to "back_channel_logout_listener",
                                    "listener" to listener::class.simpleName,
                                    "error_type" to listenerResult.error::class.simpleName,
                                ),
                            level = ErrorHandler.ErrorLevel.WARNING,
                        )
                    }
                } catch (e: Exception) {
                    hasListenerError = true
                    lastError = SrgLoginError.UnknownError(e)

                    // Report listener exception to error tracking
                    ErrorHandlerRegistry.captureException(
                        throwable = e,
                        context =
                            mapOf(
                                "operation" to "back_channel_logout_listener",
                                "listener" to listener::class.simpleName,
                                "error_type" to "exception",
                            ),
                        level = ErrorHandler.ErrorLevel.ERROR,
                    )
                }
            }

            return if (hasListenerError && lastError != null) {
                LogoutResult.Failure(
                    clearedLocalSession = true,
                    serverLogoutAttempted = false,
                    error = lastError,
                )
            } else {
                LogoutResult.Success(
                    clearedLocalSession = true,
                    // Back-channel means server initiated the logout
                    terminatedServerSession = true,
                )
            }
        } catch (e: Exception) {
            // Any unexpected error during validation is a security concern
            // Report to error tracking
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "back_channel_logout_validation",
                        "stage" to "logout_validation",
                        "security_concern" to true,
                        "error_type" to e::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.FATAL,
            )

            return LogoutResult.Failure(
                clearedLocalSession = false,
                serverLogoutAttempted = false,
                error = SrgLoginError.UnknownError(e, "Back-channel logout validation failed"),
            )
        }
    }

    private suspend fun performFrontChannelLogout(
        logoutType: LogoutType.FrontChannel,
        authContext: PlatformAuthContext,
    ): LogoutResult {
        // Validate platform context capabilities for web logout
        if (authContext !is WebAuthCapable) {
            return LogoutResult.Failure(
                clearedLocalSession = false,
                serverLogoutAttempted = false,
                error =
                    SrgLoginError.InvalidConfiguration(
                        "Front-channel logout requires a WebAuthCapable authentication context.",
                    ),
            )
        }

        try {
            // 1. Get OpenID Configuration for logout endpoint
            val openIdConfigResult = openIdConfigRepository.getConfiguration()
            val openIdConfig =
                when (openIdConfigResult) {
                    is SdkResult.Success -> {
                        openIdConfigResult.data
                    }

                    is SdkResult.Failure -> {
                        return LogoutResult.Failure(
                            clearedLocalSession = false,
                            serverLogoutAttempted = false,
                            error = openIdConfigResult.error,
                        )
                    }
                }

            // 2. Get postLogoutRedirectUri with validation
            // Priority 1: from call-site
            // Priority 2: from global config
            val postLogoutRedirectUri =
                logoutType.postLogoutRedirectUri
                    ?: config.postLogoutRedirectUri

            if (postLogoutRedirectUri == null) {
                return LogoutResult.Failure(
                    clearedLocalSession = false,
                    // We didn't even attempt it
                    serverLogoutAttempted = false,
                    error =
                        SrgLoginError.InvalidConfiguration(
                            "Front-channel logout requires a postLogoutRedirectUri to be provided " +
                                "either in SrgLoginConfig or in the logout() call.",
                        ),
                )
            }

            // 3. Get stored ID token for id_token_hint
            val storedTokens = tokenStorage.getTokens()
            val idTokenHint = storedTokens?.idToken

            // 4. Build logout URL
            val logoutUrl =
                buildString {
                    append(openIdConfig.endSessionEndpoint ?: "${config.environment.baseUrl}/logout")
                    append("?client_id=${config.clientId}")
                    append("&post_logout_redirect_uri=${postLogoutRedirectUri.urlEncode()}")
                    // Add id_token_hint for more secure and precise logout
                    idTokenHint?.let { idToken ->
                        append("&id_token_hint=$idToken")
                    }
                }

            // 5. Clear local session first (to ensure clean state)
            val localLogoutResult = performLocalLogout()
            val localCleared = localLogoutResult is LogoutResult.Success

            // 6. Trigger platform-specific browser logout (now waits for completion)
            val logoutResult = webAuthenticator.logout(logoutUrl, authContext)

            // 7. Return combined result with accurate server termination status
            return when (logoutResult) {
                is SdkResult.Success -> {
                    LogoutResult.Success(
                        clearedLocalSession = localCleared,
                        // Fixed: We now have confirmed server logout
                        terminatedServerSession = true,
                    )
                }

                is SdkResult.Failure -> {
                    LogoutResult.Failure(
                        clearedLocalSession = localCleared,
                        serverLogoutAttempted = true,
                        error = logoutResult.error,
                    )
                }
            }
        } catch (e: Exception) {
            // If anything fails, still try to clear local session
            val localLogoutResult = performLocalLogout()
            val localCleared = localLogoutResult is LogoutResult.Success

            return LogoutResult.Failure(
                clearedLocalSession = localCleared,
                serverLogoutAttempted = true,
                error = SrgLoginError.UnknownError(e),
            )
        }
    }

    private fun getQueryParameter(
        url: String,
        name: String,
    ): String? {
        val query = url.substringAfter('?', "")
        return query
            .split('&')
            .mapNotNull { pair ->
                val parts = pair.split('=', limit = 2)
                if (parts.size == 2 && parts[0] == name) {
                    // URL-decode using Ktor's built-in function to handle percent-encoding
                    // Example: "NcD%7ERz%7EardgN2JNd" → "NcD~Rz~ardgN2JNd"
                    parts[1].decodeURLQueryComponent()
                } else {
                    null
                }
            }.firstOrNull()
    }

    /**
     * Custom URL encoding for OAuth 2.0 query parameters.
     *
     * **Why not use Ktor's `encodeURLQueryComponent()`?**
     *
     * While Ktor provides `encodeURLQueryComponent()`, it follows RFC 3986 which allows
     * certain special characters (like `&`, `=`) to remain unencoded in query strings.
     * This creates **security vulnerabilities** for our use case:
     *
     * **Security Issue Example:**
     * ```
     * additionalParameters = mapOf("foo&bar" to "value")
     *
     * With Ktor: "foo&bar=value" → "foo&bar=value" (NOT encoded!)
     * Result: Creates TWO parameters: "foo" and "bar=value" (INJECTION ATTACK!)
     *
     * With our urlEncode(): "foo&bar=value" → "foo%26bar=value"
     * Result: Single parameter with key "foo&bar" (SAFE)
     * ```
     *
     * **Critical characters we MUST encode:**
     * - `&` (parameter separator) → `%26`
     * - `=` (key-value separator) → `%3D`
     * - And other special characters that could break URL parsing
     *
     * This prevents injection attacks where malicious parameter keys/values
     * could inject additional OAuth parameters (e.g., overriding `client_id`, `redirect_uri`).
     *
     * @return The URL-encoded string safe for OAuth 2.0 query parameters
     */
    private fun String.urlEncode(): String =
        this
            .replace(":", "%3A")
            .replace("/", "%2F")
            .replace("?", "%3F")
            .replace("#", "%23")
            .replace("[", "%5B")
            .replace("]", "%5D")
            .replace("@", "%40")
            .replace("!", "%21")
            .replace("$", "%24")
            .replace("&", "%26")
            .replace("'", "%27")
            .replace("(", "%28")
            .replace(")", "%29")
            .replace("*", "%2A")
            .replace("+", "%2B")
            .replace(",", "%2C")
            .replace(";", "%3B")
            .replace("=", "%3D")
            .replace(" ", "%20")
}
