package ch.srg.login.sdk.auth

import ch.srg.login.sdk.SrgLogin
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.model.TokenSet
import ch.srg.login.sdk.result.SdkResult
import kotlinx.coroutines.flow.Flow

/**
 * Defines the type of credentials to be used for a login attempt.
 * This allows the `AuthenticationManager` to support multiple login strategies.
 */
sealed class Credentials {
    /** Triggers the web-based login flow using a browser. */
    data object Web : Credentials()

    /** Triggers the device authorization flow for TVs and limited-input devices. */
    data object Device : Credentials()

    /** Triggers a login using stored credentials unlocked by biometrics. */
    data object Biometric : Credentials()

    /** Provides a username and password for a direct, non-web-based login. */
    data class UserPassword(
        val username: String,
        val password: String,
    ) : Credentials()
}

/**
 * Represents the various states that can occur during a login flow.
 * A login flow can emit multiple states over time, especially for complex flows like the device flow.
 */
sealed class LoginState {
    /** Intermediate state for the TV/Device flow. The UI must display this info. */
    data class AwaitingDeviceActivation(
        val userCode: String,
        val verificationUri: String,
    ) : LoginState()

    /** Final success state for any flow, containing the token set with parsed AccessToken. */
    data class Success(
        val tokenSet: TokenSet,
    ) : LoginState()

    /** Final failure state for any flow, containing a specific error. */
    data class Failure(
        val error: SrgLoginError,
    ) : LoginState()
}

/**
 * Defines the contract for an authentication strategy.
 * Each implementation will handle a specific login method (e.g., Web, Device, Biometric).
 *
 * This interface is internal to the SDK. External users should interact with [SrgLogin]
 * which provides a stable public API facade over this internal interface.
 */
internal interface AuthenticationManager {
    /**
     * Initiates a login flow using the specified credentials and platform context.
     *
     * @param credentials The type of login to perform.
     * @param authContext The platform-specific authentication context.
     * @param additionalScopes Additional OAuth scopes to request beyond "openid".
     *                         The "openid" scope is automatically included for OIDC compliance.
     * @param additionalParameters Additional OAuth/OIDC parameters to include in the authorization request.
     *                             Common parameters (OIDC Core 1.0, Section 3.1.2.1):
     *                             - "ui_locales": "fr" - Preferred user interface language
     *                             - "prompt": "login" | "consent" | "none" | "select_account" - Authentication/consent control
     *                             - "display": "page" | "popup" | "touch" | "wap" - Display mode for authentication UI
     *                             - "max_age": "3600" - Maximum authentication age in seconds
     *                             - "login_hint": "user@example.com" - Pre-fills username
     *                             - "acr_values": "level2" - Requested authentication context
     *
     *                             All parameter values are automatically URL-encoded.
     *                             Specification: https://openid.net/specs/openid-connect-core-1_0.html#AuthRequest
     * @return A [Flow] that emits [LoginState] updates throughout the authentication process.
     */
    fun login(
        credentials: Credentials,
        authContext: PlatformAuthContext,
        additionalScopes: List<String> = emptyList(),
        additionalParameters: Map<String, String> = emptyMap(),
    ): Flow<LoginState>

    /**
     * Logs the user out locally by clearing stored tokens.
     * This is equivalent to logout(LogoutType.LocalOnly).
     *
     * @return Result indicating success or failure of local logout
     */
    suspend fun logout(): SdkResult<Unit>

    /**
     * Logs the user out using the specified logout type.
     *
     * For LogoutType.LocalOnly: Only clears local tokens and session data.
     * For LogoutType.BackChannel: Processes server-initiated logout notification.
     * For LogoutType.FrontChannel: Use logout(logoutType, authContext) instead.
     *
     * @param logoutType The type of logout to perform
     * @return LogoutResult with details about what was cleared/terminated
     */
    suspend fun logout(logoutType: LogoutType): LogoutResult

    /**
     * Logs the user out using the specified logout type with platform context.
     *
     * This method is required for LogoutType.FrontChannel which needs to open
     * a browser using the provided authentication context.
     *
     * @param logoutType The type of logout to perform
     * @param authContext Platform-specific context (required for FrontChannel logout)
     * @return LogoutResult with details about what was cleared/terminated
     */
    suspend fun logout(
        logoutType: LogoutType,
        authContext: PlatformAuthContext,
    ): LogoutResult

    /**
     * Registers a listener for back-channel logout notifications.
     *
     * @param listener The listener to receive back-channel logout events
     */
    fun registerBackChannelLogoutListener(listener: BackChannelLogoutListener)

    /**
     * Unregisters a back-channel logout listener.
     *
     * @param listener The listener to remove
     */
    fun unregisterBackChannelLogoutListener(listener: BackChannelLogoutListener)

    /**
     * Opens another SSO client URL in platform-specific browser and suspends until user returns.
     * Leverages the current authenticated session cookies for seamless SSO experience.
     *
     * Perfect for displaying profile pages, settings, admin panels, or any other SSO client
     * that shares the same authentication system.
     *
     * Note: The method suspends until the user completes navigation and returns to the app,
     * providing reliable confirmation of the SSO client interaction.
     *
     * @param ssoClientUrl URL of the SSO client to display
     * @param authContext The platform-specific authentication context
     * @param onReturnCallback Deprecated - callback parameter is ignored in current implementation
     * @return A [SdkResult] indicating success or failure of the complete SSO client navigation
     */
    suspend fun openSsoClient(
        ssoClientUrl: String,
        authContext: PlatformAuthContext,
        onReturnCallback: ((String) -> Unit)? = null,
    ): SdkResult<Unit>
}
