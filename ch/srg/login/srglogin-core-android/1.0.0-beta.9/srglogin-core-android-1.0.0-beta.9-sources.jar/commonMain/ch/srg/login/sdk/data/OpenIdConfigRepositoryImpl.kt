package ch.srg.login.sdk.data

import ch.srg.login.sdk.Environment
import ch.srg.login.sdk.SrgLoginConfig
import ch.srg.login.sdk.data.api.SrgAuthApiService
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.internal.SecurityUtils
import ch.srg.login.sdk.internal.mapPlatformException
import ch.srg.login.sdk.logging.ErrorHandler
import ch.srg.login.sdk.logging.ErrorHandlerRegistry
import ch.srg.login.sdk.logging.LogCategory
import ch.srg.login.sdk.logging.SdkLogger
import ch.srg.login.sdk.model.OpenIdConfig
import ch.srg.login.sdk.result.SdkResult
import io.ktor.client.plugins.ClientRequestException
import io.ktor.client.plugins.ServerResponseException
import kotlinx.datetime.Clock
import kotlinx.serialization.SerializationException
import kotlin.time.Duration.Companion.hours

/**
 * Implementation of [OpenIdConfigRepository].
 *
 * @property authApiService The service responsible for making API calls.
 * @property config The SDK configuration for this repository instance.
 * @property securityUtils Security utilities for error message sanitization.
 */
internal class OpenIdConfigRepositoryImpl(
    private val authApiService: SrgAuthApiService,
    private val config: SrgLoginConfig,
    private val securityUtils: SecurityUtils,
) : OpenIdConfigRepository {
    companion object {
        private val CACHE_TTL_MS = 1.hours.inWholeMilliseconds
    }

    init {
        SdkLogger.d(LogCategory.SDK_CREATION) { "OpenIdConfigRepositoryImpl created (hashCode=${this.hashCode()})" }
    }

    private data class CachedConfig(
        val config: OpenIdConfig,
        val timestamp: Long,
        val environment: Environment,
    ) {
        fun isExpired(): Boolean = Clock.System.now().toEpochMilliseconds() - timestamp > CACHE_TTL_MS
    }

    private var cachedConfig: CachedConfig? = null

    override suspend fun getConfiguration(): SdkResult<OpenIdConfig> {
        // Check cache first
        cachedConfig?.let { cached ->
            if (cached.environment == config.environment && !cached.isExpired()) {
                SdkLogger.d(LogCategory.NETWORK) { "Using cached OpenID config for environment=${config.environment}" }
                return SdkResult.Success(cached.config)
            }
        }

        SdkLogger.i(LogCategory.NETWORK) {
            "Fetching OpenID configuration (environment=${config.environment}, baseUrl='${config.environment.baseUrl}')"
        }

        return try {
            val openIdConfig = authApiService.getOpenIdConfiguration(config.environment.baseUrl)
            // Cache successful result
            cachedConfig =
                CachedConfig(
                    config = openIdConfig,
                    timestamp = Clock.System.now().toEpochMilliseconds(),
                    environment = config.environment,
                )
            SdkLogger.i(LogCategory.NETWORK) { "OpenID configuration fetched successfully" }
            SdkResult.Success(openIdConfig)
        } catch (e: Exception) {
            SdkLogger.e(LogCategory.NETWORK, throwable = e) { "Failed to fetch OpenID config: ${e::class.simpleName}" }

            // Report to error tracking
            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "get_openid_configuration",
                        "environment" to config.environment.toString(),
                        "base_url" to config.environment.baseUrl,
                        "critical" to true,
                        "impact" to "sdk_initialization_blocked",
                        "exception_type" to e::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.FATAL,
            )

            val error = mapExceptionToError(e)
            SdkResult.Failure(error)
        }
    }

    override fun mapExceptionToError(e: Exception): SrgLoginError {
        // First, try to map the exception using the platform-specific mapper.
        mapPlatformException(e)?.let { return it }

        // If not mapped, use the common KMP-safe mappers.
        // Order matters: check subclasses before superclasses
        // (SerializationException extends IllegalArgumentException)
        return when (e) {
            // JSON parsing errors (must come before IllegalArgumentException — it's a subclass)
            is SerializationException -> {
                SrgLoginError.SerializationError(
                    originalMessage = e.message,
                    responseBody = e.message?.let { securityUtils.sanitizeErrorMessage(it) },
                )
            }

            // URL validation errors (plain IllegalArgumentException from require(...))
            is IllegalArgumentException -> {
                SrgLoginError.InvalidConfiguration(
                    reason = e.message ?: "Invalid URL configuration",
                    details = "Check base URL format and HTTPS requirement",
                )
            }

            // HTTP client errors (4xx)
            is ClientRequestException -> {
                SrgLoginError.HttpError(
                    code = e.response.status.value,
                    message = e.response.status.description,
                    url =
                        e.response.call.request.url
                            .toString(),
                )
            }

            // HTTP server errors (5xx)
            is ServerResponseException -> {
                SrgLoginError.HttpError(
                    code = e.response.status.value,
                    message = e.response.status.description,
                    url =
                        e.response.call.request.url
                            .toString(),
                )
            }

            // Fallback for unknown errors
            else -> {
                SrgLoginError.UnknownError(
                    cause = e,
                    context = "OpenID configuration fetch",
                )
            }
        }
    }
}
