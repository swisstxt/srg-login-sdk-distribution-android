package ch.srg.login.sdk.model

import kotlinx.serialization.Serializable

/**
 * Represents the header of a JWT token.
 */
@Serializable
internal data class JwtHeader(
    // Algorithm (e.g., "RS256", "ES256")
    val alg: String,
    // Type (always "JWT")
    val typ: String = "JWT",
    // Key ID for signature verification
    val kid: String? = null,
)

/**
 * Represents the payload/claims of a JWT token.
 * This is a generic container for all JWT claims.
 * Note: Not serializable as it contains Any types - used only for internal processing.
 */
internal data class JwtClaims(
    // Issuer
    val iss: String? = null,
    // Subject
    val sub: String? = null,
    // Audience
    val aud: String? = null,
    // Expiration time (Unix timestamp)
    val exp: Long? = null,
    // Not before (Unix timestamp)
    val nbf: Long? = null,
    // Issued at (Unix timestamp)
    val iat: Long? = null,
    // JWT ID (unique identifier)
    val jti: String? = null,
    // Custom claims
    val custom: Map<String, Any> = emptyMap(),
)

/**
 * Represents the validated claims of a logout token specifically.
 * Contains all the information needed for secure back-channel logout.
 */
internal data class LogoutTokenClaims(
    // Issuer - MUST match expected issuer
    val iss: String,
    // Audience - MUST match client ID
    val aud: String,
    // Subject (user ID) - at least one of sub/sid required
    val sub: String? = null,
    // Session ID - at least one of sub/sid required
    val sid: String? = null,
    // MUST contain logout event
    val events: Map<String, Any>,
    // Issued at - for age validation
    val iat: Long,
    // JWT ID - for replay protection
    val jti: String,
) {
    /**
     * Validates that this logout token contains the required back-channel logout event.
     */
    fun hasValidLogoutEvent(): Boolean = events.containsKey("http://schemas.openid.net/event/backchannel-logout")

    /**
     * Validates that at least one session identifier is present.
     */
    fun hasValidSessionIdentifier(): Boolean = !sub.isNullOrBlank() || !sid.isNullOrBlank()
}

/**
 * Represents current session information for matching against logout tokens.
 */
internal data class SessionInfo(
    // Current user ID (maps to 'sub' claim)
    val userId: String? = null,
    // Current session ID (maps to 'sid' claim)
    val sessionId: String? = null,
)
