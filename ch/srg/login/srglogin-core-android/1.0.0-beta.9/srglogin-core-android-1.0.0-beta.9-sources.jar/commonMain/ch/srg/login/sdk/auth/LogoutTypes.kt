package ch.srg.login.sdk.auth

import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.result.SdkResult

/**
 * Represents different types of logout operations supported by the SDK.
 */
sealed class LogoutType {
    /**
     * Local logout only - clears stored tokens and session data locally
     * without notifying the authorization server.
     *
     * Use cases:
     * - Network connectivity issues
     * - Quick user switching
     * - Emergency logout scenarios
     * - Fallback when server logout fails
     */
    data object LocalOnly : LogoutType()

    /**
     * Front-channel logout - redirects user to the authorization server's
     * logout endpoint via browser to terminate the server session.
     * Also clears local tokens and session data.
     *
     * Uses fire-and-forget approach: returns success immediately after launching browser.
     * Optional callback can be used for UX improvements when user returns via deeplink.
     *
     * Requires a PlatformAuthContext to open the browser.
     *
     * @property postLogoutRedirectUri Optional URI to redirect to after logout
     * @property onReturn Optional callback executed when user returns via deeplink.
     *                   Used for analytics, UI updates, and cleanup - not validation.
     */
    data class FrontChannel(
        val postLogoutRedirectUri: String? = null,
        val onReturn: ((String) -> Unit)? = null,
    ) : LogoutType()

    /**
     * Back-channel logout - server-initiated logout notification.
     * The SDK responds to logout events from the authorization server.
     *
     * This is typically handled automatically by the SDK when it receives
     * a logout notification from the server.
     *
     * @property logoutToken JWT logout token from the authorization server
     */
    data class BackChannel(
        val logoutToken: String,
    ) : LogoutType()
}

/**
 * Result of a logout operation indicating what was accomplished.
 */
sealed class LogoutResult {
    /**
     * Logout completed successfully.
     *
     * @property clearedLocalSession Whether local tokens and session were cleared
     * @property terminatedServerSession Whether the server session was terminated
     */
    data class Success(
        val clearedLocalSession: Boolean,
        val terminatedServerSession: Boolean,
    ) : LogoutResult()

    /**
     * Logout partially completed or failed.
     *
     * @property clearedLocalSession Whether local tokens were successfully cleared
     * @property serverLogoutAttempted Whether server logout was attempted
     * @property error The error that occurred during logout
     */
    data class Failure(
        val clearedLocalSession: Boolean,
        val serverLogoutAttempted: Boolean,
        val error: SrgLoginError,
    ) : LogoutResult()
}

/**
 * Listener interface for back-channel logout notifications.
 * Implementations should handle server-initiated logout events.
 *
 * Register listeners with the SDK to receive notifications when
 * the authorization server initiates a logout (e.g., user logged out
 * from another device or admin revoked access).
 */
interface BackChannelLogoutListener {
    /**
     * Called when a back-channel logout notification is received from the server.
     *
     * The implementation should:
     * 1. Clear local session data
     * 2. Update UI state to reflect logged out status
     * 3. Notify the user if appropriate
     *
     * @param logoutToken The JWT logout token containing session information
     * @return Result indicating whether the logout was processed successfully
     */
    suspend fun onBackChannelLogout(logoutToken: String): SdkResult<Unit>
}
