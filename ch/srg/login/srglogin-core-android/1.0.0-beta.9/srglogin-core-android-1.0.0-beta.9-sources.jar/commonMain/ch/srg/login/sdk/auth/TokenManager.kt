package ch.srg.login.sdk.auth

import ch.srg.login.sdk.model.AccessToken
import ch.srg.login.sdk.model.TokenSet
import ch.srg.login.sdk.result.SdkResult
import kotlinx.coroutines.flow.StateFlow

/**
 * Manages OAuth 2.0 token lifecycle including refresh, access, and state monitoring.
 *
 * This interface defines the contract for complete token management,
 * including refresh operations, token access with automatic refresh,
 * state monitoring, and authentication checks.
 *
 * **Responsibilities**:
 * - Provide access to valid tokens (with automatic refresh if enabled)
 * - Coordinate token refresh workflow (check state, call API, update storage)
 * - Monitor token state and provide reactive updates
 * - Update refresh token metadata (use count, timestamps, rotation detection)
 * - Integrate with JwtValidationService for expiration checks
 * - Integrate with TokenStorage for persistence
 *
 * **Usage Example**:
 * ```kotlin
 * val tokenManager: TokenManager = // ... from DI
 *
 * // Get access token (automatically refreshes if needed and enabled)
 * val accessTokenResult = tokenManager.getAccessToken()
 * when (accessTokenResult) {
 *     is SdkResult.Success -> useToken(accessTokenResult.data)
 *     is SdkResult.Failure -> handleError(accessTokenResult.error)
 * }
 *
 * // Or manually refresh
 * val refreshResult = tokenManager.refreshTokens()
 *
 * // Check authentication status
 * if (tokenManager.isAuthenticated()) {
 *     // User is authenticated
 * }
 * ```
 *
 * **Thread Safety**: Implementations should be thread-safe and handle
 * concurrent refresh attempts appropriately (e.g., deduplicate requests).
 */
interface TokenManager {
    /**
     * Refreshes the access token using the refresh token.
     *
     * This method orchestrates the complete token refresh workflow:
     * 1. Retrieves current tokens and metadata from storage
     * 2. Validates that a refresh token is available
     * 3. Calls the token endpoint to exchange refresh token for new tokens
     * 4. Updates refresh token metadata (use count, timestamps, token hash)
     * 5. Persists new tokens and updated metadata
     * 6. Returns the new token set with parsed access token
     *
     * **Token Rotation**: If the authorization server implements refresh token
     * rotation, the old refresh token becomes invalid after use. The new refresh
     * token from the response must be used for subsequent refreshes.
     *
     * **Metadata Tracking**: This method updates:
     * - `sessionRefreshCount`: Incremented on each successful refresh
     * - `lastUsedAt`: Updated to current timestamp (epoch seconds)
     * - `lastRefreshAt`: Updated to current timestamp (epoch milliseconds)
     * - `lastRefreshError`: Cleared on success, set on failure
     * - `previousTokenHash`: SHA-256 hash of the old refresh token (for debugging rotation)
     *
     * **Error Handling**: Returns Result.failure for:
     * - No refresh token available (user needs to re-authenticate)
     * - Network errors (can be retried with exponential backoff)
     * - Invalid grant errors (refresh token expired/revoked, re-authentication required)
     * - Storage errors (inability to persist new tokens)
     *
     * **Concurrency**: Implementations should handle concurrent calls appropriately,
     * typically by deduplicating simultaneous refresh requests.
     *
     * @return SdkResult containing new TokenSet with parsed AccessToken on success, or SrgLoginError on failure
     */
    suspend fun refreshTokens(): SdkResult<TokenSet>

    /**
     * Gets the current state of tokens for refresh decision-making.
     *
     * This method evaluates the current token response and returns the appropriate
     * state based on expiration and configuration:
     * - `TokenState.NoTokens`: No tokens available (user not logged in)
     * - `TokenState.Valid`: Token is valid and not expiring soon
     * - `TokenState.ExpiringSoon`: Token is valid but within refresh threshold
     * - `TokenState.Expired`: Token has expired
     *
     * The state determination considers:
     * - Access token expiration time (from JWT exp claim)
     * - Refresh threshold from TokenRefreshConfig
     * - Proactive refresh enabled/disabled setting
     *
     * **Use Case**: Call this before making API requests to decide if refresh is needed.
     *
     * @return Current TokenState
     */
    suspend fun getCurrentTokenState(): TokenState

    /**
     * Checks if a refresh token is available.
     *
     * A refresh token is required to refresh access tokens. If no refresh token
     * is available, the user needs to re-authenticate via the login flow.
     *
     * **Note**: Even if a refresh token exists, it may be expired or revoked.
     * Actual refresh attempts may still fail with invalid_grant errors.
     *
     * @return true if a refresh token exists in storage, false otherwise
     */
    suspend fun hasRefreshToken(): Boolean

    /**
     * Returns a valid access token with parsed JWT claims, automatically refreshing if expired and proactive refresh is enabled.
     *
     * Behavior based on enableProactiveRefresh configuration:
     * - If true: Automatically refreshes expired tokens
     * - If false: Fails with TokenExpired error if token is expired
     *
     * This method provides the primary token access mechanism for applications.
     * It handles the complexity of token expiration and refresh internally.
     *
     * **Usage Example**:
     * ```kotlin
     * when (val result = tokenManager.getAccessToken()) {
     *     is SdkResult.Success -> {
     *         val token = result.data
     *         // Use token in API calls
     *         apiClient.makeRequest("Bearer ${token.value}")
     *         // Check expiration
     *         println("Token expires: ${token.formatExpiresIn()}")
     *         // Access JWT claims
     *         println("User ID: ${token.subject}")
     *         println("Issuer: ${token.issuer}")
     *     }
     *     is SdkResult.Failure -> {
     *         when (result.error) {
     *             is SrgLoginError.TokenExpired -> {
     *                 // Proactive refresh disabled and token expired
     *                 // Redirect to login
     *             }
     *             is SrgLoginError.NotAuthenticated -> {
     *                 // No tokens available
     *                 // Redirect to login
     *             }
     *             else -> {
     *                 // Handle other errors
     *             }
     *         }
     *     }
     * }
     * ```
     *
     * @return SdkResult.Success with AccessToken containing parsed JWT claims, or SdkResult.Failure if:
     *   - No tokens stored (requires login) - returns NotAuthenticated error
     *   - Token expired and proactive refresh disabled - returns TokenExpired error
     *   - Refresh failed (network error, invalid refresh token)
     */
    suspend fun getAccessToken(): SdkResult<AccessToken>

    /**
     * Checks if the user has a valid or refreshable authentication session.
     *
     * Returns true if EITHER condition is met:
     * - Valid (non-expired) access token exists in storage, OR
     * - Refresh token exists in storage (can obtain new access token)
     *
     * Returns false if BOTH conditions are false:
     * - No valid access token available, AND
     * - No refresh token available
     *
     * **Scenarios**:
     * - ✅ Valid access token + no refresh token → `true` (can make API calls immediately)
     * - ✅ Expired access token + refresh token → `true` (can refresh to get new token)
     * - ✅ Valid access token + refresh token → `true` (optimal case)
     * - ❌ Expired/missing access token + no refresh token → `false` (requires re-authentication)
     *
     * **Important**: This method checks LOCAL state only (no network call).
     * If tokens exist locally but are invalid server-side (revoked, corrupted),
     * this method will still return true until the next token operation detects the issue.
     * Invalid tokens are automatically detected and cleaned up when:
     * - `getAccessToken()` is called
     * - `refreshTokens()` is called
     * - Server returns `invalid_grant` error
     *
     * **Usage Example**:
     * ```kotlin
     * if (tokenManager.isAuthenticated()) {
     *     // User has valid session locally, proceed to main screen
     *     navigateToMainScreen()
     * } else {
     *     // User needs to log in
     *     navigateToLoginScreen()
     * }
     * ```
     *
     * **Note**: This is a quick local check. Use `getAccessToken()` to get
     * the actual token with automatic refresh and server-side validation.
     *
     * @return true if user has valid access token OR refresh token, false otherwise
     */
    suspend fun isAuthenticated(): Boolean

    /**
     * Observes the current token state as a reactive StateFlow.
     *
     * The StateFlow emits token state changes automatically on:
     * - Login (new tokens available)
     * - Logout (tokens cleared)
     * - Token refresh (tokens updated)
     * - Periodic monitoring (if enableProactiveRefresh is true)
     *
     * **Initial Value**: Reflects actual storage state (not default NoTokens).
     *
     * **Use Cases**:
     * - UI state management (show session expiry warnings)
     * - Analytics (track session lifecycle events)
     * - Background sync coordination (pause when no valid token)
     * - Debug panels (display current token status)
     *
     * **Usage Example**:
     * ```kotlin
     * // In ViewModel
     * val tokenState = tokenManager.observeTokenState()
     *     .stateIn(viewModelScope, SharingStarted.Eagerly, TokenState.NoTokens)
     *
     * val showSessionExpiring = tokenState.map { state ->
     *     state is TokenState.ExpiringSoon
     * }
     *
     * // In Composable
     * val state by tokenState.collectAsState()
     * when (state) {
     *     is TokenState.Valid -> ShowMainContent()
     *     is TokenState.ExpiringSoon -> ShowExpiryWarning()
     *     is TokenState.Expired -> ShowReauthenticateDialog()
     *     is TokenState.NoTokens -> ShowLoginScreen()
     *     // Handle other states
     * }
     * ```
     *
     * @return StateFlow that emits current TokenState
     */
    fun observeTokenState(): StateFlow<TokenState>

    /**
     * Starts automatic background token state monitoring.
     *
     * Only active when `enableAutomaticTokenMonitoring = true` in TokenRefreshConfig.
     * When disabled, this method logs a warning and does nothing.
     *
     * **When to call**:
     * - After successful login
     * - After app returns to foreground (on Android, called automatically by PlatformLifecycleObserver)
     *
     * **What it does**:
     * - Launches background coroutine to periodically check token state
     * - Uses adaptive threshold based on token lifetime
     * - Uses smart scheduling for battery efficiency (30s to 15 min intervals)
     * - Triggers automatic refresh when ExpiringSoon/Expired (if enableProactiveRefresh = true)
     * - Updates StateFlow for UI observation via `observeTokenState()`
     *
     * **Idempotent**: Safe to call multiple times (no effect if already running)
     *
     * @see stopTokenMonitoring
     */
    suspend fun startTokenMonitoring()

    /**
     * Stops automatic background token state monitoring.
     *
     * **When to call**:
     * - On explicit logout
     * - When app goes to background (on Android, called automatically by PlatformLifecycleObserver)
     * - Before app termination (to save battery)
     *
     * **What it does**:
     * - Cancels background monitoring coroutine
     * - Stops all periodic token state checks
     * - Frees associated resources
     *
     * **Idempotent**: Safe to call multiple times (no effect if not running)
     *
     * **Note**: Not a suspend function because it only cancels coroutines (no blocking I/O).
     * Can be called from lifecycle callbacks directly.
     *
     * @see startTokenMonitoring
     */
    fun stopTokenMonitoring()

    /**
     * Disposes all SDK resources and stops background operations.
     *
     * **Lifecycle Integration**:
     * - Called automatically by PlatformLifecycleObserver on app termination/background
     * - Can also be called manually for explicit cleanup
     * - Safe to call multiple times (idempotent)
     *
     * **Cleanup Actions**:
     * 1. Stop token monitoring (cancel background coroutine)
     * 2. Cancel monitoring scope (cleanup all background jobs)
     *
     * **Platform-Specific Triggers**:
     * - Android: ProcessLifecycleOwner.onDestroy
     * - iOS: NSNotificationCenter UIApplicationWillTerminateNotification (Phase 2.8.3)
     * - JVM: Runtime.addShutdownHook (Phase 2.8.3)
     * - JS: window.addEventListener("beforeunload") (Phase 2.8.3)
     *
     * **Note**: Not a suspend function because it only cancels coroutines (no blocking I/O).
     * Can be called from lifecycle callbacks directly. After calling dispose(), the
     * TokenManager instance should not be used. Create a new instance if needed.
     */
    fun dispose()
}
