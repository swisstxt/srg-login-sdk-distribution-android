package ch.srg.login.sdk.model

import kotlinx.datetime.Clock

/**
 * Access token with parsed JWT claims.
 *
 * This type provides a type-safe wrapper around the raw JWT token string,
 * exposing parsed claims directly for easy access without manual JWT parsing.
 *
 * All properties are publicly accessible to SDK users.
 *
 * @property value Raw JWT token string for API authentication (use in Authorization header)
 * @property expiresAt Unix timestamp (seconds) when token expires
 * @property expiresIn Seconds until expiration (negative if already expired)
 * @property isExpired Whether the token has expired
 * @property issuer Token issuer from 'iss' claim (typically IDP URL)
 * @property subject Token subject from 'sub' claim (typically user ID)
 * @property issuedAt Unix timestamp when token was issued from 'iat' claim
 *
 * Usage:
 * ```kotlin
 * val result = srgLogin.getAccessToken()
 * when (result) {
 *     is SdkResult.Success -> {
 *         val token = result.data
 *         // Use token in API calls
 *         api.call("Bearer ${token.value}")
 *         // Display expiration
 *         println("Expires: ${token.formatExpiresIn()}")
 *         // Access user ID
 *         println("User: ${token.subject}")
 *     }
 *     is SdkResult.Failure -> { /* handle error */ }
 * }
 * ```
 */
data class
AccessToken(
    val value: String,
    val expiresAt: Long,
    val expiresIn: Long,
    val isExpired: Boolean,
    val issuer: String?,
    val subject: String?,
    val issuedAt: Long?,
) {
    companion object {
        /**
         * Create AccessToken from JWT token string and parsed claims.
         *
         * INTERNAL: This factory method is used internally by the SDK to convert
         * OAuth token responses into type-safe AccessToken instances.
         * SDK users should obtain AccessToken via `srgLogin.getAccessToken()`.
         *
         * @param tokenString Raw JWT token string
         * @param jwtClaims Parsed JWT claims from token validation
         * @return AccessToken with calculated expiration and extracted claims
         */
        internal fun fromJwt(
            tokenString: String,
            jwtClaims: JwtClaims,
        ): AccessToken {
            val now = Clock.System.now().epochSeconds
            val expiresAt = jwtClaims.exp ?: 0L
            val expiresIn = expiresAt - now
            val isExpired = now >= expiresAt

            return AccessToken(
                value = tokenString,
                expiresAt = expiresAt,
                expiresIn = expiresIn,
                isExpired = isExpired,
                issuer = jwtClaims.iss,
                subject = jwtClaims.sub,
                issuedAt = jwtClaims.iat,
            )
        }
    }

    /**
     * Format expiration time as human-readable string.
     *
     * Returns a formatted string indicating how long until expiration,
     * or how long ago the token expired.
     *
     * Examples:
     * - "30s" - Expires in 30 seconds
     * - "5m 30s" - Expires in 5 minutes and 30 seconds
     * - "2h 15m" - Expires in 2 hours and 15 minutes
     * - "Expired 2m ago" - Expired 2 minutes ago
     * - "Expired 1h 30m ago" - Expired 1 hour and 30 minutes ago
     *
     * @return Human-readable expiration time string
     */
    fun formatExpiresIn(): String {
        val seconds = expiresIn
        return when {
            seconds < 0 -> {
                val absSeconds = -seconds
                when {
                    absSeconds < 60 -> {
                        "Expired ${absSeconds}s ago"
                    }

                    absSeconds < 3600 -> {
                        val m = absSeconds / 60
                        val s = absSeconds % 60
                        if (s == 0L) {
                            "Expired ${m}m ago"
                        } else {
                            "Expired ${m}m ${s}s ago"
                        }
                    }

                    else -> {
                        val h = absSeconds / 3600
                        val m = (absSeconds % 3600) / 60
                        if (m == 0L) {
                            "Expired ${h}h ago"
                        } else {
                            "Expired ${h}h ${m}m ago"
                        }
                    }
                }
            }

            seconds < 60 -> {
                "${seconds}s"
            }

            seconds < 3600 -> {
                val m = seconds / 60
                val s = seconds % 60
                if (s == 0L) "${m}m" else "${m}m ${s}s"
            }

            else -> {
                val h = seconds / 3600
                val m = (seconds % 3600) / 60
                if (m == 0L) "${h}h" else "${h}h ${m}m"
            }
        }
    }

    /**
     * Returns the raw token string for string interpolation.
     *
     * This allows using AccessToken directly in contexts expecting a String:
     * ```kotlin
     * api.call("Bearer $accessToken")  // Uses toString() implicitly
     * ```
     *
     * @return Raw JWT token string
     */
    override fun toString(): String = value
}
