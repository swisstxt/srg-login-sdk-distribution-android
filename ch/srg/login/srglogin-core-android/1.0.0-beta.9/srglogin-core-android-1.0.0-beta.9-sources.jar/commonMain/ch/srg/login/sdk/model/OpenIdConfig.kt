package ch.srg.login.sdk.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

/**
 * Represents the OpenID Connect configuration.
 * https://auth0.com/docs/get-started/apis/openid-connect-protocol#openid-connect-discovery
 */
@Serializable
internal data class OpenIdConfig(
    @SerialName("issuer")
    val issuer: String,
    @SerialName("authorization_endpoint")
    val authorizationEndpoint: String,
    @SerialName("token_endpoint")
    val tokenEndpoint: String,
    @SerialName("userinfo_endpoint")
    val userInfoEndpoint: String,
    @SerialName("https://discovery.netid.de/properties/status_endpoint")
    val statusEndpoint: String,
    @SerialName("jwks_uri")
    val jwksUri: String,
    @SerialName("scopes_supported")
    val scopesSupported: List<String>,
    @SerialName("response_types_supported")
    val responseTypesSupported: List<String>,
    @SerialName("response_modes_supported")
    val responseModesSupported: List<String>,
    @SerialName("subject_types_supported")
    val subjectTypesSupported: List<String>,
    @SerialName("id_token_signing_alg_values_supported")
    val idTokenSigningAlgValuesSupported: List<String>,
    @SerialName("token_endpoint_auth_methods_supported")
    val tokenEndpointAuthMethodsSupported: List<String>,
    @SerialName("claims_supported")
    val claimsSupported: List<String>,
    @SerialName("token_endpoint_auth_signing_alg_values_supported")
    val tokenEndpointAuthSigningAlgValuesSupported: List<String>,
    @SerialName("check_session_iframe")
    val checkSessionIframe: String,
    @SerialName("end_session_endpoint")
    val endSessionEndpoint: String,
    @SerialName("social_provider_token_resolver_endpoint")
    val socialProviderTokenResolverEndpoint: String,
    @SerialName("registration_endpoint")
    val registrationEndpoint: String,
    @SerialName("userinfo_signing_alg_values_supported")
    val userInfoSigningAlgValuesSupported: List<String>,
    @SerialName("userinfo_encryption_alg_values_supported")
    val userInfoEncryptionAlgValuesSupported: List<String>,
    @SerialName("userinfo_encryption_enc_values_supported")
    val userInfoEncryptionEncValuesSupported: List<String>,
    @SerialName("id_token_encryption_alg_values_supported")
    val idTokenEncryptionAlgValuesSupported: List<String>,
    @SerialName("id_token_encryption_enc_values_supported")
    val idTokenEncryptionEncValuesSupported: List<String>,
    @SerialName("request_object_signing_alg_values_supported")
    val requestObjectSigningAlgValuesSupported: List<String>,
    @SerialName("request_object_encryption_alg_values_supported")
    val requestObjectEncryptionAlgValuesSupported: List<String>,
    @SerialName("request_object_encryption_enc_values_supported")
    val requestObjectEncryptionEncValuesSupported: List<String>,
)
