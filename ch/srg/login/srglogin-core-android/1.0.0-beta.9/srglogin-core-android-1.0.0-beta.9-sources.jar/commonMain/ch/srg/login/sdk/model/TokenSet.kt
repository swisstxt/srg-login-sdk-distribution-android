package ch.srg.login.sdk.model

/**
 * Complete set of tokens from authentication or refresh.
 *
 * This type represents the full OAuth 2.0/OIDC token response from the authorization server,
 * with the access token parsed into a type-safe [AccessToken] with JWT claims.
 *
 * All properties are publicly accessible to SDK users.
 *
 * @property accessToken Access token with parsed JWT claims
 * @property refreshToken Refresh token for obtaining new access tokens (null if not provided by server)
 * @property idToken OIDC ID token (null if not provided or not using OIDC)
 * @property tokenType Token type, typically "Bearer"
 * @property scope OAuth scopes granted (space-separated string)
 *
 * Usage:
 * ```kotlin
 * val result = srgLogin.refreshToken()
 * when (result) {
 *     is SdkResult.Success -> {
 *         val tokenSet = result.data
 *
 *         // Access the parsed access token
 *         val accessToken = tokenSet.accessToken
 *         println("Token expires: ${accessToken.formatExpiresIn()}")
 *
 *         // Check if refresh token was provided
 *         if (tokenSet.refreshToken != null) {
 *             println("New refresh token received")
 *         }
 *
 *         // Check if ID token was provided (OIDC)
 *         if (tokenSet.idToken != null) {
 *             println("ID token received")
 *         }
 *     }
 *     is SdkResult.Failure -> { /* handle error */ }
 * }
 * ```
 */
data class TokenSet(
    val accessToken: AccessToken,
    val refreshToken: String? = null,
    val idToken: String? = null,
    val tokenType: String = "Bearer",
    val scope: String? = null,
) {
    companion object {
        /**
         * Create TokenSet from TokenResponseDto (internal conversion).
         *
         * INTERNAL: This factory method is used internally by the SDK to convert
         * OAuth token endpoint responses into type-safe TokenSet instances.
         * SDK users should obtain TokenSet via `srgLogin.refreshToken()`.
         *
         * @param dto Internal DTO from OAuth 2.0 token endpoint
         * @param jwtParser Function to parse JWT token and extract claims
         * @return TokenSet with parsed access token
         */
        internal suspend fun fromDto(
            dto: TokenResponseDto,
            jwtParser: suspend (String) -> Result<JwtClaims>,
        ): TokenSet {
            // Parse JWT claims from access token
            val jwtClaims = jwtParser(dto.accessToken).getOrThrow()

            // Create AccessToken with parsed claims
            val accessToken = AccessToken.fromJwt(dto.accessToken, jwtClaims)

            return TokenSet(
                accessToken = accessToken,
                refreshToken = dto.refreshToken,
                idToken = dto.idToken,
                tokenType = dto.tokenType,
                scope = dto.scope,
            )
        }
    }
}
