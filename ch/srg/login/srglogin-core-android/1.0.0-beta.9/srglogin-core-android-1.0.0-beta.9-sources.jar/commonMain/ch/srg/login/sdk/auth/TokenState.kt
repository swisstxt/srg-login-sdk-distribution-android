package ch.srg.login.sdk.auth

import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.model.TokenSet

/**
 * Represents the current state of authentication tokens.
 *
 * This sealed class provides a type-safe way to represent all possible
 * states of the token lifecycle, enabling reactive UI updates and proper
 * error handling.
 *
 * **Usage Example**:
 * ```kotlin
 * srgLogin.observeTokenState().collect { state ->
 *     when (state) {
 *         TokenState.Valid -> showMainScreen()
 *         TokenState.Refreshing -> showLoading()
 *         is TokenState.RefreshFailed -> showLoginScreen()
 *         else -> { /* Handle other states */ }
 *     }
 * }
 * ```
 */
sealed class TokenState {
    /**
     * Tokens are valid and not expiring soon.
     * App can make API calls safely.
     */
    data object Valid : TokenState()

    /**
     * Token is expiring soon (within threshold), refresh recommended.
     * App should proactively refresh but can still use current token.
     */
    data object ExpiringSoon : TokenState()

    /**
     * Currently refreshing token in background.
     * App should queue API calls or use current token if still valid.
     */
    data object Refreshing : TokenState()

    /**
     * Token refresh succeeded with new tokens.
     *
     * @property tokenSet The new token set with fresh tokens and parsed AccessToken
     */
    data class Refreshed(
        val tokenSet: TokenSet,
    ) : TokenState()

    /**
     * Token expired and needs immediate refresh.
     * App should trigger refresh before making API calls.
     */
    data object Expired : TokenState()

    /**
     * Refresh failed, user re-authentication required.
     * This typically happens when refresh token is revoked or expired.
     *
     * @property error The error that caused the refresh failure
     */
    data class RefreshFailed(
        val error: SrgLoginError,
    ) : TokenState()

    /**
     * No tokens available (user not logged in).
     */
    data object NoTokens : TokenState()
}
