package ch.srg.login.sdk.data.api

import ch.srg.login.sdk.model.JwkSet
import ch.srg.login.sdk.model.OpenIdConfig
import ch.srg.login.sdk.model.TokenResponseDto

/**
 * Defines the contract for the SRG authentication API service.
 * This is analogous to a Retrofit interface.
 *
 * INTERNAL: This interface is not part of the public SDK API.
 */
internal interface SrgAuthApiService {
    /**
     * Fetches the OpenID Connect configuration from a given base URL.
     */
    suspend fun getOpenIdConfiguration(baseUrl: String): OpenIdConfig

    /**
     * Exchanges an authorization code for access and refresh tokens.
     *
     * @param tokenEndpoint The URL of the token endpoint.
     * @param code The authorization code received from the redirect.
     * @param redirectUri The original redirect URI.
     * @param clientId The client ID.
     * @param codeVerifier The PKCE code verifier.
     * @return A [TokenResponseDto] containing the tokens.
     */
    suspend fun exchangeCodeForToken(
        tokenEndpoint: String,
        code: String,
        redirectUri: String,
        clientId: String,
        codeVerifier: String,
    ): TokenResponseDto

    /**
     * Fetches the JSON Web Key Set (JWKS) used for JWT signature validation.
     *
     * @param jwksUri The URI of the JWKS endpoint from OpenID configuration
     * @return A [JwkSet] containing the public keys for JWT validation
     */
    suspend fun getJwks(jwksUri: String): JwkSet

    /**
     * Refreshes an access token using a refresh token.
     *
     * Implements OAuth 2.0 token refresh flow (RFC 6749 Section 6).
     * Exchanges a valid refresh token for a new access token and optionally a new refresh token.
     *
     * **Token Rotation**:
     * If the authorization server implements refresh token rotation, the response will contain
     * a new refresh token. The old refresh token should be considered invalid after use.
     *
     * **Security Note**:
     * - Always use the new refresh token from the response if provided
     * - Track token usage metadata to detect potential theft
     * - Implement exponential backoff for network failures
     *
     * @param tokenEndpoint The URL of the token endpoint from OpenID configuration
     * @param refreshToken The refresh token to exchange
     * @param clientId The client ID for this application
     * @return A [TokenResponseDto] containing new access token and optionally new refresh token
     * @throws Exception if the refresh token is invalid, expired, or revoked
     */
    suspend fun refreshAccessToken(
        tokenEndpoint: String,
        refreshToken: String,
        clientId: String,
    ): TokenResponseDto
}
