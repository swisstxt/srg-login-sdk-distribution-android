package ch.srg.login.sdk.auth

import ch.srg.login.sdk.SrgLoginConfig
import ch.srg.login.sdk.TokenRefreshConfig
import ch.srg.login.sdk.crypto.CryptoService
import ch.srg.login.sdk.data.OpenIdConfigRepository
import ch.srg.login.sdk.data.api.SrgAuthApiService
import ch.srg.login.sdk.errors.SrgLoginError
import ch.srg.login.sdk.events.EventEmitter
import ch.srg.login.sdk.events.SdkLifecycleEvent
import ch.srg.login.sdk.events.StorageOperation
import ch.srg.login.sdk.internal.mapPlatformException
import ch.srg.login.sdk.logging.ErrorHandler
import ch.srg.login.sdk.logging.ErrorHandlerRegistry
import ch.srg.login.sdk.logging.LogCategory
import ch.srg.login.sdk.logging.SdkLogger
import ch.srg.login.sdk.model.AccessToken
import ch.srg.login.sdk.model.RefreshTokenMetadata
import ch.srg.login.sdk.model.TokenResponseDto
import ch.srg.login.sdk.model.TokenSet
import ch.srg.login.sdk.result.SdkResult
import ch.srg.login.sdk.token.TokenStorage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.datetime.Clock
import kotlin.math.min
import kotlin.math.pow

/**
 * Default implementation of [TokenManager].
 *
 * Orchestrates OAuth 2.0 token lifecycle management including:
 * - Token access with automatic refresh (based on enableProactiveRefresh config)
 * - Manual token refresh operations
 * - Authentication status checks
 * - Token state monitoring
 * - Automatic retry with exponential backoff for transient errors
 * - Terminal error handling for invalid_grant (clears tokens, requires re-auth)
 * - Thread-safe concurrent request handling with mutex
 * - Comprehensive metadata tracking for debugging/analytics
 * - Proper error classification using SrgLoginError
 *
 * **Retry Strategy**:
 * - Network errors (connection failures, timeouts): Retry with exponential backoff
 * - Server errors (5xx): Retry with exponential backoff
 * - invalid_grant error: Terminal, clear all tokens, require re-authentication
 * - Storage errors: Terminal, clear tokens
 *
 * **Thread Safety**:
 * Uses a mutex to ensure only one refresh operation happens at a time.
 * Concurrent calls will wait for the active refresh to complete.
 *
 * @property config SDK configuration containing client ID and environment settings
 * @property openIdConfigRepository Repository for fetching OpenID Connect configuration (token endpoint, etc.)
 * @property apiService Service for making token endpoint requests
 * @property tokenStorage Secure storage for tokens and metadata
 * @property jwtValidationService Service for parsing and validating JWT tokens
 * @property cryptoService Service for cryptographic operations (SHA-256 hashing)
 * @property eventEmitter Event emitter for SDK lifecycle events (event-driven communication)
 */
internal class TokenManagerImpl(
    private val config: SrgLoginConfig,
    private val openIdConfigRepository: OpenIdConfigRepository,
    private val apiService: SrgAuthApiService,
    private val tokenStorage: TokenStorage,
    private val jwtValidationService: JwtValidationService,
    private val cryptoService: CryptoService,
    private val eventEmitter: EventEmitter,
) : TokenManager {
    companion object {
        private const val MONITORING_TAG = "SDK-TokenMonitoring"
    }

    // Convenience accessor for refresh configuration
    private val refreshConfig: TokenRefreshConfig
        get() = config.tokenRefreshConfig

    /**
     * Mutex to ensure only one refresh operation at a time.
     * Prevents race conditions when multiple requests attempt to refresh simultaneously.
     */
    private val refreshMutex = Mutex()

    /**
     * Mutable state flow for token state monitoring.
     * Initialized lazily with actual storage state.
     */
    @Suppress("ktlint:standard:backing-property-naming")
    private val _tokenStateFlow = MutableStateFlow<TokenState>(TokenState.NoTokens)

    /**
     * Coroutine scope for background token monitoring.
     * Uses Dispatchers.Default for background work and SupervisorJob to prevent
     * child coroutine failures from cancelling the entire scope.
     */
    private val monitoringScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    /**
     * Background monitoring job.
     * Null when monitoring is not active.
     */
    private var monitoringJob: Job? = null

    init {
        // Log TokenManager instantiation to detect multiple instances
        SdkLogger.d(LogCategory.TOKEN_MONITORING) { "TokenManagerImpl instance created (hashCode=${this.hashCode()})" }
        SdkLogger.i(LogCategory.TOKEN_MONITORING) { "Token monitoring will start via AppForegrounded event (no automatic start in init{})" }

        // Listen to SDK lifecycle events for automatic token management
        monitoringScope.launch {
            eventEmitter.events.collect { event ->
                when (event) {
                    is SdkLifecycleEvent.LoginSuccess -> {
                        // Only start monitoring if automatic monitoring is enabled
                        if (refreshConfig.enableAutomaticTokenMonitoring) {
                            SdkLogger.i(LogCategory.TOKEN_MONITORING) { "LoginSuccess received, starting token monitoring" }
                            startTokenMonitoring()
                        }
                    }

                    is SdkLifecycleEvent.LogoutSuccess -> {
                        // Always stop monitoring on logout (defensive, no tokens left)
                        SdkLogger.i(LogCategory.TOKEN_MONITORING) { "LogoutSuccess received, stopping token monitoring" }
                        stopTokenMonitoring()
                    }

                    is SdkLifecycleEvent.AppForegrounded -> {
                        // Only restart monitoring if automatic monitoring is enabled and tokens exist
                        if (refreshConfig.enableAutomaticTokenMonitoring) {
                            SdkLogger.d(LogCategory.TOKEN_MONITORING) { "AppForegrounded received, checking for tokens" }
                            val tokens = tokenStorage.getTokens()
                            if (tokens != null) {
                                SdkLogger.i(LogCategory.TOKEN_MONITORING) { "Tokens found, restarting token monitoring" }
                                startTokenMonitoring()
                            }
                        }
                    }

                    is SdkLifecycleEvent.AppBackgrounded -> {
                        // Only stop monitoring if automatic monitoring is enabled (consistency with start)
                        if (refreshConfig.enableAutomaticTokenMonitoring) {
                            SdkLogger.i(
                                LogCategory.TOKEN_MONITORING,
                            ) { "AppBackgrounded received, stopping token monitoring to save battery" }
                            stopTokenMonitoring()
                        }
                    }

                    is SdkLifecycleEvent.TokenRefreshSuccess -> {
                        // Restart monitoring so the next cycle is immediately scheduled against
                        // the new token's expiry, rather than sleeping out the interval that was
                        // calculated for the old (expired/expiring) token.
                        if (refreshConfig.enableAutomaticTokenMonitoring) {
                            SdkLogger.i(LogCategory.TOKEN_MONITORING) {
                                "TokenRefreshSuccess received, restarting monitoring for fresh token evaluation"
                            }
                            startTokenMonitoring()
                        }
                    }

                    is SdkLifecycleEvent.SessionInvalidated -> {
                        // Tokens have been cleared. Stop monitoring — there is nothing left to
                        // monitor and the user must re-authenticate.
                        SdkLogger.i(LogCategory.TOKEN_MONITORING) {
                            "SessionInvalidated received, stopping token monitoring"
                        }
                        stopTokenMonitoring()
                    }

                    is SdkLifecycleEvent.TokenRefreshFailure -> {
                        // Restart monitoring immediately only for terminal invalid_grant failures.
                        // The SessionInvalidated handler above already stopped monitoring; this
                        // restart triggers one final cycle that reads empty storage and emits
                        // NoTokens right away instead of waiting out the Expired interval sleep.
                        //
                        // For transient errors (NetworkError, HttpError) do NOT restart — the
                        // Expired-state sleep serves as the outer cooldown between macro retries
                        // and restarting here would create an infinite retry loop.
                        if (event.error is SrgLoginError.InvalidGrant && refreshConfig.enableAutomaticTokenMonitoring) {
                            SdkLogger.i(LogCategory.TOKEN_MONITORING) {
                                "TokenRefreshFailure(InvalidGrant) received, restarting monitoring to emit NoTokens"
                            }
                            startTokenMonitoring()
                        }
                    }

                    else -> {
                        // Ignore other events (not relevant for TokenManager)
                    }
                }
            }
        }
    }

    override suspend fun refreshTokens(): SdkResult<TokenSet> =
        refreshMutex.withLock {
            try {
                // Emit TokenRefreshStarted event
                val timestamp = Clock.System.now().toEpochMilliseconds()
                eventEmitter.emit(SdkLifecycleEvent.TokenRefreshStarted(timestamp))

                // Step 0: Fetch OpenID configuration for token endpoint
                val openIdConfigResult = openIdConfigRepository.getConfiguration()
                if (openIdConfigResult is SdkResult.Failure) {
                    return openIdConfigResult
                }
                val openIdConfig = (openIdConfigResult as SdkResult.Success).data

                // Step 1: Retrieve current tokens and metadata
                val currentTokens =
                    tokenStorage.getTokens()
                        ?: return SdkResult.Failure(SrgLoginError.TokenExpired)

                val refreshToken =
                    currentTokens.refreshToken
                        ?: return SdkResult.Failure(SrgLoginError.TokenExpired)

                // Step 2: Get current metadata (may be null for first refresh in session)
                val currentMetadata = tokenStorage.getRefreshTokenMetadata()

                // Step 3: Hash the current refresh token for rotation tracking
                val currentRefreshTokenHash = hashRefreshToken(refreshToken)

                // Step 4: Attempt refresh with retry logic
                val refreshResult =
                    attemptRefreshWithRetry(
                        tokenEndpoint = openIdConfig.tokenEndpoint,
                        clientId = config.clientId,
                        refreshToken = refreshToken,
                        currentMetadata = currentMetadata,
                    )

                // Handle refresh failure
                if (refreshResult is SdkResult.Failure) {
                    val error = refreshResult.error

                    // Report unexpected errors to error tracking.
                    // InvalidGrant is intentionally excluded — a revoked or expired refresh token
                    // is an expected operational condition, not a bug. Reporting it as FATAL would
                    // generate noise in Sentry and obscure real errors.
                    if (error !is SrgLoginError.InvalidGrant) {
                        ErrorHandlerRegistry.captureException(
                            throwable =
                                when (error) {
                                    is SrgLoginError.NetworkError -> {
                                        error.cause ?: Exception(error.details ?: "Network error")
                                    }

                                    is SrgLoginError.HttpError -> {
                                        Exception("HTTP ${error.code}: ${error.message}")
                                    }

                                    else -> {
                                        Exception(error.toString())
                                    }
                                },
                            context =
                                mapOf(
                                    "operation" to "token_refresh",
                                    "error_type" to error::class.simpleName,
                                ),
                            level = ErrorHandler.ErrorLevel.ERROR,
                        )
                    }

                    // If it's invalid_grant, clear all tokens (terminal error) and signal
                    // session end. SessionInvalidated is emitted before TokenRefreshFailure
                    // so listeners can stop monitoring before the failure is reported.
                    if (error is SrgLoginError.InvalidGrant) {
                        clearAllTokensAndMetadata()
                        val invalidatedTimestamp = Clock.System.now().toEpochMilliseconds()
                        eventEmitter.emit(SdkLifecycleEvent.SessionInvalidated(error, invalidatedTimestamp))
                    }

                    // Emit TokenRefreshFailure event
                    val failureTimestamp = Clock.System.now().toEpochMilliseconds()
                    eventEmitter.emit(SdkLifecycleEvent.TokenRefreshFailure(error, failureTimestamp))

                    return refreshResult
                }

                val newTokens = (refreshResult as SdkResult.Success).data

                // Step 5: Update metadata after successful refresh
                val now = Clock.System.now()
                val nowSeconds = now.epochSeconds
                val nowMillis = now.toEpochMilliseconds()

                val updatedMetadata =
                    if (currentMetadata != null) {
                        // Update existing metadata
                        currentMetadata.withSuccessfulRefresh(
                            newLastUsedAt = nowSeconds,
                            newLastRefreshAt = nowMillis,
                            newPreviousTokenHash = currentRefreshTokenHash,
                        )
                    } else {
                        // Create new metadata (first refresh in session or metadata was cleared)
                        RefreshTokenMetadata(
                            sessionCreatedAt = nowMillis,
                            issuedAt = nowSeconds,
                            lastUsedAt = nowSeconds,
                            lastRefreshAt = nowMillis,
                            // First refresh
                            sessionRefreshCount = 1,
                            lastRefreshError = null,
                            previousTokenHash = currentRefreshTokenHash,
                        )
                    }

                // Step 6: Persist new tokens and updated metadata
                SdkLogger.i(LogCategory.TOKEN_MONITORING) {
                    "Attempting to save refreshed tokens " +
                        "(accessToken length: ${newTokens.accessToken.length}, " +
                        "refreshToken present: ${newTokens.refreshToken != null}, " +
                        "expiresIn: ${newTokens.expiresIn}s)"
                }

                val saveTokensResult = tokenStorage.saveTokens(newTokens)
                if (saveTokensResult.isFailure) {
                    // Emit StorageError event
                    val storageErrorTimestamp = Clock.System.now().toEpochMilliseconds()
                    val storageException = saveTokensResult.exceptionOrNull() ?: Exception("Failed to save refreshed tokens")
                    val storageError =
                        SrgLoginError.TokenStorageError(
                            message = "Failed to save refreshed tokens",
                            cause = storageException,
                        )
                    SdkLogger.e(LogCategory.TOKEN_MONITORING, throwable = storageException) { "Failed to save tokens" }

                    // Report to error tracking
                    ErrorHandlerRegistry.captureException(
                        throwable = storageException,
                        context =
                            mapOf(
                                "operation" to "save_refreshed_tokens",
                                "critical" to true,
                                "action" to "clearing_all_tokens",
                                "error_message" to "Token save failed - tokens will be cleared",
                            ),
                        level = ErrorHandler.ErrorLevel.FATAL,
                    )

                    eventEmitter.tryEmit(
                        SdkLifecycleEvent.StorageError(
                            operation = StorageOperation.SAVE,
                            error = storageError,
                            timestamp = storageErrorTimestamp,
                        ),
                    )

                    // Token save failed - clear everything as we're in inconsistent state
                    clearAllTokensAndMetadata()
                    return SdkResult.Failure(storageError)
                }

                SdkLogger.i(LogCategory.TOKEN_MONITORING) { "Tokens successfully saved to storage" }

                // Convert TokenResponseDto to TokenSet with parsed AccessToken
                val tokenSet =
                    TokenSet.fromDto(newTokens) { token ->
                        jwtValidationService.parseJwt(token).map { it.claims }
                    }

                // Step 7: Emit TokenRefreshSuccess event first (refresh succeeded with new tokens)
                val successTimestamp = Clock.System.now().toEpochMilliseconds()
                eventEmitter.emit(SdkLifecycleEvent.TokenRefreshSuccess(tokenSet, successTimestamp))

                // Emit TokensSaved event after (tokens persisted to storage)
                val tokensSavedTimestamp = Clock.System.now().toEpochMilliseconds()
                eventEmitter.tryEmit(
                    SdkLifecycleEvent.TokensSaved(
                        hasRefreshToken = newTokens.refreshToken != null,
                        timestamp = tokensSavedTimestamp,
                    ),
                )

                val saveMetadataResult = tokenStorage.saveRefreshTokenMetadata(updatedMetadata)
                if (saveMetadataResult.isFailure) {
                    // Metadata save failed but tokens saved - not critical, just log
                    // Metadata is for debugging/analytics, not critical for auth flow
                    SdkLogger.w(LogCategory.TOKEN_MONITORING, throwable = saveMetadataResult.exceptionOrNull()) {
                        "Failed to save refresh token metadata"
                    }
                }

                SdkResult.Success(tokenSet)
            } catch (e: Exception) {
                // Unexpected exception - wrap in UnknownError
                val error =
                    SrgLoginError.UnknownError(
                        cause = e,
                        context = "Unexpected error during token refresh",
                    )

                // Emit TokenRefreshFailure event
                val failureTimestamp = Clock.System.now().toEpochMilliseconds()
                eventEmitter.emit(SdkLifecycleEvent.TokenRefreshFailure(error, failureTimestamp))

                SdkResult.Failure(error)
            }
        }

    /**
     * Attempts to refresh tokens with retry logic and exponential backoff.
     *
     * **Retry Strategy**:
     * - Network errors: Retry up to maxRetryAttempts times with exponential backoff
     * - Server errors (5xx): Retry up to maxRetryAttempts times
     * - invalid_grant: No retry (terminal error)
     * - Other errors: No retry
     *
     * @param tokenEndpoint Token endpoint URL from OpenID configuration
     * @param clientId OAuth 2.0 client identifier
     * @param refreshToken The refresh token to use
     * @param currentMetadata Current metadata (for error tracking)
     * @return SdkResult with new tokens or error
     */
    private suspend fun attemptRefreshWithRetry(
        tokenEndpoint: String,
        clientId: String,
        refreshToken: String,
        currentMetadata: RefreshTokenMetadata?,
    ): SdkResult<TokenResponseDto> {
        var lastError: SrgLoginError? = null
        var attemptNumber = 0

        while (attemptNumber <= refreshConfig.maxRetryAttempts) {
            try {
                // Attempt the refresh
                val newTokens =
                    apiService.refreshAccessToken(
                        tokenEndpoint = tokenEndpoint,
                        refreshToken = refreshToken,
                        clientId = clientId,
                    )

                // Success!
                return SdkResult.Success(newTokens)
            } catch (e: Exception) {
                // Classify the error
                val error = classifyRefreshError(e)
                lastError = error

                // Report to error tracking
                ErrorHandlerRegistry.captureException(
                    throwable = e,
                    context =
                        mapOf(
                            "operation" to "token_refresh_attempt",
                            "attempt_number" to (attemptNumber + 1),
                            "max_attempts" to refreshConfig.maxRetryAttempts,
                            "error_type" to error::class.simpleName,
                            "is_retryable" to isRetryableError(error),
                        ),
                    level = ErrorHandler.ErrorLevel.ERROR,
                )

                // Update metadata with error (for debugging)
                currentMetadata?.let { metadata ->
                    val updatedMetadata =
                        metadata.withFailedRefresh(
                            errorMessage =
                                when (error) {
                                    is SrgLoginError.InvalidGrant -> {
                                        "invalid_grant: ${error.errorDescription ?: "Refresh token invalid/expired/revoked"}"
                                    }

                                    is SrgLoginError.NetworkError -> {
                                        "Network error: ${error.details ?: error.cause?.message ?: "Unknown"}"
                                    }

                                    is SrgLoginError.HttpError -> {
                                        "Server error: HTTP ${error.code} - ${error.message ?: "Unknown"}"
                                    }

                                    else -> {
                                        error.toString()
                                    }
                                },
                        )
                    tokenStorage.saveRefreshTokenMetadata(updatedMetadata)
                }

                // Check if error is retryable
                if (!isRetryableError(error) || attemptNumber >= refreshConfig.maxRetryAttempts) {
                    return SdkResult.Failure(error)
                }

                // Calculate backoff delay
                val delayMs = calculateBackoffDelay(attemptNumber)

                // Log retry attempt
                SdkLogger.e(LogCategory.TOKEN_MONITORING) {
                    "Token refresh attempt ${attemptNumber + 1} failed, retrying in ${delayMs}ms: $error"
                }

                // Wait before retry
                delay(delayMs)

                attemptNumber++
            }
        }

        // Should never reach here, but just in case
        return SdkResult.Failure(
            lastError ?: SrgLoginError.UnknownError(
                cause = Exception("Token refresh failed after all retries"),
                context = "Exhausted all retry attempts",
            ),
        )
    }

    /**
     * Classifies an exception from token refresh into appropriate SrgLoginError.
     *
     * Uses Ktor exception types and OAuth error response parsing for accurate classification:
     * - [ClientRequestException] (4xx) → Parsed for OAuth errors like invalid_grant
     * - [ServerResponseException] (5xx) → Mapped to retryable HTTP errors
     * - Platform-specific exceptions → Mapped using [mapPlatformException]
     * - Generic exceptions with message patterns → Fallback string matching (for testing compatibility)
     *
     * @param exception The exception that occurred
     * @return Classified SrgLoginError
     */
    private suspend fun classifyRefreshError(exception: Exception): SrgLoginError {
        // First, try platform-specific exception mapping (network errors, timeouts, etc.)
        mapPlatformException(exception)?.let { return it }

        // Then, handle Ktor HTTP exceptions
        return when (exception) {
            // 4xx client errors - may contain OAuth errors like invalid_grant
            is io.ktor.client.plugins.ClientRequestException -> {
                OAuthErrorMapper.mapClientRequestException(exception)
            }

            // 5xx server errors - retryable
            is io.ktor.client.plugins.ServerResponseException -> {
                OAuthErrorMapper.mapServerResponseException(exception)
            }

            // Fallback: Check message for common error patterns (for testing and legacy compatibility)
            else -> {
                val errorMessage = exception.message ?: ""

                when {
                    // Check for invalid_grant (OAuth 2.0 error)
                    errorMessage.contains("invalid_grant", ignoreCase = true) -> {
                        SrgLoginError.InvalidGrant(
                            errorDescription = errorMessage,
                            errorCode = "invalid_grant",
                        )
                    }

                    // Network errors
                    errorMessage.contains("network", ignoreCase = true) ||
                        errorMessage.contains("connection", ignoreCase = true) ||
                        errorMessage.contains("timeout", ignoreCase = true) ||
                        errorMessage.contains("unreachable", ignoreCase = true) -> {
                        SrgLoginError.NetworkError(
                            details = errorMessage,
                            cause = exception,
                        )
                    }

                    // Fallback to unknown error
                    else -> {
                        SrgLoginError.UnknownError(
                            cause = exception,
                            context = "Token refresh failed with unexpected exception",
                        )
                    }
                }
            }
        }
    }

    /**
     * Determines if an error is retryable.
     *
     * **Retryable errors**:
     * - NetworkError
     * - HttpError with 5xx status code
     *
     * **Non-retryable (terminal) errors**:
     * - InvalidGrant
     * - TokenStorageError
     * - HttpError with 4xx status code
     * - Other errors
     *
     * @param error The error to check
     * @return true if error is retryable, false otherwise
     */
    private fun isRetryableError(error: SrgLoginError): Boolean =
        when (error) {
            is SrgLoginError.NetworkError -> true
            is SrgLoginError.HttpError -> error.code in 500..599
            is SrgLoginError.InvalidGrant -> false
            is SrgLoginError.TokenStorageError -> false
            else -> false
        }

    /**
     * Calculates the backoff delay for retry attempt.
     *
     * Uses exponential backoff: delay = min(initialDelay * (2^attempt), maxDelay)
     *
     * @param attemptNumber The retry attempt number (0-indexed)
     * @return Delay in milliseconds
     */
    private fun calculateBackoffDelay(attemptNumber: Int): Long {
        val exponentialDelay =
            refreshConfig.initialRetryDelayMs *
                (2.0.pow(attemptNumber)).toLong()
        return min(exponentialDelay, refreshConfig.maxRetryDelayMs)
    }

    /**
     * Clears all tokens and metadata from storage.
     *
     * Called when terminal errors occur (invalid_grant, storage errors).
     * This ensures clean state for re-authentication.
     */
    private suspend fun clearAllTokensAndMetadata() {
        tokenStorage.clearTokens()
        tokenStorage.clearRefreshTokenMetadata()
    }

    /**
     * Evaluates the current state of tokens for refresh decision-making.
     *
     * This method determines whether tokens are valid, expired, or expiring soon
     * based on JWT expiration claims and refresh configuration.
     *
     * @param tokenResponse The token response to evaluate, or null if no tokens exist
     * @param refreshConfig The refresh configuration with thresholds
     * @return The current TokenState
     */
    private suspend fun evaluateTokenState(
        tokenResponse: TokenResponseDto?,
        refreshConfig: TokenRefreshConfig,
    ): TokenState {
        // No tokens available
        if (tokenResponse == null) {
            return TokenState.NoTokens
        }

        // Check if access token is expired
        if (jwtValidationService.isAccessTokenExpired(tokenResponse.accessToken)) {
            return TokenState.Expired
        }

        // Check if access token is expiring soon.
        // Use the adaptive threshold so that short-lived IDP tokens (e.g. 60s) are not
        // permanently stuck in ExpiringSoon when the SDK default threshold (300s) exceeds
        // the token lifetime. calculateAdaptiveThreshold handles that fallback.
        val threshold =
            calculateAdaptiveThreshold(
                tokenLifetime = tokenResponse.expiresIn,
                configuredThreshold = refreshConfig.refreshThresholdSeconds,
            )
        if (jwtValidationService.isAccessTokenExpiringSoon(tokenResponse.accessToken, threshold)) {
            return TokenState.ExpiringSoon
        }

        // Token is valid and not expiring soon
        return TokenState.Valid
    }

    override suspend fun getCurrentTokenState(): TokenState {
        val tokens = tokenStorage.getTokens()
        return evaluateTokenState(tokens, refreshConfig)
    }

    override suspend fun hasRefreshToken(): Boolean {
        val tokens = tokenStorage.getTokens()
        return tokens?.refreshToken != null
    }

    override suspend fun getAccessToken(): SdkResult<AccessToken> {
        // Step 1: Get current tokens
        val tokens =
            tokenStorage.getTokens()
                ?: return SdkResult.Failure(SrgLoginError.NotAuthenticated)

        val accessTokenString = tokens.accessToken

        // Step 2: Check token state
        val tokenState = evaluateTokenState(tokens, refreshConfig)

        // Step 3: Handle based on state and configuration
        return when (tokenState) {
            TokenState.Valid -> {
                // Token is valid, parse JWT and return AccessToken
                parseAndReturnAccessToken(accessTokenString)
            }

            TokenState.ExpiringSoon -> {
                // Token is expiring soon but still valid
                // Parse JWT and return current token (caller can optionally trigger background refresh)
                parseAndReturnAccessToken(accessTokenString)
            }

            TokenState.Expired -> {
                // Token is expired
                if (refreshConfig.enableProactiveRefresh) {
                    // Automatic refresh enabled - try to refresh
                    val refreshResult = refreshTokens()
                    if (refreshResult is SdkResult.Success) {
                        // Refresh successful, return new access token from TokenSet
                        SdkResult.Success(refreshResult.data.accessToken)
                    } else {
                        // Refresh failed, return the error
                        refreshResult as SdkResult.Failure
                    }
                } else {
                    // Automatic refresh disabled - return TokenExpired error
                    SdkResult.Failure(SrgLoginError.TokenExpired)
                }
            }

            TokenState.Refreshing -> {
                // Token refresh is in progress (from another caller)
                // Parse JWT and return current token for now (may be expired, but caller requested it)
                parseAndReturnAccessToken(accessTokenString)
            }

            is TokenState.Refreshed -> {
                // Token was just refreshed - AccessToken is already parsed in TokenSet
                SdkResult.Success(tokenState.tokenSet.accessToken)
            }

            is TokenState.RefreshFailed -> {
                // Token refresh failed
                // Return the error from the failed refresh
                SdkResult.Failure(tokenState.error)
            }

            TokenState.NoTokens -> {
                // No tokens available (shouldn't happen as we checked above, but handle gracefully)
                SdkResult.Failure(SrgLoginError.NotAuthenticated)
            }
        }
    }

    /**
     * Helper function to parse JWT and return AccessToken.
     *
     * @param tokenString Raw JWT token string
     * @return SdkResult with AccessToken on success, or error on parsing failure
     */
    private suspend fun parseAndReturnAccessToken(tokenString: String): SdkResult<AccessToken> =
        try {
            val parseResult = jwtValidationService.parseJwt(tokenString)
            if (parseResult.isSuccess) {
                val parsedJwt = parseResult.getOrThrow()
                val accessToken = AccessToken.fromJwt(tokenString, parsedJwt.claims)
                SdkResult.Success(accessToken)
            } else {
                // JWT parsing failed
                val error =
                    SrgLoginError.UnknownError(
                        cause = parseResult.exceptionOrNull() ?: Exception("Failed to parse JWT"),
                        context = "Failed to parse access token JWT",
                    )

                ErrorHandlerRegistry.captureException(
                    throwable = parseResult.exceptionOrNull() ?: Exception("JWT parsing failed"),
                    context =
                        mapOf(
                            "operation" to "parse_access_token",
                            "stage" to "jwt_parsing",
                        ),
                    level = ErrorHandler.ErrorLevel.ERROR,
                )

                SdkResult.Failure(error)
            }
        } catch (e: Exception) {
            val error =
                SrgLoginError.UnknownError(
                    cause = e,
                    context = "Error parsing access token JWT",
                )

            ErrorHandlerRegistry.captureException(
                throwable = e,
                context =
                    mapOf(
                        "operation" to "parse_access_token",
                        "exception_type" to e::class.simpleName,
                    ),
                level = ErrorHandler.ErrorLevel.ERROR,
            )

            SdkResult.Failure(error)
        }

    override suspend fun isAuthenticated(): Boolean {
        SdkLogger.d(LogCategory.TOKEN_MONITORING) { "Checking authentication status" }

        // If the last refresh failed with invalid_grant, the session is definitively over.
        // clearAllTokensAndMetadata() is called before SessionInvalidated is emitted, so
        // storage is already empty by the time StateFlow reaches RefreshFailed(InvalidGrant).
        // This guard closes any residual inconsistency window and makes isAuthenticated()
        // consistent with the observable StateFlow value for this terminal error type.
        //
        // Note: RefreshFailed(NetworkError) is intentionally excluded — tokens are NOT
        // cleared for transient failures, so isAuthenticated() should still return true
        // and let the storage check below provide the authoritative answer.
        val currentStateFlowValue = _tokenStateFlow.value
        val isInvalidGrantFailure =
            currentStateFlowValue is TokenState.RefreshFailed &&
                currentStateFlowValue.error is SrgLoginError.InvalidGrant

        val tokens = tokenStorage.getTokens()

        // User is authenticated if they have EITHER:
        // 1. A valid (non-expired) access token, OR
        // 2. A refresh token (can obtain new access token when needed)
        //
        // This handles multiple scenarios:
        // - Access token valid + no refresh token → authenticated (can make API calls now)
        // - Access token expired + refresh token → authenticated (can refresh to get new token)
        // - Access token valid + refresh token → authenticated (optimal case)
        // - No valid access token + no refresh token → NOT authenticated
        val hasAccessToken = tokens?.accessToken?.isNotEmpty() ?: false
        val accessTokenExpired = tokens?.let { jwtValidationService.isAccessTokenExpired(it.accessToken) } ?: true
        val hasValidAccessToken = hasAccessToken && !accessTokenExpired
        val hasRefreshToken = tokens?.refreshToken != null

        SdkLogger.d(LogCategory.TOKEN_MONITORING) {
            "Access token present: $hasAccessToken, expired: $accessTokenExpired, " +
                "valid: $hasValidAccessToken, has refresh: $hasRefreshToken, " +
                "invalid_grant failure: $isInvalidGrantFailure"
        }

        val isAuthenticated = !isInvalidGrantFailure && tokens != null && (hasValidAccessToken || hasRefreshToken)
        SdkLogger.i(LogCategory.TOKEN_MONITORING) { "Authentication check result: $isAuthenticated" }

        return isAuthenticated
    }

    override fun observeTokenState(): StateFlow<TokenState> {
        // Return read-only StateFlow
        // Note: For now, the state is not automatically updated
        // Future enhancement: Add background monitoring with monitoringIntervalSeconds
        return _tokenStateFlow.asStateFlow()
    }

    override suspend fun startTokenMonitoring() {
        // Check if automatic monitoring is enabled
        if (!refreshConfig.enableAutomaticTokenMonitoring) {
            SdkLogger.w(LogCategory.TOKEN_MONITORING) { "Automatic token monitoring is disabled in config" }
            return
        }

        // Cancel any existing monitoring job so the new cycle begins with an immediate
        // updateTokenState() call. This guarantees that any caller — LoginSuccess,
        // AppForegrounded, TokenRefreshSuccess, etc. — always triggers a fresh evaluation
        // rather than waiting out the remainder of a previously-scheduled sleep interval.
        if (monitoringJob?.isActive == true) {
            SdkLogger.d(LogCategory.TOKEN_MONITORING) { "Restarting token monitoring for immediate re-evaluation" }
            monitoringJob?.cancel()
            monitoringJob = null
        }

        SdkLogger.i(LogCategory.TOKEN_MONITORING) {
            "Launching automatic token monitoring " +
                "(enableProactiveRefresh: ${refreshConfig.enableProactiveRefresh}, " +
                "refreshThresholdSeconds: ${refreshConfig.refreshThresholdSeconds}s, " +
                "maxRetryAttempts: ${refreshConfig.maxRetryAttempts})"
        }

        // Launch monitoring coroutine in background scope
        monitoringJob =
            monitoringScope.launch {
                var cycleCount = 0
                while (isActive) {
                    try {
                        cycleCount++
                        SdkLogger.d(LogCategory.TOKEN_MONITORING) { "Monitoring cycle #$cycleCount - Checking token state" }

                        // Update token state and get next check interval
                        val nextIntervalSeconds = updateTokenState()

                        SdkLogger.i(LogCategory.TOKEN_MONITORING) {
                            "Next check scheduled in ${nextIntervalSeconds}s (${nextIntervalSeconds / 60}m)"
                        }

                        // Wait for calculated interval (in milliseconds)
                        delay(nextIntervalSeconds * 1000L)
                    } catch (e: CancellationException) {
                        // Monitoring job was intentionally cancelled (e.g. startTokenMonitoring()
                        // restart). Rethrow so the coroutine exits cleanly instead of logging
                        // a spurious "Monitoring error".
                        throw e
                    } catch (e: Exception) {
                        // Log error but continue monitoring
                        SdkLogger.w(LogCategory.TOKEN_MONITORING, throwable = e) { "Monitoring error, retrying in 60s" }

                        // Report to error tracking
                        ErrorHandlerRegistry.captureException(
                            throwable = e,
                            context =
                                mapOf(
                                    "operation" to "token_monitoring",
                                    "cycle" to cycleCount,
                                    "recovery_action" to "retry_after_60s",
                                ),
                            level = ErrorHandler.ErrorLevel.WARNING,
                        )

                        // Wait default interval before retrying
                        delay(60_000L) // 60 seconds
                    }
                }
            }
    }

    override fun stopTokenMonitoring() {
        SdkLogger.i(LogCategory.TOKEN_MONITORING) { "Stopping automatic token monitoring" }

        // Cancel monitoring job if active
        monitoringJob?.cancel()
        monitoringJob = null
    }

    /**
     * Updates the token state in StateFlow and emits TokenStateChanged event.
     *
     * @param newState The new token state
     */
    private suspend fun updateTokenStateAndEmitEvent(newState: TokenState) {
        _tokenStateFlow.value = newState
        val timestamp = Clock.System.now().toEpochMilliseconds()
        eventEmitter.emit(SdkLifecycleEvent.TokenStateChanged(newState, timestamp))
    }

    /**
     * Updates the token state and triggers refresh if needed.
     *
     * This is the core monitoring logic that:
     * 1. Reads current tokens from storage
     * 2. Calculates adaptive threshold based on token lifetime
     * 3. Determines current token state
     * 4. Triggers proactive refresh for ExpiringSoon/Expired states
     * 5. Updates StateFlow for UI observation
     * 6. Returns next check interval for smart scheduling
     *
     * **Adaptive Threshold**:
     * - Short tokens (< 5 min): Use 50% of lifetime (min 10s)
     * - Long tokens (≥ 5 min): Use configured threshold (capped at 25% of lifetime)
     *
     * **Smart Scheduling**:
     * - Valid: Check halfway to threshold (30s - 15min)
     * - ExpiringSoon: Check every 30s
     * - Expired/NoTokens: Check every 5min
     * - Refreshing: Check every 10s
     *
     * @return Next check interval in seconds
     */
    private suspend fun updateTokenState(): Long {
        // Step 1: Read current tokens
        val tokens = tokenStorage.getTokens()

        if (tokens == null) {
            // No tokens available
            updateTokenStateAndEmitEvent(TokenState.NoTokens)
            return 300L // Check again in 5 minutes
        }

        // Step 2: Calculate token lifetime and adaptive threshold
        val tokenLifetime = tokens.expiresIn

        val adaptiveThreshold =
            calculateAdaptiveThreshold(
                tokenLifetime = tokenLifetime,
                configuredThreshold = refreshConfig.refreshThresholdSeconds,
            )

        // Step 3: Determine current token state
        val currentState = evaluateTokenState(tokens, refreshConfig)

        // Step 4: Calculate time until expiration (for smart scheduling)
        // Use JWT exp claim as authoritative source — TokenResponseDto.expiresAt is a
        // computed getter (now + expiresIn), not a stored timestamp, so it cannot be
        // used to measure remaining time.
        val now = Clock.System.now().epochSeconds
        val expFromJwt =
            jwtValidationService
                .parseJwt(tokens.accessToken)
                .getOrNull()
                ?.claims
                ?.exp
        val timeUntilExpiration =
            if (expFromJwt != null) {
                (expFromJwt - now).coerceAtLeast(0L)
            } else {
                tokenLifetime // Fallback: conservative, treats token as just-issued
            }

        // Step 5: Trigger proactive refresh if needed and enabled
        if (refreshConfig.enableProactiveRefresh) {
            when (currentState) {
                TokenState.ExpiringSoon, TokenState.Expired -> {
                    // Emit the actual current state (ExpiringSoon or Expired) before launching
                    // the background refresh. Without this, observers would see the previous
                    // state (typically Valid) throughout the refresh, then jump directly to
                    // Refreshed or RefreshFailed with no intermediate visibility.
                    updateTokenStateAndEmitEvent(currentState)

                    // Launch refresh in background (don't block monitoring loop)
                    monitoringScope.launch {
                        SdkLogger.i(LogCategory.TOKEN_MONITORING) {
                            "Auto-refresh triggered (state=$currentState, timeUntilExpiration=${timeUntilExpiration}s)"
                        }
                        // Signal that a refresh is actively in progress so observers can show
                        // a loading state (e.g. spinner) while the network call is in flight.
                        updateTokenStateAndEmitEvent(TokenState.Refreshing)

                        val refreshResult = refreshTokens()

                        if (refreshResult is SdkResult.Success) {
                            SdkLogger.i(LogCategory.TOKEN_MONITORING) { "Auto-refresh successful, new token obtained" }
                            updateTokenStateAndEmitEvent(TokenState.Refreshed(refreshResult.data))
                        } else {
                            val error = (refreshResult as SdkResult.Failure).error
                            SdkLogger.w(LogCategory.TOKEN_MONITORING) { "Auto-refresh failed: $error" }
                            updateTokenStateAndEmitEvent(TokenState.RefreshFailed(error))
                        }
                    }
                }

                else -> {
                    // No refresh needed, just update state
                    updateTokenStateAndEmitEvent(currentState)
                }
            }
        } else {
            // Proactive refresh disabled, just update state
            updateTokenStateAndEmitEvent(currentState)
        }

        // Step 6: Calculate next check interval using smart scheduling
        val nextInterval =
            calculateNextCheckInterval(
                currentState = currentState,
                timeUntilExpiration = timeUntilExpiration,
                threshold = adaptiveThreshold,
            )

        SdkLogger.d(LogCategory.TOKEN_MONITORING) {
            "Token state: $currentState | Next check: ${nextInterval}s (${nextInterval / 60}m) | Adaptive threshold: ${adaptiveThreshold}s"
        }

        return nextInterval
    }

    /**
     * Returns the effective threshold for ExpiringSoon detection.
     *
     * The threshold is an independent SDK configuration ([TokenRefreshConfig.refreshThresholdSeconds])
     * and is used as-is. The only fallback applies when the configured threshold equals or exceeds
     * the token lifetime — which can happen when the IDP issues short-lived tokens (e.g. 60s for
     * testing) against an SDK default of 300s. In that case the threshold is capped at half the
     * token lifetime so the token still progresses through Valid → ExpiringSoon → Expired.
     *
     * Examples:
     * - 3600s token, 300s config → 300s  (normal case, config used as-is)
     * - 60s token,   300s config → 30s   (fallback: 300 >= 60, so 60/2)
     * - 8s token,    300s config → 4s    (fallback: 300 >= 8,  so 8/2)
     *
     * @param tokenLifetime Original token lifetime in seconds (from [TokenResponseDto.expiresIn])
     * @param configuredThreshold Configured threshold from [TokenRefreshConfig.refreshThresholdSeconds]
     * @return Effective threshold in seconds
     */
    private fun calculateAdaptiveThreshold(
        tokenLifetime: Long,
        configuredThreshold: Long,
    ): Long {
        // Use the configured threshold as-is. The only fallback is when the threshold
        // equals or exceeds the token lifetime (e.g. SDK default 300s threshold with a
        // short-lived IDP test token of 60s). In that case cap at half the lifetime so
        // the token can still pass through Valid → ExpiringSoon → Expired rather than
        // starting in ExpiringSoon immediately.
        return if (configuredThreshold >= tokenLifetime) {
            (tokenLifetime / 2).coerceAtLeast(1L)
        } else {
            configuredThreshold
        }
    }

    /**
     * Schedules the next monitoring cycle at the exact moment of the next state transition.
     *
     * - **Valid**: fires at `timeUntilExpiration - threshold` — the instant the token enters
     *   ExpiringSoon. Capped at 900s so very long-lived tokens still get a periodic check.
     * - **ExpiringSoon**: fires at `timeUntilExpiration` — the instant the token expires.
     *   This handles any remaining time correctly, including app restarts mid-lifetime
     *   (e.g. 28s left on a 3600s token is detected and fires in exactly 28s).
     * - **Expired/NoTokens**: 300s — infrequent polling while waiting for re-authentication.
     * - **Refreshing**: 10s — frequent polling while a refresh is in progress.
     * - **Refreshed/RefreshFailed/Other**: 60s / 300s defaults.
     *
     * Both Valid and ExpiringSoon intervals are floored at 1s to prevent tight loops.
     *
     * @param currentState Current token state
     * @param timeUntilExpiration Seconds until the token expires (from JWT exp claim)
     * @param threshold Effective threshold in seconds (from [calculateAdaptiveThreshold])
     * @return Next check interval in seconds
     */
    private fun calculateNextCheckInterval(
        currentState: TokenState,
        timeUntilExpiration: Long,
        threshold: Long,
    ): Long =
        when (currentState) {
            TokenState.Valid -> {
                // Schedule exactly at the Valid → ExpiringSoon transition point.
                // Cap at 900s so very long-lived tokens (e.g. 5h) still get a periodic
                // check, and floor at 1s to avoid a tight loop.
                val timeUntilExpiringSoon = timeUntilExpiration - threshold
                timeUntilExpiringSoon.coerceIn(1L, 900L)
            }

            TokenState.ExpiringSoon -> {
                // Schedule exactly at the ExpiringSoon → Expired transition point.
                // Floor at 1s to avoid a tight loop on already-expired tokens.
                timeUntilExpiration.coerceAtLeast(1L)
            }

            TokenState.Expired, TokenState.NoTokens -> {
                // Check every 5min (infrequent, waiting for manual re-auth)
                300L
            }

            TokenState.Refreshing -> {
                // Check every 10s (monitor refresh completion)
                10L
            }

            is TokenState.Refreshed -> {
                // Token just refreshed, check in 60s to verify new state
                60L
            }

            is TokenState.RefreshFailed -> {
                // Use error-aware intervals to balance responsiveness against IDP hammering:
                // - NetworkError: transient connectivity issue, retry quickly (30s)
                // - HttpError (5xx): server-side problem, brief cooldown before retry (60s)
                // - All other (InvalidGrant, TokenExpired, etc.): terminal auth error,
                //   wait for manual user action (300s). In practice invalid_grant clears
                //   tokens and stops monitoring via SessionInvalidated, so this branch is
                //   mainly a safety net for other non-retryable auth errors.
                when (currentState.error) {
                    is SrgLoginError.NetworkError -> 30L
                    is SrgLoginError.HttpError -> 60L
                    else -> 300L
                }
            }
        }

    override fun dispose() {
        SdkLogger.i(LogCategory.TOKEN_MONITORING) { "Cleaning up TokenManager resources" }

        // Stop monitoring
        stopTokenMonitoring()

        // Cancel monitoring scope (cleanup all background jobs)
        monitoringScope.cancel()

        SdkLogger.i(LogCategory.TOKEN_MONITORING) { "TokenManager cleanup complete" }
    }

    /**
     * Computes SHA-256 hash of the refresh token for rotation tracking.
     *
     * Used for debugging token rotation issues. The hash is stored in metadata
     * instead of the actual token value for security and privacy.
     *
     * **Security Note**: This hash is for debugging/analytics purposes only,
     * not for authentication. It helps detect token rotation issues without
     * storing the actual refresh token value in metadata.
     *
     * @param refreshToken The refresh token to hash
     * @return SHA-256 hash of the token as lowercase hex string (64 characters)
     */
    private fun hashRefreshToken(refreshToken: String): String {
        val tokenBytes = refreshToken.encodeToByteArray()
        val hashBytes = cryptoService.sha256(tokenBytes)

        // Convert bytes to lowercase hex string
        return hashBytes.joinToString("") { byte ->
            byte.toUByte().toString(16).padStart(2, '0')
        }
    }
}
