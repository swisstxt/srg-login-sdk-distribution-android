package ch.srg.login.sdk.auth

import ch.srg.login.sdk.SrgLoginConfig
import ch.srg.login.sdk.data.api.SrgAuthApiService
import ch.srg.login.sdk.model.JwtClaims
import ch.srg.login.sdk.model.LogoutTokenClaims
import ch.srg.login.sdk.model.OpenIdConfig
import ch.srg.login.sdk.model.TokenResponseDto

/**
 * Unified service for validating all types of tokens in the SRG Login SDK.
 *
 * This service orchestrates token validation by:
 * - Using the existing JwtValidationService for ID tokens and access tokens
 * - Preserving the specialized LogoutTokenValidationService for logout tokens
 * - Providing a unified API for token validation across the SDK
 *
 * Token validation is critical for security and should be performed immediately
 * after successful OAuth/OIDC authentication to ensure token integrity.
 */
internal class TokenValidationService(
    private val jwtValidationService: JwtValidationService,
    private val logoutTokenValidationService: LogoutTokenValidationService,
    private val apiService: SrgAuthApiService,
) {
    /**
     * Validates a complete TokenResponseDto received after OAuth authentication.
     * This performs comprehensive validation of ID token and access token.
     *
     * @param tokenResponse The token response from the authorization server
     * @param config The SRG Login configuration
     * @param openIdConfig The OpenID Connect configuration
     * @param nonce Optional nonce value to validate in ID token
     * @return Result containing validated token claims or error
     */
    suspend fun validateTokenResponse(
        tokenResponse: TokenResponseDto,
        config: SrgLoginConfig,
        openIdConfig: OpenIdConfig,
        nonce: String? = null,
    ): Result<ValidatedTokens> {
        try {
            val validatedTokens = mutableMapOf<String, JwtClaims>()

            // Validate ID token if present (required for OIDC)
            tokenResponse.idToken?.let { idToken ->
                val idTokenResult =
                    validateIdToken(
                        idToken = idToken,
                        config = config,
                        openIdConfig = openIdConfig,
                        nonce = nonce,
                    )

                if (idTokenResult.isFailure) {
                    return Result.failure(
                        Exception("ID token validation failed: ${idTokenResult.exceptionOrNull()?.message}"),
                    )
                }

                validatedTokens["id_token"] = idTokenResult.getOrThrow()
            }

            // Validate access token
            val accessTokenResult =
                validateAccessToken(
                    accessToken = tokenResponse.accessToken,
                    config = config,
                    openIdConfig = openIdConfig,
                )

            if (accessTokenResult.isFailure) {
                return Result.failure(
                    Exception("Access token validation failed: ${accessTokenResult.exceptionOrNull()?.message}"),
                )
            }

            validatedTokens["access_token"] = accessTokenResult.getOrThrow()

            return Result.success(ValidatedTokens(validatedTokens))
        } catch (e: Exception) {
            return Result.failure(
                Exception("Token response validation failed: ${e.message}"),
            )
        }
    }

    /**
     * Validates an ID token according to OIDC specification.
     */
    suspend fun validateIdToken(
        idToken: String,
        config: SrgLoginConfig,
        openIdConfig: OpenIdConfig,
        nonce: String? = null,
    ): Result<JwtClaims> =
        jwtValidationService.validateIdToken(
            idToken = idToken,
            clientId = config.clientId,
            issuer = openIdConfig.issuer,
            jwksUri = openIdConfig.jwksUri,
            nonce = nonce,
            // 5 minutes max age for ID tokens
            maxAgeSeconds = 300,
        )

    /**
     * Validates an access token according to OAuth 2.0 specification.
     *
     * Note: Scope validation is NOT performed as OAuth 2.0 spec allows
     * authorization servers to return fewer scopes than requested.
     */
    suspend fun validateAccessToken(
        accessToken: String,
        config: SrgLoginConfig,
        openIdConfig: OpenIdConfig,
    ): Result<JwtClaims> =
        jwtValidationService.validateAccessToken(
            accessToken = accessToken,
            clientId = config.clientId,
            issuer = openIdConfig.issuer,
            jwksUri = openIdConfig.jwksUri,
            // 1 hour max age for access tokens
            maxAgeSeconds = 3600,
        )

    /**
     * Validates a logout token using the existing specialized service.
     * This preserves the existing LogoutTokenValidationService functionality.
     */
    suspend fun validateLogoutToken(
        logoutToken: String,
        config: SrgLoginConfig,
        openIdConfig: OpenIdConfig,
    ): Result<LogoutTokenClaims> {
        // TODO: Pass actual session when available
        return logoutTokenValidationService.validateLogoutToken(
            token = logoutToken,
            currentSession = null,
        )
    }

    /**
     * Clears any cached validation data (JWKS cache, etc.).
     * Useful for testing or when keys are rotated.
     */
    fun clearValidationCache() {
        jwtValidationService.clearJwksCache()
        logoutTokenValidationService.clearJwksCache()
    }
}

/**
 * Contains validated token claims for different token types.
 */
internal data class ValidatedTokens(
    private val tokens: Map<String, JwtClaims>,
) {
    /**
     * Gets the validated ID token claims.
     */
    val idTokenClaims: JwtClaims?
        get() = tokens["id_token"]

    /**
     * Gets the validated access token claims.
     */
    val accessTokenClaims: JwtClaims?
        get() = tokens["access_token"]

    /**
     * Gets the user subject ID from ID token or access token.
     */
    val userId: String?
        get() = idTokenClaims?.sub ?: accessTokenClaims?.sub

    /**
     * Gets the issuer from any validated token.
     */
    val issuer: String?
        get() = idTokenClaims?.iss ?: accessTokenClaims?.iss

    /**
     * Checks if both ID token and access token are present and validated.
     */
    val isComplete: Boolean
        get() = idTokenClaims != null && accessTokenClaims != null

    /**
     * Gets all custom claims from all tokens.
     */
    val allCustomClaims: Map<String, Any>
        get() {
            val combined = mutableMapOf<String, Any>()
            tokens.values.forEach { claims ->
                combined.putAll(claims.custom)
            }
            return combined
        }
}
